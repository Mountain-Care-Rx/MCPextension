(()=>{function nn(t){if(window.__crmConsoleMonitor)return;window.__crmConsoleMonitor=!0;let e=console.log,n=console.error,o=console.warn;console.log=function(...r){e.apply(console,r),!(typeof r[0]=="string"&&r[0].includes("[CRM Extension]"))&&ut(r,"log",t)},console.error=function(...r){n.apply(console,r),!(typeof r[0]=="string"&&r[0].includes("[CRM Extension]"))&&ut(r,"error",t)},console.warn=function(...r){o.apply(console,r),!(typeof r[0]=="string"&&r[0].includes("[CRM Extension]"))&&ut(r,"warn",t)}}function ut(t,e,n){let o=t.join(" ");["error","failed","unauthorized","critical"].some(s=>o.toLowerCase().includes(s))&&n(o)}var on=window.location.href,pe="";function _e(){if(!rn())return"";let t=document.querySelector('input[name="contact.phone"]');if(t&&t.value.trim()!=="")return t.value.trim();let e=document.querySelector(".phone-number .number");if(e&&e.textContent.trim()!=="")return e.textContent.trim();let n=['input[placeholder="Phone"]','input[placeholder="Phone Number"]',".patient-info .phone",".contact-info .phone","span.phone",'label[for*="phone"]',".phone-display",'div[data-field="phone"]','span[data-field="phone_number"]'];for(let o of n){let r=document.querySelector(o);if(r)if(r.tagName==="INPUT"){let s=r.value.trim();if(s)return s}else if(r.tagName==="LABEL"){let s=r.getAttribute("for");if(s){let a=document.getElementById(s);if(a&&a.value.trim())return a.value.trim()}let i=r.parentElement?.querySelector("input");if(i&&i.value.trim())return i.value.trim()}else{let s=r.textContent.trim();if(s)return s}}return""}function rn(){let t=window.location.href;return[/\/patient\/\d+/i,/\/contact\/\d+/i,/\/profile\/\d+/i,/[?&]patient_id=\d+/i,/[?&]contact_id=\d+/i].some(o=>o.test(t))?!0:['input[name="contact.phone"]','input[name="contact.first_name"]','input[name="contact.last_name"]','input[name="contact.date_of_birth"]',".patient-info",".contact-details",".patient-header",".patient-profile"].some(o=>document.querySelector(o)!==null)}function sn(t){try{let e=t?bo(t):"";if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("phone",e);else{let n=document.getElementById("phone-text");if(n){n.textContent=e;let o=document.getElementById("phone-display");o&&(t?o.setAttribute("data-value",t):o.removeAttribute("data-value"))}}}catch(e){console.error("[CRM Extension] Error updating phone display:",e)}}function H(){pe="",sn("");try{let t=document.getElementById("phone-display");t&&t.removeAttribute("data-value")}catch(t){console.error("[CRM Extension] Error clearing phone display:",t)}}function bo(t){if(!t)return"";let e=t.replace(/\D/g,"");if(e.length===0)return"";if(e.length===10)return`(${e.substring(0,3)}) ${e.substring(3,6)}-${e.substring(6)}`;if(e.length===11&&e.startsWith("1"))return`(${e.substring(1,4)}) ${e.substring(4,7)}-${e.substring(7)}`;if(e.length>4){let n="";for(let o=0;o<e.length;o+=3)if(o+4>=e.length&&e.length%3!==0){n+=" "+e.substring(o);break}else n+=" "+e.substring(o,o+3);return n.trim()}return e.replace(/(\d{3})/g,"$1 ").trim()}function Fe(){try{if(!rn())return pe&&H(),!1;let t=_e();return t?(t!==pe&&(pe=t,sn(t)),!0):(pe&&H(),!1)}catch(t){return console.error("[CRM Extension] Error detecting phone number:",t),!1}}function an(){H(),Fe();let t=setInterval(()=>{let e=window.location.href;e!==on&&(console.log("[CRM Extension] URL changed, resetting phone detection"),on=e,H()),Fe()},200);try{let e=new MutationObserver(o=>{Fe()}),n=document.body;e.observe(n,{childList:!0,subtree:!0,characterData:!0,attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] Phone number mutation observer active")}catch(e){console.error("[CRM Extension] Error setting up phone mutation observer:",e)}}function ln(t){let e=_e();if(!e){x("No phone number found");return}let n=ht(e);if(!n){x("Invalid phone number format");return}t.setAttribute("data-value",e),ue(n).then(o=>{x(o?"Copied: "+n:"Failed to copy phone number")})}function ht(t){if(!t)return"";let e=t.replace(/\D/g,"");return e.length<7?"":"+1"+e}async function ue(t){if(navigator.clipboard&&navigator.clipboard.writeText)try{return await navigator.clipboard.writeText(t),!0}catch(e){console.warn("Clipboard API failed, trying fallback method:",e)}try{let e=document.createElement("textarea");e.value=t,e.style.position="fixed",e.style.top="0",e.style.left="0",e.style.opacity="0",e.style.pointerEvents="none",document.body.appendChild(e),e.focus(),e.select();let n=document.execCommand("copy");return document.body.removeChild(e),n}catch(e){return console.error("All clipboard methods failed:",e),!1}}function x(t,e=2e3){let n=document.getElementById("crm-plus-toast-container");n||(n=document.createElement("div"),n.id="crm-plus-toast-container",n.style.position="fixed",n.style.bottom="20px",n.style.right="20px",n.style.zIndex="100000",document.body.appendChild(n));let o=document.createElement("div");o.textContent=t,o.style.background="#333",o.style.color="#fff",o.style.padding="10px",o.style.borderRadius="5px",o.style.marginTop="10px",o.style.boxShadow="0 2px 5px rgba(0,0,0,0.2)",o.style.transition="opacity 0.5s, transform 0.5s",o.style.opacity="0",o.style.transform="translateY(20px)",n.appendChild(o),o.offsetWidth,o.style.opacity="1",o.style.transform="translateY(0)",setTimeout(()=>{o.style.opacity="0",o.style.transform="translateY(20px)",setTimeout(()=>{o.parentNode&&o.parentNode.removeChild(o),n.childNodes.length===0&&document.body.removeChild(n)},500)},e)}var cn=window.location.href;function he(t){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("name",t);else{let e=document.getElementById("name-text");if(e){e.textContent=t;let n=document.getElementById("name-display");n&&n.setAttribute("data-value",t)}}}catch(e){console.error("[CRM Extension] Error updating name display:",e)}}function Oe(){try{let t=document.querySelector('input[name="contact.first_name"]'),e=document.querySelector('input[name="contact.last_name"]');if(t&&t.value&&e&&e.value){let r=`${t.value} ${e.value}`;return he(r),!0}let n=document.querySelectorAll(".patient-name, .contact-name, h1.name, .customer-name");for(let r of n)if(r&&r.textContent&&r.textContent.trim()!==""){let s=r.textContent.trim();return he(s),!0}let o=["span.name",".profile-name","h2.name",".contact-header .name",'div[data-field="name"]',".patient-info .name"];for(let r of o){let s=document.querySelector(r);if(s&&s.textContent&&s.textContent.trim()!==""){let i=s.textContent.trim();return he(i),!0}}return!1}catch(t){return console.error("[CRM Extension] Error detecting name:",t),!1}}function dn(){Oe();let t=setInterval(()=>{let e=window.location.href;e!==cn&&(console.log("[CRM Extension] URL changed, resetting name detection"),cn=e,he(""),Oe());let n=document.getElementById("name-text");n&&(n.textContent==="Loading..."||!n.textContent)&&Oe()},1e3);try{let e=new MutationObserver(o=>{o.some(s=>s.addedNodes.length>5||s.removedNodes.length>5)&&(console.log("[CRM Extension] Significant DOM changes detected, rechecking name"),he(""),Oe())}),n=document.querySelector("main")||document.body;e.observe(n,{childList:!0,subtree:!0})}catch(e){console.error("[CRM Extension] Error setting up navigation observer for name:",e)}}var pn=window.location.href;function je(t){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("dob",t);else{let e=document.getElementById("dob-text");if(e){e.textContent=t;let n=document.getElementById("dob-display");n&&n.setAttribute("data-value",t)}}}catch(e){console.error("[CRM Extension] Error updating DOB display:",e)}}function un(t){if(!t)return"";if(t.match(/^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2}(st|nd|rd|th)?\s+\d{4}$/))try{let e=t.match(/(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+(\d{1,2})(st|nd|rd|th)?\s+(\d{4})/);if(e){let n=e[1],o=e[2],r=e[4];return`${(["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"].indexOf(n)+1).toString().padStart(2,"0")}/${o.toString().padStart(2,"0")}/${r}`}}catch(e){console.error("[CRM Extension] Error parsing date:",e)}try{let e=new Date(t);if(!isNaN(e.getTime()))return`${(e.getMonth()+1).toString().padStart(2,"0")}/${e.getDate().toString().padStart(2,"0")}/${e.getFullYear()}`}catch(e){console.error("[CRM Extension] Error parsing date as Date object:",e)}return t}function $e(){try{let t=document.querySelector('input[name="contact.date_of_birth"]');if(t&&t.value){let n=un(t.value);return je(n),!0}let e=[".dob",".patient-dob",".contact-dob",'span[data-field="date_of_birth"]','div[data-field="dob"]',".patient-info .dob",".contact-info .dob"];for(let n of e){let o=document.querySelector(n);if(o&&o.textContent&&o.textContent.trim()!==""){let r=un(o.textContent.trim());return je(r),!0}}return!1}catch(t){return console.error("[CRM Extension] Error detecting DOB:",t),!1}}function hn(){$e();let t=setInterval(()=>{let e=window.location.href;e!==pn&&(console.log("[CRM Extension] URL changed, resetting DOB detection"),pn=e,je(""),$e());let n=document.getElementById("dob-text");n&&(n.textContent==="Loading..."||!n.textContent)&&$e()},1e3);try{let e=new MutationObserver(o=>{o.some(s=>s.addedNodes.length>5||s.removedNodes.length>5)&&(console.log("[CRM Extension] Significant DOM changes detected, rechecking DOB"),je(""),$e())}),n=document.querySelector("main")||document.body;e.observe(n,{childList:!0,subtree:!0})}catch(e){console.error("[CRM Extension] Error setting up navigation observer for DOB:",e)}}var mn=window.location.href,He="";function gn(t){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("srxid",t);else{let e=document.getElementById("srxid-text");if(e){e.textContent=t;let n=document.getElementById("srxid-display");n&&n.setAttribute("data-value",t)}}}catch(e){console.error("[CRM Extension] Error updating SRx ID display:",e)}}function me(){try{let t=document.querySelector('input[name="contact.srx_id"]');if(t&&t.value){let e=t.value.trim();if(e&&/^\d+$/.test(e))return e!==He&&(console.log("[CRM Extension] Found SRx ID from contact.srx_id input:",e),He=e,gn(e)),!0}return!!He}catch(t){return console.error("[CRM Extension] Error detecting SRx ID:",t),!1}}function fn(){me();let t=setInterval(()=>{let e=window.location.href;e!==mn&&(console.log("[CRM Extension] URL changed, resetting SRx ID detection"),mn=e,He="",gn(""),me()),me()},500);try{new MutationObserver(n=>{let o=!1;for(let r of n){if(r.target.tagName==="INPUT"&&r.target.name==="contact.srx_id"||r.target.querySelector&&r.target.querySelector('input[name="contact.srx_id"]')){o=!0;break}if(r.addedNodes.length>0){for(let s of r.addedNodes)if(s.nodeType===1&&s.querySelector&&(s.tagName==="INPUT"&&s.name==="contact.srx_id"||s.querySelector('input[name="contact.srx_id"]'))){o=!0;break}}}o&&me()}).observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] SRx ID mutation observer active")}catch(e){console.error("[CRM Extension] Error setting up observer for SRx ID:",e)}setTimeout(()=>{try{let e=document.querySelector('input[name="contact.srx_id"]');e&&(new MutationObserver(o=>{me()}).observe(e,{attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] Direct input observer attached to contact.srx_id"))}catch(e){console.error("[CRM Extension] Error setting up direct input observer:",e)}},1e3)}var We=["np-tirz-1.5ml-inj","refill-sema-inj","refill-tirz-inj","vial-sema-b12","vial-sema-b6","vial-sema-lipo","vial-sema-nad+","vial-tirz-cyano","vial-tirz-nad+","vial-tirz-pyridoxine","np-sema-0.125ml-inj","np-sema-0.25ml-inj","np-sema-0.5ml-inj","np-sema-0.75ml-inj","np-sema-1.0ml-inj","np-sema-1.25ml-inj","np-sema-1.5ml-inj","np-sema-2.0ml-inj","np-tirz-0.25ml-inj","np-tirz-0.5ml-inj","np-tirz-0.75ml-inj","np-tirz-1.0ml-inj","np-tirz-1.25ml-inj"],F=[];function yn(){console.log("[CRM Extension] Tag removal system initialized")}function Eo(){F=[];try{let t=document.querySelectorAll(".tag, .tag-label, .pill, .badge");for(let r of t){let s=r.textContent.trim().toLowerCase();We.some(i=>s.includes(i))&&F.push({element:r,text:s})}let e=document.querySelectorAll("[data-tag]");for(let r of e){let s=r.getAttribute("data-tag").toLowerCase();We.some(i=>s.includes(i))&&F.push({element:r,text:s})}let n=document.querySelectorAll(".tags-container, .tag-list, .tags");for(let r of n){let s=r.querySelectorAll("*");for(let i of s)if(i.nodeType===1){let a=i.textContent.trim().toLowerCase();We.some(l=>a.includes(l))&&(F.some(l=>l.element===i)||F.push({element:i,text:a}))}}let o=document.querySelectorAll("*[class]");for(let r of o){let s=r.className.toLowerCase();s&&typeof s=="string"&&We.some(i=>s.includes(i))&&(F.some(i=>i.element===r)||F.push({element:r,text:r.textContent.trim().toLowerCase()}))}return console.log(`[CRM Extension] Found ${F.length} removable tags`),F}catch(t){return console.error("[CRM Extension] Error detecting tags:",t),[]}}function So(t){try{let e=t.querySelector('.close, .remove, .delete, .tag-remove, [aria-label="Remove"], .x-button');if(e)return console.log("[CRM Extension] Found close button in tag, clicking it"),e.click(),!0;let n=t.parentElement;if(n){let s=n.querySelector('.close, .remove, .delete, .tag-remove, [aria-label="Remove"], .x-button');if(s)return console.log("[CRM Extension] Found close button as sibling, clicking it"),s.click(),!0}let o=[...Array.from(t.querySelectorAll("*")),...Array.from(n?n.children:[])];for(let s of o){let i=s.textContent.trim();if(i==="\xD7"||i==="x"||i==="\u2715"||i==="\u2716"||i==="X")return console.log("[CRM Extension] Found X button by text content, clicking it"),s.click(),!0;if(s.className&&(s.className.includes("close")||s.className.includes("delete")||s.className.includes("remove")||s.className.includes("x-button")))return console.log("[CRM Extension] Found X button by class name, clicking it"),s.click(),!0;if(s.classList&&(s.classList.contains("fa-times")||s.classList.contains("fa-close")||s.classList.contains("icon-close")||s.classList.contains("icon-remove")))return console.log("[CRM Extension] Found X button by icon class, clicking it"),s.click(),!0}if(t.tagName==="BUTTON"||t.tagName==="A"||t.getAttribute("role")==="button"||window.getComputedStyle(t).cursor==="pointer")return console.log("[CRM Extension] Tag appears to be clickable, clicking it"),t.click(),!0;let r=n;for(let s=0;s<3&&r;s++){let i=r.querySelectorAll("button, span, i, div");for(let a of i){let l=a.textContent.trim();if(l==="\xD7"||l==="x"||l==="\u2715"||l==="\u2716"||l==="X"||a.classList.contains("fa-times")||a.classList.contains("fa-close")||a.classList.contains("close")||a.classList.contains("remove"))return console.log("[CRM Extension] Found X button in parent container, clicking it"),a.click(),!0}r=r.parentElement}return console.log("[CRM Extension] No method found to remove tag:",t),!1}catch(e){return console.error("[CRM Extension] Error removing tag:",e),!1}}function mt(){return new Promise((t,e)=>{try{let r=function(s){if(s>=F.length){console.log(`[CRM Extension] Removed ${n}/${o} tags`),t({success:!0,message:`Removed ${n} of ${o} tags`,removed:n,total:o});return}let i=F[s];console.log(`[CRM Extension] Removing tag: ${i.text}`),So(i.element)&&n++,setTimeout(()=>{r(s+1)},300)};Eo();let n=0,o=F.length;if(o===0){console.log("[CRM Extension] No removable tags found"),t({success:!0,message:"No tags to remove",removed:0,total:0});return}console.log(`[CRM Extension] Attempting to remove ${o} tags`),r(0)}catch(n){console.error("[CRM Extension] Error in removeAllTags:",n),e(n)}})}var wo=["Workflow - New Patient - Semaglutide 0.125ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 0.25ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 0.5ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 0.75ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 1.0ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 1.25ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 1.5ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 2.0ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 0.25ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 0.5ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 0.75ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 1.0ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 1.25ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 1.5ml Onboarding - (Step 1)","Workflow - Refill - Semaglutide/B12 Injection Refill Order - (Step 1)","Workflow - Semaglutide/B12 Vial Order - (Step 1)","Workflow - Semaglutide/B6 Vial Order - (Step 1)","Workflow - Semaglutide/Lipo Vial Order - (Step 1)","Workflow - Semaglutide/NAD+ Vial Order - (Step 1)","Workflow - Syringe - Tirzepatide/Pyridoxine Injection Order - (Step 1)","Workflow - Tirzepatide/Cyano Vial Order - (Step 1)","Workflow - Tirzepatide/NAD+ Vial Order - (Step 1)","Workflow - Tirzepatide/Pyridoxine Vial Order - (Step 1)"],qe=[];function W(t){try{if(t&&typeof t.getBoundingClientRect=="function")return t.getBoundingClientRect()}catch{}return{top:0,bottom:0,left:0,right:0,width:0,height:0}}function bn(){console.log("[CRM Extension] Automation removal system initialized")}function vo(){qe=[];try{let t=En("Active");return t?(qe=(t.workflows.length?t.workflows:ko(t.label)).filter(n=>{if(!n)return!1;let o=(n.textContent||"").trim();return o.includes("Workflow")&&wo.some(r=>o.includes(r))}),console.log(`[CRM Extension] Found ${qe.length} automation(s) in Active section.`),qe):(console.log("[CRM Extension] Active section not found."),[])}catch(t){return console.error("[CRM Extension] Error detecting automations:",t),[]}}function ko(t){let e=W(t).bottom,n=null,o=En("Past");return o&&o.label&&(n=W(o.label).top),Array.from(document.querySelectorAll('div[id^="workflow_"], div[data-workflow-id]')).filter(s=>{let i=W(s);return!(i.top<e||n&&i.top>=n)})}function En(t){try{let n=Array.from(document.querySelectorAll("div.py-2")).find(s=>(s.textContent||"").trim()===t);if(n)return{label:n,workflows:t==="Active"?Mo(n):Lo(n)};let o=t==="Active"?'[data-automation="Active"], #automation-active':'[data-automation="Past"], #automation-past',r=document.querySelector(o);return r?{label:r,workflows:[]}:null}catch(e){return console.error(`[CRM Extension] Error finding section for "${t}":`,e),null}}function Mo(t){let e=W(t).bottom,o=Array.from(document.querySelectorAll("div.py-2")).find(i=>(i.textContent||"").trim()==="Past"),r=o?W(o).top:null;return Array.from(document.querySelectorAll('div[id^="workflow_"], div[data-workflow-id]')).filter(i=>{let a=W(i);return a.top>e&&(!r||a.top<r)})}function Lo(t){let e=W(t).bottom;return Array.from(document.querySelectorAll('div[id^="workflow_"], div[data-workflow-id]')).filter(o=>W(o).top>e)}function Ao(t){if(!t)return console.error("[CRM Extension] removeAutomation called with undefined element."),!1;try{let e=W(t),n=e.width>0&&e.height>0,o=e.top>=0&&e.left>=0&&e.bottom<=(window.innerHeight||document.documentElement.clientHeight);return!n||!o?(t.scrollIntoView({behavior:"smooth",block:"center"}),new Promise(r=>{setTimeout(()=>r(xn(t)),500)})):xn(t)}catch(e){return console.error("[CRM Extension] Error removing automation:",e),!1}}function xn(t){if(!t)return!1;try{let e=t.querySelectorAll("i.icon-close, i.icon.icon-close");if(e.length)return e[0].click(),!0}catch(e){console.error("[CRM Extension] Error in Strategy 1:",e)}try{let e=t.querySelectorAll("a");for(let n of e){let o=(n.textContent||"").trim();if(o==="\xD7"||o.toLowerCase()==="x")return n.click(),!0}}catch(e){console.error("[CRM Extension] Error in Strategy 2:",e)}try{let e=t.querySelectorAll('button, .btn, [role="button"]');for(let n of e)if((n.textContent||"").toLowerCase().includes("manage"))return n.click(),setTimeout(()=>{document.querySelectorAll(".dropdown-menu .dropdown-item, .menu-item").forEach(s=>{let i=(s.textContent||"").toLowerCase();(i.includes("remove")||i.includes("delete"))&&s.click()})},300),!0}catch(e){console.error("[CRM Extension] Error in Strategy 3:",e)}if(t.id&&t.id.startsWith("workflow_")){let e=t.id;try{let n=`#${e} i.icon-close, #${e} i.icon.icon-close`,o=document.querySelector(n);if(o)return o.click(),!0;n=`#${e} .remove, #${e} .close`;let r=document.querySelector(n);if(r)return r.click(),!0}catch(n){console.error("[CRM Extension] Error in Strategy 4:",n)}}try{let e=t.querySelectorAll("span");for(let n of e){let o=(n.textContent||"").trim();if(o==="\xD7"||o.toLowerCase()==="x")return n.click(),!0}}catch(e){console.error("[CRM Extension] Error in Strategy 5:",e)}try{let e=t.nextElementSibling,n=0;for(;e&&n<3;){if(e.classList&&(e.classList.contains("close")||e.classList.contains("remove"))||e.textContent&&(e.textContent.trim()==="\xD7"||e.textContent.trim().toLowerCase()==="x"))return e.click(),!0;let o=e.querySelector("i.icon-close, i.icon.icon-close");if(o)return o.click(),!0;e=e.nextElementSibling,n++}}catch(e){console.error("[CRM Extension] Error in Strategy 6:",e)}try{let e=W(t),n=e.right-10,o=e.top+e.height/2,r=document.elementsFromPoint(n,o);for(let i of r)if(i!==t)return i.click(),!0;let s=new MouseEvent("click",{view:window,bubbles:!0,cancelable:!0,clientX:n,clientY:o});return(r[0]||document.elementFromPoint(n,o))?.dispatchEvent(s),!0}catch(e){console.error("[CRM Extension] Error in Strategy 7:",e)}return console.error("[CRM Extension] No method found to remove automation:",t),!1}function Cn(){return new Promise(t=>{setTimeout(()=>{if(document.querySelectorAll('.modal, [role="dialog"], .dialog').length){let n=document.querySelectorAll('.modal .btn-primary, .modal .btn-danger, .modal .confirm-btn, [role="dialog"] .btn-primary, .modal button, [role="dialog"] button');for(let r of n){let s=(r.textContent||"").trim().toLowerCase();if(["delete","remove","yes","confirm","ok","continue"].includes(s)){r.click(),t(!0);return}}let o=document.querySelectorAll('.modal button, [role="dialog"] button, .dialog button');if(o.length){o[o.length-1].click(),t(!0);return}}t(!1)},500)})}function gt(){return new Promise((t,e)=>{try{let s=function(i){if(i>=r){t({success:!0,message:`Removed ${o} of ${r} automations`,removed:o,total:r});return}let a=n[i],l=Ao(a.element);l instanceof Promise?l.then(c=>{c&&o++,Cn().then(()=>setTimeout(()=>s(i+1),1e3))}):(l&&o++,Cn().then(()=>setTimeout(()=>s(i+1),1e3)))},n=vo();if(!n.length){console.log("[CRM Extension] No automations to remove."),t({success:!0,message:"No automations to remove",removed:0,total:0});return}let o=0,r=n.length;s(0)}catch(n){console.error("[CRM Extension] Error in removeAllAutomations:",n),e(n)}})}var N=[];var Ge="crmplus_history";function kn(){Mn(),Ro(),No(),window.addEventListener("storage",Io),console.log("[CRM Extension] History tracking initialized")}function Mn(){try{let t=localStorage.getItem(Ge);if(t){N=JSON.parse(t);let e=Date.now();N=N.filter(n=>e-n.timestamp<144e5),ft()}}catch(t){console.error("[CRM Extension] Error loading history:",t),N=[]}}function ft(){try{localStorage.setItem(Ge,JSON.stringify(N))}catch(t){console.error("[CRM Extension] Error saving history:",t)}}function Io(t){if(t.key===Ge)try{t.newValue?(N=JSON.parse(t.newValue),console.log("[CRM Extension] History updated from another tab")):(N=[],console.log("[CRM Extension] History cleared from another tab"))}catch(e){console.error("[CRM Extension] Error processing cross-tab history update:",e)}}function Ro(){let t=window.location.href;setInterval(()=>{let o=window.location.href;o!==t&&(t=o,ge(o))},500),ge(window.location.href);let e=history.pushState;history.pushState=function(){e.apply(this,arguments),ge(window.location.href)};let n=history.replaceState;history.replaceState=function(){n.apply(this,arguments),ge(window.location.href)},window.addEventListener("popstate",()=>{ge(window.location.href)})}function ge(t){if(!t)return;let e=t.match(/\/detail\/([^/]+)/);if(e&&e[1]){let n=e[1];setTimeout(()=>{let o=Sn(),r=wn();o&&o!=="Unknown Patient"?vn(n,o,r,t):(console.log("[CRM Extension] Patient name not found yet, retrying in 3 seconds..."),setTimeout(()=>{let s=Sn(),i=wn();s&&s!=="Unknown Patient"?vn(n,s,i,t):console.log("[CRM Extension] Could not retrieve patient info after retry, not adding to history")},3e3))},5e3)}}function Sn(){let t=document.getElementById("name-text");if(t&&t.textContent&&t.textContent.trim()!=="")return t.textContent.trim();let e=document.querySelector('input[name="contact.first_name"]'),n=document.querySelector('input[name="contact.last_name"]');if(e&&e.value&&n&&n.value)return`${e.value} ${n.value}`.trim();let o=[".patient-name",".contact-name","h1.name",".customer-name","span.name",".profile-name","h2.name",".contact-header .name",'div[data-field="name"]',".patient-info .name"];for(let r of o){let s=document.querySelector(r);if(s&&s.textContent&&s.textContent.trim()!=="")return s.textContent.trim()}return"Unknown Patient"}function wn(){let t=document.getElementById("phone-text");if(t&&t.textContent&&t.textContent.trim()!=="")return t.textContent.trim();let e=document.querySelector('input[name="contact.phone"]');if(e&&e.value.trim()!=="")return e.value.trim();let n=[".phone-number .number",'input[placeholder="Phone"]','input[placeholder="Phone Number"]',".patient-info .phone",".contact-info .phone","span.phone",'div[data-field="phone"]','span[data-field="phone_number"]'];for(let o of n){let r=document.querySelector(o);if(r)if(r.tagName==="INPUT"){let s=r.value.trim();if(s)return s}else{let s=r.textContent.trim();if(s)return s}}return""}function vn(t,e,n,o){let s=Date.now(),i=N.findIndex(a=>a.patientId===t);if(i!==-1){let a=N[i];a.timestamp=s,a.patientName=e,a.phoneNumber=n,N.splice(i,1),N.unshift(a)}else N.unshift({patientId:t,patientName:e,phoneNumber:n,url:o,timestamp:s}),N.length>20&&N.pop();ft()}function No(){setInterval(()=>{let t=Date.now(),e=0;N=N.filter(n=>{let o=t-n.timestamp<144e5;return o||e++,o}),e>0&&(console.log(`[CRM Extension] Removed ${e} expired history entries`),ft())},5*60*1e3)}function Ln(){Mn();let t=Date.now();return N=N.filter(e=>t-e.timestamp<144e5),[...N]}function An(){N=[],localStorage.removeItem(Ge),console.log("[CRM Extension] History cleared")}function In(t){return new Date(t).toLocaleString("en-US",{hour:"numeric",minute:"2-digit",hour12:!0})}var Rn="crmplus_chat_audit_log";function d(t,e,n={}){try{let o={timestamp:new Date().toISOString(),category:t,action:e,details:n,username:localStorage.getItem("crmplus_chat_username")||"Unknown",browser:Uo(),ip:"127.0.0.1"},r=fe();return r.unshift(o),r.length>1e3&&(r.length=1e3),localStorage.setItem(Rn,JSON.stringify(r)),!0}catch(o){return console.error("[CRM Extension] Error logging audit event:",o),!1}}function fe(){try{let t=localStorage.getItem(Rn);return t?JSON.parse(t):[]}catch(t){return console.error("[CRM Extension] Error getting audit log:",t),[]}}function Uo(){let t=navigator.userAgent,e="Unknown Browser";return t.includes("Firefox")?e="Firefox":t.includes("Edg")?e="Edge":t.includes("Chrome")?e="Chrome":t.includes("Safari")&&(e="Safari"),e}function yt(t={},e=100){try{let n=fe();if(t.category&&(n=n.filter(o=>o.category===t.category)),t.username&&(n=n.filter(o=>o.username===t.username)),t.startDate){let o=new Date(t.startDate).getTime();n=n.filter(r=>new Date(r.timestamp).getTime()>=o)}if(t.endDate){let o=new Date(t.endDate).getTime();n=n.filter(r=>new Date(r.timestamp).getTime()<=o)}return t.action&&(n=n.filter(o=>o.action.includes(t.action))),n.slice(0,e)}catch(n){return console.error("[CRM Extension] Error searching audit log:",n),[]}}function xt(){try{let t=fe(),e=`timestamp,category,action,username,browser,details
`;t.forEach(r=>{let s=JSON.stringify(r.details||{}).replace(/"/g,'""');e+=`"${r.timestamp}","${r.category}","${r.action.replace(/"/g,'""')}","${r.username}","${r.browser}","${s}"
`});let n=new Blob([e],{type:"text/csv;charset=utf-8;"}),o=document.createElement("a");return o.href=URL.createObjectURL(n),o.download=`chat_audit_log_${new Date().toISOString().slice(0,10)}.csv`,document.body.appendChild(o),o.click(),document.body.removeChild(o),d("system","Audit log exported"),console.log("[CRM Extension] Exported audit log to file"),!0}catch(t){return console.error("[CRM Extension] Error exporting audit log:",t),!1}}function Ct(){try{let t=fe(),e={};t.forEach(r=>{e[r.category]=(e[r.category]||0)+1});let n=null,o=null;return t.length>0&&(n=t[t.length-1].timestamp,o=t[0].timestamp),{totalEntries:t.length,categories:e,oldestEntry:n,newestEntry:o,retentionDays:7776e6/(24*60*60*1e3)}}catch(t){return console.error("[CRM Extension] Error getting audit log statistics:",t),{totalEntries:0,categories:{},oldestEntry:null,newestEntry:null,retentionDays:7776e6/(24*60*60*1e3)}}}var Ye="crmplus_chat_",Ke=`${Ye}messages`,bt=`${Ye}channels`,Un=`${Ye}users`,Et=`${Ye}settings`,Nn=100,To=24*60*60*1e3;function Tn(){try{return Je(),setInterval(Je,60*60*1e3),d("storage","Storage system initialized"),console.log("[CRM Extension] Storage system initialized"),!0}catch(t){return console.error("[CRM Extension] Error initializing storage:",t),!1}}function Dn(t){try{if(!t||!t.id)return!1;let e=t.channel||"general",n={...t,stored:Date.now()},o=Ze(),r=o[e]||[],s=r.findIndex(i=>i.id===t.id);return s>=0?r[s]=n:r.unshift(n),r.length>Nn&&(r.length=Nn),o[e]=r,localStorage.setItem(Ke,JSON.stringify(o)),d("storage",`Message saved from ${t.sender}`,{messageId:t.id,channel:e}),!0}catch(e){return console.error("[CRM Extension] Error saving message:",e),d("storage","Error saving message",{error:e.message}),!1}}function Ze(){try{let t=localStorage.getItem(Ke);return t?JSON.parse(t):{}}catch(t){return console.error("[CRM Extension] Error getting messages map:",t),d("storage","Error getting messages map",{error:t.message}),{}}}function ye(t="general",e=50){try{return(Ze()[t]||[]).slice(0,e)}catch(n){return console.error("[CRM Extension] Error getting channel messages:",n),d("storage","Error getting channel messages",{error:n.message}),[]}}function Je(){try{let t=Ze(),e=Date.now(),n=0;return Object.keys(t).forEach(o=>{let s=t[o].filter(i=>{let a=i.stored||e,l=e-a>=To;return l&&n++,!l});t[o]=s}),localStorage.setItem(Ke,JSON.stringify(t)),n>0&&(d("storage",`Removed ${n} expired messages`),console.log(`[CRM Extension] Removed ${n} expired messages`)),n}catch(t){return console.error("[CRM Extension] Error cleaning up messages:",t),d("storage","Error cleaning up expired messages",{error:t.message}),0}}function Qe(t){try{if(!t||!t.id)return!1;let e=xe(),n=e.findIndex(o=>o.id===t.id);return n>=0?e[n]=t:e.push(t),localStorage.setItem(bt,JSON.stringify(e)),d("storage",`Channel saved: ${t.name}`,{channelId:t.id}),!0}catch(e){return console.error("[CRM Extension] Error saving channel:",e),d("storage","Error saving channel",{error:e.message}),!1}}function xe(){try{let t=localStorage.getItem(bt);return t?JSON.parse(t):[]}catch(t){return console.error("[CRM Extension] Error getting channels:",t),d("storage","Error getting channels",{error:t.message}),[]}}function Xe(){try{let t=localStorage.getItem(Un);return t?JSON.parse(t):[]}catch(t){return console.error("[CRM Extension] Error getting users:",t),d("storage","Error getting users",{error:t.message}),[]}}function Ce(t,e){try{if(!t)return!1;let n=Bn();return n[t]=e,localStorage.setItem(Et,JSON.stringify(n)),d("storage",`Setting saved: ${t}`),!0}catch(n){return console.error("[CRM Extension] Error saving setting:",n),d("storage","Error saving setting",{error:n.message}),!1}}function V(t,e=null){try{let n=Bn();return t in n?n[t]:e}catch(n){return console.error("[CRM Extension] Error getting setting:",n),d("storage","Error getting setting",{error:n.message}),e}}function Bn(){try{let t=localStorage.getItem(Et);return t?JSON.parse(t):{}}catch(t){return console.error("[CRM Extension] Error getting settings:",t),d("storage","Error getting settings",{error:t.message}),{}}}function St(){try{let t=localStorage.getItem(Ke)?.length||0,e=localStorage.getItem(bt)?.length||0,n=localStorage.getItem(Un)?.length||0,o=localStorage.getItem(Et)?.length||0,r=t+e+n+o,s=i=>Math.round(i*2/1024*10)/10;return{totalKB:s(r),messagesKB:s(t),channelsKB:s(e),usersKB:s(n),settingsKB:s(o),messageCount:Object.values(Ze()).reduce((i,a)=>i+a.length,0),channelCount:xe().length,userCount:Xe().length}}catch(t){return console.error("[CRM Extension] Error calculating storage usage:",t),{totalKB:0,messagesKB:0,channelsKB:0,usersKB:0,settingsKB:0,messageCount:0,channelCount:0,userCount:0}}}var ce=null,wt=null,le=typeof window<"u"&&window.crypto&&window.crypto.subtle;async function vt(){try{return le?(ce=await window.crypto.subtle.generateKey({name:"AES-GCM",length:256},!0,["encrypt","decrypt"]),wt=window.crypto.getRandomValues(new Uint8Array(12)),console.log("[CRM Extension] Generated secure encryption keys using Web Crypto API")):(ce=Vn(32),wt=Vn(16),console.warn("[CRM Extension] Using fallback encryption methods - less secure"),d("security","Using fallback encryption (not recommended for PHI)")),d("security","Generated new encryption keys"),!0}catch(t){return console.error("[CRM Extension] Error generating encryption keys:",t),d("security","Failed to generate encryption keys",{error:t.message}),!1}}function Vn(t){let e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",n="";if(window.crypto&&window.crypto.getRandomValues){let o=new Uint32Array(t);window.crypto.getRandomValues(o);for(let r=0;r<t;r++)n+=e.charAt(o[r]%e.length)}else for(let o=0;o<t;o++)n+=e.charAt(Math.floor(Math.random()*e.length));return n}function Pn(t){let e=new ArrayBuffer(t.length),n=new Uint8Array(e);for(let o=0;o<t.length;o++)n[o]=t.charCodeAt(o);return e}function Do(t){return String.fromCharCode.apply(null,new Uint8Array(t))}async function Bo(t){try{let e=Pn(atob(t.encryptedData)),n=Pn(atob(t.iv)),o=new Uint8Array(n),r=await window.crypto.subtle.decrypt({name:"AES-GCM",iv:o,tagLength:128},ce,e),s=Do(r);return JSON.parse(s)}catch(e){throw console.error("[CRM Extension] Error decrypting with Web Crypto API:",e),e}}function Vo(t){try{let e=Po(t.encryptedData,ce);return JSON.parse(e)}catch(e){throw console.error("[CRM Extension] Error in legacy decryption:",e),e}}function Po(t,e){let n="";for(let o=0;o<t.length;o++){let r=t.charCodeAt(o)^e.charCodeAt(o%e.length);n+=String.fromCharCode(r)}return btoa(n)}async function kt(t){try{if(!t||!t.encrypted)return t;if(!ce||!wt)throw new Error("Encryption keys not available");return t.encryptionMethod==="AES-GCM"&&le?await Bo(t):Vo(t)}catch(e){return console.error("[CRM Extension] Error decrypting message:",e),d("security","Decryption error",{error:e.message}),{id:t.id||zo(),sender:t.sender||"Unknown",text:"[Encrypted message - unable to decrypt]",timestamp:t.timestamp||new Date().toISOString(),type:t.type||"chat",channel:t.channel||"general"}}}function zo(){return Date.now().toString(36)+Math.random().toString(36).substr(2,5)}function zn(){return!!ce}function Mt(){return{active:zn(),method:le?"AES-GCM (256-bit)":"XOR (Legacy)",secure:le,hipaaCompliant:le,browserSupport:le?"Full":"Limited"}}var tt="crmplus_chat_auth_token",de="crmplus_chat_user_info",et=15*60*1e3,C=null,q=null,Ee=Date.now(),J=null,Lt=[],be={username:"CBarnett",password:"Admin123",role:"admin",displayName:"Admin"};function Fn(){try{return Fo(),nt(),Oo(),_o(),d("auth","Authentication service initialized"),!0}catch(t){return console.error("[CRM Extension] Error initializing auth service:",t),!1}}function Fo(){try{let t=localStorage.getItem(tt);t&&(q=t);let e=localStorage.getItem(de);e&&(C=JSON.parse(e)),q&&C&&(Ee=Date.now(),Se(),console.log("[CRM Extension] Loaded saved authentication data"),d("auth","Restored authentication session",{username:C.username}))}catch(t){console.error("[CRM Extension] Error loading saved auth data:",t),localStorage.removeItem(tt),localStorage.removeItem(de)}}function _o(){V("admin_account_created",!1)||(console.log("[CRM Extension] Setting up initial admin account"),Ce("admin_account_created",!0),d("auth","Initial admin account setup completed"))}function Oo(){["mousedown","keydown","touchstart","click"].forEach(e=>{document.addEventListener(e,()=>{_n()})})}function _n(){Ee=Date.now(),J&&clearTimeout(J),M()&&nt()}function nt(){J&&clearTimeout(J),M()&&(J=setTimeout(()=>{let t=Date.now()-Ee;if(t>=et)d("auth","Session timed out due to inactivity",{username:C?.username,inactiveTime:Math.round(t/1e3)+" seconds"}),we("Session timed out due to inactivity");else{let e=et-t;J=setTimeout(nt,e)}},et))}async function At(t,e){try{if(!t||!e)throw new Error("Username and password are required");d("auth","Login attempt",{username:t});let o=(localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000").replace("ws://","http://").replace("wss://","https://"),r=null;if(t===be.username&&e===be.password)r={success:!0,token:"admin_"+Date.now().toString(36)+Math.random().toString(36).substr(2),user:{id:"admin_"+Math.random().toString(36).substr(2),username:be.username,role:be.role,displayName:be.displayName,isAdmin:!0}};else try{let s=await fetch(`${o}/auth/login`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username:t,password:e})});if(!s.ok){let i=await s.json();throw new Error(i.message||"Login failed")}r=await s.json()}catch(s){if(console.error("[CRM Extension] Server auth error:",s),V("allow_local_auth",!1)){let a=V("local_users",[]).find(l=>l.username===t);if(a&&a.password===e)r={success:!0,token:"local_"+Date.now().toString(36)+Math.random().toString(36).substr(2),user:{id:a.id||"user_"+Math.random().toString(36).substr(2),username:a.username,role:a.role||"user",displayName:a.displayName||a.username,isLocal:!0}};else throw new Error("Invalid username or password")}else throw new Error("Server authentication failed")}if(!r||!r.success)throw new Error("Authentication failed");return q=r.token,C=r.user,localStorage.setItem(tt,q),localStorage.setItem(de,JSON.stringify(C)),_n(),nt(),d("auth","Login successful",{username:C.username,role:C.role}),Se(),{success:!0,user:C}}catch(n){return d("auth","Login failed",{username:t,error:n.message}),console.error("[CRM Extension] Login error:",n),{success:!1,error:n.message}}}function we(t="User logout"){try{if(!M())return!1;d("auth","Logout",{username:C?.username,reason:t}),q=null;let e=C;return C=null,localStorage.removeItem(tt),localStorage.removeItem(de),J&&(clearTimeout(J),J=null),Se(e),!0}catch(e){return console.error("[CRM Extension] Logout error:",e),!1}}async function It(t){try{if(!M()||C.role!=="admin")return{success:!1,error:"Administrator privileges required to create users"};if(!t.username||!t.password)throw new Error("Username and password are required");d("auth","User registration attempt",{username:t.username,createdBy:C.username});let n=(localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000").replace("ws://","http://").replace("wss://","https://");try{let o=await fetch(`${n}/auth/register`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${q}`},body:JSON.stringify(t)});if(!o.ok){let s=await o.json();throw new Error(s.message||"Registration failed")}let r=await o.json();return d("auth","User registration successful",{username:t.username,createdBy:C.username,role:t.role||"user"}),{success:!0,user:r.user}}catch(o){if(console.error("[CRM Extension] Server registration error:",o),V("allow_local_auth",!1)){let r={id:"user_"+Date.now().toString(36),username:t.username,password:t.password,role:t.role||"user",displayName:t.displayName||t.username,createdAt:new Date().toISOString(),createdBy:C.id},s=V("local_users",[]);if(s.some(i=>i.username===r.username))throw new Error("Username already exists");return s.push(r),Ce("local_users",s),d("auth","Local user registration successful",{username:t.username,createdBy:C.username,role:t.role||"user",isLocal:!0}),{success:!0,user:{id:r.id,username:r.username,role:r.role,displayName:r.displayName,isLocal:!0}}}else throw new Error("Server registration failed: "+o.message)}}catch(e){return d("auth","User registration failed",{username:t.username,error:e.message}),console.error("[CRM Extension] Registration error:",e),{success:!1,error:e.message}}}function M(){return!!q&&!!C}function I(){return C}function ot(){return q}function re(){if(!M())return{authenticated:!1,timeRemaining:0,lastActivity:null};let t=Date.now()-Ee,e=Math.max(0,et-t);return{authenticated:!0,timeRemaining:e,lastActivity:Ee,formattedTimeRemaining:$o(e)}}function $o(t){let e=Math.floor(t/6e4),n=Math.floor(t%6e4/1e3);return e>0?`${e}m ${n}s`:`${n}s`}function Rt(t){typeof t=="function"&&!Lt.includes(t)&&Lt.push(t)}function Se(t=null){let e={authenticated:M(),user:C,prevUser:t,token:q};Lt.forEach(n=>{try{n(e)}catch(o){console.error("[CRM Extension] Error in auth listener:",o)}})}async function Nt(t){try{if(!M())throw new Error("User must be authenticated to update profile");let n=(localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000").replace("ws://","http://").replace("wss://","https://");try{let o=await fetch(`${n}/auth/profile`,{method:"PUT",headers:{"Content-Type":"application/json",Authorization:`Bearer ${q}`},body:JSON.stringify(t)});if(!o.ok){let s=await o.json();throw new Error(s.message||"Profile update failed")}let r=await o.json();return C={...C,...r.user},localStorage.setItem(de,JSON.stringify(C)),d("auth","Profile updated",{username:C.username,updatedFields:Object.keys(t).join(", ")}),Se(),{success:!0,user:C}}catch(o){if(console.error("[CRM Extension] Server profile update error:",o),V("allow_local_auth",!1)&&C.isLocal){let r=V("local_users",[]),s=r.findIndex(i=>i.id===C.id);if(s>=0){let i={...r[s],displayName:t.displayName||r[s].displayName};return r[s]=i,Ce("local_users",r),C={...C,displayName:i.displayName},localStorage.setItem(de,JSON.stringify(C)),d("auth","Local profile updated",{username:C.username,updatedFields:Object.keys(t).join(", "),isLocal:!0}),Se(),{success:!0,user:C}}}throw new Error("Server profile update failed: "+o.message)}}catch(e){return d("auth","Profile update failed",{error:e.message}),console.error("[CRM Extension] Profile update error:",e),{success:!1,error:e.message}}}function Y(t){return!M()||!C.role?!1:C.role==="admin"?!0:C.role==="moderator"?["user.view","channel.create","channel.view","channel.update","channel.invite","message.delete","message.create","message.view"].includes(t):["user.view","channel.view","message.create","message.view","message.update.own","message.delete.own"].includes(t)}var U=null,ke="disconnected",Ut=localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000",ve=0,Ho=5,Wo=5e3,K=null,qo=3e4,rt=[],Go=[],Jo=[],st=[],it="general";function On(){return Yo(),d("system","Message service initialized"),console.log("[CRM Extension] Message service initialized"),!0}function Yo(){Ut=localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000",it=localStorage.getItem("crmplus_chat_active_channel")||"general"}function ne(){return new Promise(t=>{if(U&&(U.readyState===WebSocket.OPEN||U.readyState===WebSocket.CONNECTING)){console.log("[CRM Extension] WebSocket is already connected or connecting"),se("connected"),t(!0);return}try{console.log(`[CRM Extension] Connecting to WebSocket server: ${Ut}`),U=new WebSocket(Ut),se("connecting"),U.onopen=()=>{console.log("[CRM Extension] WebSocket connection established"),se("connected"),ve=0,Ko(),Zo(),d("system","Connected to chat server"),t(!0)},U.onmessage=e=>{Xo(e.data)},U.onclose=e=>{console.log(`[CRM Extension] WebSocket connection closed: ${e.code} - ${e.reason}`),se("disconnected"),K&&(clearInterval(K),K=null),d("system",`Disconnected from chat server: ${e.code}`),e.code!==1e3&&e.code!==1001&&Qo(),t(!1)},U.onerror=e=>{console.error("[CRM Extension] WebSocket error:",e),se("error"),d("system","WebSocket error occurred",{error:"Connection error"}),t(!1)}}catch(e){console.error("[CRM Extension] Error connecting to WebSocket server:",e),se("error"),d("system","Failed to connect to chat server",{error:e.message}),t(!1)}})}function se(t){ke!==t&&(ke=t,or())}function Ko(){if(!U||U.readyState!==WebSocket.OPEN)return;let t=ot(),e=I();if(!t||!e)return;let n={type:"auth",token:t,username:e.username,timestamp:new Date().toISOString()};U.send(JSON.stringify(n)),d("system","Sent authentication request")}function Zo(){K&&clearInterval(K),K=setInterval(()=>{if(U&&U.readyState===WebSocket.OPEN){let t={type:"heartbeat",timestamp:new Date().toISOString()};U.send(JSON.stringify(t))}},qo)}function Qo(){if(ve>=Ho){console.log("[CRM Extension] Maximum reconnection attempts reached");return}ve++;let t=Wo*Math.pow(1.5,ve-1);console.log(`[CRM Extension] Attempting to reconnect in ${t}ms (attempt ${ve})`),setTimeout(()=>{ne()},t)}function Xo(t){try{let e=JSON.parse(t);switch(e.type){case"chat":er(e);break;case"user_list":tr(e.users);break;case"channel_list":nr(e.channels);break;case"auth_response":e.success?(console.log("[CRM Extension] Authentication successful"),d("system","Authentication successful"),jn(),Hn(it)):(console.error("[CRM Extension] Authentication failed:",e.reason),d("system","Authentication failed",{reason:e.reason}));break;case"error":console.error("[CRM Extension] Server error:",e.message),d("error",`Server error: ${e.message}`);break;case"heartbeat_response":break;default:console.log("[CRM Extension] Unknown message type:",e.type)}}catch(e){console.error("[CRM Extension] Error parsing WebSocket message:",e)}}function er(t){let e=t;if(t.encrypted)try{e=kt(t)}catch(n){console.error("[CRM Extension] Failed to decrypt message:",n),e={...t,text:"[Encrypted message - unable to decrypt]"}}Dn(e),d("message",`Received message from ${t.sender}`,{messageId:t.id,channel:t.channel||"general"}),rr([e])}function tr(t){sr(t)}function nr(t){ir(t)}function $n(t){if(!U||U.readyState!==WebSocket.OPEN)return console.error("[CRM Extension] WebSocket is not connected"),!1;try{return U.send(JSON.stringify(t)),!0}catch(e){return console.error("[CRM Extension] Error sending message:",e),!1}}function at(){if(U)try{let t={type:"logout",timestamp:new Date().toISOString()};U.send(JSON.stringify(t)),U.close(1e3,"User disconnected"),se("disconnected"),K&&(clearInterval(K),K=null),d("system","Disconnected from chat server"),console.log("[CRM Extension] Disconnected from WebSocket server")}catch(t){console.error("[CRM Extension] Error disconnecting from WebSocket server:",t)}}function Tt(){return ke}function Dt(t){return typeof t!="function"?()=>{}:(st.push(t),t(ke),()=>{st=st.filter(e=>e!==t)})}function or(){st.forEach(t=>{try{t(ke)}catch(e){console.error("[CRM Extension] Error in connection status listener:",e)}})}function Me(t){return typeof t!="function"?()=>{}:(rt.push(t),()=>{rt=rt.filter(e=>e!==t)})}function rr(t){rt.forEach(e=>{try{e(t)}catch(n){console.error("[CRM Extension] Error in message listener:",n)}})}function sr(t){Go.forEach(e=>{try{e(t)}catch(n){console.error("[CRM Extension] Error in user list listener:",n)}})}function ir(t){Jo.forEach(e=>{try{e(t)}catch(n){console.error("[CRM Extension] Error in channel list listener:",n)}})}function jn(){if(!M())return;let t={type:"channel_list_request",timestamp:new Date().toISOString()};$n(t)}function Hn(t){if(!t||!M())return;it=t,localStorage.setItem("crmplus_chat_active_channel",t);let e={type:"channel_join",channel:t,timestamp:new Date().toISOString()};$n(e),d("system",`Switched to channel: ${t}`)}function Bt(){return it}function Wn(){try{return lr(),d("system","User service initialized"),console.log("[CRM Extension] User service initialized"),!0}catch(t){return console.error("[CRM Extension] Error initializing user service:",t),!1}}function lr(){let t=Xe();t.length>0&&t.forEach(e=>{e.online=!1,e.lastSeen=e.lastSeen||new Date().toISOString()})}var qn=[];var Ts=localStorage.getItem("crmplus_chat_active_channel")||"general";function Gn(){try{return dr(),d("system","Channel service initialized"),console.log("[CRM Extension] Channel service initialized"),!0}catch(t){return console.error("[CRM Extension] Error initializing channel service:",t),!1}}function dr(){let t=xe();if(t.length===0){let e={id:"general",name:"General",description:"General discussion channel",type:"public",createdAt:new Date().toISOString(),createdBy:"system"},n={id:"announcements",name:"Announcements",description:"Important announcements",type:"public",createdAt:new Date().toISOString(),createdBy:"system",readonly:!0};Qe(e),Qe(n),qn=[e,n]}else qn=t}var Vt=class{constructor(){this.listeners=[],this.authState={authenticated:M(),user:I(),sessionStatus:re()},this.setupAuthListener(),this.setupSessionRefresh()}notifyListeners(){let e=this.getAuthState();this.listeners.forEach(n=>{try{n(e)}catch(o){console.error("[CRM Extension] Error in auth context listener:",o)}})}setupAuthListener(){Rt(e=>{this.authState={...this.authState,authenticated:e.authenticated,user:e.user},this.notifyListeners()})}setupSessionRefresh(){setInterval(()=>{this.authState.sessionStatus=re(),this.authState.authenticated&&this.notifyListeners()},6e4)}async login(e,n){let o=await At(e,n);return o.success&&(this.authState={authenticated:!0,user:o.user,sessionStatus:re()},this.notifyListeners()),o}logout(e){let n=we(e);return n&&(this.authState={authenticated:!1,user:null,sessionStatus:re()},this.notifyListeners()),n}async register(e){return await It(e)}async updateProfile(e){let n=await Nt(e);return n.success&&(this.authState={...this.authState,user:n.user},this.notifyListeners()),n}hasPermission(e){return Y(e)}getAuthState(){return this.authState.sessionStatus=re(),{...this.authState}}subscribe(e){return typeof e!="function"?(console.error("[CRM Extension] Auth context listener must be a function"),()=>{}):(this.listeners.push(e),e(this.getAuthState()),()=>{this.listeners=this.listeners.filter(n=>n!==e)})}},pr=new Vt,Pt=pr;var ur={server:{url:V("server_url","ws://localhost:3000"),connectionTimeout:1e4,reconnect:{maxAttempts:5,delay:5e3,useExponentialBackoff:!0},heartbeatInterval:3e4},security:{sessionTimeout:15*60*1e3,hasCryptoAPI:typeof window<"u"&&window.crypto&&window.crypto.subtle,minPasswordLength:8,enableTwoFactorAuth:!1},storage:{maxMessagesPerChannel:100,messageExpiration:24*60*60*1e3,keyPrefix:"crmplus_chat_"},ui:{theme:V("theme","light"),notifications:{enabled:V("notifications_enabled",!0),sound:V("notification_sound",!0),soundUrl:V("notification_sound_url",null)},messages:{maxLength:2e3,allowEditing:!0,editWindow:5*60*1e3,allowDeletion:!0},channels:{defaultChannel:"general"}},features:{directMessaging:!0,fileSharing:!1,messageThreading:!1,messageReactions:!0,userChannelCreation:V("user_channel_creation",!1),userStatus:!0},hipaa:{enableSessionTimeout:!0,enableAuditLogging:!0,enableMessageExpiration:!0,showPhiIndicators:!0,enableEncryption:!0},roles:{admin:{name:"Administrator",permissions:["user.create","user.read","user.update","user.delete","channel.create","channel.read","channel.update","channel.delete","channel.invite","message.delete","audit.read"]},moderator:{name:"Moderator",permissions:["user.read","channel.create","channel.read","channel.update","channel.invite","message.delete"]},user:{name:"User",permissions:["user.read","channel.read","message.create","message.read","message.update.own","message.delete.own"]}},version:{number:"1.0.0",buildDate:new Date("2025-03-18").toISOString()}};function Le(t,e=null){try{let n=t.split("."),o=ur;for(let r of n)if(o&&typeof o=="object"&&r in o)o=o[r];else return e;return o}catch(n){return console.error("[CRM Extension] Error getting config value:",n),e}}var Ae={primary:"#343a40",secondary:"#3a444f",text:"#ffffff",accent:"#2196F3"},zt=class{constructor(e,n){this.container=e,this.onLoginSuccess=n||(()=>{}),this.formElement=null,this.render=this.render.bind(this),this.handleSubmit=this.handleSubmit.bind(this),this.handleDemoLogin=this.handleDemoLogin.bind(this),this.render()}render(){let e=document.createElement("div");e.className="login-container",this.applyStyles(e,{maxWidth:"380px",width:"100%",margin:"40px auto 0",padding:"20px",backgroundColor:"white",borderRadius:"8px",boxShadow:"0 2px 10px rgba(0,0,0,0.1)",textAlign:"center"});let n=document.createElement("h2");n.textContent="Mountain Care Pharmacy",this.applyStyles(n,{color:Ae.primary,fontSize:"24px",margin:"0 0 8px",fontWeight:"bold"});let o=document.createElement("p");o.textContent="Please log in to continue",this.applyStyles(o,{color:"#666",margin:"0 0 20px",fontSize:"14px"}),this.formElement=document.createElement("form"),this.formElement.className="login-form",this.applyStyles(this.formElement,{display:"flex",flexDirection:"column",gap:"16px"}),this.formElement.addEventListener("submit",this.handleSubmit);let r=this.createFormGroup("Username","username","text"),s=this.createFormGroup("Password","password","password"),i=document.createElement("div");this.applyStyles(i,{display:"flex",alignItems:"center",marginTop:"-8px"});let a=document.createElement("input");a.type="checkbox",a.id="remember-me",a.name="remember";let l=document.createElement("label");l.htmlFor="remember-me",l.textContent="Remember me",this.applyStyles(l,{fontSize:"14px",color:"#666",marginLeft:"8px",cursor:"pointer"}),i.appendChild(a),i.appendChild(l);let c=document.createElement("button");c.type="submit",c.textContent="Login",this.applyStyles(c,{backgroundColor:Ae.primary,color:Ae.text,border:"none",padding:"10px",borderRadius:"4px",fontSize:"16px",cursor:"pointer",fontWeight:"bold"}),c.addEventListener("mouseover",()=>{c.style.backgroundColor=Ae.secondary}),c.addEventListener("mouseout",()=>{c.style.backgroundColor=Ae.primary});let p=document.createElement("button");p.type="button",p.textContent="Demo",p.id="demo-login-button",this.applyStyles(p,{backgroundColor:"#4CAF50",color:"white",border:"none",padding:"10px",borderRadius:"4px",fontSize:"16px",cursor:"pointer",fontWeight:"bold",marginTop:"8px"}),p.addEventListener("click",this.handleDemoLogin),p.addEventListener("mouseover",()=>{p.style.backgroundColor="#45a049"}),p.addEventListener("mouseout",()=>{p.style.backgroundColor="#4CAF50"});let h=document.createElement("p");h.textContent="This system complies with HIPAA security requirements",this.applyStyles(h,{fontSize:"12px",color:"#666",margin:"16px 0 0"});let f=document.createElement("p");f.textContent="All communication is encrypted",this.applyStyles(f,{fontSize:"12px",color:"#666",margin:"8px 0 0"}),this.formElement.appendChild(r),this.formElement.appendChild(s),this.formElement.appendChild(i),this.formElement.appendChild(c),this.formElement.appendChild(p),e.appendChild(n),e.appendChild(o),e.appendChild(this.formElement),e.appendChild(h),e.appendChild(f),this.container.innerHTML="",this.container.appendChild(e)}createFormGroup(e,n,o){let r=document.createElement("div");this.applyStyles(r,{display:"flex",flexDirection:"column",textAlign:"left"});let s=document.createElement("label");s.htmlFor=n,s.textContent=e,this.applyStyles(s,{fontSize:"14px",color:"#666",marginBottom:"4px"});let i=document.createElement("div");this.applyStyles(i,{position:"relative"});let a=document.createElement("input");if(a.type=o,a.id=n,a.name=n,a.required=!0,this.applyStyles(a,{padding:"10px",border:"1px solid #ddd",borderRadius:"4px",width:"100%",boxSizing:"border-box",fontSize:"14px"}),o==="password"){let l=document.createElement("button");l.type="button",l.textContent="\u{1F441}\uFE0F",this.applyStyles(l,{position:"absolute",right:"8px",top:"50%",transform:"translateY(-50%)",backgroundColor:"transparent",border:"none",cursor:"pointer",fontSize:"16px",color:"#f44336"}),l.addEventListener("click",()=>{a.type=a.type==="password"?"text":"password"}),i.appendChild(l)}return i.appendChild(a),r.appendChild(s),r.appendChild(i),r}async handleSubmit(e){e.preventDefault();try{let n=e.target.username.value,o=e.target.password.value,r=e.target.remember?.checked||!1,s=e.target.querySelector('button[type="submit"]'),i=e.target.querySelectorAll("input");s.disabled=!0,s.textContent="Logging in...",i.forEach(a=>a.disabled=!0),setTimeout(()=>{alert("Server connection not available. Please use the Demo button to explore the UI."),s.disabled=!1,s.textContent="Login",i.forEach(a=>a.disabled=!1)},1e3)}catch(n){console.error("[CRM Extension] Login error:",n),alert("An error occurred during login. Please try again or use the Demo button.");let o=e.target.querySelector('button[type="submit"]'),r=e.target.querySelectorAll("input");o.disabled=!1,o.textContent="Login",r.forEach(s=>s.disabled=!1)}}handleDemoLogin(){try{console.log("[CRM Extension] Demo login button clicked - Direct UI access");let e={id:"demo_user_"+Date.now(),username:"DemoUser",displayName:"Demo User",role:"user",isDemo:!0};localStorage.setItem("crmplus_chat_auth_token","demo_token_"+Date.now()),localStorage.setItem("crmplus_chat_user_info",JSON.stringify(e)),d("system","Demo UI access - no server connection",{username:e.username}),setTimeout(()=>{this.onLoginSuccess(e)},100)}catch(e){console.error("[CRM Extension] Demo login error:",e),alert("An error occurred. Please try again.")}}applyStyles(e,n){Object.assign(e.style,n)}destroy(){this.formElement&&this.formElement.removeEventListener("submit",this.handleSubmit),this.container&&(this.container.innerHTML="")}},Ft=zt;var Ot=class{constructor(e){this.container=e,this.panelElement=null,this.activeTab="dashboard",this.tabContents={},this.userManager=null,this.channelManager=null,this.roleManager=null,this.render=this.render.bind(this),this.switchTab=this.switchTab.bind(this),this.renderDashboard=this.renderDashboard.bind(this),this.renderAuditLog=this.renderAuditLog.bind(this),this.renderSettings=this.renderSettings.bind(this),this.refreshStats=this.refreshStats.bind(this),this.handleExportAuditLog=this.handleExportAuditLog.bind(this),this.handleMessageCleanup=this.handleMessageCleanup.bind(this),this.auditStats=null,this.storageStats=null,this.encryptionInfo=null,this.initialize()}initialize(){this.panelElement=document.createElement("div"),this.panelElement.className="admin-panel",this.applyStyles(this.panelElement,{display:"flex",flexDirection:"column",width:"100%",height:"100%",overflow:"hidden",backgroundColor:"#f8f9fa"}),this.container&&this.container.appendChild(this.panelElement),this.refreshStats(),this.render(),d("admin","Admin panel initialized")}refreshStats(){this.auditStats=Ct(),this.storageStats=St(),this.encryptionInfo=Mt()}render(){if(!this.panelElement)return;this.panelElement.innerHTML="";let e=I();if(!(e&&e.role==="admin")){this.renderAccessDenied();return}let o=document.createElement("div");o.className="admin-header",this.applyStyles(o,{padding:"16px",backgroundColor:"#343a40",color:"white",display:"flex",alignItems:"center",boxShadow:"0 2px 4px rgba(0,0,0,0.1)"});let r=document.createElement("h2");r.textContent="HIPAA Chat Administration",this.applyStyles(r,{margin:"0",fontSize:"18px",fontWeight:"bold"}),o.appendChild(r),this.panelElement.appendChild(o);let s=document.createElement("div");s.className="admin-tabs",this.applyStyles(s,{display:"flex",backgroundColor:"#f8f9fa",borderBottom:"1px solid #dee2e6"}),[{id:"dashboard",label:"Dashboard",icon:"\u{1F4CA}"},{id:"users",label:"User Management",icon:"\u{1F465}"},{id:"channels",label:"Channel Management",icon:"\u{1F4AC}"},{id:"roles",label:"Roles & Permissions",icon:"\u{1F511}"},{id:"audit",label:"Audit Log",icon:"\u{1F4DD}"},{id:"settings",label:"System Settings",icon:"\u2699\uFE0F"}].forEach(l=>{let c=document.createElement("button");c.className=`tab-button ${this.activeTab===l.id?"active":""}`,c.setAttribute("data-tab",l.id),this.applyStyles(c,{padding:"12px 16px",backgroundColor:this.activeTab===l.id?"#ffffff":"transparent",border:"none",borderBottom:this.activeTab===l.id?"2px solid #2196F3":"2px solid transparent",cursor:"pointer",fontSize:"14px",fontWeight:this.activeTab===l.id?"bold":"normal",display:"flex",alignItems:"center",color:this.activeTab===l.id?"#2196F3":"#495057"});let p=document.createElement("span");p.textContent=l.icon,this.applyStyles(p,{marginRight:"8px",fontSize:"16px"});let h=document.createElement("span");h.textContent=l.label,c.appendChild(p),c.appendChild(h),c.addEventListener("click",()=>this.switchTab(l.id)),s.appendChild(c)}),this.panelElement.appendChild(s);let a=document.createElement("div");switch(a.className="tab-content",this.applyStyles(a,{flex:"1",padding:"20px",backgroundColor:"#ffffff",overflowY:"auto"}),this.activeTab){case"dashboard":this.renderDashboard(a);break;case"users":this.renderUserManagement(a);break;case"channels":this.renderChannelManagement(a);break;case"roles":this.renderRoleManagement(a);break;case"audit":this.renderAuditLog(a);break;case"settings":this.renderSettings(a);break;default:this.renderDashboard(a)}this.panelElement.appendChild(a),this.tabContents[this.activeTab]=a}renderAccessDenied(){this.panelElement.innerHTML="";let e=document.createElement("div");this.applyStyles(e,{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",padding:"20px",textAlign:"center",color:"#721c24",backgroundColor:"#f8d7da"});let n=document.createElement("div");n.innerHTML="\u26D4",this.applyStyles(n,{fontSize:"48px",marginBottom:"16px"});let o=document.createElement("h3");o.textContent="Access Denied",this.applyStyles(o,{margin:"0 0 10px 0",fontSize:"24px"});let r=document.createElement("p");r.textContent="Administrator privileges are required to access this area.",e.appendChild(n),e.appendChild(o),e.appendChild(r),this.panelElement.appendChild(e),d("admin","Access denied to admin panel")}switchTab(e){this.activeTab!==e&&(this.activeTab=e,d("admin",`Switched to ${e} tab`),this.render())}renderDashboard(e){this.refreshStats();let n=document.createElement("div");this.applyStyles(n,{marginBottom:"20px"});let o=document.createElement("h3");o.textContent="System Dashboard",this.applyStyles(o,{margin:"0 0 8px 0",fontSize:"20px",fontWeight:"bold"});let r=document.createElement("p");r.textContent="Overview of system status and metrics",this.applyStyles(r,{margin:"0",color:"#6c757d",fontSize:"14px"}),n.appendChild(o),n.appendChild(r),e.appendChild(n);let s=document.createElement("div");this.applyStyles(s,{display:"grid",gridTemplateColumns:"repeat(auto-fill, minmax(300px, 1fr))",gap:"20px",marginBottom:"30px"});let i=this.createStatCard("\u{1F465} Users",[{label:"Total Users",value:this.storageStats.userCount},{label:"Users Online",value:"..."},{label:"Admin Users",value:"..."},{label:"Last Login",value:"..."}]),a=this.createStatCard("\u{1F4AC} Messages",[{label:"Total Messages",value:this.storageStats.messageCount},{label:"Storage Usage",value:`${this.storageStats.messagesKB} KB`},{label:"Expiration",value:"24 hours"},{label:"Encryption",value:this.encryptionInfo.method}]),l=this.createStatCard("\u{1F4E2} Channels",[{label:"Total Channels",value:this.storageStats.channelCount},{label:"Public Channels",value:"..."},{label:"Private Channels",value:"..."},{label:"Storage Usage",value:`${this.storageStats.channelsKB} KB`}]),c=this.createStatCard("\u{1F4DD} Audit Log",[{label:"Total Entries",value:this.auditStats.totalEntries},{label:"Oldest Entry",value:this.formatDate(this.auditStats.oldestEntry)},{label:"Newest Entry",value:this.formatDate(this.auditStats.newestEntry)},{label:"Retention Period",value:`${this.auditStats.retentionDays} days`}]),p=this.createStatCard("\u{1F512} Security",[{label:"Encryption Status",value:this.encryptionInfo.active?"Active":"Inactive"},{label:"Encryption Method",value:this.encryptionInfo.method},{label:"HIPAA Compliant",value:this.encryptionInfo.hipaaCompliant?"Yes":"No"},{label:"Browser Support",value:this.encryptionInfo.browserSupport}]);s.appendChild(i),s.appendChild(a),s.appendChild(l),s.appendChild(c),s.appendChild(p),e.appendChild(s);let h=document.createElement("div");this.applyStyles(h,{marginBottom:"30px"});let f=document.createElement("h4");f.textContent="Quick Actions",this.applyStyles(f,{margin:"0 0 15px 0",fontSize:"16px",fontWeight:"bold"}),h.appendChild(f);let u=document.createElement("div");this.applyStyles(u,{display:"grid",gridTemplateColumns:"repeat(auto-fill, minmax(200px, 1fr))",gap:"10px"});let k=this.createActionButton("Add New User","\u{1F464}",()=>{this.switchTab("users")}),w=this.createActionButton("Create Channel","\u{1F4E2}",()=>{this.switchTab("channels")}),b=this.createActionButton("Export Audit Log","\u{1F4E5}",this.handleExportAuditLog),y=this.createActionButton("Clean Expired Messages","\u{1F9F9}",this.handleMessageCleanup),g=this.createActionButton("View Audit Log","\u{1F4CB}",()=>{this.switchTab("audit")});u.appendChild(k),u.appendChild(w),u.appendChild(b),u.appendChild(y),u.appendChild(g),h.appendChild(u),e.appendChild(h);let E=document.createElement("button");E.textContent="Refresh Dashboard",this.applyStyles(E,{padding:"8px 16px",backgroundColor:"#f8f9fa",border:"1px solid #ced4da",borderRadius:"4px",cursor:"pointer",fontSize:"14px",display:"flex",alignItems:"center",justifyContent:"center",margin:"20px auto"}),E.addEventListener("click",()=>{this.refreshStats(),this.renderDashboard(e),d("admin","Refreshed dashboard")}),e.appendChild(E)}createStatCard(e,n){let o=document.createElement("div");this.applyStyles(o,{backgroundColor:"#ffffff",borderRadius:"8px",boxShadow:"0 2px 4px rgba(0,0,0,0.1)",padding:"16px",border:"1px solid #e9ecef"});let r=document.createElement("h4");r.textContent=e,this.applyStyles(r,{margin:"0 0 12px 0",fontSize:"16px",fontWeight:"bold",color:"#495057",borderBottom:"1px solid #e9ecef",paddingBottom:"8px"}),o.appendChild(r);let s=document.createElement("div");return n.forEach(i=>{let a=document.createElement("div");this.applyStyles(a,{display:"flex",justifyContent:"space-between",margin:"8px 0"});let l=document.createElement("span");l.textContent=i.label,this.applyStyles(l,{color:"#6c757d",fontSize:"14px"});let c=document.createElement("span");c.textContent=i.value,this.applyStyles(c,{fontWeight:"bold",fontSize:"14px"}),a.appendChild(l),a.appendChild(c),s.appendChild(a)}),o.appendChild(s),o}createActionButton(e,n,o){let r=document.createElement("button");this.applyStyles(r,{padding:"10px",backgroundColor:"#ffffff",border:"1px solid #dee2e6",borderRadius:"4px",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"flex-start",width:"100%",textAlign:"left",transition:"background-color 0.2s"}),r.addEventListener("mouseover",()=>{r.style.backgroundColor="#f8f9fa"}),r.addEventListener("mouseout",()=>{r.style.backgroundColor="#ffffff"});let s=document.createElement("span");s.textContent=n,this.applyStyles(s,{marginRight:"8px",fontSize:"16px"});let i=document.createElement("span");return i.textContent=e,r.appendChild(s),r.appendChild(i),typeof o=="function"&&r.addEventListener("click",o),r}handleExportAuditLog(){xt(),alert("Audit log has been exported successfully."),d("admin","Exported audit log")}handleMessageCleanup(){let e=Je();alert(`Cleanup complete. Removed ${e} expired messages.`),this.refreshStats(),this.activeTab==="dashboard"&&this.tabContents.dashboard&&this.renderDashboard(this.tabContents.dashboard),d("admin",`Cleaned up ${e} expired messages`)}renderUserManagement(e){let n=document.createElement("div");this.applyStyles(n,{textAlign:"center",padding:"50px",color:"#6c757d"});let o=document.createElement("div");o.innerHTML="\u{1F465}",this.applyStyles(o,{fontSize:"48px",marginBottom:"16px"});let r=document.createElement("h4");r.textContent="User Management",this.applyStyles(r,{margin:"0 0 8px 0",fontSize:"20px"});let s=document.createElement("p");s.textContent="User Management component will be implemented here.",n.appendChild(o),n.appendChild(r),n.appendChild(s),e.appendChild(n)}renderChannelManagement(e){let n=document.createElement("div");this.applyStyles(n,{textAlign:"center",padding:"50px",color:"#6c757d"});let o=document.createElement("div");o.innerHTML="\u{1F4AC}",this.applyStyles(o,{fontSize:"48px",marginBottom:"16px"});let r=document.createElement("h4");r.textContent="Channel Management",this.applyStyles(r,{margin:"0 0 8px 0",fontSize:"20px"});let s=document.createElement("p");s.textContent="Channel Management component will be implemented here.",n.appendChild(o),n.appendChild(r),n.appendChild(s),e.appendChild(n)}renderRoleManagement(e){let n=document.createElement("div");this.applyStyles(n,{textAlign:"center",padding:"50px",color:"#6c757d"});let o=document.createElement("div");o.innerHTML="\u{1F511}",this.applyStyles(o,{fontSize:"48px",marginBottom:"16px"});let r=document.createElement("h4");r.textContent="Roles & Permissions",this.applyStyles(r,{margin:"0 0 8px 0",fontSize:"20px"});let s=document.createElement("p");s.textContent="Role Management component will be implemented here.",n.appendChild(o),n.appendChild(r),n.appendChild(s),e.appendChild(n)}renderAuditLog(e){this.refreshStats();let n=document.createElement("div");this.applyStyles(n,{marginBottom:"20px",display:"flex",justifyContent:"space-between",alignItems:"flex-start"});let o=document.createElement("div"),r=document.createElement("h3");r.textContent="Audit Log",this.applyStyles(r,{margin:"0 0 8px 0",fontSize:"20px",fontWeight:"bold"});let s=document.createElement("p");s.textContent=`${this.auditStats.totalEntries} total entries \xB7 Retention: ${this.auditStats.retentionDays} days`,this.applyStyles(s,{margin:"0",color:"#6c757d",fontSize:"14px"}),o.appendChild(r),o.appendChild(s);let i=document.createElement("button");i.textContent="Export Log",this.applyStyles(i,{padding:"8px 16px",backgroundColor:"#f8f9fa",border:"1px solid #ced4da",borderRadius:"4px",cursor:"pointer",fontSize:"14px",display:"flex",alignItems:"center"});let a=document.createElement("span");a.textContent="\u{1F4E5}",this.applyStyles(a,{marginRight:"8px"}),i.prepend(a),i.addEventListener("click",this.handleExportAuditLog),n.appendChild(o),n.appendChild(i),e.appendChild(n);let l=document.createElement("div");this.applyStyles(l,{backgroundColor:"#f8f9fa",padding:"16px",borderRadius:"4px",marginBottom:"20px",border:"1px solid #dee2e6"});let c=document.createElement("h4");c.textContent="Search & Filter",this.applyStyles(c,{margin:"0 0 12px 0",fontSize:"16px",fontWeight:"bold"});let p=document.createElement("form");this.applyStyles(p,{display:"grid",gridTemplateColumns:"repeat(auto-fill, minmax(200px, 1fr))",gap:"12px"});let h=document.createElement("div"),f=document.createElement("label");f.textContent="Category",f.htmlFor="category-filter",this.applyStyles(f,{display:"block",marginBottom:"5px",fontSize:"14px"});let u=document.createElement("select");u.id="category-filter",this.applyStyles(u,{width:"100%",padding:"8px",border:"1px solid #ced4da",borderRadius:"4px",boxSizing:"border-box"}),[{value:"",label:"All Categories"},{value:"system",label:"System"},{value:"auth",label:"Authentication"},{value:"message",label:"Messages"},{value:"channel",label:"Channels"},{value:"user",label:"Users"},{value:"admin",label:"Admin"},{value:"security",label:"Security"},{value:"storage",label:"Storage"}].forEach(j=>{let G=document.createElement("option");G.value=j.value,G.textContent=j.label,u.appendChild(G)}),h.appendChild(f),h.appendChild(u);let w=document.createElement("div"),b=document.createElement("label");b.textContent="Username",b.htmlFor="username-filter",this.applyStyles(b,{display:"block",marginBottom:"5px",fontSize:"14px"});let y=document.createElement("input");y.type="text",y.id="username-filter",y.placeholder="Enter username",this.applyStyles(y,{width:"100%",padding:"8px",border:"1px solid #ced4da",borderRadius:"4px",boxSizing:"border-box"}),w.appendChild(b),w.appendChild(y);let g=document.createElement("div"),E=document.createElement("label");E.textContent="Start Date",E.htmlFor="start-date-filter",this.applyStyles(E,{display:"block",marginBottom:"5px",fontSize:"14px"});let v=document.createElement("input");v.type="date",v.id="start-date-filter",this.applyStyles(v,{width:"100%",padding:"8px",border:"1px solid #ced4da",borderRadius:"4px",boxSizing:"border-box"}),g.appendChild(E),g.appendChild(v);let A=document.createElement("div"),T=document.createElement("label");T.textContent="End Date",T.htmlFor="end-date-filter",this.applyStyles(T,{display:"block",marginBottom:"5px",fontSize:"14px"});let D=document.createElement("input");D.type="date",D.id="end-date-filter",this.applyStyles(D,{width:"100%",padding:"8px",border:"1px solid #ced4da",borderRadius:"4px",boxSizing:"border-box"}),A.appendChild(T),A.appendChild(D);let S=document.createElement("div"),B=document.createElement("label");B.textContent="Action",B.htmlFor="action-filter",this.applyStyles(B,{display:"block",marginBottom:"5px",fontSize:"14px"});let P=document.createElement("input");P.type="text",P.id="action-filter",P.placeholder="Filter by action",this.applyStyles(P,{width:"100%",padding:"8px",border:"1px solid #ced4da",borderRadius:"4px",boxSizing:"border-box"}),S.appendChild(B),S.appendChild(P),p.appendChild(h),p.appendChild(w),p.appendChild(g),p.appendChild(A),p.appendChild(S);let ee=document.createElement("div");this.applyStyles(ee,{display:"flex",alignItems:"flex-end"});let $=document.createElement("button");$.type="button",$.textContent="Search",this.applyStyles($,{padding:"8px 16px",backgroundColor:"#2196F3",color:"white",border:"none",borderRadius:"4px",cursor:"pointer"}),$.addEventListener("click",()=>{let j={category:u.value,username:y.value,startDate:v.value,endDate:D.value,action:P.value};this.renderAuditLogResults(e,j),d("admin","Searched audit log",{filters:j})}),ee.appendChild($),p.appendChild(ee),l.appendChild(c),l.appendChild(p),e.appendChild(l),this.renderAuditLogResults(e,{})}renderAuditLogResults(e,n){let o=e.querySelector(".audit-log-results");o&&e.removeChild(o);let r=document.createElement("div");r.className="audit-log-results";let s=yt({category:n.category||void 0,username:n.username||void 0,startDate:n.startDate||void 0,endDate:n.endDate||void 0,action:n.action||void 0},100),i=document.createElement("table");this.applyStyles(i,{width:"100%",borderCollapse:"collapse",fontSize:"14px"});let a=document.createElement("thead");this.applyStyles(a,{backgroundColor:"#f8f9fa",fontWeight:"bold"});let l=document.createElement("tr"),c=["Timestamp","Category","Username","Action","Details"];c.forEach(b=>{let y=document.createElement("th");y.textContent=b,this.applyStyles(y,{padding:"10px 8px",textAlign:"left",borderBottom:"2px solid #dee2e6"}),l.appendChild(y)}),a.appendChild(l),i.appendChild(a);let p=document.createElement("tbody");if(s.length===0){let b=document.createElement("tr"),y=document.createElement("td");y.textContent="No audit log entries found matching the criteria.",this.applyStyles(y,{padding:"20px 10px",textAlign:"center",color:"#6c757d"}),y.colSpan=c.length,b.appendChild(y),p.appendChild(b)}else s.forEach(b=>{let y=document.createElement("tr");y.addEventListener("mouseover",()=>{y.style.backgroundColor="#f8f9fa"}),y.addEventListener("mouseout",()=>{y.style.backgroundColor=""});let g=document.createElement("td");g.textContent=this.formatDateTime(b.timestamp),this.applyStyles(g,{padding:"8px",borderBottom:"1px solid #dee2e6",whiteSpace:"nowrap"});let E=document.createElement("td");E.textContent=b.category,this.applyStyles(E,{padding:"8px",borderBottom:"1px solid #dee2e6"});let v=document.createElement("td");v.textContent=b.username,this.applyStyles(v,{padding:"8px",borderBottom:"1px solid #dee2e6"});let A=document.createElement("td");A.textContent=b.action,this.applyStyles(A,{padding:"8px",borderBottom:"1px solid #dee2e6"});let T=document.createElement("td");if(b.details&&Object.keys(b.details).length>0){let D=Object.entries(b.details).map(([S,B])=>`${S}: ${B}`).join(", ");T.textContent=D}else T.textContent="-";this.applyStyles(T,{padding:"8px",borderBottom:"1px solid #dee2e6",fontSize:"12px",color:"#6c757d"}),y.appendChild(g),y.appendChild(E),y.appendChild(v),y.appendChild(A),y.appendChild(T),p.appendChild(y)});i.appendChild(p),r.appendChild(i);let h=document.createElement("div");this.applyStyles(h,{display:"flex",justifyContent:"space-between",alignItems:"center",marginTop:"16px",padding:"8px 0",borderTop:"1px solid #dee2e6"});let f=document.createElement("div");f.textContent=`Showing ${s.length} of ${this.auditStats.totalEntries} entries`,this.applyStyles(f,{fontSize:"14px",color:"#6c757d"});let u=document.createElement("div");this.applyStyles(u,{display:"flex",gap:"8px"});let k=document.createElement("button");k.textContent="\u2190 Previous",this.applyStyles(k,{padding:"4px 8px",backgroundColor:"#f8f9fa",border:"1px solid #dee2e6",borderRadius:"4px",cursor:"pointer",fontSize:"14px"}),k.disabled=!0;let w=document.createElement("button");w.textContent="Next \u2192",this.applyStyles(w,{padding:"4px 8px",backgroundColor:"#f8f9fa",border:"1px solid #dee2e6",borderRadius:"4px",cursor:"pointer",fontSize:"14px"}),w.disabled=s.length<100,u.appendChild(k),u.appendChild(w),h.appendChild(f),h.appendChild(u),r.appendChild(h),e.appendChild(r)}renderSettings(e){let n=document.createElement("div");this.applyStyles(n,{marginBottom:"20px"});let o=document.createElement("h3");o.textContent="System Settings",this.applyStyles(o,{margin:"0 0 8px 0",fontSize:"20px",fontWeight:"bold"});let r=document.createElement("p");r.textContent="Configure HIPAA-compliant chat system settings",this.applyStyles(r,{margin:"0",color:"#6c757d",fontSize:"14px"}),n.appendChild(o),n.appendChild(r),e.appendChild(n);let s=this.createSettingsSection("Server Configuration","\u{1F5A5}\uFE0F"),i=this.createSettingItem("WebSocket Server URL","The URL of the WebSocket server for real-time communication","server_url","text",localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000");s.contentElement.appendChild(i);let a=this.createSettingItem("Max Reconnection Attempts","Maximum number of times to attempt reconnection on disconnection","max_reconnect_attempts","number","5");s.contentElement.appendChild(a);let l=this.createSettingItem("Heartbeat Interval (sec)","Time between heartbeat messages to keep connection alive","heartbeat_interval","number","30");s.contentElement.appendChild(l),e.appendChild(s.section);let c=this.createSettingsSection("Security Settings","\u{1F512}"),p=this.createSettingItem("Session Timeout (min)","Automatically log out users after this period of inactivity","session_timeout","number","15");c.contentElement.appendChild(p);let h=this.createSettingItem("Two-Factor Authentication","Enable two-factor authentication for login","enable_2fa","checkbox","false");c.contentElement.appendChild(h);let f=this.createSettingItem("Minimum Password Length","Minimum number of characters required for passwords","min_password_length","number","8");c.contentElement.appendChild(f),e.appendChild(c.section);let u=this.createSettingsSection("Message Configuration","\u{1F4AC}"),k=this.createSettingItem("Message Expiration (hours)","Time after which messages are automatically deleted","message_expiration","number","24");u.contentElement.appendChild(k);let w=this.createSettingItem("Maximum Message Length","Maximum character count for chat messages","max_message_length","number","2000");u.contentElement.appendChild(w);let b=this.createSettingItem("Allow Message Editing","Allow users to edit their messages","allow_message_editing","checkbox","true");u.contentElement.appendChild(b);let y=this.createSettingItem("Allow Message Deletion","Allow users to delete their messages","allow_message_deletion","checkbox","true");u.contentElement.appendChild(y),e.appendChild(u.section);let g=this.createSettingsSection("Feature Flags","\u{1F6A9}"),E=this.createSettingItem("Direct Messaging","Allow users to send private messages to each other","enable_direct_messaging","checkbox","true");g.contentElement.appendChild(E);let v=this.createSettingItem("File Sharing","Allow users to share files (disabled for HIPAA compliance)","enable_file_sharing","checkbox","false");g.contentElement.appendChild(v);let A=this.createSettingItem("Message Threading","Allow threaded replies to messages","enable_threading","checkbox","false");g.contentElement.appendChild(A);let T=this.createSettingItem("User Channel Creation","Allow non-admin users to create channels","user_channel_creation","checkbox","false");g.contentElement.appendChild(T),e.appendChild(g.section);let D=document.createElement("div");this.applyStyles(D,{marginTop:"30px",display:"flex",justifyContent:"center"});let S=document.createElement("button");S.textContent="Save Settings",this.applyStyles(S,{padding:"10px 20px",backgroundColor:"#28a745",color:"white",border:"none",borderRadius:"4px",cursor:"pointer",fontSize:"16px",fontWeight:"bold"}),S.addEventListener("click",()=>{alert("Settings saved successfully."),d("admin","Updated system settings")}),D.appendChild(S),e.appendChild(D)}createSettingsSection(e,n){let o=document.createElement("div");this.applyStyles(o,{backgroundColor:"#ffffff",borderRadius:"4px",border:"1px solid #dee2e6",marginBottom:"20px",overflow:"hidden"});let r=document.createElement("div");this.applyStyles(r,{padding:"12px 16px",backgroundColor:"#f8f9fa",borderBottom:"1px solid #dee2e6",display:"flex",alignItems:"center"});let s=document.createElement("span");s.textContent=n,this.applyStyles(s,{marginRight:"8px",fontSize:"18px"});let i=document.createElement("h4");i.textContent=e,this.applyStyles(i,{margin:"0",fontSize:"16px",fontWeight:"bold"}),r.appendChild(s),r.appendChild(i),o.appendChild(r);let a=document.createElement("div");return this.applyStyles(a,{padding:"16px"}),o.appendChild(a),{section:o,headerElement:r,contentElement:a}}createSettingItem(e,n,o,r,s){let i=document.createElement("div");this.applyStyles(i,{marginBottom:"16px",paddingBottom:"16px",borderBottom:"1px solid #f0f0f0"});let a=document.createElement("div");this.applyStyles(a,{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"8px"});let l=document.createElement("label");l.textContent=e,l.htmlFor=`setting-${o}`,this.applyStyles(l,{fontWeight:"bold",fontSize:"14px"});let c;r==="checkbox"?(c=document.createElement("input"),c.type="checkbox",c.id=`setting-${o}`,c.checked=s==="true",this.applyStyles(c,{transform:"scale(1.2)"})):(c=document.createElement("input"),c.type=r,c.id=`setting-${o}`,c.value=s,this.applyStyles(c,{padding:"6px 8px",border:"1px solid #ced4da",borderRadius:"4px",width:"200px"})),a.appendChild(l),a.appendChild(c);let p=document.createElement("div");return p.textContent=n,this.applyStyles(p,{fontSize:"12px",color:"#6c757d"}),i.appendChild(a),i.appendChild(p),i}formatDate(e){if(!e)return"N/A";try{return new Date(e).toLocaleDateString()}catch{return e}}formatDateTime(e){if(!e)return"N/A";try{let n=new Date(e);return`${n.toLocaleDateString()} ${n.toLocaleTimeString()}`}catch{return e}}applyStyles(e,n){Object.assign(e.style,n)}destroy(){this.panelElement&&this.panelElement.parentNode&&this.panelElement.parentNode.removeChild(this.panelElement),d("admin","Admin panel destroyed")}},$t=Ot;var jt=class{constructor(e={}){this.options={sound:Le("ui.notifications.sound",!0),soundUrl:Le("ui.notifications.soundUrl",null),desktop:Le("ui.notifications.enabled",!0),onNotificationClick:null,...e},this.notificationCount=0,this.notificationQueue=[],this.processingQueue=!1,this.enabled=!0,this.focused=document.hasFocus(),this.unsubscribeMessageListener=null,this.notificationPermission="default",this.audio=null,this.initialize=this.initialize.bind(this),this.handleMessage=this.handleMessage.bind(this),this.showNotification=this.showNotification.bind(this),this.playNotificationSound=this.playNotificationSound.bind(this),this.handleVisibilityChange=this.handleVisibilityChange.bind(this),this.processBatchedNotifications=this.processBatchedNotifications.bind(this),this.requestNotificationPermission=this.requestNotificationPermission.bind(this),this.initialize()}initialize(){try{"Notification"in window&&(this.notificationPermission=Notification.permission,this.notificationPermission!=="granted"&&this.options.desktop&&document.addEventListener("click",this.requestNotificationPermission,{once:!0})),this.options.sound&&(this.audio=new Audio(this.options.soundUrl||this.getDefaultSoundUrl()),this.audio.load()),document.addEventListener("visibilitychange",this.handleVisibilityChange),window.addEventListener("focus",()=>{this.focused=!0,this.resetNotificationCount()}),window.addEventListener("blur",()=>{this.focused=!1}),this.unsubscribeMessageListener=Me(this.handleMessage),d("ui","Notification system initialized"),console.log("[CRM Extension] Notification system initialized")}catch(e){console.error("[CRM Extension] Error initializing notification system:",e)}}getDefaultSoundUrl(){return"data:audio/mp3;base64,SUQzBAAAAAABEVRYWFgAAAAtAAADY29tbWVudABCaWdTb3VuZEJhbmsuY29tIC8gTGFTb25vdGhlcXVlLm9yZwBURU5DAAAAHQAAA1N3aXRjaCBQbHVzIMKpIE5DSCBTb2Z0d2FyZQBUSVQyAAAABgAAAzIyMzUAVFNTRQAAAA8AAANMYXZmNTguMTYuMTAwAAAAAAAAAAAAAAD/80DEAAAAA0gAAAAATEFNRTMuMTAwVVVVVVVVVVVVVUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/zQsRbAAADSAAAAABVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/zQMSkAAADSAAAAABVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV"}requestNotificationPermission(){"Notification"in window&&this.notificationPermission!=="granted"&&Notification.requestPermission().then(e=>{this.notificationPermission=e,d("ui",`Notification permission ${e}`)})}handleVisibilityChange(){document.visibilityState==="visible"?(this.focused=!0,this.resetNotificationCount()):this.focused=!1}handleMessage(e){if(!this.enabled||!e||e.length===0)return;let n=I();if(!n)return;let o=e.filter(r=>r.sender!==n.username&&r.sender!==n.id);o.length!==0&&(this.notificationQueue.push(...o),this.notificationCount+=o.length,this.dispatchNotificationCountEvent(),this.processingQueue||this.processBatchedNotifications())}processBatchedNotifications(){if(this.notificationQueue.length===0){this.processingQueue=!1;return}this.processingQueue=!0;let e=this.notificationQueue.shift();this.focused||this.showNotification(e),this.options.sound&&this.notificationQueue.length===0&&this.playNotificationSound(),setTimeout(this.processBatchedNotifications,300)}showNotification(e){try{if(!this.options.desktop||!("Notification"in window)||this.notificationPermission!=="granted")return;let n=`New message from ${e.senderDisplayName||e.sender}`,o={body:"You have received a new message",icon:this.getIconUrl(e.sender),tag:`chat-msg-${e.id}`,requireInteraction:!1,silent:!0},r=new Notification(n,o);r.onclick=()=>{window.focus(),this.options.onNotificationClick&&typeof this.options.onNotificationClick=="function"&&this.options.onNotificationClick(e),r.close()},d("ui","Showed desktop notification",{sender:e.sender})}catch(n){console.error("[CRM Extension] Error showing notification:",n)}}playNotificationSound(){try{if(!this.options.sound||!this.audio)return;this.audio.currentTime=0,this.audio.play().catch(e=>{console.warn("[CRM Extension] Could not play notification sound:",e)})}catch(e){console.error("[CRM Extension] Error playing notification sound:",e)}}getIconUrl(e){return"data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA0OCA0OCIgd2lkdGg9IjQ4IiBoZWlnaHQ9IjQ4Ij48Y2lyY2xlIGN4PSIyNCIgY3k9IjI0IiByPSIyNCIgZmlsbD0iIzQyOTVmMyIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0yNCAyMGMzLjMgMCA2LTIuNyA2LTZzLTIuNy02LTYtNi02IDIuNy02IDYgMi43IDYgNiA2em0wIDRjLTQgMC0xMiAyLTEyIDZWMzRoMjR2LTRjMC00LTgtNi0xMi02eiIvPjwvc3ZnPg=="}getNotificationCount(){return this.notificationCount}resetNotificationCount(){this.notificationCount!==0&&(this.notificationCount=0,this.dispatchNotificationCountEvent(),d("ui","Reset notification count"))}dispatchNotificationCountEvent(){let e=new CustomEvent("chat_notification_count",{detail:{count:this.notificationCount}});window.dispatchEvent(e)}setEnabled(e){this.enabled=!!e,d("ui",`Notifications ${e?"enabled":"disabled"}`)}setSound(e,n=null){this.options.sound=!!e,e&&n&&(this.options.soundUrl=n,this.audio?(this.audio.src=n,this.audio.load()):(this.audio=new Audio(n),this.audio.load())),d("ui",`Notification sound ${e?"enabled":"disabled"}`)}showSystemNotification(e,n){try{if(!this.options.desktop||!("Notification"in window)||this.notificationPermission!=="granted")return;let o={body:n,icon:"data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA0OCA0OCIgd2lkdGg9IjQ4IiBoZWlnaHQ9IjQ4Ij48Y2lyY2xlIGN4PSIyNCIgY3k9IjI0IiByPSIyNCIgZmlsbD0iIzI4YTc0NSIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0yMCAzNGwtOS05IDMtMyA2IDYgMTQtMTQgMyAzeiIvPjwvc3ZnPg==",tag:`chat-system-${Date.now()}`,requireInteraction:!1,silent:!0},r=new Notification(e,o);r.onclick=()=>{window.focus(),r.close()},this.options.sound&&this.playNotificationSound(),d("ui","Showed system notification",{title:e})}catch(o){console.error("[CRM Extension] Error showing system notification:",o)}}destroy(){document.removeEventListener("visibilitychange",this.handleVisibilityChange),window.removeEventListener("focus",()=>{this.focused=!0}),window.removeEventListener("blur",()=>{this.focused=!1}),this.unsubscribeMessageListener&&this.unsubscribeMessageListener(),this.audio&&(this.audio.pause(),this.audio=null),d("ui","Notification system destroyed")}},Ht=jt;var _={primary:"#343a40",secondary:"#3a444f",text:"#ffffff",accent:"#2196F3"},Wt=class{constructor(e){this.container=e,this.appElement=null,this.headerComponent=null,this.loginFormComponent=null,this.channelListComponent=null,this.channelViewComponent=null,this.userListComponent=null,this.adminPanelComponent=null,this.notificationSystem=null,this.connectionStatus="connected",this.currentView="chat",this.showUserList=!0,this.selectedChannel="general",this.unsubscribeConnectionStatus=null,this.render=this.render.bind(this),this.handleConnectionStatusChange=this.handleConnectionStatusChange.bind(this),this.handleLoginSuccess=this.handleLoginSuccess.bind(this),this.handleChannelSelect=this.handleChannelSelect.bind(this),this.handleUserSelect=this.handleUserSelect.bind(this),this.switchView=this.switchView.bind(this),this.toggleUserList=this.toggleUserList.bind(this),this.toggleAdminPanel=this.toggleAdminPanel.bind(this),this.toggleChatVisibility=this.toggleChatVisibility.bind(this),this.initialize()}async initialize(){this.appElement=document.createElement("div"),this.appElement.className="hipaa-chat-app",this.applyStyles(this.appElement,{display:"flex",flexDirection:"column",width:"100%",height:"100%",overflow:"hidden",fontFamily:'-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, "Open Sans", "Helvetica Neue", sans-serif',borderRadius:"8px",boxShadow:"0 4px 12px rgba(0, 0, 0, 0.15)"}),this.container&&this.container.appendChild(this.appElement),this.setupMockData(),window.toggleChatUI=this.toggleChatVisibility,Xn()||await O(),this.unsubscribeConnectionStatus=Dt(this.handleConnectionStatusChange),this.connectionStatus=Tt(),this.notificationSystem=new Ht,M()&&ne(),this.render(),d("system","Application initialized")}setupMockData(){this.mockChannels=[{id:"general",name:"General",type:"public",unread:0},{id:"announcements",name:"Announcements",type:"public",unread:2},{id:"support",name:"Support",type:"public",unread:0},{id:"billing",name:"Billing",type:"private",unread:3}],this.mockUsers=[{id:"user1",username:"john.doe",displayName:"John Doe",status:"online"},{id:"user2",username:"jane.smith",displayName:"Jane Smith",status:"away"},{id:"user3",username:"admin",displayName:"Admin",status:"online"},{id:"user4",username:"support",displayName:"Support Team",status:"dnd"}],this.mockMessages={general:[{id:"msg1",sender:"john.doe",senderDisplayName:"John Doe",text:"Hello team! How is everyone doing today?",timestamp:"2023-04-15T09:30:00Z"},{id:"msg2",sender:"jane.smith",senderDisplayName:"Jane Smith",text:"Hi John! Going well here, working on the new reports.",timestamp:"2023-04-15T09:32:00Z"},{id:"msg3",sender:"admin",senderDisplayName:"Admin",text:"Good morning everyone! Just a reminder about the team meeting at 2 PM today.",timestamp:"2023-04-15T09:35:00Z"},{id:"msg4",sender:"john.doe",senderDisplayName:"John Doe",text:"Thanks for the reminder! Ill prepare my updates.",timestamp:"2023-04-15T09:36:00Z"}],announcements:[{id:"ann1",sender:"admin",senderDisplayName:"Admin",text:"Important: System maintenance scheduled for this weekend. Please save all your work by Friday 5 PM.",timestamp:"2023-04-14T15:00:00Z"},{id:"ann2",sender:"admin",senderDisplayName:"Admin",text:"New feature release: You can now export reports directly to PDF. Check the documentation for details.",timestamp:"2023-04-13T11:00:00Z"}]}}toggleChatVisibility(){this.appElement&&(this.appElement.style.display==="none"?this.appElement.style.display="flex":this.appElement.style.display="none")}handleConnectionStatusChange(e){this.connectionStatus=e,this.headerComponent&&this.headerComponent.updateConnectionStatus(e),d("system",`Connection status changed: ${e}`)}handleLoginSuccess(e){ne(),this.render(),d("auth","User logged in successfully",{username:e.username})}handleChannelSelect(e){console.log(`[CRM Extension] Channel selected: ${e.id}`),this.selectedChannel=e.id,this.render()}handleUserSelect(e){console.log(`[CRM Extension] Selected user for direct message: ${e.username}`),d("ui","Selected user for direct message",{targetUser:e.username})}switchView(e){this.currentView!==e&&(this.currentView=e,this.render(),d("ui",`Switched to ${e} view`))}toggleUserList(){this.showUserList=!this.showUserList,this.render(),d("ui",`${this.showUserList?"Showed":"Hid"} user list`)}toggleAdminPanel(){this.currentView==="admin"?this.switchView("chat"):this.switchView("admin")}render(){if(!this.appElement)return;if(this.appElement.innerHTML="",!M()){this.loginFormComponent=new Ft(this.appElement,this.handleLoginSuccess);return}let n=I();this.createCustomHeader(n);let o=document.createElement("div");o.className="app-content",this.applyStyles(o,{display:"flex",flex:"1",overflow:"hidden",backgroundColor:"#f5f7f9"}),this.currentView==="chat"?this.renderChatView(o):this.currentView==="admin"?this.renderAdminView(o):this.currentView==="settings"&&this.renderSettingsView(o),this.appElement.appendChild(o)}createCustomHeader(e){let n=document.createElement("div");n.className="mcp-chat-header",this.applyStyles(n,{backgroundColor:_.primary,color:_.text,padding:"0 16px",height:"50px",display:"flex",alignItems:"center",justifyContent:"space-between",borderTopLeftRadius:"8px",borderTopRightRadius:"8px",borderBottom:`1px solid ${_.secondary}`});let o=document.createElement("div");this.applyStyles(o,{display:"flex",alignItems:"center"});let r=document.createElement("span");r.textContent="\u{1F4AC}",this.applyStyles(r,{fontSize:"20px",marginRight:"8px"});let s=document.createElement("h1");s.textContent="Mountain Care",this.applyStyles(s,{margin:"0",fontSize:"16px",fontWeight:"bold"}),o.appendChild(r),o.appendChild(s);let i=document.createElement("div");this.applyStyles(i,{display:"flex",alignItems:"center",marginLeft:"20px"});let a=this.createNavTab("Chat",this.currentView==="chat",()=>this.switchView("chat"));i.appendChild(a);let l=this.createNavTab("Settings",this.currentView==="settings",()=>this.switchView("settings"));if(i.appendChild(l),e&&e.role==="admin"){let f=this.createNavTab("Admin",this.currentView==="admin",()=>this.switchView("admin"));i.appendChild(f)}let c=document.createElement("div");this.applyStyles(c,{display:"flex",alignItems:"center",gap:"12px"});let p=this.createConnectionIndicator(this.connectionStatus),h=this.createUserInfo(e);c.appendChild(p),c.appendChild(h),n.appendChild(o),n.appendChild(i),n.appendChild(c),this.appElement.appendChild(n)}createNavTab(e,n,o){let r=document.createElement("button");return r.textContent=e,this.applyStyles(r,{backgroundColor:"transparent",border:"none",color:n?"#fff":"rgba(255, 255, 255, 0.7)",padding:"8px 16px",cursor:"pointer",fontSize:"14px",fontWeight:n?"bold":"normal",borderBottom:n?"2px solid #fff":"none"}),r.addEventListener("mouseover",()=>{n||(r.style.color="rgba(255, 255, 255, 0.9)")}),r.addEventListener("mouseout",()=>{n||(r.style.color="rgba(255, 255, 255, 0.7)")}),r.addEventListener("click",o),r}createConnectionIndicator(e){let n={connected:"#4CAF50",connecting:"#FFC107",disconnected:"#F44336",error:"#F44336"},o={connected:"Online",connecting:"Connecting...",disconnected:"Offline",error:"Error"},r=document.createElement("div");r.className="connection-indicator",this.applyStyles(r,{display:"flex",alignItems:"center",gap:"6px",fontSize:"12px",padding:"4px 8px",borderRadius:"12px",backgroundColor:"rgba(0, 0, 0, 0.2)"});let s=document.createElement("span");this.applyStyles(s,{display:"inline-block",width:"8px",height:"8px",borderRadius:"50%",backgroundColor:n[e]||"#F44336"});let i=document.createElement("span");return i.textContent=o[e]||"Unknown",r.appendChild(s),r.appendChild(i),r}createUserInfo(e){let n=document.createElement("div");this.applyStyles(n,{display:"flex",alignItems:"center",gap:"8px",cursor:"pointer"});let o=document.createElement("div"),r=e?.username?.charAt(0)?.toUpperCase()||"?";o.textContent=r,this.applyStyles(o,{width:"32px",height:"32px",borderRadius:"50%",backgroundColor:"rgba(255, 255, 255, 0.2)",color:"#fff",display:"flex",alignItems:"center",justifyContent:"center",fontWeight:"bold",fontSize:"14px"});let s=document.createElement("span");return s.textContent=e?.displayName||e?.username||"User",this.applyStyles(s,{fontWeight:"medium",fontSize:"14px"}),n.appendChild(o),n.appendChild(s),n.addEventListener("click",()=>{console.log("User menu clicked")}),n}renderChatView(e){let n=document.createElement("div");this.applyStyles(n,{display:"flex",width:"100%",height:"100%"});let r=this.createSidebar("220px"),s=this.createChatArea(),i=this.createUserPanel();n.appendChild(r),n.appendChild(s),this.showUserList&&n.appendChild(i),e.appendChild(n)}createSidebar(e){let n=document.createElement("div");this.applyStyles(n,{width:e,minWidth:e,height:"100%",borderRight:"1px solid #e0e0e0",display:"flex",flexDirection:"column",backgroundColor:"#f8f9fa"});let o=document.createElement("div");this.applyStyles(o,{padding:"16px",borderBottom:"1px solid #e0e0e0",fontWeight:"bold",fontSize:"16px"}),o.textContent="Channels";let r=document.createElement("div");this.applyStyles(r,{flex:"1",overflowY:"auto",padding:"8px 0"}),this.addChannelGroup(r,"PUBLIC CHANNELS",this.mockChannels.filter(l=>l.type==="public")),this.addChannelGroup(r,"PRIVATE CHANNELS",this.mockChannels.filter(l=>l.type==="private"));let s=document.createElement("button");this.applyStyles(s,{margin:"12px 16px",padding:"8px 12px",backgroundColor:_.primary,color:"white",border:"none",borderRadius:"4px",fontSize:"14px",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:"6px"});let i=document.createElement("span");i.textContent="+",s.appendChild(i);let a=document.createElement("span");return a.textContent="New Channel",s.appendChild(a),n.appendChild(o),n.appendChild(r),n.appendChild(s),n}addChannelGroup(e,n,o){if(!o||o.length===0)return;let r=document.createElement("div");this.applyStyles(r,{padding:"8px 16px",fontSize:"12px",color:"#666",fontWeight:"bold"}),r.textContent=n;let s=document.createElement("div");o.forEach(i=>{let a=this.createChannelItem(i);s.appendChild(a)}),e.appendChild(r),e.appendChild(s)}createChannelItem(e){let n=this.selectedChannel===e.id,o=document.createElement("div");this.applyStyles(o,{padding:"8px 16px 8px 12px",display:"flex",alignItems:"center",cursor:"pointer",fontSize:"14px",color:n?_.primary:"#333",backgroundColor:n?"#e3f2fd":"transparent",borderLeft:n?`4px solid ${_.primary}`:"4px solid transparent"});let r=document.createElement("span");r.textContent=e.type==="public"?"\u{1F310}":"\u{1F512}",this.applyStyles(r,{marginRight:"8px",fontSize:"14px",opacity:"0.7"});let s=document.createElement("span");if(s.textContent=e.name,this.applyStyles(s,{flex:"1"}),e.unread>0){let i=document.createElement("span");i.textContent=e.unread>9?"9+":e.unread,this.applyStyles(i,{minWidth:"20px",height:"20px",backgroundColor:n?_.primary:"#f44336",color:"white",borderRadius:"10px",fontSize:"12px",fontWeight:"bold",display:"flex",alignItems:"center",justifyContent:"center",padding:"0 4px"}),o.appendChild(i)}return o.appendChild(r),o.appendChild(s),o.addEventListener("click",()=>{this.handleChannelSelect(e)}),o.addEventListener("mouseover",()=>{n||(o.style.backgroundColor="#f0f0f0")}),o.addEventListener("mouseout",()=>{n||(o.style.backgroundColor="transparent")}),o}createChatArea(){let e=document.createElement("div");this.applyStyles(e,{flex:"1",display:"flex",flexDirection:"column",backgroundColor:"#fff",overflowX:"hidden"});let n=this.createChatHeader(),o=this.createMessagesContainer(),r=this.createChatInput();return e.appendChild(n),e.appendChild(o),e.appendChild(r),e}createChatHeader(){let e=document.createElement("div");this.applyStyles(e,{padding:"12px 16px",borderBottom:"1px solid #e0e0e0",display:"flex",alignItems:"center",justifyContent:"space-between",backgroundColor:"#fff"});let n=this.mockChannels.find(p=>p.id===this.selectedChannel)||{id:"general",name:"General",type:"public"},o=document.createElement("div");this.applyStyles(o,{display:"flex",alignItems:"center",gap:"8px"});let r=document.createElement("span");r.textContent=n.type==="public"?"\u{1F310}":"\u{1F512}",this.applyStyles(r,{fontSize:"18px"});let s=document.createElement("span");s.textContent=n.name,this.applyStyles(s,{fontSize:"16px",fontWeight:"bold"});let i=document.createElement("span");i.textContent=n.type==="public"?"Public":"Private",this.applyStyles(i,{fontSize:"12px",padding:"2px 8px",backgroundColor:n.type==="public"?"#e3f2fd":"#fff3e0",color:n.type==="public"?"#1565c0":"#e65100",borderRadius:"12px"}),o.appendChild(r),o.appendChild(s),o.appendChild(i);let a=document.createElement("div");this.applyStyles(a,{display:"flex",gap:"12px"});let l=this.createIconButton("\u{1F50D}","Search in channel"),c=this.createIconButton(this.showUserList?"\u{1F465}":"\u{1F464}",this.showUserList?"Hide team members":"Show team members");return c.addEventListener("click",()=>{this.toggleUserList()}),a.appendChild(l),a.appendChild(c),e.appendChild(o),e.appendChild(a),e}createIconButton(e,n){let o=document.createElement("button");return o.textContent=e,o.title=n,this.applyStyles(o,{width:"32px",height:"32px",borderRadius:"50%",backgroundColor:"transparent",border:"none",cursor:"pointer",fontSize:"16px",display:"flex",alignItems:"center",justifyContent:"center"}),o.addEventListener("mouseover",()=>{o.style.backgroundColor="#f5f5f5"}),o.addEventListener("mouseout",()=>{o.style.backgroundColor="transparent"}),o}createMessagesContainer(){let e=document.createElement("div");this.applyStyles(e,{flex:"1",overflowY:"auto",padding:"16px",display:"flex",flexDirection:"column",gap:"8px"});let n=this.mockMessages[this.selectedChannel]||[];if(n.length===0){let o=document.createElement("div");this.applyStyles(o,{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",gap:"16px",color:"#666",textAlign:"center"});let r=document.createElement("div");r.textContent="\u{1F4AC}",this.applyStyles(r,{fontSize:"48px",marginBottom:"8px"});let s=document.createElement("h3");s.textContent="No messages yet",this.applyStyles(s,{fontSize:"18px",margin:"0",fontWeight:"bold"});let i=document.createElement("p");i.textContent="Be the first to send a message in this channel!",this.applyStyles(i,{fontSize:"14px",margin:"0",maxWidth:"300px"}),o.appendChild(r),o.appendChild(s),o.appendChild(i),e.appendChild(o)}else{let o=this.groupMessagesByDate(n);Object.keys(o).forEach(r=>{let s=this.createDateSeparator(r);e.appendChild(s),o[r].forEach(i=>{let a=this.createMessageElement(i);e.appendChild(a)})})}return e}groupMessagesByDate(e){let n={};return e.forEach(o=>{let r=new Date(o.timestamp).toLocaleDateString();n[r]||(n[r]=[]),n[r].push(o)}),n}createDateSeparator(e){let n=document.createElement("div");this.applyStyles(n,{display:"flex",alignItems:"center",gap:"8px",margin:"16px 0 8px",color:"#666"});let o=document.createElement("div");this.applyStyles(o,{flex:"1",height:"1px",backgroundColor:"#e0e0e0"});let r=document.createElement("div");r.textContent=this.formatDateLabel(e),this.applyStyles(r,{fontSize:"12px",fontWeight:"bold",padding:"2px 8px"});let s=document.createElement("div");return this.applyStyles(s,{flex:"1",height:"1px",backgroundColor:"#e0e0e0"}),n.appendChild(o),n.appendChild(r),n.appendChild(s),n}formatDateLabel(e){let n=new Date,o=new Date(e);if(o.toDateString()===n.toDateString())return"Today";let r=new Date(n);return r.setDate(r.getDate()-1),o.toDateString()===r.toDateString()?"Yesterday":e}createMessageElement(e){let n=document.createElement("div");this.applyStyles(n,{display:"flex",gap:"12px",marginBottom:"12px"});let o=document.createElement("div"),r=e.sender.charAt(0).toUpperCase();o.textContent=r,this.applyStyles(o,{width:"36px",height:"36px",borderRadius:"50%",backgroundColor:this.getAvatarColor(e.sender),color:"white",display:"flex",alignItems:"center",justifyContent:"center",fontWeight:"bold",fontSize:"14px",flexShrink:"0"});let s=document.createElement("div");this.applyStyles(s,{flex:"1"});let i=document.createElement("div");this.applyStyles(i,{display:"flex",alignItems:"baseline",gap:"8px",marginBottom:"4px"});let a=document.createElement("span");a.textContent=e.senderDisplayName,this.applyStyles(a,{fontWeight:"bold",fontSize:"14px"});let l=document.createElement("span");l.textContent=this.formatTime(e.timestamp),this.applyStyles(l,{color:"#666",fontSize:"12px"}),i.appendChild(a),i.appendChild(l);let c=document.createElement("div");return c.textContent=e.text,this.applyStyles(c,{fontSize:"14px",lineHeight:"1.4",whiteSpace:"pre-wrap",wordBreak:"break-word"}),s.appendChild(i),s.appendChild(c),n.appendChild(o),n.appendChild(s),n}getAvatarColor(e){let n=["#2196F3","#4CAF50","#FFC107","#9C27B0","#F44336","#009688","#3F51B5","#FF5722"],o=0;for(let s=0;s<e.length;s++)o=e.charCodeAt(s)+((o<<5)-o);let r=Math.abs(o)%n.length;return n[r]}formatTime(e){return new Date(e).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}createChatInput(){let e=document.createElement("div");this.applyStyles(e,{padding:"16px",borderTop:"1px solid #e0e0e0",backgroundColor:"#f9f9f9"});let n=document.createElement("form");this.applyStyles(n,{display:"flex",gap:"12px",alignItems:"flex-end"});let o=document.createElement("textarea");o.placeholder=`Message #${this.selectedChannel}`,o.rows=1,this.applyStyles(o,{flex:"1",padding:"12px",border:"1px solid #ddd",borderRadius:"6px",resize:"none",fontSize:"14px",fontFamily:"inherit",minHeight:"44px",maxHeight:"120px"}),o.addEventListener("input",()=>{o.style.height="auto",o.style.height=o.scrollHeight+"px"});let r=this.createIconButton("\u{1F4CE}","Add attachment"),s=this.createIconButton("\u{1F60A}","Add emoji"),i=document.createElement("button");return i.textContent="Send",i.type="submit",this.applyStyles(i,{padding:"0 16px",height:"36px",backgroundColor:_.primary,color:"white",border:"none",borderRadius:"4px",fontSize:"14px",fontWeight:"bold",cursor:"pointer"}),i.addEventListener("mouseover",()=>{i.style.backgroundColor=_.secondary}),i.addEventListener("mouseout",()=>{i.style.backgroundColor=_.primary}),n.addEventListener("submit",a=>{a.preventDefault();let l=o.value.trim();l&&(console.log(`[CRM Extension] Sending message to #${this.selectedChannel}: ${l}`),o.value="",o.style.height="auto",o.focus())}),n.appendChild(o),n.appendChild(r),n.appendChild(s),n.appendChild(i),e.appendChild(n),e}createUserPanel(){let e="240px",n=document.createElement("div");this.applyStyles(n,{width:e,minWidth:e,height:"100%",borderLeft:"1px solid #e0e0e0",display:"flex",flexDirection:"column",backgroundColor:"#f8f9fa",transform:"translateX(0)",transition:"transform 0.3s ease-in-out",position:"relative"});let o=document.createElement("div");this.applyStyles(o,{padding:"14px 16px",borderBottom:"1px solid #e0e0e0",display:"flex",alignItems:"center",justifyContent:"space-between",fontSize:"16px",fontWeight:"bold"}),o.textContent="Team Members";let r=this.createIconButton("\xD7","Hide team members");r.addEventListener("click",()=>{this.toggleUserList()}),o.appendChild(r);let s=document.createElement("div");this.applyStyles(s,{padding:"12px 16px",borderBottom:"1px solid #e0e0e0"});let i=document.createElement("input");i.type="text",i.placeholder="Search users...",this.applyStyles(i,{width:"100%",padding:"8px 12px",border:"1px solid #ddd",borderRadius:"16px",fontSize:"14px"}),s.appendChild(i);let a=document.createElement("div");this.applyStyles(a,{flex:"1",overflowY:"auto",padding:"8px 0"});let l=document.createElement("div");l.textContent=this.mockUsers.length,this.applyStyles(l,{position:"absolute",right:"16px",top:"16px",minWidth:"20px",height:"20px",backgroundColor:"#4CAF50",color:"white",borderRadius:"10px",fontSize:"12px",fontWeight:"bold",display:"flex",alignItems:"center",justifyContent:"center",padding:"0 6px"});let c=this.mockUsers.filter(u=>u.status==="online"),p=this.mockUsers.filter(u=>u.status==="away"),h=this.mockUsers.filter(u=>u.status==="dnd"),f=this.mockUsers.filter(u=>u.status==="offline");if(c.length>0&&this.addUserGroup(a,"Online",c),p.length>0&&this.addUserGroup(a,"Away",p),h.length>0&&this.addUserGroup(a,"Do Not Disturb",h),f.length>0&&this.addUserGroup(a,"Offline",f),this.mockUsers.length===0){let u=document.createElement("div");this.applyStyles(u,{padding:"16px",textAlign:"center",color:"#666",fontSize:"14px"}),u.textContent="No users available",a.appendChild(u)}return n.appendChild(o),n.appendChild(l),n.appendChild(s),n.appendChild(a),n}addUserGroup(e,n,o){let r=document.createElement("div");this.applyStyles(r,{padding:"8px 16px",fontSize:"12px",color:"#666",fontWeight:"bold",display:"flex",alignItems:"center",justifyContent:"space-between"}),r.textContent=n;let s=document.createElement("span");s.textContent=o.length,this.applyStyles(s,{fontSize:"12px",backgroundColor:"#eee",color:"#666",borderRadius:"10px",padding:"1px 6px"}),r.appendChild(s);let i=document.createElement("div");o.forEach(a=>{let l=this.createUserItem(a);i.appendChild(l)}),e.appendChild(r),e.appendChild(i)}createUserItem(e){let n=document.createElement("div");this.applyStyles(n,{padding:"8px 16px",display:"flex",alignItems:"center",cursor:"pointer",fontSize:"14px"});let o=document.createElement("div"),r=e.username.charAt(0).toUpperCase();o.textContent=r,this.applyStyles(o,{width:"32px",height:"32px",borderRadius:"50%",backgroundColor:this.getAvatarColor(e.username),color:"white",display:"flex",alignItems:"center",justifyContent:"center",fontWeight:"bold",fontSize:"14px",marginRight:"8px",position:"relative"});let s={online:"#4CAF50",away:"#FFC107",dnd:"#F44336",offline:"#9E9E9E"},i=document.createElement("div");this.applyStyles(i,{position:"absolute",bottom:"0",right:"0",width:"10px",height:"10px",borderRadius:"50%",backgroundColor:s[e.status]||s.offline,border:"2px solid #f8f9fa"}),o.appendChild(i);let a=document.createElement("span");return a.textContent=e.displayName,this.applyStyles(a,{flex:"1"}),n.appendChild(o),n.appendChild(a),n.addEventListener("click",()=>{this.handleUserSelect(e)}),n.addEventListener("mouseover",()=>{n.style.backgroundColor="#f0f0f0"}),n.addEventListener("mouseout",()=>{n.style.backgroundColor="transparent"}),n}renderAdminView(e){let n=I();if(!(n&&n.role==="admin")){let r=document.createElement("div");this.applyStyles(r,{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",width:"100%",padding:"20px",textAlign:"center",color:"#721c24",backgroundColor:"#f8d7da"});let s=document.createElement("div");s.innerHTML="\u26D4",this.applyStyles(s,{fontSize:"48px",marginBottom:"16px"});let i=document.createElement("h3");i.textContent="Access Denied",this.applyStyles(i,{margin:"0 0 10px 0",fontSize:"24px"});let a=document.createElement("p");a.textContent="Administrator privileges are required to access this area.",r.appendChild(s),r.appendChild(i),r.appendChild(a),e.appendChild(r),d("admin","Access denied to admin panel");return}this.adminPanelComponent=new $t(e)}renderSettingsView(e){let n=document.createElement("div");this.applyStyles(n,{display:"flex",flexDirection:"column",width:"100%",height:"100%",padding:"20px",backgroundColor:"#ffffff"});let o=document.createElement("div");this.applyStyles(o,{marginBottom:"24px",borderBottom:"1px solid #e0e0e0",paddingBottom:"16px"});let r=document.createElement("h2");r.textContent="Settings",this.applyStyles(r,{margin:"0",fontSize:"20px",color:"#333"}),o.appendChild(r),n.appendChild(o),[{title:"Profile",icon:"\u{1F464}",description:"Manage your personal information and preferences.",settings:[{name:"Display Name",type:"text",placeholder:"Your display name"},{name:"Email",type:"email",placeholder:"Your email address"}]},{title:"Notifications",icon:"\u{1F514}",description:"Configure how you receive notifications.",settings:[{name:"Enable sound",type:"checkbox"},{name:"Desktop notifications",type:"checkbox"}]},{title:"Appearance",icon:"\u{1F3A8}",description:"Customize the look and feel of the chat.",settings:[{name:"Theme",type:"select",options:["Light","Dark","System"]},{name:"Font Size",type:"select",options:["Small","Medium","Large"]}]},{title:"Privacy & Security",icon:"\u{1F512}",description:"Manage security and privacy settings.",settings:[{name:"Change Password",type:"button",label:"Change Password"},{name:"Two-Factor Authentication",type:"checkbox"}]}].forEach(i=>{let a=this.createSettingsSection(i);n.appendChild(a)}),e.appendChild(n)}createSettingsSection(e){let n=document.createElement("div");this.applyStyles(n,{marginBottom:"24px",padding:"16px",backgroundColor:"#f8f9fa",borderRadius:"8px"});let o=document.createElement("div");this.applyStyles(o,{display:"flex",alignItems:"center",marginBottom:"12px"});let r=document.createElement("span");r.textContent=e.icon,this.applyStyles(r,{fontSize:"20px",marginRight:"8px"});let s=document.createElement("h3");s.textContent=e.title,this.applyStyles(s,{margin:"0",fontSize:"16px",color:"#333"}),o.appendChild(r),o.appendChild(s);let i=document.createElement("p");if(i.textContent=e.description,this.applyStyles(i,{margin:"0 0 16px 0",fontSize:"14px",color:"#666"}),n.appendChild(o),n.appendChild(i),e.settings&&e.settings.length){let a=document.createElement("div");this.applyStyles(a,{display:"flex",flexDirection:"column",gap:"12px"}),e.settings.forEach(l=>{let c=this.createSettingControl(l);a.appendChild(c)}),n.appendChild(a)}return n}createSettingControl(e){let n=document.createElement("div");this.applyStyles(n,{display:"flex",alignItems:"center",justifyContent:"space-between"});let o=document.createElement("label");o.textContent=e.name,this.applyStyles(o,{fontSize:"14px",color:"#333"});let r;switch(e.type){case"text":case"email":r=document.createElement("input"),r.type=e.type,r.placeholder=e.placeholder||"",this.applyStyles(r,{padding:"8px",border:"1px solid #ddd",borderRadius:"4px",width:"200px"});break;case"checkbox":r=document.createElement("input"),r.type="checkbox";break;case"select":r=document.createElement("select"),this.applyStyles(r,{padding:"8px",border:"1px solid #ddd",borderRadius:"4px",width:"200px"}),e.options&&e.options.length&&e.options.forEach(s=>{let i=document.createElement("option");i.value=s,i.textContent=s,r.appendChild(i)});break;case"button":r=document.createElement("button"),r.textContent=e.label||e.name,this.applyStyles(r,{padding:"8px 12px",backgroundColor:_.primary,color:"#fff",border:"none",borderRadius:"4px",cursor:"pointer"});break;default:r=document.createElement("span"),r.textContent="Unsupported setting type"}return n.appendChild(o),n.appendChild(r),n}applyStyles(e,n){Object.assign(e.style,n)}destroy(){this.unsubscribeConnectionStatus&&this.unsubscribeConnectionStatus(),at(),this.headerComponent&&this.headerComponent.destroy(),this.loginFormComponent&&this.loginFormComponent.destroy(),this.channelListComponent&&this.channelListComponent.destroy(),this.channelViewComponent&&this.channelViewComponent.destroy(),this.userListComponent&&this.userListComponent.destroy(),this.adminPanelComponent&&this.adminPanelComponent.destroy(),this.notificationSystem&&this.notificationSystem.destroy(),this.appElement&&this.appElement.parentNode&&this.appElement.parentNode.removeChild(this.appElement),d("system","Application destroyed")}},qt=Wt;var Gt=null;function z(){try{if(document.getElementById("hipaa-chat-container"))return console.log("[CRM Extension] Chat UI already initialized"),!0;console.log("[CRM Extension] Initializing Chat UI");let t=document.createElement("div");return t.id="hipaa-chat-container",Object.assign(t.style,{position:"fixed",bottom:"20px",right:"20px",width:"400px",height:"500px",backgroundColor:"#f0f8ff",borderRadius:"8px",boxShadow:"0 4px 12px rgba(0, 0, 0, 0.3)",zIndex:"10000",overflow:"hidden",border:"2px solid #2196F3",display:"none"}),document.body.appendChild(t),Gt=new qt(t),window.toggleChatUI=function(){console.log("[CRM Extension] toggleChatUI called");let e=document.getElementById("hipaa-chat-container");if(!e){console.error("[CRM Extension] Chat container not found");return}let n=e.style.display!=="none";if(e.style.display=n?"none":"flex",console.log(`[CRM Extension] Chat container toggled to: ${e.style.display}`),!n&&Gt)try{Gt.render()}catch(o){console.error("[CRM Extension] Error rendering chat app:",o)}},d("system","Chat UI initialized"),!0}catch(t){return console.error("[CRM Extension] Error initializing Chat UI:",t),!1}}var Jt=!1,oo=[];async function O(){if(Jt)return console.log("[CRM Extension] Chat system already initialized"),!0;try{if(console.log("[CRM Extension] Initializing HIPAA-compliant chat system"),!Tn())throw new Error("Failed to initialize storage");if(await vt(),!Fn())throw new Error("Failed to initialize auth service");if(!Wn())throw new Error("Failed to initialize user service");if(!Gn())throw new Error("Failed to initialize channel service");if(!On())throw new Error("Failed to initialize message service");return z(),d("system","HIPAA-compliant chat system initialized"),Jt=!0,console.log("[CRM Extension] HIPAA-compliant chat system initialized successfully"),Pt.getAuthState().authenticated&&ne(),!0}catch(t){return console.error("[CRM Extension] Failed to initialize chat system:",t),d("error","Failed to initialize chat system",{error:t.message}),!1}}function ro(){let t=ye(Bt());setInterval(()=>{getConnectionStatus()==="disconnected"&&(console.log("[CRM Extension] Attempting to reconnect chat"),ne())},3e4),d("system","Chat monitoring initialized")}function Xn(){return Jt}function so(t){typeof t=="function"&&!oo.includes(t)&&oo.push(t)}function Ie(t,e,n={}){let o=document.createElement("div");o.className="group";let r=document.createElement("span");r.className="label",r.textContent=`${e}:`,o.appendChild(r);let s=document.createElement("span");if(s.id=`${t}-display`,s.className="clickable-value",n.initialValue&&s.setAttribute("data-value",n.initialValue),n.icon){let l=document.createElement("span");l.className="btn-icon",l.innerHTML=n.icon,s.appendChild(l)}let i=document.createElement("span");i.textContent=n.initialValue||"",i.id=`${t}-text`,s.appendChild(i);let a=async()=>{let l=s.getAttribute("data-value")||i.textContent.trim();l&&l!==""?await ue(l)?x(`Copied ${e}: ${l}`):x(`Failed to copy ${e.toLowerCase()}`):x(`No ${e.toLowerCase()} available to copy`)};return s.addEventListener("click",()=>{n.onClick?n.onClick(s):a()}),s.title=`Click to copy ${e.toLowerCase()} to clipboard`,o.appendChild(s),o}function io(){let t=document.createElement("div");return t.className="group",t.id="crm-actions-group",t}function ao(){let t=document.createElement("div");t.className="dropdown",t.id="crm-tags-dropdown";let e=document.createElement("button");e.className="dropdown-btn",e.textContent="Tags",e.addEventListener("click",m=>{m.stopPropagation(),document.querySelectorAll(".dropdown.show").forEach(tn=>{tn!==t&&tn.classList.remove("show")}),t.classList.toggle("show")});let n=document.createElement("div");if(n.className="dropdown-content",n.style.padding="10px",!document.getElementById("tags-dropdown-styles")){let m=document.createElement("style");m.id="tags-dropdown-styles",m.textContent=`
      .nested-dropdown {
        margin-bottom: 8px;
        width: 100%;
        position: relative;
      }
      .nested-dropdown-btn {
        width: 100%;
        text-align: left;
        padding: 8px 12px;
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 3px;
        cursor: pointer;
        font-weight: bold;
        font-size: 13px;
        color: #e6e6e6;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .nested-dropdown-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      .nested-dropdown-btn:after {
        content: "\u25BC";
        font-size: 8px;
        color: #e6e6e6;
      }
      .nested-dropdown-content {
        display: none;
        padding: 5px 0 5px 10px;
        margin-top: 3px !important;
      }
      .nested-dropdown.open .nested-dropdown-content {
        display: block;
      }
      
      /* Button-style tag options */
      .tag-btn {
        display: block;
        width: 100%;
        padding: 8px 12px;
        margin-bottom: 8px;
        background-color: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 4px;
        text-align: left;
        font-size: 13px;
        color: #e6e6e6;
        cursor: pointer;
        transition: all 0.2s ease;
        font-weight: normal;
      }
      .tag-btn:hover {
        background-color: rgba(255, 255, 255, 0.15);
        border-color: rgba(255, 255, 255, 0.2);
      }
      .tag-btn:active {
        background-color: rgba(255, 255, 255, 0.2);
      }
    `,document.head.appendChild(m)}let o=document.createElement("button");o.className="tag-btn",o.textContent="Opt-in",o.addEventListener("click",()=>{lo("opt-in"),t.classList.remove("show")}),n.appendChild(o);let r=document.createElement("button");r.className="tag-btn",r.textContent="Refill-Sema-Inj",r.addEventListener("click",()=>{L("refill-sema-inj"),t.classList.remove("show")}),n.appendChild(r);let s=document.createElement("button");s.className="tag-btn",s.textContent="Refill-Tirz-Inj",s.addEventListener("click",()=>{L("refill-tirz-inj"),t.classList.remove("show")}),n.appendChild(s);let i=document.createElement("div");i.className="nested-dropdown";let a=document.createElement("button");a.className="nested-dropdown-btn",a.textContent="Vial-Semaglutide";let l=document.createElement("div");l.className="nested-dropdown-content",a.addEventListener("click",m=>{m.stopPropagation(),i.classList.toggle("open")});let c=document.createElement("button");c.className="tag-btn",c.textContent="Vial-Sema-B12",c.addEventListener("click",m=>{m.stopPropagation(),R(),L("vial-sema-b12")}),l.appendChild(c);let p=document.createElement("button");p.className="tag-btn",p.textContent="Vial-Sema-B6",p.addEventListener("click",m=>{m.stopPropagation(),R(),L("vial-sema-b6")}),l.appendChild(p);let h=document.createElement("button");h.className="tag-btn",h.textContent="Vial-Sema-Lipo",h.addEventListener("click",m=>{m.stopPropagation(),R(),L("vial-sema-lipo")}),l.appendChild(h);let f=document.createElement("button");f.className="tag-btn",f.textContent="Vial-Sema-NAD+",f.addEventListener("click",m=>{m.stopPropagation(),R(),L("vial-sema-nad+")}),l.appendChild(f),i.appendChild(a),i.appendChild(l),n.appendChild(i);let u=document.createElement("div");u.className="nested-dropdown";let k=document.createElement("button");k.className="nested-dropdown-btn",k.textContent="Vial-Tirzepatide";let w=document.createElement("div");w.className="nested-dropdown-content",k.addEventListener("click",m=>{m.stopPropagation(),u.classList.toggle("open")});let b=document.createElement("button");b.className="tag-btn",b.textContent="Vial-Tirz-Cyano",b.addEventListener("click",m=>{m.stopPropagation(),R(),L("vial-tirz-cyano")}),w.appendChild(b);let y=document.createElement("button");y.className="tag-btn",y.textContent="Vial-Tirz-NAD+",y.addEventListener("click",m=>{m.stopPropagation(),R(),L("vial-tirz-nad+")}),w.appendChild(y);let g=document.createElement("button");g.className="tag-btn",g.textContent="Vial-Tirz-Pyr",g.addEventListener("click",m=>{m.stopPropagation(),R(),L("vial-tirz-pyridoxine")}),w.appendChild(g),u.appendChild(k),u.appendChild(w),n.appendChild(u);let E=document.createElement("div");E.className="nested-dropdown";let v=document.createElement("button");v.className="nested-dropdown-btn",v.textContent="NP-Semaglutide";let A=document.createElement("div");A.className="nested-dropdown-content",v.addEventListener("click",m=>{m.stopPropagation(),E.classList.toggle("open")});let T=document.createElement("button");T.className="tag-btn",T.textContent="NP-Sema 0.125",T.addEventListener("click",m=>{m.stopPropagation(),R(),L("np-sema-0.125ml-inj")}),A.appendChild(T);let D=document.createElement("button");D.className="tag-btn",D.textContent="NP-Sema 0.25",D.addEventListener("click",m=>{m.stopPropagation(),R(),L("np-sema-0.25ml-inj")}),A.appendChild(D);let S=document.createElement("button");S.className="tag-btn",S.textContent="NP-Sema 0.5",S.addEventListener("click",m=>{m.stopPropagation(),R(),L("np-sema-0.5ml-inj")}),A.appendChild(S);let B=document.createElement("button");B.className="tag-btn",B.textContent="NP-Sema 0.75",B.addEventListener("click",m=>{m.stopPropagation(),R(),L("np-sema-0.75ml-inj")}),A.appendChild(B);let P=document.createElement("button");P.className="tag-btn",P.textContent="NP-Sema 1.0",P.addEventListener("click",m=>{m.stopPropagation(),R(),L("np-sema-1.0ml-inj")}),A.appendChild(P);let ee=document.createElement("button");ee.className="tag-btn",ee.textContent="NP-Sema 1.25",ee.addEventListener("click",m=>{m.stopPropagation(),R(),L("np-sema-1.25ml-inj")}),A.appendChild(ee);let $=document.createElement("button");$.className="tag-btn",$.textContent="NP-Sema 1.5",$.addEventListener("click",m=>{m.stopPropagation(),R(),L("np-sema-1.5ml-inj")}),A.appendChild($);let j=document.createElement("button");j.className="tag-btn",j.textContent="NP-Sema 2.0",j.addEventListener("click",m=>{m.stopPropagation(),R(),L("np-sema-2.0ml-inj")}),A.appendChild(j),E.appendChild(v),E.appendChild(A),n.appendChild(E);let G=document.createElement("div");G.className="nested-dropdown";let Ue=document.createElement("button");Ue.className="nested-dropdown-btn",Ue.textContent="NP-Tirzepatide";let te=document.createElement("div");te.className="nested-dropdown-content",Ue.addEventListener("click",m=>{m.stopPropagation(),G.classList.toggle("open")});let Te=document.createElement("button");Te.className="tag-btn",Te.textContent="NP-Tirz 0.25",Te.addEventListener("click",m=>{m.stopPropagation(),R(),L("np-tirz-0.25ml-inj")}),te.appendChild(Te);let De=document.createElement("button");De.className="tag-btn",De.textContent="NP-Tirz 0.5",De.addEventListener("click",m=>{m.stopPropagation(),R(),L("np-tirz-0.5ml-inj")}),te.appendChild(De);let Be=document.createElement("button");Be.className="tag-btn",Be.textContent="NP-Tirz 0.75",Be.addEventListener("click",m=>{m.stopPropagation(),R(),L("np-tirz-0.75ml-inj")}),te.appendChild(Be);let Ve=document.createElement("button");Ve.className="tag-btn",Ve.textContent="NP-Tirz 1.0",Ve.addEventListener("click",m=>{m.stopPropagation(),R(),L("np-tirz-1.0ml-inj")}),te.appendChild(Ve);let Pe=document.createElement("button");Pe.className="tag-btn",Pe.textContent="NP-Tirz 1.25",Pe.addEventListener("click",m=>{m.stopPropagation(),R(),L("np-tirz-1.25ml-inj")}),te.appendChild(Pe);let ze=document.createElement("button");return ze.className="tag-btn",ze.textContent="NP-Tirz 1.5",ze.addEventListener("click",m=>{m.stopPropagation(),R(),L("np-tirz-1.5ml-inj")}),te.appendChild(ze),G.appendChild(Ue),G.appendChild(te),n.appendChild(G),t.appendChild(e),t.appendChild(n),t}function R(){document.querySelectorAll(".dropdown.show").forEach(t=>t.classList.remove("show")),document.querySelectorAll(".nested-dropdown.open").forEach(t=>t.classList.remove("open"))}async function L(t){try{let[e,n]=await Promise.all([mt(),gt()]);console.log("[CRM Extension] Cleanup completed:"),console.log(`- Tags: ${e.removed}/${e.total} removed`),console.log(`- Automations: ${n.removed}/${n.total} removed`),lo(t)}catch(e){console.error("[CRM Extension] Error during cleanup:",e),x("Error during cleanup. Please try again.")}}function lo(t){let e=Wr();e?(e.focus(),setTimeout(()=>{e.value=t,e.dispatchEvent(new Event("input",{bubbles:!0})),setTimeout(()=>{let n=document.querySelectorAll(".v-list-item, .dropdown-item, .select-option, li"),o=!1;for(let r of n)if(r.textContent.toLowerCase().includes(t)){r.click(),o=!0,x(`Selected tag: ${t}`);break}if(!o){let r=document.querySelectorAll("*");for(let s of r)if(s.textContent.trim().toLowerCase()===t){s.click(),o=!0,x(`Selected tag: ${t}`);break}o||e.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",code:"Enter",keyCode:13,which:13,bubbles:!0}))}},300)},300)):x("Tags field not found")}function Wr(){let t=document.querySelector('input[placeholder="Add Tags"]');if(t)return t;let e=Array.from(document.querySelectorAll("input[placeholder]")).filter(s=>s.placeholder.toLowerCase().includes("tag"));if(e.length>0)return e[0];let n=document.querySelectorAll(".tag-input, .tags-input, .tag-container");for(let s of n){let i=s.querySelector("input");if(i)return i}if(t=document.querySelector('input[placeholder="smartList.bulkTags.addTags"]'),t)return t;let o=document.querySelectorAll(".hl-text-input");if(o.length>0)return o[0];console.error("[CRM Extension] Could not find tag input field with any strategy");let r=document.querySelectorAll("input");return console.log("[CRM Extension] All inputs on page:",r),null}var Z={"Sema/B12 Refill - Step 2":"Refill - Semaglutide/B12 Injection Refill Order - (Step 2)","Sema/B12 Vial - Step 2":"Semaglutide/B12 Vial Order - (Step 2)","Sema/B6 Vial - Step 2":"Semaglutide/B6 Vial Order - (Step 2)","Sema/Lipo Vial - Step 2":"Semaglutide/Lipo Vial Order - (Step 2)","Sema/NAD+ Vial - Step 2":"Semaglutide/NAD+ Vial Order - (Step 2)","Tirz/B6 Refill - Step 2":"Syringe - Tirzepatide/Pyridoxine Injection Order - (Step 2)","Tirz/B12 Vial - Step 2":"Tirzepatide/Cyano Vial Order - (Step 2)","Tirz/NAD+ Vial - Step 2":"Tirzepatide/NAD+ Vial Order - (Step 2)","Tirz/B6 Vial - Step 2":"Tirzepatide/Pyridoxine Vial Order - (Step 2)"};function co(){let t=document.createElement("div");t.className="dropdown",t.id="crm-automation-dropdown";let e=document.createElement("button");e.className="dropdown-btn",e.textContent="Automation",e.addEventListener("click",g=>{g.stopPropagation(),document.querySelectorAll(".dropdown.show").forEach(E=>{E!==t&&E.classList.remove("show")}),t.classList.toggle("show")});let n=document.createElement("div");if(n.className="dropdown-content",n.style.padding="10px",!document.getElementById("automation-dropdown-styles")){let g=document.createElement("style");g.id="automation-dropdown-styles",g.textContent=`
      .nested-dropdown {
        margin-bottom: 8px;
        width: 100%;
        position: relative;
      }
      .nested-dropdown-btn {
        width: 100%;
        text-align: left;
        padding: 8px 12px;
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 3px;
        cursor: pointer;
        font-weight: bold;
        font-size: 13px;
        color: #e6e6e6;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .nested-dropdown-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      .nested-dropdown-btn:after {
        content: "\u25BC";
        font-size: 8px;
        color: #e6e6e6;
      }
      .nested-dropdown-content {
        display: none;
        padding: 5px 0 5px 10px;
        margin-top: 3px !important;
      }
      .nested-dropdown.open .nested-dropdown-content {
        display: block;
      }
      
      /* Button-style options */
      .automation-btn {
        display: block;
        width: 100%;
        padding: 8px 12px;
        margin-bottom: 8px;
        background-color: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 4px;
        text-align: left;
        font-size: 13px;
        color: #e6e6e6;
        cursor: pointer;
        transition: all 0.2s ease;
        font-weight: normal;
      }
      .automation-btn:hover {
        background-color: rgba(255, 255, 255, 0.15);
        border-color: rgba(255, 255, 255, 0.2);
      }
      .automation-btn:active {
        background-color: rgba(255, 255, 255, 0.2);
      }
    `,document.head.appendChild(g)}let o=document.createElement("div");o.className="nested-dropdown";let r=document.createElement("button");r.className="nested-dropdown-btn",r.textContent="Semaglutide (Step 2)";let s=document.createElement("div");s.className="nested-dropdown-content",r.addEventListener("click",g=>{g.stopPropagation(),o.classList.toggle("open")});let i=document.createElement("button");i.className="automation-btn",i.textContent="Sema/B12 Refill - Step 2",i.addEventListener("click",g=>{g.stopPropagation(),Q(),setTimeout(()=>{X(Z["Sema/B12 Refill - Step 2"])},300)}),s.appendChild(i);let a=document.createElement("button");a.className="automation-btn",a.textContent="Sema/B12 Vial - Step 2",a.addEventListener("click",g=>{g.stopPropagation(),Q(),setTimeout(()=>{X(Z["Sema/B12 Vial - Step 2"])},300)}),s.appendChild(a);let l=document.createElement("button");l.className="automation-btn",l.textContent="Sema/B6 Vial - Step 2",l.addEventListener("click",g=>{g.stopPropagation(),Q(),setTimeout(()=>{X(Z["Sema/B6 Vial - Step 2"])},300)}),s.appendChild(l);let c=document.createElement("button");c.className="automation-btn",c.textContent="Sema/Lipo Vial - Step 2",c.addEventListener("click",g=>{g.stopPropagation(),Q(),setTimeout(()=>{X(Z["Sema/Lipo Vial - Step 2"])},300)}),s.appendChild(c);let p=document.createElement("button");p.className="automation-btn",p.textContent="Sema/NAD+ Vial - Step 2",p.addEventListener("click",g=>{g.stopPropagation(),Q(),setTimeout(()=>{X(Z["Sema/NAD+ Vial - Step 2"])},300)}),s.appendChild(p),o.appendChild(r),o.appendChild(s),n.appendChild(o);let h=document.createElement("div");h.className="nested-dropdown";let f=document.createElement("button");f.className="nested-dropdown-btn",f.textContent="Tirzepatide (Step 2)";let u=document.createElement("div");u.className="nested-dropdown-content",f.addEventListener("click",g=>{g.stopPropagation(),h.classList.toggle("open")});let k=document.createElement("button");k.className="automation-btn",k.textContent="Tirz/B6 Refill - Step 2",k.addEventListener("click",g=>{g.stopPropagation(),Q(),setTimeout(()=>{X(Z["Tirz/B6 Refill - Step 2"])},300)}),u.appendChild(k);let w=document.createElement("button");w.className="automation-btn",w.textContent="Tirz/B12 Vial - Step 2",w.addEventListener("click",g=>{g.stopPropagation(),Q(),setTimeout(()=>{X(Z["Tirz/B12 Vial - Step 2"])},300)}),u.appendChild(w);let b=document.createElement("button");b.className="automation-btn",b.textContent="Tirz/NAD+ Vial - Step 2",b.addEventListener("click",g=>{g.stopPropagation(),Q(),setTimeout(()=>{X(Z["Tirz/NAD+ Vial - Step 2"])},300)}),u.appendChild(b);let y=document.createElement("button");return y.className="automation-btn",y.textContent="Tirz/B6 Vial - Step 2",y.addEventListener("click",g=>{g.stopPropagation(),Q(),setTimeout(()=>{X(Z["Tirz/B6 Vial - Step 2"])},300)}),u.appendChild(y),h.appendChild(f),h.appendChild(u),n.appendChild(h),t.appendChild(e),t.appendChild(n),t}function Q(){document.querySelectorAll(".dropdown.show").forEach(t=>t.classList.remove("show")),document.querySelectorAll(".nested-dropdown.open").forEach(t=>t.classList.remove("open"))}function X(t){try{console.log(`[CRM Extension] Starting workflow for "${t}"`),x(`Starting workflow for "${t}"`);let e=Array.from(document.querySelectorAll("button.btn.btn-light2.btn-xs")).find(n=>n.textContent.trim().includes("Add"));if(!e){console.error("[CRM Extension] Add Automation button not found"),x("Add Automation button not found");return}console.log("[CRM Extension] Found Add button, clicking it"),e.click(),setTimeout(()=>{let n=document.querySelector('input[placeholder="Type to search"]');if(!n){console.error("[CRM Extension] Search input not found"),x("Search input not found");return}console.log("[CRM Extension] Found search input, entering 'step 2'"),n.focus(),n.value="step 2",n.dispatchEvent(new Event("input",{bubbles:!0})),setTimeout(()=>{let o=[".v-list",".dropdown-menu",".v-select-list",".vs__dropdown-menu",'[role="listbox"]',"ul",".v-menu__content"],r=null;for(let c of o){let p=document.querySelector(c);if(p&&p.querySelector("li, .v-list-item, .dropdown-item")&&p.scrollHeight>p.clientHeight){r=p,console.log(`[CRM Extension] Found scrollable dropdown container: ${c}`);break}}if(!r){let c=document.querySelector('.modal, dialog, [role="dialog"]');if(c){let p=Array.from(c.querySelectorAll("*")).filter(h=>h.scrollHeight>h.clientHeight&&h.clientHeight>50);p.length>0&&(r=p[0],console.log("[CRM Extension] Found scrollable element via fallback method"))}}if(!r){console.error("[CRM Extension] Could not find scrollable container"),x("Could not find dropdown container");return}console.log("[CRM Extension] Starting scroll wheel simulation"),console.log(`[CRM Extension] Container dimensions: ${r.scrollHeight}x${r.clientHeight}`);let s=0,i=20,a=!1;function l(){if(a||s>=i){a||(console.error("[CRM Extension] Max scroll attempts reached without finding match"),x("Option not found after scrolling"));return}s++,console.log(`[CRM Extension] Scroll attempt ${s}/${i}`);let c=new WheelEvent("wheel",{deltaY:100,bubbles:!0});r.dispatchEvent(c),r.scrollTop+=100,console.log(`[CRM Extension] Scrolled to position: ${r.scrollTop}/${r.scrollHeight}`),setTimeout(()=>{let p=r.querySelectorAll('li, .v-list-item, .dropdown-item, [role="option"]');console.log(`[CRM Extension] Found ${p.length} options after scrolling`);for(let h of p){if(!h.textContent)continue;let f=h.textContent.trim();if(f===t&&!f.includes("Provider Paid")&&!f.includes("New Patient")){console.log(`[CRM Extension] Found exact matching option: "${f}"`);try{h.scrollIntoView({block:"center"}),setTimeout(()=>{h.click(),a=!0,setTimeout(()=>{let u=Array.from(document.querySelectorAll("button")).find(k=>k.textContent.trim()==="Add");u?(console.log("[CRM Extension] Clicking Add button in dialog"),u.click(),x(`Added "${t}" workflow`)):(console.error("[CRM Extension] Add button in dialog not found"),x("Add button in dialog not found"))},1e3)},300)}catch(u){console.error("[CRM Extension] Error clicking option:",u)}break}}if(!a){if(r.scrollHeight-r.scrollTop<=r.clientHeight+20){console.log("[CRM Extension] Reached bottom of dropdown without finding match"),x(`Reached end without finding "${t}"`);return}setTimeout(l,500)}},500)}l()},1500)},1e3)}catch(e){console.error("[CRM Extension] Error in workflow:",e),x(`Error in workflow: ${e.message}`)}}function po(){let t=document.createElement("div");return t.className="group",t.id="crm-dropdowns-group",t.appendChild(co()),t.appendChild(ao()),document.addEventListener("click",e=>{document.querySelectorAll(".dropdown").forEach(o=>{o.contains(e.target)||(o.classList.remove("show"),o.querySelectorAll(".nested-dropdown").forEach(s=>{s.classList.remove("open")}))})}),qr(),t}function qr(){if(document.getElementById("custom-dropdown-styles"))return;let t=document.createElement("style");t.id="custom-dropdown-styles",t.textContent=`
    /* Improved dropdown positioning */
    .dropdown {
      position: relative !important;
      margin-right: 8px !important; /* Ensure space between dropdowns, reduced for tighter layout */
    }
    
    .dropdown:last-child {
      margin-right: 0 !important; /* Remove margin from the last dropdown */
    }
    
    .dropdown-content {
      position: absolute !important;
      background-color: #2F3A4B; /* Match toolbar background color */
      min-width: 220px !important; /* Increased width */
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.3);
      z-index: 999;
      border-radius: 4px;
      margin-top: 5px !important; /* Add space between button and dropdown */
      left: 0;
      top: 100% !important; /* Position below the button */
      display: none;
      border: 1px solid rgba(255, 255, 255, 0.1); /* Subtle border */
    }
    
    /* Ensure right-aligned dropdowns don't overflow */
    #crm-tags-dropdown .dropdown-content {
      right: 0;
      left: auto; /* Override left positioning for Tags dropdown */
    }
    
    .dropdown.show .dropdown-content {
      display: block;
    }
    
    /* Improved nested dropdown positioning */
    .nested-dropdown-content {
      margin-top: 3px !important;
      background-color: #2F3A4B; /* Match toolbar background color */
      border-radius: 4px;
      padding: 5px !important;
    }
    
    /* Style dropdown items */
    .dropdown-item {
      color: #e6e6e6; /* White text for visibility */
      padding: 10px 14px !important; /* Increased padding */
      text-decoration: none;
      display: block;
      font-size: 14px;
      cursor: pointer;
      border-radius: 3px;
      font-weight: normal;
    }
    
    .dropdown-item:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
    
    /* Fix for Vial-Sema and Vial-Tirz nested dropdowns */
    .nested-dropdown-btn {
      text-align: left !important;
      padding: 8px 12px !important;
      background-color: rgba(255, 255, 255, 0.1) !important;
      border: 1px solid rgba(255, 255, 255, 0.15) !important;
      color: #e6e6e6 !important;
      font-weight: bold !important;
    }
    
    .nested-dropdown-btn:hover {
      background-color: rgba(255, 255, 255, 0.2) !important;
    }
    
    /* Force visibility for Tags dropdown */
    #crm-tags-dropdown {
      display: flex !important;
    }
    
    #crm-tags-dropdown .dropdown-content {
      min-width: 220px !important;
    }
  `,document.head.appendChild(t)}function uo(){let t=document.createElement("div");t.className="group",t.id="crm-settings-group",t.style.position="relative";let e=document.createElement("button");e.className="btn",e.id="crm-settings-btn";let n=document.createElement("span");n.className="btn-icon",n.innerHTML="\u2699\uFE0F",e.appendChild(n);let o=document.createElement("span");o.textContent="Settings",e.appendChild(o);let r=Jr();if(e.addEventListener("click",s=>{s.stopPropagation(),r.classList.toggle("show")}),document.addEventListener("click",s=>{s.target!==e&&!e.contains(s.target)&&s.target!==r&&!r.contains(s.target)&&r.classList.remove("show")}),!document.getElementById("settings-dropdown-styles")){let s=document.createElement("style");s.id="settings-dropdown-styles",s.textContent=`
      #mcp-crm-settings-dropdown {
        display: none;
        position: absolute;
        top: calc(100% + 5px); /* Position below the button with 5px gap */
        right: 0;
        z-index: 1000;
        min-width: 230px;
        background-color: #2F3A4B;
        border-radius: 4px;
        border: 1px solid rgba(255, 255, 255, 0.1);
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
        overflow: hidden;
      }
      
      #mcp-crm-settings-dropdown.show {
        display: block;
      }
      
      .settings-header {
        padding: 10px;
        background-color: rgba(255, 255, 255, 0.1);
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        font-weight: bold;
        color: #e6e6e6;
      }
      
      .settings-body {
        padding: 10px;
        color: #e6e6e6;
      }
      
      .setting-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
        font-size: 13px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        padding-bottom: 10px;
      }
      
      .setting-item:last-child {
        margin-bottom: 0;
        border-bottom: none;
        padding-bottom: 0;
      }
      
      .setting-label {
        color: #e6e6e6;
        font-weight: normal;
      }
      
      /* Toggle switch styles */
      .switch {
        position: relative;
        display: inline-block;
        width: 40px;
        height: 20px;
      }
      
      .switch input {
        opacity: 0;
        width: 0;
        height: 0;
      }
      
      .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #555;
        transition: .4s;
        border-radius: 34px;
      }
      
      .slider:before {
        position: absolute;
        content: "";
        height: 16px;
        width: 16px;
        left: 2px;
        bottom: 2px;
        background-color: white;
        transition: .4s;
        border-radius: 50%;
      }
      
      input:checked + .slider {
        background-color: #2196F3;
      }
      
      input:focus + .slider {
        box-shadow: 0 0 1px #2196F3;
      }
      
      input:checked + .slider:before {
        transform: translateX(20px);
      }
      
      /* Version info styles */
      .version-info {
        border-top: 1px solid rgba(255, 255, 255, 0.1);
        margin-top: 10px;
        padding-top: 10px;
        font-size: 12px;
        color: #e6e6e6;
      }
      
      .version-info p {
        margin: 5px 0;
        color: #e6e6e6;
      }
      
      .version-number {
        font-weight: 600;
        color: #e6e6e6;
      }
      
      .check-updates-btn {
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 3px;
        padding: 4px 8px;
        margin-top: 5px;
        font-size: 11px;
        cursor: pointer;
        transition: background-color 0.2s;
        width: 100%;
        text-align: center;
        color: #e6e6e6;
      }
      
      .check-updates-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      
      .check-updates-btn:disabled {
        opacity: 0.6;
        cursor: not-allowed;
      }
      
      #crm-update-status {
        margin: 5px 0 0 0;
        padding: 3px 6px;
        font-size: 11px;
        border-radius: 3px;
        background-color: rgba(255, 255, 255, 0.05);
        text-align: center;
        transition: all 0.3s ease;
        color: #e6e6e6;
      }
      
      #last-update-check {
        font-size: 11px;
        margin: 5px 0;
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        color: #e6e6e6;
      }
      
      .check-status {
        font-size: 10px;
        margin-left: 5px;
        padding: 1px 4px;
        border-radius: 3px;
        font-weight: normal;
      }
      
      .loading-text {
        font-style: italic;
        color: #aaa;
      }
      
      /* Section styles */
      .setting-section {
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      }
      
      .setting-section-title {
        font-size: 12px;
        font-weight: bold;
        color: #e6e6e6;
        margin-bottom: 10px;
      }
    `,document.head.appendChild(s)}return t.appendChild(e),t.appendChild(r),t}function Gr(t){try{(typeof browser<"u"?browser:chrome).runtime.sendMessage({action:"getLastUpdateCheck"}).then(n=>{if(n&&n.success&&n.lastUpdateCheck){let o=n.lastUpdateCheck,r="",s="";o.success?o.status==="update_available"?(r="Update available",s="#4CAF50"):o.status==="no_update"?(r="No updates needed",s="#2196F3"):o.status==="throttled"?(r="Check throttled",s="#FF9800"):(r="Completed",s="#2196F3"):(r="Failed",s="#F44336"),t.innerHTML=`Last Check: <span class="version-number">${o.formattedTime}</span> <span class="check-status" style="color:${s};font-size:10px;margin-left:5px;">${r}</span>`}else t.innerHTML='Last Check: <span class="version-number">No checks recorded</span>'}).catch(n=>{console.error("[CRM Extension] Error fetching last update check:",n),t.innerHTML='Last Check: <span class="version-number">Unknown</span>'})}catch(e){console.error("[CRM Extension] Error in fetchLastUpdateCheckInfo:",e),t.innerHTML='Last Check: <span class="version-number">Error</span>'}}function Jr(){let t=document.createElement("div");t.id="mcp-crm-settings-dropdown";let e=document.createElement("div");e.className="settings-header",e.textContent="CRM+ Settings",t.appendChild(e);let n=document.createElement("div");if(n.className="settings-body",t.appendChild(n),!document.getElementById("collapsible-settings-styles")){let a=document.createElement("style");a.id="collapsible-settings-styles",a.textContent=`
      .setting-section {
        margin-bottom: 8px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        padding-bottom: 0; /* No bottom padding when collapsed */
      }
      
      .setting-section-title {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 13px;
        font-weight: bold;
        color: #e6e6e6;
        padding: 8px 0;
        cursor: pointer;
        user-select: none;
      }
      
      .setting-section-title:after {
        content: "\u25BC";
        font-size: 8px;
        color: #e6e6e6;
        transition: transform 0.2s ease;
      }
      
      .setting-section.collapsed .setting-section-title:after {
        transform: rotate(-90deg);
      }
      
      .setting-section-content {
        max-height: 500px;
        overflow: hidden;
        transition: max-height 0.3s ease, opacity 0.2s ease, margin-bottom 0.3s ease;
        opacity: 1;
        margin-bottom: 10px;
      }
      
      .setting-section.collapsed .setting-section-content {
        max-height: 0;
        opacity: 0;
        margin-bottom: 0;
      }
    `,document.head.appendChild(a)}let o=Yt("General Settings");o.content.appendChild(ie("Show Header Bar","crmplus_headerBarVisible",a=>{let l=document.getElementById("mcp-crm-header");l&&(l.style.display=a?"flex":"none",document.body.style.paddingTop=a?"32px":"0"),x(`Header bar: ${a?"Visible":"Hidden"}`)},!0)),o.content.appendChild(ie("Show Provider-Paid Alerts","crmplus_showProviderPaidAlerts",a=>{x(`Provider-Paid alerts: ${a?"Enabled":"Disabled"}`)},!0)),n.appendChild(o.section);let r=Yt("External Links");r.content.appendChild(ie("Show ShipStation Link","crmplus_showShipStation",a=>{let l=document.querySelector(".shipstation-link");l&&(l.style.display=a?"flex":"none"),x(`ShipStation link: ${a?"Visible":"Hidden"}`)},!0)),r.content.appendChild(ie("Show Stripe Link","crmplus_showStripe",a=>{let l=document.querySelector(".stripe-link");l&&(l.style.display=a?"flex":"none"),x(`Stripe link: ${a?"Visible":"Hidden"}`)},!0)),r.content.appendChild(ie("Show Webmail Link","crmplus_showWebmail",a=>{let l=document.querySelector(".webmail-link");l&&(l.style.display=a?"flex":"none"),x(`Webmail link: ${a?"Visible":"Hidden"}`)},!0)),n.appendChild(r.section);let s=Yt("Features");s.content.appendChild(ie("Auto-copy phone number on page load","crmplus_autoCopyPhone",a=>{x(`Auto-copy phone: ${a?"Enabled":"Disabled"}`)},!1)),s.content.appendChild(ie("CRM Automation","crmplus_automationEnabled",a=>{[document.getElementById("crm-automation-dropdown"),document.getElementById("crm-tags-dropdown")].forEach(c=>{c?(c.style.display=a?"flex":"none",console.log(`[CRM Extension] Changed visibility for ${c.id}: ${a?"visible":"hidden"}`)):console.error("[CRM Extension] Could not find automation element to toggle")}),x(`CRM Automation: ${a?"Enabled":"Disabled"}`)},!0)),n.appendChild(s.section);let i=Yr();return n.appendChild(i),t}function Yt(t,e=!1){let n=document.createElement("div");n.className="setting-section"+(e?" collapsed":"");let o=document.createElement("div");o.className="setting-section-title",o.textContent=t,o.addEventListener("click",()=>{n.classList.toggle("collapsed")}),n.appendChild(o);let r=document.createElement("div");return r.className="setting-section-content",n.appendChild(r),{section:n,content:r}}function Yr(){let t=document.createElement("div");t.className="version-info";let e="Loading...",n="Loading...";try{let l=(typeof browser<"u"?browser:chrome).runtime.getManifest();if(l&&l.version&&(e=l.version,e.includes("."))){let c=e.split(".");if(c.length===3&&c[0].length===4){let p=c[0],h=c[1],f=c[2];n=`${h}/${f}/${p}`}}}catch(a){console.error("[CRM Extension] Error fetching version:",a),e="Unknown",n="Unknown"}let o=document.createElement("p");o.innerHTML=`Version: <span class="version-number">${e}</span>`,t.appendChild(o);let r=document.createElement("p");r.innerHTML=`Last Updated: <span class="version-number">${n}</span>`,t.appendChild(r);let s=document.createElement("p");s.id="last-update-check",s.innerHTML='Last Check: <span class="loading-text">Loading...</span>',t.appendChild(s),Gr(s);let i=document.createElement("button");return i.className="check-updates-btn",i.textContent="Check for Updates",i.addEventListener("click",()=>{let a=typeof browser<"u"?browser:chrome;i.disabled=!0,i.textContent="Checking...",x("Checking for updates...");let l=document.getElementById("crm-update-status");l||(l=document.createElement("p"),l.id="crm-update-status",l.style.fontSize="11px",l.style.marginTop="5px",l.style.color="#e6e6e6",l.textContent="",t.appendChild(l)),a.runtime.sendMessage({action:"checkForUpdates"}).then(c=>{if(c&&c.success){x("Update check completed"),c.updateStatus==="update_available"?(l.textContent=`Update available (${c.updateVersion})`,l.style.color="#4CAF50"):c.updateStatus==="no_update"?(l.textContent="You have the latest version",l.style.color="#2196F3"):c.updateStatus==="throttled"?(l.textContent="Update check throttled, try again later",l.style.color="#FF9800"):c.updateStatus==="error"?(l.textContent="Error checking for updates",l.style.color="#F44336"):(l.textContent="Update check initiated",l.style.color="#e6e6e6");let p=document.getElementById("last-update-check");if(p&&c.lastCheck){let h=c.lastCheck,f="",u="";h.success?h.status==="update_available"?(f="Update available",u="#4CAF50"):h.status==="no_update"?(f="No updates needed",u="#2196F3"):h.status==="throttled"?(f="Check throttled",u="#FF9800"):(f="Completed",u="#2196F3"):(f="Failed",u="#F44336"),p.innerHTML=`Last Check: <span class="version-number">${h.formattedTime}</span> <span class="check-status" style="color:${u};font-size:10px;margin-left:5px;">${f}</span>`}}else x("Error checking for updates"),l.textContent="Update check failed",l.style.color="#F44336";i.disabled=!1,i.textContent="Check for Updates"}).catch(c=>{console.error("[CRM Extension] Error sending update check message:",c),x("Error checking for updates"),l.textContent="Connection failed",l.style.color="#F44336",i.disabled=!1,i.textContent="Check for Updates"})}),t.appendChild(i),t}function ie(t,e,n,o=!1){let r=document.createElement("div");r.className="setting-item";let s=document.createElement("div");s.className="setting-label",s.textContent=t,r.appendChild(s);let i=document.createElement("label");i.className="switch";let a=document.createElement("input");a.type="checkbox";let l=localStorage.getItem(e),c=l!==null?l==="true":o;l===null&&localStorage.setItem(e,o.toString()),a.checked=c,a.addEventListener("change",()=>{let h=a.checked;localStorage.setItem(e,h.toString()),n&&typeof n=="function"&&n(h)});let p=document.createElement("span");return p.className="slider",i.appendChild(a),i.appendChild(p),r.appendChild(i),r}function ho(){if(document.getElementById("mcp-crm-header-styles"))return;let t=document.createElement("style");t.id="mcp-crm-header-styles",t.textContent=`
    #mcp-crm-header {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 32px;
      background-color: #2F3A4B;
      display: flex;
      align-items: center;
      padding: 0 15px;
      font-family: 'Segoe UI', 'Roboto', sans-serif;
      font-size: 12px;
      z-index: 999999;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    }
    
    #mcp-crm-header .group {
      display: flex;
      align-items: center;
      margin-right: 15px;
      border-right: 1px solid rgba(255, 255, 255, 0.1);
      padding-right: 15px;
    }
    
    #mcp-crm-header .group:last-child {
      border-right: none;
      margin-right: 0; /* Remove margin from the last group (Settings) */
    }
    
    /* Special styling for dropdowns group to match other elements' spacing */
    #crm-dropdowns-group {
      margin-right: 15px; /* Same spacing as other elements */
      padding-right: 15px; /* Same padding as other elements */
    }
    
    /* Ensure settings is positioned at the far right */
    #crm-settings-btn {
      margin-right: 0;
    }
    
    #mcp-crm-header .spacer {
      flex-grow: 1;
    }
    
    #mcp-crm-header .label {
      color: #8a9cad;
      margin-right: 6px;
      font-weight: 500;
    }
    
    #mcp-crm-header .value {
      color: #e6e6e6;
      font-weight: 600;
    }
    
    #mcp-crm-header .clickable-value {
      color: #e6e6e6;
      font-weight: 600;
      cursor: pointer;
      background-color: rgba(255, 255, 255, 0.05);
      padding: 2px 8px;
      border-radius: 3px;
      transition: background-color 0.2s;
      display: inline-flex;
      align-items: center;
    }
    
    #mcp-crm-header .clickable-value:hover {
      background-color: rgba(255, 255, 255, 0.15);
    }
    
    #mcp-crm-header .btn-icon {
      margin-right: 4px;
      font-size: 10px;
    }
    
    /* Logo link styling */
    #mcp-crm-header .logo-link {
      display: flex;
      align-items: center;
      text-decoration: none;
      transition: all 0.2s ease;
    }
    
    #mcp-crm-header .logo-link:hover {
      opacity: 0.85;
    }
    
    #mcp-crm-header .logo-icon {
      width: 16px;
      height: 16px;
      margin-right: 6px;
    }
    
    #mcp-crm-header .logo {
      font-weight: bold;
      color: white;
      font-size: 14px;
    }
    
    #mcp-crm-header .external-link {
      text-decoration: none;
      color: #e6e6e6;
      display: flex;
      align-items: center;
      transition: all 0.2s ease;
      margin-right: 10px;
    }
    
    #mcp-crm-header .external-link:hover {
      background: rgba(255, 255, 255, 0.2);
      transform: translateY(-1px);
    }
    
    #mcp-crm-header .ext-link-icon {
      font-size: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    /* Styling for text links with icons */
    #mcp-crm-header .text-link {
      text-decoration: none;
      margin-right: 4px; /* Reduced margin between buttons */
      font-size: 12px;
      padding: 3px 6px; /* Reduced horizontal padding to make buttons skinnier */
      border-radius: 3px;
      color: #e6e6e6;
      display: flex;
      align-items: center;
      justify-content: center; /* Center content horizontally */
      white-space: nowrap; /* Prevent text wrapping */
      min-width: 68px; /* Set minimum width to keep consistency */
    }
    
    #mcp-crm-header .text-link:hover {
      background-color: rgba(255, 255, 255, 0.15);
    }
    
    #mcp-crm-header .text-link .link-icon {
      margin-right: 4px; /* Slightly reduced margin for tighter look */
      width: 16px;
      height: 16px;
      vertical-align: middle;
      flex-shrink: 0; /* Prevent icon from shrinking */
    }
    
    /* Add a specific class for each button to fine-tune widths if needed */
    #mcp-crm-header .shipstation-link {
      min-width: 92px;
    }
    
    #mcp-crm-header .stripe-link {
      min-width: 65px;
    }
    
    #mcp-crm-header .webmail-link {
      min-width: 78px;
    }
    
    #mcp-crm-header .btn {
      color: #e6e6e6;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 3px;
      padding: 4px 8px;
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      margin-right: 8px;
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
    }
    
    #mcp-crm-header .btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    #mcp-crm-header .btn:active {
      background-color: rgba(255, 255, 255, 0.3);
    }
    
    #mcp-crm-header .btn:last-child {
      margin-right: 0;
    }
    
    /* Dropdown styling */
    .dropdown {
      position: relative;
      display: inline-block;
      margin-right: 8px;
    }
    
    .dropdown-btn {
      color: #e6e6e6;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 3px;
      padding: 4px 8px;
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
      justify-content: space-between;
      min-width: 100px;
    }
    
    .dropdown-btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .dropdown-btn:after {
      content: "\u25BC";
      font-size: 8px;
      margin-left: 5px;
    }
    
    .dropdown-content {
      display: none;
      position: absolute;
      background-color: #2F3A4B;
      min-width: 180px;
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.3);
      z-index: 1000000;
      border-radius: 4px;
      border: 1px solid rgba(255, 255, 255, 0.1);
      margin-top: 2px;
      left: 0;
    }
    
    .dropdown.show .dropdown-content {
      display: block;
    }
    
    .dropdown-item {
      color: #e6e6e6;
      padding: 8px 12px;
      text-decoration: none;
      display: block;
      font-size: 12px;
      cursor: pointer;
      font-weight: normal;
    }
    
    .dropdown-item:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
    
    /* Nested Dropdown styling */
    .nested-dropdown {
      margin-bottom: 5px;
      width: 100%;
    }
    
    .nested-dropdown-btn {
      width: 100%;
      text-align: left;
      padding: 6px 10px;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 3px;
      cursor: pointer;
      font-weight: bold;
      font-size: 12px;
      color: #e6e6e6;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .nested-dropdown-btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .nested-dropdown-btn:after {
      content: "\u25BC";
      font-size: 8px;
      color: #e6e6e6;
    }
    
    .nested-dropdown-content {
      display: none;
      padding: 5px 0 5px 10px;
      background-color: #2F3A4B;
    }
    
    .nested-dropdown.open .nested-dropdown-content {
      display: block;
    }
    
    .nested-dropdown-item {
      display: block;
      padding: 5px 10px;
      color: #e6e6e6;
      text-decoration: none;
      font-size: 12px;
      cursor: pointer;
      border-radius: 3px;
      font-weight: normal;
    }
    
    .nested-dropdown-item:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
    
    /* Settings dropdown styling */
    #mcp-crm-settings-dropdown {
      position: absolute;
      top: 32px;
      right: 15px;
      background-color: #2F3A4B;
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 4px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.3);
      min-width: 200px;
      z-index: 1000000;
      display: none;
      color: #e6e6e6;
    }
    
    #mcp-crm-settings-dropdown.show {
      display: block;
    }
    
    #mcp-crm-settings-dropdown .settings-header {
      background-color: rgba(255, 255, 255, 0.1);
      color: #e6e6e6;
      padding: 8px 12px;
      font-weight: bold;
      border-top-left-radius: 3px;
      border-top-right-radius: 3px;
    }
    
    #mcp-crm-settings-dropdown .settings-body {
      padding: 10px;
    }
    
    #mcp-crm-settings-dropdown .setting-item {
      display: flex;
      align-items: center;
      margin-bottom: 8px;
      padding-bottom: 8px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    #mcp-crm-settings-dropdown .setting-item:last-child {
      margin-bottom: 0;
      padding-bottom: 0;
      border-bottom: none;
    }
    
    #mcp-crm-settings-dropdown .setting-label {
      flex-grow: 1;
      font-size: 13px;
      color: #e6e6e6;
    }
    
    /* Toggle switch styling */
    .switch {
      position: relative;
      display: inline-block;
      width: 40px;
      height: 20px;
    }
    
    .switch input { 
      opacity: 0;
      width: 0;
      height: 0;
    }
    
    .slider {
      position: absolute;
      cursor: pointer;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: #555;
      transition: .4s;
      border-radius: 34px;
    }
    
    .slider:before {
      position: absolute;
      content: "";
      height: 16px;
      width: 16px;
      left: 2px;
      bottom: 2px;
      background-color: white;
      transition: .4s;
      border-radius: 50%;
    }
    
    input:checked + .slider {
      background-color: #2196F3;
    }
    
    input:checked + .slider:before {
      transform: translateX(20px);
    }
    
    /* Version info section in settings */
    .version-info {
      border-top: 1px solid rgba(255, 255, 255, 0.1);
      margin-top: 10px;
      padding-top: 10px;
      font-size: 12px;
      color: #e6e6e6;
    }
    
    .version-info p {
      margin: 5px 0;
    }
    
    .version-number {
      font-weight: 600;
      color: #e6e6e6;
    }
    
    .check-updates-btn {
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 3px;
      padding: 4px 8px;
      margin-top: 5px;
      font-size: 11px;
      cursor: pointer;
      transition: background-color 0.2s;
      width: 100%;
      text-align: center;
      color: #e6e6e6;
    }
    
    .check-updates-btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .check-updates-btn:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
  `,document.head.appendChild(t)}function go(){let t=document.createElement("div");t.className="dropdown",t.id="crm-history-dropdown";let e=document.createElement("button");e.className="dropdown-btn",e.textContent="History",e.addEventListener("click",a=>{a.stopPropagation(),document.querySelectorAll(".dropdown.show").forEach(l=>{l!==t&&l.classList.remove("show")}),t.classList.toggle("show"),t.classList.contains("show")&&mo(t)});let n=document.createElement("div");if(n.className="dropdown-content",n.id="crm-history-content",n.style.width="300px",n.style.maxHeight="400px",n.style.overflowY="auto",n.style.right="0",n.style.left="auto",!document.getElementById("history-dropdown-styles")){let a=document.createElement("style");a.id="history-dropdown-styles",a.textContent=`
      #crm-history-dropdown .dropdown-content {
        padding: 0;
        right: 0;
        left: auto;
      }
      
      /* For small screens, make sure the dropdown doesn't extend beyond viewport */
      @media screen and (max-width: 768px) {
        #crm-history-dropdown .dropdown-content {
          right: 0;
          left: auto;
          max-width: 100vw;
          width: 280px; /* Slightly smaller on small screens */
        }
      }
      
      .history-header {
        padding: 10px;
        background-color: rgba(255, 255, 255, 0.1);
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      
      .history-title {
        font-weight: bold;
        color: #e6e6e6;
        font-size: 14px;
      }
      
      .history-clear-btn {
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 3px;
        padding: 2px 6px;
        font-size: 11px;
        cursor: pointer;
        color: #e6e6e6;
        transition: background-color 0.2s;
      }
      
      .history-clear-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      
      .history-empty {
        padding: 20px;
        text-align: center;
        color: #aaa;
        font-style: italic;
        font-size: 13px;
      }
      
      .history-item {
        padding: 10px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        cursor: pointer;
        transition: background-color 0.2s;
      }
      
      .history-item:hover {
        background-color: rgba(255, 255, 255, 0.1);
      }
      
      .history-item:last-child {
        border-bottom: none;
      }
      
      .history-item-row {
        display: flex;
        margin-bottom: 3px;
        width: 100%;
      }
      
      .history-item-time {
        color: #aaa;
        font-size: 11px;
        width: 60px;
        flex-shrink: 0;
        margin-right: 5px;
      }
      
      .history-item-name {
        font-weight: bold;
        color: #e6e6e6;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        flex-grow: 1;
      }
      
      .history-item-phone {
        color: #ccc;
        font-size: 12px;
        margin-left: 65px; /* Align with name (time width + margin) */
      }
    `,document.head.appendChild(a)}let o=document.createElement("div");o.className="history-header";let r=document.createElement("div");r.className="history-title",r.textContent="Recent Patients",o.appendChild(r);let s=document.createElement("button");s.className="history-clear-btn",s.textContent="Clear All",s.addEventListener("click",a=>{a.stopPropagation(),An(),mo(t),x("History cleared")}),o.appendChild(s),n.appendChild(o);let i=document.createElement("div");return i.className="history-empty",i.textContent="No patient history yet",n.appendChild(i),t.appendChild(e),t.appendChild(n),t}function mo(t){let e=t.querySelector("#crm-history-content");if(!e)return;let n=Ln(),o=e.querySelector(".history-header");if(e.innerHTML="",o&&e.appendChild(o),n.length===0){let r=document.createElement("div");r.className="history-empty",r.textContent="No patient history yet",e.appendChild(r);return}n.forEach(r=>{let s=document.createElement("div");s.className="history-item",s.addEventListener("click",()=>{window.location.href=r.url,t.classList.remove("show")});let i=document.createElement("div");i.className="history-item-row";let a=document.createElement("div");a.className="history-item-time",a.textContent=In(r.timestamp);let l=document.createElement("div");if(l.className="history-item-name",l.textContent=r.patientName||"Unknown Patient",i.appendChild(a),i.appendChild(l),s.appendChild(i),r.phoneNumber){let c=document.createElement("div");c.className="history-item-phone",c.textContent=r.phoneNumber,s.appendChild(c)}e.appendChild(s)})}var Kr=!1;function Zt(){try{if(document.getElementById("mcp-crm-header")){console.log("[uiHeaderBar] Toolbar already exists.");return}ho();let t=document.createElement("div");t.id="mcp-crm-header";let e=localStorage.getItem("crmplus_headerBarVisible")!=="false";console.log("[CRM Extension] Header visibility setting:",e),t.style.display=e?"flex":"none";let n=typeof browser<"u"?browser:chrome,o=S=>n.runtime.getURL(S),r=document.createElement("div");r.className="group";let s=document.createElement("a");s.href="https://app.mtncarerx.com/",s.className="logo-link";let i=document.createElement("img");i.src=o("assets/mcp-favicon.ico"),i.alt="",i.className="logo-icon",s.appendChild(i);let a=document.createElement("span");a.className="logo",a.textContent="CRM+",s.appendChild(a),r.appendChild(s);let l=document.createElement("div");l.className="group external-links";let c=Kt("ShipStation","https://ship15.shipstation.com/onboard","shipstation-link",o("assets/shipstation-favicon.ico"));l.appendChild(c);let p=Kt("Stripe","https://dashboard.stripe.com/login","stripe-link",o("assets/stripe-favicon.ico"));l.appendChild(p);let h=Kt("Webmail","https://p3plzcpnl506102.prod.phx3.secureserver.net:2096/cpsess5640910985/webmail/jupiter/index.html?login=1&post_login=89371011642013","webmail-link",o("assets/webmail-favicon.ico"));l.appendChild(h);let f=Ie("name","Name"),u=Ie("phone","Phone",{icon:"\u{1F4DE}",initialValue:"",onClick:async S=>{ln(S)}}),k=Ie("dob","DOB"),w=Ie("srxid","SRx ID"),b=io(),y=po(),g=document.createElement("div");g.className="spacer";let E=document.createElement("div");E.className="group right-buttons",E.style.borderRight="none",E.style.display="flex",E.style.marginRight="0";let v=document.createElement("button");v.className="chat-button btn",v.innerHTML='<span class="icon">\u{1F4AC}</span><span class="badge" style="display:none">0</span>',v.title="HIPAA-Compliant Chat",v.style.marginRight="8px";let A=v.querySelector(".badge");Object.assign(A.style,{position:"absolute",top:"0",right:"0",backgroundColor:"#f44336",color:"white",fontSize:"12px",fontWeight:"bold",padding:"2px 6px",borderRadius:"50%",display:"none"}),v.addEventListener("click",function(){if(console.log("[CRM Extension] Chat button clicked"),typeof window.toggleChatUI=="function")window.toggleChatUI();else{console.error("[CRM Extension] toggleChatUI function not available");let S=document.getElementById("hipaa-chat-container");if(S)S.style.display=S.style.display==="none"?"flex":"none",console.log("[CRM Extension] Toggled chat container visibility as fallback");else{console.error("[CRM Extension] Chat container not found");try{typeof O=="function"&&O().then(()=>{typeof window.toggleChatUI=="function"&&window.toggleChatUI()})}catch(B){console.error("[CRM Extension] Failed to initialize chat:",B)}}}});let T=go();E.appendChild(v),E.appendChild(T);let D=uo();t.appendChild(r),t.appendChild(l),t.appendChild(f),t.appendChild(u),t.appendChild(k),t.appendChild(w),t.appendChild(y),t.appendChild(b),t.appendChild(g),t.appendChild(E),t.appendChild(D),document.body.appendChild(t),document.body.style.paddingTop=e?"32px":"0",setTimeout(()=>{try{let S=localStorage.getItem("crmplus_automationEnabled")==="true";[document.getElementById("crm-automation-dropdown"),document.getElementById("crm-tags-dropdown")].forEach(P=>{P&&(P.style.display=S?"flex":"none",console.log(`[CRM Extension] Initial visibility for ${P.id}: ${S?"visible":"hidden"}`))})}catch(S){console.error("[CRM Extension] Error setting initial automation visibility:",S)}},100),H(),dn(),hn(),an(),fn(),kn(),O(),ro(),so(S=>{if(S.length>0){let B=S[0];x(`New message from ${B.sender}: ${B.text.substring(0,30)}${B.text.length>30?"...":""}`,3e3)}}),window.addEventListener("popstate",function(){console.log("[CRM Extension] Navigation detected, clearing phone display"),H()}),Zr()||H(),Kr=!0,console.log("[CRM Extension] Header successfully initialized")}catch(t){console.error("[CRM Extension] Critical error creating toolbar:",t);try{let e=document.getElementById("mcp-crm-header");e&&(e.style.display="flex")}catch(e){console.error("[CRM Extension] Failed to recover toolbar:",e)}}}function Kt(t,e,n="",o=""){let r=document.createElement("a");r.href=e,r.target="_blank",r.className=`text-link btn ${n}`,r.rel="noopener noreferrer";let s=document.createElement("div");if(s.style.display="flex",s.style.alignItems="center",s.style.justifyContent="center",s.style.width="100%",o){let a=document.createElement("img");a.src=o,a.alt="",a.className="link-icon",a.style.width="16px",a.style.height="16px",a.style.marginRight="4px",s.appendChild(a)}let i=document.createElement("span");return i.textContent=t,s.appendChild(i),r.appendChild(s),r}function Zr(){let t=window.location.href;return[/\/patient\/\d+/i,/\/contact\/\d+/i,/\/profile\/\d+/i,/[?&]patient_id=\d+/i,/[?&]contact_id=\d+/i].some(o=>o.test(t))?!0:['input[name="contact.phone"]','input[name="contact.first_name"]','input[name="contact.last_name"]','input[name="contact.date_of_birth"]',".patient-info",".contact-details",".patient-header",".patient-profile"].some(o=>document.querySelector(o)!==null)}function Qt(t){try{let e=document.getElementById("mcp-crm-header");if(e){console.log(`[CRM Extension] Setting header visibility to: ${t}`),e.style.display=t?"flex":"none";let n=document.body.classList.contains("has-alert");return t?(document.body.style.paddingTop=n?"72px":"32px",document.body.classList.remove("no-header")):(document.body.style.paddingTop=n?"40px":"0",document.body.classList.add("no-header")),localStorage.setItem("crmplus_headerBarVisible",t.toString()),!0}else if(t)return console.log("[CRM Extension] Header not found but should be visible, creating it"),Zt(),!0;return!1}catch(e){return console.error("[CRM Extension] Error toggling header visibility:",e),!1}}function fo(){if(!(localStorage.getItem("crmplus_autoCopyPhone")==="true")){console.log("[CRM Extension] Auto-copy phone is disabled");return}let e=()=>{let o=_e();if(o){let r=ht(o);r&&ue(r).then(s=>{if(s)return x("Phone number auto-copied: "+r),!0})}return!1};if(e())return;let n=new MutationObserver((o,r)=>{e()&&r.disconnect()});n.observe(document.body,{childList:!0,subtree:!0,attributes:!0,characterData:!0}),setTimeout(()=>{n.disconnect(),e()},5e3)}var yo=!1,Re=new Set,lt="",en=!1,ct=null,Xt=null;function Co(){yo||(Qr(),Xr(),yo=!0,console.log("[CRM Extension] Alert system initialized"))}function Qr(){if(document.getElementById("crm-alert-styles"))return;let t=document.createElement("style");t.id="crm-alert-styles",t.textContent=`
    .crm-alert-banner {
      position: fixed;
      top: 32px; /* Positioned right below the header bar */
      left: 0;
      right: 0;
      width: 100%;
      padding: 4px 15px; /* Reduced vertical padding for smaller height */
      font-size: 13px;
      font-weight: 500;
      z-index: 999990;
      display: flex;
      align-items: center;
      justify-content: center; /* Center contents horizontally */
      transition: all 0.3s ease;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
      transform: translateY(-100%);
      opacity: 0;
      height: 25px; /* Fixed height at 3/4 of original (approx) */
    }
    
    .crm-alert-banner.show {
      transform: translateY(0);
      opacity: 1;
    }
    
    .crm-alert-banner .alert-icon {
      margin-right: 8px;
      font-size: 16px;
    }
    
    .crm-alert-banner .alert-message {
      text-align: center; /* Center the text */
      margin: 0 auto; /* Center with auto margins */
      flex-grow: 0; /* Don't grow to fill space */
    }
    
    /* Provider Paid specific alert styling */
    .crm-alert-banner.provider-paid {
      background-color: #FFAB40; /* Orange */
      color: #5F4200;
      border-bottom: 1px solid #FF9100;
    }
    
    /* Adjust body padding to accommodate the alert banner */
    body.has-alert {
      padding-top: 72px !important; /* 32px (header) + approx alert height */
    }
    
    /* When header is hidden but alert is visible */
    body.no-header.has-alert {
      padding-top: 25px !important; /* Just the alert height */
    }
    
    /* Multiple alerts stacking */
    .crm-alert-banner.second-alert {
      top: 57px;
    }
    
    .crm-alert-banner.third-alert {
      top: 82px;
    }
    
    /* Countdown timer styling */
    .countdown-timer {
      margin-left: 5px;
      font-size: 11px;
      opacity: 0.75;
      background-color: rgba(0, 0, 0, 0.1);
      padding: 1px 4px;
      border-radius: 3px;
      min-width: 30px;
      text-align: center;
    }
  `,document.head.appendChild(t)}function xo(){let t=window.location.href,e=[/\/patient\/(\d+)/i,/\/contact\/(\d+)/i,/\/profile\/(\d+)/i,/[?&]patient_id=(\d+)/i,/[?&]contact_id=(\d+)/i];for(let n of e){let o=t.match(n);if(o&&o[1])return o[1]}return""}function Xr(){lt=xo(),dt(),ct&&ct.disconnect(),ct=new MutationObserver(t=>{for(let e of t)e.type==="childList"&&dt(),e.type==="attributes"&&(e.target.classList.contains("tag")||e.target.classList.contains("tag-label")||e.target.classList.contains("provider-paid"))&&dt()}),ct.observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["class","data-tag"]}),Xt&&clearInterval(Xt),Xt=setInterval(()=>{let t=xo();t!==lt&&(console.log("[CRM Extension] Navigation detected, patient changed from",lt,"to",t),lt=t,en=!1,pt("provider-paid"),setTimeout(dt,1e3))},1e3)}function dt(){if(!(localStorage.getItem("crmplus_showProviderPaidAlerts")!=="false")){pt("provider-paid");return}es()?en||ts():pt("provider-paid")}function es(){let t=document.querySelectorAll(".tag, .tag-label, .pill, .badge");for(let r of t)if(r.textContent.toLowerCase().includes("provider-paid"))return r;let e=document.querySelectorAll(".provider-paid");if(e.length>0)return e[0];let n=document.querySelectorAll('[data-tag="provider-paid"], [data-tag-name="provider-paid"]');if(n.length>0)return n[0];let o=document.querySelectorAll(".tags-container, .tag-list, .tags");for(let r of o)if(r.textContent.toLowerCase().includes("provider-paid"))return r;return null}function ts(){if(Re.has("provider-paid"))return;en=!0;let t=document.createElement("div");t.className="crm-alert-banner provider-paid",t.id="provider-paid-alert",t.setAttribute("data-alert-type","provider-paid");let e=document.createElement("span");e.className="alert-icon",e.innerHTML="\u26A0\uFE0F",t.appendChild(e);let n=document.createElement("span");n.className="alert-message",n.textContent="This patient has Provider Paid status. Special billing rules apply.";let o=document.createElement("span");o.className="countdown-timer",o.textContent="30",n.appendChild(o),t.appendChild(n),document.body.appendChild(t),ns(t),setTimeout(()=>{t.classList.add("show"),document.body.classList.add("has-alert")},10),Re.add("provider-paid");let r=document.getElementById("mcp-crm-header");r&&r.style.display==="none"?document.body.classList.add("no-header"):document.body.classList.remove("no-header"),console.log("[CRM Extension] Provider Paid alert shown");let s=15,i=setInterval(()=>{s--,o&&(o.textContent=s),s<=0&&(clearInterval(i),pt("provider-paid"))},1e3)}function ns(t){let e=Re.size;e===1?t.classList.add("second-alert"):e===2&&t.classList.add("third-alert")}function pt(t){let e=document.querySelector(`.crm-alert-banner[data-alert-type="${t}"]`);e&&(e.classList.remove("show"),Re.delete(t),setTimeout(()=>{e.parentNode&&e.parentNode.removeChild(e),Re.size===0&&document.body.classList.remove("has-alert"),os()},300))}function os(){document.querySelectorAll(".crm-alert-banner").forEach((e,n)=>{e.classList.remove("second-alert","third-alert"),n===1?e.classList.add("second-alert"):n===2&&e.classList.add("third-alert")})}console.log("[CRM Extension] Content script injected.");var Ne=typeof browser<"u"?browser:chrome;Ne.runtime.sendMessage({action:"loadSettings"}).then(t=>{t&&t.success&&(console.log("[CRM Extension] Settings loaded from browser storage on startup:",t.settings),document.getElementById("mcp-crm-header")||ae())}).catch(t=>{console.error("[CRM Extension] Error requesting settings on startup:",t)});localStorage.getItem("crmplus_headerBarVisible")===null?(console.log("[CRM Extension] No local toolbar visibility setting, requesting from browser storage"),Ne.runtime.sendMessage({action:"loadSettings"}).then(t=>{t&&t.success?(console.log("[CRM Extension] Settings loaded from browser storage:",t.settings),ae()):(console.error("[CRM Extension] Failed to load settings, using defaults"),localStorage.setItem("crmplus_headerBarVisible","true"),ae())}).catch(t=>{console.error("[CRM Extension] Error requesting settings:",t),localStorage.setItem("crmplus_headerBarVisible","true"),ae()})):(console.log("[CRM Extension] Using existing localStorage settings"),ae());function ae(){let t=localStorage.getItem("crmplus_headerBarVisible")!=="false";console.log("[CRM Extension] Header visibility setting on init:",t);try{console.log("[CRM Extension] Creating fixed header..."),Zt(),Qt(t)}catch(e){console.error("[CRM Extension] Error creating fixed header:",e)}try{nn(e=>{console.log(`[CRM Extension] Intercepted console message: ${e}`)})}catch(e){console.error("[CRM Extension] Error initializing console monitor:",e)}try{fo()}catch(e){console.error("[CRM Extension] Error initializing auto phone copy:",e)}try{Co()}catch(e){console.error("[CRM Extension] Error initializing alert system:",e)}try{yn()}catch(e){console.error("[CRM Extension] Error initializing tag removal system:",e)}try{bn()}catch(e){console.error("[CRM Extension] Error initializing automation removal system:",e)}H();try{O().then(()=>{console.log("[CRM Extension] Chat system initialized successfully"),setTimeout(()=>{typeof z=="function"?(z(),console.log("[CRM Extension] Explicitly initialized Chat UI")):console.error("[CRM Extension] initChatUI function not found")},500)})}catch(e){console.error("[CRM Extension] Error initializing chat system:",e)}}document.addEventListener("click",function(t){if(t.target.closest(".chat-button")&&(console.log("[CRM Extension] Chat button clicked (global event listener)"),console.log("window.toggleChatUI exists:",typeof window.toggleChatUI=="function"),console.log("Chat container exists:",!!document.getElementById("hipaa-chat-container")),!document.getElementById("hipaa-chat-container"))){console.log("[CRM Extension] Chat container not found, initializing chat UI...");try{typeof z=="function"&&(z(),setTimeout(()=>{if(typeof window.toggleChatUI=="function")window.toggleChatUI();else{let n=document.getElementById("hipaa-chat-container");n&&(n.style.display=n.style.display==="none"?"flex":"none")}},100))}catch(n){console.error("[CRM Extension] Error initializing chat UI:",n)}}});Ne.runtime.onMessage.addListener((t,e,n)=>{if(console.log("[CRM Extension] Received message:",t),t.action==="toggleHeaderVisibility"){console.log("[CRM Extension] Toggling header visibility to:",t.isVisible);try{let o=Qt(t.isVisible);localStorage.setItem("crmplus_headerBarVisible",t.isVisible.toString()),Ne.runtime.sendMessage({action:"syncSettings"}).catch(r=>console.error("[CRM Extension] Error syncing settings:",r)),n({success:o})}catch(o){console.error("[CRM Extension] Error toggling header visibility:",o),n({success:!1,error:o.message})}return!0}if(t.action==="initializeChat"){try{O().then(()=>{typeof z=="function"?(z(),n({success:!0})):n({success:!1,error:"initChatUI function not found"})})}catch(o){console.error("[CRM Extension] Error initializing chat:",o),n({success:!1,error:o.message})}return!0}return!1});document.addEventListener("DOMContentLoaded",()=>{if(console.log("[CRM Extension] DOM fully loaded, checking visibility setting"),document.getElementById("mcp-crm-header")||Ne.runtime.sendMessage({action:"loadSettings"}).then(t=>{t&&t.success&&ae()}).catch(()=>{localStorage.setItem("crmplus_headerBarVisible","true"),ae()}),!document.getElementById("hipaa-chat-container"))try{O().then(()=>{typeof z=="function"&&z()})}catch(t){console.error("[CRM Extension] Error initializing chat on DOMContentLoaded:",t)}});try{window.addEventListener("load",()=>{console.log("[CRM Extension] Window loaded, initializing chat..."),O().then(()=>{typeof z=="function"&&z()})})}catch(t){console.error("[CRM Extension] Critical error initializing chat on window.load:",t)}})();
