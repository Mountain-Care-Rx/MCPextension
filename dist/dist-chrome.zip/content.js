(()=>{var lr=Object.create;var Lt=Object.defineProperty;var cr=Object.getOwnPropertyDescriptor;var dr=Object.getOwnPropertyNames;var pr=Object.getPrototypeOf,ur=Object.prototype.hasOwnProperty;var hr=(t,e)=>()=>(e||t((e={exports:{}}).exports,e),e.exports),ye=(t,e)=>{for(var n in e)Lt(t,n,{get:e[n],enumerable:!0})},Mt=(t,e,n,o)=>{if(e&&typeof e=="object"||typeof e=="function")for(let r of dr(e))!ur.call(t,r)&&r!==n&&Lt(t,r,{get:()=>e[r],enumerable:!(o=cr(e,r))||o.enumerable});return t},O=(t,e,n)=>(Mt(t,e,"default"),n&&Mt(n,e,"default")),Ln=(t,e,n)=>(n=t!=null?lr(pr(t)):{},Mt(e||!t||!t.__esModule?Lt(n,"default",{value:t,enumerable:!0}):n,t));var Gt=hr(()=>{});function An(t){if(window.__crmConsoleMonitor)return;window.__crmConsoleMonitor=!0;let e=console.log,n=console.error,o=console.warn;console.log=function(...r){e.apply(console,r),!(typeof r[0]=="string"&&r[0].includes("[CRM Extension]"))&&At(r,"log",t)},console.error=function(...r){n.apply(console,r),!(typeof r[0]=="string"&&r[0].includes("[CRM Extension]"))&&At(r,"error",t)},console.warn=function(...r){o.apply(console,r),!(typeof r[0]=="string"&&r[0].includes("[CRM Extension]"))&&At(r,"warn",t)}}function At(t,e,n){let o=t.join(" ");["error","failed","unauthorized","critical"].some(s=>o.toLowerCase().includes(s))&&n(o)}var Rn=window.location.href,Se="";function He(){if(!In())return"";let t=document.querySelector('input[name="contact.phone"]');if(t&&t.value.trim()!=="")return t.value.trim();let e=document.querySelector(".phone-number .number");if(e&&e.textContent.trim()!=="")return e.textContent.trim();let n=['input[placeholder="Phone"]','input[placeholder="Phone Number"]',".patient-info .phone",".contact-info .phone","span.phone",'label[for*="phone"]',".phone-display",'div[data-field="phone"]','span[data-field="phone_number"]'];for(let o of n){let r=document.querySelector(o);if(r)if(r.tagName==="INPUT"){let s=r.value.trim();if(s)return s}else if(r.tagName==="LABEL"){let s=r.getAttribute("for");if(s){let a=document.getElementById(s);if(a&&a.value.trim())return a.value.trim()}let i=r.parentElement?.querySelector("input");if(i&&i.value.trim())return i.value.trim()}else{let s=r.textContent.trim();if(s)return s}}return""}function In(){let t=window.location.href;return[/\/patient\/\d+/i,/\/contact\/\d+/i,/\/profile\/\d+/i,/[?&]patient_id=\d+/i,/[?&]contact_id=\d+/i].some(o=>o.test(t))?!0:['input[name="contact.phone"]','input[name="contact.first_name"]','input[name="contact.last_name"]','input[name="contact.date_of_birth"]',".patient-info",".contact-details",".patient-header",".patient-profile"].some(o=>document.querySelector(o)!==null)}function Nn(t){try{let e=t?mr(t):"";if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("phone",e);else{let n=document.getElementById("phone-text");if(n){n.textContent=e;let o=document.getElementById("phone-display");o&&(t?o.setAttribute("data-value",t):o.removeAttribute("data-value"))}}}catch(e){console.error("[CRM Extension] Error updating phone display:",e)}}function te(){Se="",Nn("");try{let t=document.getElementById("phone-display");t&&t.removeAttribute("data-value")}catch(t){console.error("[CRM Extension] Error clearing phone display:",t)}}function mr(t){if(!t)return"";let e=t.replace(/\D/g,"");if(e.length===0)return"";if(e.length===10)return`(${e.substring(0,3)}) ${e.substring(3,6)}-${e.substring(6)}`;if(e.length===11&&e.startsWith("1"))return`(${e.substring(1,4)}) ${e.substring(4,7)}-${e.substring(7)}`;if(e.length>4){let n="";for(let o=0;o<e.length;o+=3)if(o+4>=e.length&&e.length%3!==0){n+=" "+e.substring(o);break}else n+=" "+e.substring(o,o+3);return n.trim()}return e.replace(/(\d{3})/g,"$1 ").trim()}function je(){try{if(!In())return Se&&te(),!1;let t=He();return t?(t!==Se&&(Se=t,Nn(t)),!0):(Se&&te(),!1)}catch(t){return console.error("[CRM Extension] Error detecting phone number:",t),!1}}function Un(){te(),je();let t=setInterval(()=>{let e=window.location.href;e!==Rn&&(console.log("[CRM Extension] URL changed, resetting phone detection"),Rn=e,te()),je()},200);try{let e=new MutationObserver(o=>{je()}),n=document.body;e.observe(n,{childList:!0,subtree:!0,characterData:!0,attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] Phone number mutation observer active")}catch(e){console.error("[CRM Extension] Error setting up phone mutation observer:",e)}}function Tn(t){let e=He();if(!e){y("No phone number found");return}let n=Rt(e);if(!n){y("Invalid phone number format");return}t.setAttribute("data-value",e),we(n).then(o=>{y(o?"Copied: "+n:"Failed to copy phone number")})}function Rt(t){if(!t)return"";let e=t.replace(/\D/g,"");return e.length<7?"":"+1"+e}async function we(t){if(navigator.clipboard&&navigator.clipboard.writeText)try{return await navigator.clipboard.writeText(t),!0}catch(e){console.warn("Clipboard API failed, trying fallback method:",e)}try{let e=document.createElement("textarea");e.value=t,e.style.position="fixed",e.style.top="0",e.style.left="0",e.style.opacity="0",e.style.pointerEvents="none",document.body.appendChild(e),e.focus(),e.select();let n=document.execCommand("copy");return document.body.removeChild(e),n}catch(e){return console.error("All clipboard methods failed:",e),!1}}function y(t,e=2e3){let n=document.getElementById("crm-plus-toast-container");n||(n=document.createElement("div"),n.id="crm-plus-toast-container",n.style.position="fixed",n.style.bottom="20px",n.style.right="20px",n.style.zIndex="100000",document.body.appendChild(n));let o=document.createElement("div");o.textContent=t,o.style.background="#333",o.style.color="#fff",o.style.padding="10px",o.style.borderRadius="5px",o.style.marginTop="10px",o.style.boxShadow="0 2px 5px rgba(0,0,0,0.2)",o.style.transition="opacity 0.5s, transform 0.5s",o.style.opacity="0",o.style.transform="translateY(20px)",n.appendChild(o),o.offsetWidth,o.style.opacity="1",o.style.transform="translateY(0)",setTimeout(()=>{o.style.opacity="0",o.style.transform="translateY(20px)",setTimeout(()=>{o.parentNode&&o.parentNode.removeChild(o),n.childNodes.length===0&&document.body.removeChild(n)},500)},e)}var Pn=window.location.href;function ve(t){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("name",t);else{let e=document.getElementById("name-text");if(e){e.textContent=t;let n=document.getElementById("name-display");n&&n.setAttribute("data-value",t)}}}catch(e){console.error("[CRM Extension] Error updating name display:",e)}}function We(){try{let t=document.querySelector('input[name="contact.first_name"]'),e=document.querySelector('input[name="contact.last_name"]');if(t&&t.value&&e&&e.value){let r=`${t.value} ${e.value}`;return ve(r),!0}let n=document.querySelectorAll(".patient-name, .contact-name, h1.name, .customer-name");for(let r of n)if(r&&r.textContent&&r.textContent.trim()!==""){let s=r.textContent.trim();return ve(s),!0}let o=["span.name",".profile-name","h2.name",".contact-header .name",'div[data-field="name"]',".patient-info .name"];for(let r of o){let s=document.querySelector(r);if(s&&s.textContent&&s.textContent.trim()!==""){let i=s.textContent.trim();return ve(i),!0}}return!1}catch(t){return console.error("[CRM Extension] Error detecting name:",t),!1}}function Dn(){We();let t=setInterval(()=>{let e=window.location.href;e!==Pn&&(console.log("[CRM Extension] URL changed, resetting name detection"),Pn=e,ve(""),We());let n=document.getElementById("name-text");n&&(n.textContent==="Loading..."||!n.textContent)&&We()},1e3);try{let e=new MutationObserver(o=>{o.some(s=>s.addedNodes.length>5||s.removedNodes.length>5)&&(console.log("[CRM Extension] Significant DOM changes detected, rechecking name"),ve(""),We())}),n=document.querySelector("main")||document.body;e.observe(n,{childList:!0,subtree:!0})}catch(e){console.error("[CRM Extension] Error setting up navigation observer for name:",e)}}var Bn=window.location.href;function Ge(t){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("dob",t);else{let e=document.getElementById("dob-text");if(e){e.textContent=t;let n=document.getElementById("dob-display");n&&n.setAttribute("data-value",t)}}}catch(e){console.error("[CRM Extension] Error updating DOB display:",e)}}function Vn(t){if(!t)return"";if(t.match(/^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2}(st|nd|rd|th)?\s+\d{4}$/))try{let e=t.match(/(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+(\d{1,2})(st|nd|rd|th)?\s+(\d{4})/);if(e){let n=e[1],o=e[2],r=e[4];return`${(["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"].indexOf(n)+1).toString().padStart(2,"0")}/${o.toString().padStart(2,"0")}/${r}`}}catch(e){console.error("[CRM Extension] Error parsing date:",e)}try{let e=new Date(t);if(!isNaN(e.getTime()))return`${(e.getMonth()+1).toString().padStart(2,"0")}/${e.getDate().toString().padStart(2,"0")}/${e.getFullYear()}`}catch(e){console.error("[CRM Extension] Error parsing date as Date object:",e)}return t}function qe(){try{let t=document.querySelector('input[name="contact.date_of_birth"]');if(t&&t.value){let n=Vn(t.value);return Ge(n),!0}let e=[".dob",".patient-dob",".contact-dob",'span[data-field="date_of_birth"]','div[data-field="dob"]',".patient-info .dob",".contact-info .dob"];for(let n of e){let o=document.querySelector(n);if(o&&o.textContent&&o.textContent.trim()!==""){let r=Vn(o.textContent.trim());return Ge(r),!0}}return!1}catch(t){return console.error("[CRM Extension] Error detecting DOB:",t),!1}}function zn(){qe();let t=setInterval(()=>{let e=window.location.href;e!==Bn&&(console.log("[CRM Extension] URL changed, resetting DOB detection"),Bn=e,Ge(""),qe());let n=document.getElementById("dob-text");n&&(n.textContent==="Loading..."||!n.textContent)&&qe()},1e3);try{let e=new MutationObserver(o=>{o.some(s=>s.addedNodes.length>5||s.removedNodes.length>5)&&(console.log("[CRM Extension] Significant DOM changes detected, rechecking DOB"),Ge(""),qe())}),n=document.querySelector("main")||document.body;e.observe(n,{childList:!0,subtree:!0})}catch(e){console.error("[CRM Extension] Error setting up navigation observer for DOB:",e)}}var Fn=window.location.href,Je="";function On(t){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("srxid",t);else{let e=document.getElementById("srxid-text");if(e){e.textContent=t;let n=document.getElementById("srxid-display");n&&n.setAttribute("data-value",t)}}}catch(e){console.error("[CRM Extension] Error updating SRx ID display:",e)}}function ke(){try{let t=document.querySelector('input[name="contact.srx_id"]');if(t&&t.value){let e=t.value.trim();if(e&&/^\d+$/.test(e))return e!==Je&&(console.log("[CRM Extension] Found SRx ID from contact.srx_id input:",e),Je=e,On(e)),!0}return!!Je}catch(t){return console.error("[CRM Extension] Error detecting SRx ID:",t),!1}}function _n(){ke();let t=setInterval(()=>{let e=window.location.href;e!==Fn&&(console.log("[CRM Extension] URL changed, resetting SRx ID detection"),Fn=e,Je="",On(""),ke()),ke()},500);try{new MutationObserver(n=>{let o=!1;for(let r of n){if(r.target.tagName==="INPUT"&&r.target.name==="contact.srx_id"||r.target.querySelector&&r.target.querySelector('input[name="contact.srx_id"]')){o=!0;break}if(r.addedNodes.length>0){for(let s of r.addedNodes)if(s.nodeType===1&&s.querySelector&&(s.tagName==="INPUT"&&s.name==="contact.srx_id"||s.querySelector('input[name="contact.srx_id"]'))){o=!0;break}}}o&&ke()}).observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] SRx ID mutation observer active")}catch(e){console.error("[CRM Extension] Error setting up observer for SRx ID:",e)}setTimeout(()=>{try{let e=document.querySelector('input[name="contact.srx_id"]');e&&(new MutationObserver(o=>{ke()}).observe(e,{attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] Direct input observer attached to contact.srx_id"))}catch(e){console.error("[CRM Extension] Error setting up direct input observer:",e)}},1e3)}var Ye=["np-tirz-1.5ml-inj","refill-sema-inj","refill-tirz-inj","vial-sema-b12","vial-sema-b6","vial-sema-lipo","vial-sema-nad+","vial-tirz-cyano","vial-tirz-nad+","vial-tirz-pyridoxine","np-sema-0.125ml-inj","np-sema-0.25ml-inj","np-sema-0.5ml-inj","np-sema-0.75ml-inj","np-sema-1.0ml-inj","np-sema-1.25ml-inj","np-sema-1.5ml-inj","np-sema-2.0ml-inj","np-tirz-0.25ml-inj","np-tirz-0.5ml-inj","np-tirz-0.75ml-inj","np-tirz-1.0ml-inj","np-tirz-1.25ml-inj"],J=[];function $n(){console.log("[CRM Extension] Tag removal system initialized")}function gr(){J=[];try{let t=document.querySelectorAll(".tag, .tag-label, .pill, .badge");for(let r of t){let s=r.textContent.trim().toLowerCase();Ye.some(i=>s.includes(i))&&J.push({element:r,text:s})}let e=document.querySelectorAll("[data-tag]");for(let r of e){let s=r.getAttribute("data-tag").toLowerCase();Ye.some(i=>s.includes(i))&&J.push({element:r,text:s})}let n=document.querySelectorAll(".tags-container, .tag-list, .tags");for(let r of n){let s=r.querySelectorAll("*");for(let i of s)if(i.nodeType===1){let a=i.textContent.trim().toLowerCase();Ye.some(l=>a.includes(l))&&(J.some(l=>l.element===i)||J.push({element:i,text:a}))}}let o=document.querySelectorAll("*[class]");for(let r of o){let s=r.className.toLowerCase();s&&typeof s=="string"&&Ye.some(i=>s.includes(i))&&(J.some(i=>i.element===r)||J.push({element:r,text:r.textContent.trim().toLowerCase()}))}return console.log(`[CRM Extension] Found ${J.length} removable tags`),J}catch(t){return console.error("[CRM Extension] Error detecting tags:",t),[]}}function fr(t){try{let e=t.querySelector('.close, .remove, .delete, .tag-remove, [aria-label="Remove"], .x-button');if(e)return console.log("[CRM Extension] Found close button in tag, clicking it"),e.click(),!0;let n=t.parentElement;if(n){let s=n.querySelector('.close, .remove, .delete, .tag-remove, [aria-label="Remove"], .x-button');if(s)return console.log("[CRM Extension] Found close button as sibling, clicking it"),s.click(),!0}let o=[...Array.from(t.querySelectorAll("*")),...Array.from(n?n.children:[])];for(let s of o){let i=s.textContent.trim();if(i==="\xD7"||i==="x"||i==="\u2715"||i==="\u2716"||i==="X")return console.log("[CRM Extension] Found X button by text content, clicking it"),s.click(),!0;if(s.className&&(s.className.includes("close")||s.className.includes("delete")||s.className.includes("remove")||s.className.includes("x-button")))return console.log("[CRM Extension] Found X button by class name, clicking it"),s.click(),!0;if(s.classList&&(s.classList.contains("fa-times")||s.classList.contains("fa-close")||s.classList.contains("icon-close")||s.classList.contains("icon-remove")))return console.log("[CRM Extension] Found X button by icon class, clicking it"),s.click(),!0}if(t.tagName==="BUTTON"||t.tagName==="A"||t.getAttribute("role")==="button"||window.getComputedStyle(t).cursor==="pointer")return console.log("[CRM Extension] Tag appears to be clickable, clicking it"),t.click(),!0;let r=n;for(let s=0;s<3&&r;s++){let i=r.querySelectorAll("button, span, i, div");for(let a of i){let l=a.textContent.trim();if(l==="\xD7"||l==="x"||l==="\u2715"||l==="\u2716"||l==="X"||a.classList.contains("fa-times")||a.classList.contains("fa-close")||a.classList.contains("close")||a.classList.contains("remove"))return console.log("[CRM Extension] Found X button in parent container, clicking it"),a.click(),!0}r=r.parentElement}return console.log("[CRM Extension] No method found to remove tag:",t),!1}catch(e){return console.error("[CRM Extension] Error removing tag:",e),!1}}function It(){return new Promise((t,e)=>{try{let r=function(s){if(s>=J.length){console.log(`[CRM Extension] Removed ${n}/${o} tags`),t({success:!0,message:`Removed ${n} of ${o} tags`,removed:n,total:o});return}let i=J[s];console.log(`[CRM Extension] Removing tag: ${i.text}`),fr(i.element)&&n++,setTimeout(()=>{r(s+1)},300)};gr();let n=0,o=J.length;if(o===0){console.log("[CRM Extension] No removable tags found"),t({success:!0,message:"No tags to remove",removed:0,total:0});return}console.log(`[CRM Extension] Attempting to remove ${o} tags`),r(0)}catch(n){console.error("[CRM Extension] Error in removeAllTags:",n),e(n)}})}var xr=["Workflow - New Patient - Semaglutide 0.125ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 0.25ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 0.5ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 0.75ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 1.0ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 1.25ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 1.5ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 2.0ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 0.25ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 0.5ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 0.75ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 1.0ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 1.25ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 1.5ml Onboarding - (Step 1)","Workflow - Refill - Semaglutide/B12 Injection Refill Order - (Step 1)","Workflow - Semaglutide/B12 Vial Order - (Step 1)","Workflow - Semaglutide/B6 Vial Order - (Step 1)","Workflow - Semaglutide/Lipo Vial Order - (Step 1)","Workflow - Semaglutide/NAD+ Vial Order - (Step 1)","Workflow - Syringe - Tirzepatide/Pyridoxine Injection Order - (Step 1)","Workflow - Tirzepatide/Cyano Vial Order - (Step 1)","Workflow - Tirzepatide/NAD+ Vial Order - (Step 1)","Workflow - Tirzepatide/Pyridoxine Vial Order - (Step 1)"],Ke=[];function ne(t){try{if(t&&typeof t.getBoundingClientRect=="function")return t.getBoundingClientRect()}catch{}return{top:0,bottom:0,left:0,right:0,width:0,height:0}}function Wn(){console.log("[CRM Extension] Automation removal system initialized")}function yr(){Ke=[];try{let t=qn("Active");return t?(Ke=(t.workflows.length?t.workflows:Cr(t.label)).filter(n=>{if(!n)return!1;let o=(n.textContent||"").trim();return o.includes("Workflow")&&xr.some(r=>o.includes(r))}),console.log(`[CRM Extension] Found ${Ke.length} automation(s) in Active section.`),Ke):(console.log("[CRM Extension] Active section not found."),[])}catch(t){return console.error("[CRM Extension] Error detecting automations:",t),[]}}function Cr(t){let e=ne(t).bottom,n=null,o=qn("Past");return o&&o.label&&(n=ne(o.label).top),Array.from(document.querySelectorAll('div[id^="workflow_"], div[data-workflow-id]')).filter(s=>{let i=ne(s);return!(i.top<e||n&&i.top>=n)})}function qn(t){try{let n=Array.from(document.querySelectorAll("div.py-2")).find(s=>(s.textContent||"").trim()===t);if(n)return{label:n,workflows:t==="Active"?br(n):Er(n)};let o=t==="Active"?'[data-automation="Active"], #automation-active':'[data-automation="Past"], #automation-past',r=document.querySelector(o);return r?{label:r,workflows:[]}:null}catch(e){return console.error(`[CRM Extension] Error finding section for "${t}":`,e),null}}function br(t){let e=ne(t).bottom,o=Array.from(document.querySelectorAll("div.py-2")).find(i=>(i.textContent||"").trim()==="Past"),r=o?ne(o).top:null;return Array.from(document.querySelectorAll('div[id^="workflow_"], div[data-workflow-id]')).filter(i=>{let a=ne(i);return a.top>e&&(!r||a.top<r)})}function Er(t){let e=ne(t).bottom;return Array.from(document.querySelectorAll('div[id^="workflow_"], div[data-workflow-id]')).filter(o=>ne(o).top>e)}function Sr(t){if(!t)return console.error("[CRM Extension] removeAutomation called with undefined element."),!1;try{let e=ne(t),n=e.width>0&&e.height>0,o=e.top>=0&&e.left>=0&&e.bottom<=(window.innerHeight||document.documentElement.clientHeight);return!n||!o?(t.scrollIntoView({behavior:"smooth",block:"center"}),new Promise(r=>{setTimeout(()=>r(jn(t)),500)})):jn(t)}catch(e){return console.error("[CRM Extension] Error removing automation:",e),!1}}function jn(t){if(!t)return!1;try{let e=t.querySelectorAll("i.icon-close, i.icon.icon-close");if(e.length)return e[0].click(),!0}catch(e){console.error("[CRM Extension] Error in Strategy 1:",e)}try{let e=t.querySelectorAll("a");for(let n of e){let o=(n.textContent||"").trim();if(o==="\xD7"||o.toLowerCase()==="x")return n.click(),!0}}catch(e){console.error("[CRM Extension] Error in Strategy 2:",e)}try{let e=t.querySelectorAll('button, .btn, [role="button"]');for(let n of e)if((n.textContent||"").toLowerCase().includes("manage"))return n.click(),setTimeout(()=>{document.querySelectorAll(".dropdown-menu .dropdown-item, .menu-item").forEach(s=>{let i=(s.textContent||"").toLowerCase();(i.includes("remove")||i.includes("delete"))&&s.click()})},300),!0}catch(e){console.error("[CRM Extension] Error in Strategy 3:",e)}if(t.id&&t.id.startsWith("workflow_")){let e=t.id;try{let n=`#${e} i.icon-close, #${e} i.icon.icon-close`,o=document.querySelector(n);if(o)return o.click(),!0;n=`#${e} .remove, #${e} .close`;let r=document.querySelector(n);if(r)return r.click(),!0}catch(n){console.error("[CRM Extension] Error in Strategy 4:",n)}}try{let e=t.querySelectorAll("span");for(let n of e){let o=(n.textContent||"").trim();if(o==="\xD7"||o.toLowerCase()==="x")return n.click(),!0}}catch(e){console.error("[CRM Extension] Error in Strategy 5:",e)}try{let e=t.nextElementSibling,n=0;for(;e&&n<3;){if(e.classList&&(e.classList.contains("close")||e.classList.contains("remove"))||e.textContent&&(e.textContent.trim()==="\xD7"||e.textContent.trim().toLowerCase()==="x"))return e.click(),!0;let o=e.querySelector("i.icon-close, i.icon.icon-close");if(o)return o.click(),!0;e=e.nextElementSibling,n++}}catch(e){console.error("[CRM Extension] Error in Strategy 6:",e)}try{let e=ne(t),n=e.right-10,o=e.top+e.height/2,r=document.elementsFromPoint(n,o);for(let i of r)if(i!==t)return i.click(),!0;let s=new MouseEvent("click",{view:window,bubbles:!0,cancelable:!0,clientX:n,clientY:o});return(r[0]||document.elementFromPoint(n,o))?.dispatchEvent(s),!0}catch(e){console.error("[CRM Extension] Error in Strategy 7:",e)}return console.error("[CRM Extension] No method found to remove automation:",t),!1}function Hn(){return new Promise(t=>{setTimeout(()=>{if(document.querySelectorAll('.modal, [role="dialog"], .dialog').length){let n=document.querySelectorAll('.modal .btn-primary, .modal .btn-danger, .modal .confirm-btn, [role="dialog"] .btn-primary, .modal button, [role="dialog"] button');for(let r of n){let s=(r.textContent||"").trim().toLowerCase();if(["delete","remove","yes","confirm","ok","continue"].includes(s)){r.click(),t(!0);return}}let o=document.querySelectorAll('.modal button, [role="dialog"] button, .dialog button');if(o.length){o[o.length-1].click(),t(!0);return}}t(!1)},500)})}function Nt(){return new Promise((t,e)=>{try{let s=function(i){if(i>=r){t({success:!0,message:`Removed ${o} of ${r} automations`,removed:o,total:r});return}let a=n[i],l=Sr(a.element);l instanceof Promise?l.then(c=>{c&&o++,Hn().then(()=>setTimeout(()=>s(i+1),1e3))}):(l&&o++,Hn().then(()=>setTimeout(()=>s(i+1),1e3)))},n=yr();if(!n.length){console.log("[CRM Extension] No automations to remove."),t({success:!0,message:"No automations to remove",removed:0,total:0});return}let o=0,r=n.length;s(0)}catch(n){console.error("[CRM Extension] Error in removeAllAutomations:",n),e(n)}})}var D=[];var Ze="crmplus_history";function Kn(){Zn(),vr(),kr(),window.addEventListener("storage",wr),console.log("[CRM Extension] History tracking initialized")}function Zn(){try{let t=localStorage.getItem(Ze);if(t){D=JSON.parse(t);let e=Date.now();D=D.filter(n=>e-n.timestamp<144e5),Ut()}}catch(t){console.error("[CRM Extension] Error loading history:",t),D=[]}}function Ut(){try{localStorage.setItem(Ze,JSON.stringify(D))}catch(t){console.error("[CRM Extension] Error saving history:",t)}}function wr(t){if(t.key===Ze)try{t.newValue?(D=JSON.parse(t.newValue),console.log("[CRM Extension] History updated from another tab")):(D=[],console.log("[CRM Extension] History cleared from another tab"))}catch(e){console.error("[CRM Extension] Error processing cross-tab history update:",e)}}function vr(){let t=window.location.href;setInterval(()=>{let o=window.location.href;o!==t&&(t=o,Me(o))},500),Me(window.location.href);let e=history.pushState;history.pushState=function(){e.apply(this,arguments),Me(window.location.href)};let n=history.replaceState;history.replaceState=function(){n.apply(this,arguments),Me(window.location.href)},window.addEventListener("popstate",()=>{Me(window.location.href)})}function Me(t){if(!t)return;let e=t.match(/\/detail\/([^/]+)/);if(e&&e[1]){let n=e[1];setTimeout(()=>{let o=Gn(),r=Jn();o&&o!=="Unknown Patient"?Yn(n,o,r,t):(console.log("[CRM Extension] Patient name not found yet, retrying in 3 seconds..."),setTimeout(()=>{let s=Gn(),i=Jn();s&&s!=="Unknown Patient"?Yn(n,s,i,t):console.log("[CRM Extension] Could not retrieve patient info after retry, not adding to history")},3e3))},5e3)}}function Gn(){let t=document.getElementById("name-text");if(t&&t.textContent&&t.textContent.trim()!=="")return t.textContent.trim();let e=document.querySelector('input[name="contact.first_name"]'),n=document.querySelector('input[name="contact.last_name"]');if(e&&e.value&&n&&n.value)return`${e.value} ${n.value}`.trim();let o=[".patient-name",".contact-name","h1.name",".customer-name","span.name",".profile-name","h2.name",".contact-header .name",'div[data-field="name"]',".patient-info .name"];for(let r of o){let s=document.querySelector(r);if(s&&s.textContent&&s.textContent.trim()!=="")return s.textContent.trim()}return"Unknown Patient"}function Jn(){let t=document.getElementById("phone-text");if(t&&t.textContent&&t.textContent.trim()!=="")return t.textContent.trim();let e=document.querySelector('input[name="contact.phone"]');if(e&&e.value.trim()!=="")return e.value.trim();let n=[".phone-number .number",'input[placeholder="Phone"]','input[placeholder="Phone Number"]',".patient-info .phone",".contact-info .phone","span.phone",'div[data-field="phone"]','span[data-field="phone_number"]'];for(let o of n){let r=document.querySelector(o);if(r)if(r.tagName==="INPUT"){let s=r.value.trim();if(s)return s}else{let s=r.textContent.trim();if(s)return s}}return""}function Yn(t,e,n,o){let s=Date.now(),i=D.findIndex(a=>a.patientId===t);if(i!==-1){let a=D[i];a.timestamp=s,a.patientName=e,a.phoneNumber=n,D.splice(i,1),D.unshift(a)}else D.unshift({patientId:t,patientName:e,phoneNumber:n,url:o,timestamp:s}),D.length>20&&D.pop();Ut()}function kr(){setInterval(()=>{let t=Date.now(),e=0;D=D.filter(n=>{let o=t-n.timestamp<144e5;return o||e++,o}),e>0&&(console.log(`[CRM Extension] Removed ${e} expired history entries`),Ut())},5*60*1e3)}function Qn(){Zn();let t=Date.now();return D=D.filter(e=>t-e.timestamp<144e5),[...D]}function Xn(){D=[],localStorage.removeItem(Ze),console.log("[CRM Extension] History cleared")}function eo(t){return new Date(t).toLocaleString("en-US",{hour:"numeric",minute:"2-digit",hour12:!0})}var to="crmplus_chat_audit_log";function d(t,e,n={}){try{let o={timestamp:new Date().toISOString(),category:t,action:e,details:n,username:localStorage.getItem("crmplus_chat_username")||"Unknown",browser:Mr(),ip:"127.0.0.1"},r=no();return r.unshift(o),r.length>1e3&&(r.length=1e3),localStorage.setItem(to,JSON.stringify(r)),!0}catch(o){return console.error("[CRM Extension] Error logging audit event:",o),!1}}function no(){try{let t=localStorage.getItem(to);return t?JSON.parse(t):[]}catch(t){return console.error("[CRM Extension] Error getting audit log:",t),[]}}function Mr(){let t=navigator.userAgent,e="Unknown Browser";return t.includes("Firefox")?e="Firefox":t.includes("Edg")?e="Edge":t.includes("Chrome")?e="Chrome":t.includes("Safari")&&(e="Safari"),e}var Qe="crmplus_chat_",Pt=`${Qe}messages`,ro=`${Qe}channels`,Lr=`${Qe}users`,so=`${Qe}settings`,oo=100,Ar=24*60*60*1e3;function io(){try{return Tt(),setInterval(Tt,60*60*1e3),d("storage","Storage system initialized"),console.log("[CRM Extension] Storage system initialized"),!0}catch(t){return console.error("[CRM Extension] Error initializing storage:",t),!1}}function Dt(t){try{if(!t||!t.id)return!1;let e=t.channel||"general",n={...t,stored:Date.now()},o=Bt(),r=o[e]||[],s=r.findIndex(i=>i.id===t.id);return s>=0?r[s]=n:r.unshift(n),r.length>oo&&(r.length=oo),o[e]=r,localStorage.setItem(Pt,JSON.stringify(o)),d("storage",`Message saved from ${t.sender}`,{messageId:t.id,channel:e}),!0}catch(e){return console.error("[CRM Extension] Error saving message:",e),d("storage","Error saving message",{error:e.message}),!1}}function Bt(){try{let t=localStorage.getItem(Pt);return t?JSON.parse(t):{}}catch(t){return console.error("[CRM Extension] Error getting messages map:",t),d("storage","Error getting messages map",{error:t.message}),{}}}function Xe(t="general",e=50){try{return(Bt()[t]||[]).slice(0,e)}catch(n){return console.error("[CRM Extension] Error getting channel messages:",n),d("storage","Error getting channel messages",{error:n.message}),[]}}function Tt(){try{let t=Bt(),e=Date.now(),n=0;return Object.keys(t).forEach(o=>{let s=t[o].filter(i=>{let a=i.stored||e,l=e-a>=Ar;return l&&n++,!l});t[o]=s}),localStorage.setItem(Pt,JSON.stringify(t)),n>0&&(d("storage",`Removed ${n} expired messages`),console.log(`[CRM Extension] Removed ${n} expired messages`)),n}catch(t){return console.error("[CRM Extension] Error cleaning up messages:",t),d("storage","Error cleaning up expired messages",{error:t.message}),0}}function et(t){try{if(!t||!t.id)return!1;let e=tt(),n=e.findIndex(o=>o.id===t.id);return n>=0?e[n]=t:e.push(t),localStorage.setItem(ro,JSON.stringify(e)),d("storage",`Channel saved: ${t.name}`,{channelId:t.id}),!0}catch(e){return console.error("[CRM Extension] Error saving channel:",e),d("storage","Error saving channel",{error:e.message}),!1}}function tt(){try{let t=localStorage.getItem(ro);return t?JSON.parse(t):[]}catch(t){return console.error("[CRM Extension] Error getting channels:",t),d("storage","Error getting channels",{error:t.message}),[]}}function Vt(){try{let t=localStorage.getItem(Lr);return t?JSON.parse(t):[]}catch(t){return console.error("[CRM Extension] Error getting users:",t),d("storage","Error getting users",{error:t.message}),[]}}function j(t,e){try{if(!t)return!1;let n=ao();return n[t]=e,localStorage.setItem(so,JSON.stringify(n)),d("storage",`Setting saved: ${t}`),!0}catch(n){return console.error("[CRM Extension] Error saving setting:",n),d("storage","Error saving setting",{error:n.message}),!1}}function v(t,e=null){try{let n=ao();return t in n?n[t]:e}catch(n){return console.error("[CRM Extension] Error getting setting:",n),d("storage","Error getting setting",{error:n.message}),e}}function ao(){try{let t=localStorage.getItem(so);return t?JSON.parse(t):{}}catch(t){return console.error("[CRM Extension] Error getting settings:",t),d("storage","Error getting settings",{error:t.message}),{}}}var pe=null,Ce=null,Ot=typeof window<"u"&&window.crypto&&window.crypto.subtle;async function nt(){try{return Ot?(pe=await window.crypto.subtle.generateKey({name:"AES-GCM",length:256},!0,["encrypt","decrypt"]),Ce=window.crypto.getRandomValues(new Uint8Array(12)),console.log("[CRM Extension] Generated secure encryption keys using Web Crypto API")):(pe=lo(32),Ce=lo(16),console.warn("[CRM Extension] Using fallback encryption methods - less secure"),d("security","Using fallback encryption (not recommended for PHI)")),d("security","Generated new encryption keys"),!0}catch(t){return console.error("[CRM Extension] Error generating encryption keys:",t),d("security","Failed to generate encryption keys",{error:t.message}),!1}}function lo(t){let e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",n="";if(window.crypto&&window.crypto.getRandomValues){let o=new Uint32Array(t);window.crypto.getRandomValues(o);for(let r=0;r<t;r++)n+=e.charAt(o[r]%e.length)}else for(let o=0;o<t;o++)n+=e.charAt(Math.floor(Math.random()*e.length));return n}function zt(t){let e=new ArrayBuffer(t.length),n=new Uint8Array(e);for(let o=0;o<t.length;o++)n[o]=t.charCodeAt(o);return e}function Ft(t){return String.fromCharCode.apply(null,new Uint8Array(t))}async function Rr(t){try{let e=JSON.stringify(t),n=zt(e),o=await window.crypto.subtle.encrypt({name:"AES-GCM",iv:Ce,tagLength:128},pe,n),r=btoa(Ft(o)),s=btoa(Ft(Ce.buffer));return{id:t.id,sender:t.sender,recipient:t.recipient,channel:t.channel,encrypted:!0,encryptionMethod:"AES-GCM",encryptedData:r,iv:s,timestamp:t.timestamp,type:t.type}}catch(e){return console.error("[CRM Extension] Error encrypting with Web Crypto API:",e),co(t)}}async function Ir(t){try{let e=zt(atob(t.encryptedData)),n=zt(atob(t.iv)),o=new Uint8Array(n),r=await window.crypto.subtle.decrypt({name:"AES-GCM",iv:o,tagLength:128},pe,e),s=Ft(r);return JSON.parse(s)}catch(e){throw console.error("[CRM Extension] Error decrypting with Web Crypto API:",e),e}}function co(t){try{let e=JSON.stringify(t),n=po(e,pe);return{id:t.id,sender:t.sender,recipient:t.recipient,channel:t.channel,encrypted:!0,encryptionMethod:"XOR",encryptedData:n,timestamp:t.timestamp,type:t.type}}catch(e){return console.error("[CRM Extension] Error in legacy encryption:",e),{...t,encrypted:!1}}}function Nr(t){try{let e=po(t.encryptedData,pe);return JSON.parse(e)}catch(e){throw console.error("[CRM Extension] Error in legacy decryption:",e),e}}function po(t,e){let n="";for(let o=0;o<t.length;o++){let r=t.charCodeAt(o)^e.charCodeAt(o%e.length);n+=String.fromCharCode(r)}return btoa(n)}async function _t(t){try{return t?((!pe||!Ce)&&await nt(),Ot?await Rr(t):co(t)):null}catch(e){return console.error("[CRM Extension] Error encrypting message:",e),d("security","Encryption error",{error:e.message}),{...t,encrypted:!1}}}async function $t(t){try{if(!t||!t.encrypted)return t;if(!pe||!Ce)throw new Error("Encryption keys not available");return t.encryptionMethod==="AES-GCM"&&Ot?await Ir(t):Nr(t)}catch(e){return console.error("[CRM Extension] Error decrypting message:",e),d("security","Decryption error",{error:e.message}),{id:t.id||Ur(),sender:t.sender||"Unknown",text:"[Encrypted message - unable to decrypt]",timestamp:t.timestamp||new Date().toISOString(),type:t.type||"chat",channel:t.channel||"general"}}}function Ur(){return Date.now().toString(36)+Math.random().toString(36).substr(2,5)}var g={};ye(g,{PermissionCatalog:()=>go,addAuthListener:()=>Re,createRole:()=>Eo,createUser:()=>Co,default:()=>Wr,deleteRole:()=>wo,deleteUser:()=>Jt,forceLogoutUser:()=>Mo,generateUserImportTemplate:()=>qr,getAllPermissions:()=>uo,getAllRoles:()=>vo,getAllUsers:()=>Yt,getAuthToken:()=>be,getAvailablePermissions:()=>ko,getCurrentUser:()=>E,getPermissionsForRole:()=>mo,getSessionStatus:()=>ie,hasPermission:()=>B,importUsers:()=>Kt,initAuth:()=>lt,isAuthenticated:()=>S,login:()=>ge,logout:()=>oe,removeAuthListener:()=>Wt,resetUserPassword:()=>Zt,updateLastActivity:()=>ct,updateRole:()=>So,updateUser:()=>bo,validatePermissions:()=>ho});var qt={};ye(qt,{addAuthListener:()=>Re,getAuthToken:()=>be,getCurrentUser:()=>E,getSessionStatus:()=>ie,hasPermission:()=>B,initAuth:()=>lt,isAuthenticated:()=>S,login:()=>ge,logout:()=>oe,removeAuthListener:()=>Wt,updateLastActivity:()=>ct});var ot={};ye(ot,{PermissionCatalog:()=>go,getAllPermissions:()=>uo,getPermissionsForRole:()=>mo,hasPermission:()=>B,validatePermissions:()=>ho});var _={USER:{VIEW:"user.view",CREATE:"user.create",UPDATE:"user.update",DELETE:"user.delete",MANAGE_ROLES:"user.manage_roles"},CHANNEL:{VIEW:"channel.view",CREATE:"channel.create",UPDATE:"channel.update",DELETE:"channel.delete",INVITE:"channel.invite"},MESSAGE:{VIEW:"message.view",CREATE:"message.create",UPDATE:"message.update",DELETE:"message.delete",UPDATE_OWN:"message.update.own",DELETE_OWN:"message.delete.own"},ADMIN:{SYSTEM_SETTINGS:"admin.system_settings",AUDIT_LOG:"admin.audit_log",MANAGE_ROLES:"admin.manage_roles"}},jt={admin:Object.values(_).flatMap(Object.values),moderator:[_.USER.VIEW,_.CHANNEL.VIEW,_.CHANNEL.CREATE,_.MESSAGE.VIEW,_.MESSAGE.CREATE,_.MESSAGE.DELETE],user:[_.MESSAGE.CREATE,_.MESSAGE.VIEW,_.MESSAGE.UPDATE_OWN,_.MESSAGE.DELETE_OWN,_.CHANNEL.VIEW]};function B(t){if(!S())return!1;let e=E();return e.role==="admin"?!0:(jt[e.role]||[]).includes(t)}function uo(){let t=E();return!t||t.role!=="admin"?(d("permissions","Unauthorized permissions access attempt",{requestingUser:t?.username||"unauthenticated"}),null):{catalog:_,roleSets:jt}}function ho(t){let e=Object.values(_).flatMap(Object.values),n=t.filter(o=>!e.includes(o));return{valid:n.length===0,invalidPermissions:n}}function mo(t){let e=E();return!e||e.role!=="admin"?(d("permissions","Unauthorized role permissions access",{requestedRole:t,requestingUser:e?.username||"unauthenticated"}),[]):jt[t]||[]}var go=_;var st="crmplus_chat_auth_token",it="crmplus_chat_user_info",rt=15*60*1e3,H=null,me=null,at=Date.now(),se=null,Ae=[],Le={username:"CBarnett",password:"Admin123",role:"admin",displayName:"Admin"};function Ht(t=null){let e={authenticated:S(),user:E()};Ae.forEach(n=>{try{n(e,t)}catch(o){console.error("[CRM Extension] Error in auth listener:",o)}})}function Re(t){typeof t=="function"&&!Ae.includes(t)&&Ae.push(t)}function Wt(t){let e=Ae.indexOf(t);e!==-1&&Ae.splice(e,1)}function lt(){try{return Tr(),dt(),Dr(),Pr(),d("auth","Authentication service initialized"),!0}catch(t){return console.error("[CRM Extension] Error initializing auth service:",t),!1}}function ie(){return{authenticated:S(),user:E(),lastActivity:at,sessionTimeout:rt}}function Tr(){try{let t=localStorage.getItem(st);t&&(me=t);let e=localStorage.getItem(it);e&&(H=JSON.parse(e)),me&&H&&(at=Date.now(),Ht(),console.log("[CRM Extension] Loaded saved authentication data"),d("auth","Restored authentication session",{username:H.username}))}catch(t){console.error("[CRM Extension] Error loading saved auth data:",t),localStorage.removeItem(st),localStorage.removeItem(it)}}function Pr(){v("admin_account_created",!1)||(console.log("[CRM Extension] Setting up initial admin account"),j("admin_account_created",!0),d("auth","Initial admin account setup completed"))}function Dr(){["mousedown","keydown","touchstart","click"].forEach(e=>{document.addEventListener(e,()=>{ct()})})}function ct(){at=Date.now(),se&&clearTimeout(se),S()&&dt()}function dt(){se&&clearTimeout(se),S()&&(se=setTimeout(()=>{let t=Date.now()-at;if(t>=rt)d("auth","Session timed out due to inactivity",{username:H?.username,inactiveTime:Math.round(t/1e3)+" seconds"}),oe("Session timed out due to inactivity");else{let e=rt-t;se=setTimeout(dt,e)}},rt))}async function ge(t,e){try{if(!t||!e)throw new Error("Username and password are required");d("auth","Login attempt",{username:t});let o=(localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000").replace("ws://","http://").replace("wss://","https://"),r=null;if(t===Le.username&&e===Le.password)r={success:!0,token:"admin_"+Date.now().toString(36)+Math.random().toString(36).substr(2),user:{id:"admin_"+Math.random().toString(36).substr(2),username:Le.username,role:Le.role,displayName:Le.displayName,isAdmin:!0}};else try{let s=await fetch(`${o}/auth/login`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username:t,password:e})});if(!s.ok){let i=await s.json();throw new Error(i.message||"Login failed")}r=await s.json()}catch(s){if(console.error("[CRM Extension] Server auth error:",s),v("allow_local_auth",!1)){let a=v("local_users",[]).find(l=>l.username===t);if(a&&a.password===e)r={success:!0,token:"local_"+Date.now().toString(36)+Math.random().toString(36).substr(2),user:{id:a.id||"user_"+Math.random().toString(36).substr(2),username:a.username,role:a.role||"user",displayName:a.displayName||a.username,isLocal:!0}};else throw new Error("Invalid username or password")}else throw new Error("Server authentication failed")}if(!r||!r.success)throw new Error("Authentication failed");return me=r.token,H=r.user,localStorage.setItem(st,me),localStorage.setItem(it,JSON.stringify(H)),ct(),dt(),d("auth","Login successful",{username:H.username,role:H.role}),Ht(),{success:!0,user:H}}catch(n){return d("auth","Login failed",{username:t,error:n.message}),console.error("[CRM Extension] Login error:",n),{success:!1,error:n.message}}}function oe(t="User logout"){try{if(!S())return!1;d("auth","Logout",{username:H?.username,reason:t}),me=null;let e=H;return H=null,localStorage.removeItem(st),localStorage.removeItem(it),se&&(clearTimeout(se),se=null),Ht(e),!0}catch(e){return console.error("[CRM Extension] Logout error:",e),!1}}function S(){return!!me&&!!H}function E(){return H}function be(){return me}var pt={};ye(pt,{createRole:()=>Vr,deleteRole:()=>Fr,getAllRoles:()=>Br,updateRole:()=>zr});async function Br(){try{if(!S())return{success:!1,error:"Authentication required"};if(!B("roles.view"))return{success:!1,error:"Permission denied"};let e=(localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000").replace("ws://","http://").replace("wss://","https://");try{let n=await fetch(`${e}/admin/roles`,{method:"GET",headers:{Authorization:`Bearer ${localStorage.getItem("crmplus_chat_auth_token")}`}});if(!n.ok){let r=await n.json();throw new Error(r.message||"Failed to retrieve roles")}return{success:!0,roles:await n.json()}}catch(n){if(console.error("[CRM Extension] Server roles retrieval error:",n),v("allow_local_auth",!1))return{success:!0,roles:[{id:"user",name:"User",description:"Standard user with basic permissions",permissions:["message.create","channel.view"]},{id:"moderator",name:"Moderator",description:"User with additional moderation powers",permissions:["message.create","message.delete","channel.create","user.view"]},{id:"admin",name:"Administrator",description:"Full system access",permissions:["*"]}]};throw new Error("Server request failed: "+n.message)}}catch(t){return console.error("[CRM Extension] Roles retrieval error:",t),{success:!1,error:t.message}}}async function Vr(t){try{let e=E();if(!S())return{success:!1,error:"Authentication required"};if(!B("roles.create"))return{success:!1,error:"Permission denied"};if(!t.name)return{success:!1,error:"Role name is required"};let o=(localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000").replace("ws://","http://").replace("wss://","https://");try{let r=await fetch(`${o}/admin/roles`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${localStorage.getItem("crmplus_chat_auth_token")}`},body:JSON.stringify(t)});if(!r.ok){let i=await r.json();throw new Error(i.message||"Failed to create role")}let s=await r.json();return d("auth","Role created",{roleName:s.name,createdBy:e.username}),{success:!0,role:s}}catch(r){if(console.error("[CRM Extension] Server role creation error:",r),v("allow_local_auth",!1)){let s=v("local_roles",[]),i={id:`role_${Date.now().toString(36)}`,...t,createdAt:new Date().toISOString(),createdBy:e.id};return s.push(i),j("local_roles",s),d("auth","Local role created",{roleName:i.name,createdBy:e.username,isLocal:!0}),{success:!0,role:i}}throw new Error("Server request failed: "+r.message)}}catch(e){return console.error("[CRM Extension] Role creation error:",e),{success:!1,error:e.message}}}async function zr(t,e){try{let n=E();if(!S())return{success:!1,error:"Authentication required"};if(!B("roles.update"))return{success:!1,error:"Permission denied"};if(!t)return{success:!1,error:"Role ID is required"};let r=(localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000").replace("ws://","http://").replace("wss://","https://");try{let s=await fetch(`${r}/admin/roles/${t}`,{method:"PUT",headers:{"Content-Type":"application/json",Authorization:`Bearer ${localStorage.getItem("crmplus_chat_auth_token")}`},body:JSON.stringify(e)});if(!s.ok){let a=await s.json();throw new Error(a.message||"Failed to update role")}let i=await s.json();return d("auth","Role updated",{roleId:t,roleName:i.name,updatedBy:n.username}),{success:!0,role:i}}catch(s){if(console.error("[CRM Extension] Server role update error:",s),v("allow_local_auth",!1)){let i=v("local_roles",[]),a=i.findIndex(c=>c.id===t);if(a===-1)return{success:!1,error:"Role not found"};let l={...i[a],...e,updatedAt:new Date().toISOString(),updatedBy:n.id};return i[a]=l,j("local_roles",i),d("auth","Local role updated",{roleId:t,roleName:l.name,updatedBy:n.username,isLocal:!0}),{success:!0,role:l}}throw new Error("Server request failed: "+s.message)}}catch(n){return console.error("[CRM Extension] Role update error:",n),{success:!1,error:n.message}}}async function Fr(t){try{let e=E();if(!S())return{success:!1,error:"Authentication required"};if(!B("roles.delete"))return{success:!1,error:"Permission denied"};if(!t)return{success:!1,error:"Role ID is required"};if(["admin","moderator","user"].includes(t))return{success:!1,error:"Cannot delete default roles"};let r=(localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000").replace("ws://","http://").replace("wss://","https://");try{let s=await fetch(`${r}/admin/roles/${t}`,{method:"DELETE",headers:{Authorization:`Bearer ${localStorage.getItem("crmplus_chat_auth_token")}`}});if(!s.ok){let i=await s.json();throw new Error(i.message||"Failed to delete role")}return d("auth","Role deleted",{roleId:t,deletedBy:e.username}),{success:!0}}catch(s){if(console.error("[CRM Extension] Server role deletion error:",s),v("allow_local_auth",!1)){let i=v("local_roles",[]),a=i.findIndex(l=>l.id===t);return a===-1?{success:!1,error:"Role not found"}:(i.splice(a,1),j("local_roles",i),d("auth","Local role deleted",{roleId:t,deletedBy:e.username,isLocal:!0}),{success:!0})}throw new Error("Server request failed: "+s.message)}}catch(e){return console.error("[CRM Extension] Role deletion error:",e),{success:!1,error:e.message}}}var ut={};ye(ut,{createUser:()=>fo,deleteUser:()=>yo,getAllUsers:()=>Or,updateUser:()=>xo});async function fo(t){try{let e=E();if(!S()||e.role!=="admin")return{success:!1,error:"Administrator privileges required to create users"};if(!t.username||!t.password)return{success:!1,error:"Username and password are required"};let o=(localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000").replace("ws://","http://").replace("wss://","https://");try{let r=await fetch(`${o}/admin/users`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${localStorage.getItem("crmplus_chat_auth_token")}`},body:JSON.stringify(t)});if(!r.ok){let i=await r.json();throw new Error(i.message||"Failed to create user")}let s=await r.json();return d("auth","Admin created user",{username:s.username,role:s.role||"user"}),{success:!0,user:s}}catch(r){if(console.error("[CRM Extension] Server create user error:",r),v("allow_local_auth",!1)){let s=v("local_users",[]);if(s.some(a=>a.username===t.username))return{success:!1,error:"Username already exists"};let i={id:`user_${Date.now().toString(36)}`,...t,role:t.role||"user",displayName:t.displayName||t.username,createdAt:new Date().toISOString(),createdBy:e.id};return s.push(i),j("local_users",s),d("auth","Local user created",{username:i.username,role:i.role,isLocal:!0}),{success:!0,user:{id:i.id,username:i.username,displayName:i.displayName,role:i.role,isLocal:!0}}}throw new Error("Server request failed: "+r.message)}}catch(e){return console.error("[CRM Extension] Create user error:",e),{success:!1,error:e.message}}}async function xo(t,e){try{let n=E();if(!S())return{success:!1,error:"Authentication required"};if(t!==n.id&&n.role!=="admin")return{success:!1,error:"Permission denied"};if(!t)return{success:!1,error:"User ID is required"};let r=(localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000").replace("ws://","http://").replace("wss://","https://");try{let s=await fetch(`${r}/admin/users/${t}`,{method:"PUT",headers:{"Content-Type":"application/json",Authorization:`Bearer ${localStorage.getItem("crmplus_chat_auth_token")}`},body:JSON.stringify(e)});if(!s.ok){let a=await s.json();throw new Error(a.message||"Failed to update user")}let i=await s.json();return d("auth","User updated",{userId:t,updatedFields:Object.keys(e).join(", ")}),{success:!0,user:i}}catch(s){if(console.error("[CRM Extension] Server update user error:",s),v("allow_local_auth",!1)){let i=v("local_users",[]),a=i.findIndex(c=>c.id===t);if(a===-1)return{success:!1,error:"User not found"};let l={...i[a],displayName:e.displayName||i[a].displayName,email:e.email||i[a].email};return n.role==="admin"&&e.role&&(l.role=e.role),i[a]=l,j("local_users",i),d("auth","Updated local user",{userId:t,updatedFields:Object.keys(e).join(", "),isLocal:!0}),{success:!0,user:{id:l.id,username:l.username,displayName:l.displayName,role:l.role,email:l.email,isLocal:!0}}}throw new Error("Server request failed: "+s.message)}}catch(n){return console.error("[CRM Extension] Update user error:",n),{success:!1,error:n.message}}}async function yo(t){try{let e=E();if(!S())return{success:!1,error:"Authentication required"};if(e.role!=="admin")return{success:!1,error:"Administrator privileges required to delete users"};if(!t)throw new Error("User ID is required");if(t===e.id)return{success:!1,error:"Cannot delete your own account"};let o=(localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000").replace("ws://","http://").replace("wss://","https://");try{let r=await fetch(`${o}/admin/users/${t}`,{method:"DELETE",headers:{Authorization:`Bearer ${localStorage.getItem("crmplus_chat_auth_token")}`}});if(!r.ok){let s=await r.json();throw new Error(s.message||"Failed to delete user")}return d("auth","Admin deleted user",{adminUsername:e.username,targetUserId:t}),{success:!0}}catch(r){if(console.error("[CRM Extension] Server delete user error:",r),v("allow_local_auth",!1)){let s=v("local_users",[]),i=s.findIndex(a=>a.id===t);if(i>=0){let a=s[i].username;return s.splice(i,1),j("local_users",s),d("auth","Admin deleted local user",{adminUsername:e.username,targetUserId:t,targetUsername:a,isLocal:!0}),{success:!0}}else throw new Error("User not found")}throw new Error("Server request failed: "+r.message)}}catch(e){return console.error("[CRM Extension] Delete user error:",e),d("auth","Admin user deletion failed",{error:e.message}),{success:!1,error:e.message}}}async function Or(){try{let t=E();if(!S())return{success:!1,error:"Authentication required"};if(!B("user.view"))return{success:!1,error:"Permission denied"};let n=(localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000").replace("ws://","http://").replace("wss://","https://");try{let o=await fetch(`${n}/admin/users`,{method:"GET",headers:{Authorization:`Bearer ${localStorage.getItem("crmplus_chat_auth_token")}`}});if(!o.ok){let s=await o.json();throw new Error(s.message||"Failed to get users")}return{success:!0,users:await o.json()}}catch(o){if(console.error("[CRM Extension] Server get users error:",o),v("allow_local_auth",!1))return{success:!0,users:v("local_users",[]).map(s=>({id:s.id,username:s.username,displayName:s.displayName,role:s.role,createdAt:s.createdAt,isLocal:!0}))};throw new Error("Server request failed: "+o.message)}}catch(t){return console.error("[CRM Extension] Get users error:",t),{success:!1,error:t.message}}}var ht={};ye(ht,{generateUserImportTemplate:()=>jr,importUsers:()=>$r});function _r(t){let e={validUsers:[],invalidUsers:[]};return t.forEach(n=>{let o=[];n.username||o.push("Username is required"),n.password||o.push("Password is required"),n.email||o.push("Email is recommended");let r=["user","moderator","admin"];n.role&&!r.includes(n.role)&&o.push(`Invalid role. Must be one of: ${r.join(", ")}`),o.length>0?e.invalidUsers.push({user:n,errors:o}):e.validUsers.push(n)}),e}async function $r(t){try{let e=E();if(!S())return{success:!1,error:"Authentication required"};if(e.role!=="admin")return{success:!1,error:"Administrator privileges required to import users"};if(!Array.isArray(t)||t.length===0)return{success:!1,error:"Valid user array is required"};let{validUsers:n,invalidUsers:o}=_r(t),s=(localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000").replace("ws://","http://").replace("wss://","https://"),i={success:!0,totalUsers:t.length,successCount:0,failedCount:0,validationErrors:o,importedUsers:[],serverErrors:[]};try{let a=await fetch(`${s}/admin/users/import`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${localStorage.getItem("crmplus_chat_auth_token")}`},body:JSON.stringify({users:n})});if(!a.ok){let c=await a.json();throw new Error(c.message||"Failed to import users")}let l=await a.json();return i.successCount=l.successCount||0,i.failedCount=l.failedCount||0,i.importedUsers=l.importedUsers||[],d("auth","Admin bulk user import",{adminUsername:e.username,totalUsers:t.length,successCount:i.successCount,failedCount:i.failedCount}),i}catch(a){if(console.error("[CRM Extension] Server user import error:",a),v("allow_local_auth",!1)){let l=v("local_users",[]),c=new Set(l.map(p=>p.username));return n.forEach(p=>{try{if(c.has(p.username)){i.failedCount++,i.serverErrors.push({username:p.username,error:"Username already exists"});return}let u={id:`user_${Date.now().toString(36)}`,...p,role:p.role||"user",displayName:p.displayName||p.username,createdAt:new Date().toISOString(),createdBy:e.id};l.push(u),c.add(p.username),i.successCount++,i.importedUsers.push(u)}catch(u){i.failedCount++,i.serverErrors.push({username:p.username||"Unknown",error:u.message})}}),j("local_users",l),d("auth","Local bulk user import",{adminUsername:e.username,totalUsers:t.length,successCount:i.successCount,failedCount:i.failedCount,isLocal:!0}),i}throw new Error("Server request failed: "+a.message)}}catch(e){return console.error("[CRM Extension] Bulk user import error:",e),{success:!1,error:e.message,totalUsers:t.length,successCount:0,failedCount:t.length}}}function jr(){return[{username:"john.doe",password:"SecurePassword123!",email:"john.doe@example.com",displayName:"John Doe",role:"user"},{username:"jane.smith",password:"AnotherSecurePass456!",email:"jane.smith@example.com",displayName:"Jane Smith",role:"moderator"}]}var Hr=Ln(Gt());O(g,Ln(Gt()));var Wr={...qt,...pt,...ot,...ut,...ht,...Hr},{createUser:Co,updateUser:bo,deleteUser:Jt,getAllUsers:Yt,importUsers:Kt,createRole:Eo,updateRole:So,deleteRole:wo,getAllRoles:vo,getAvailablePermissions:ko,resetUserPassword:Zt,forceLogoutUser:Mo,generateUserImportTemplate:qr}={...ut,...pt,...ot,...ht};var Lo="ws://localhost:3000",Gr=5e3,Jr=5,Yr=3e4,V=null,xt="disconnected",Ie=0,mt=null,Xt=localStorage.getItem("crmplus_chat_active_channel")||"general",gt=[],ft=[],Kr=[],Zr=[];function Ao(){return Xt=localStorage.getItem("crmplus_chat_active_channel")||"general",d("system","Message service initialized"),!0}function ue(){return V&&(V.readyState===WebSocket.OPEN||V.readyState===WebSocket.CONNECTING)?(console.log("[MessageService] WebSocket already connected or connecting"),Promise.resolve(!0)):new Promise(t=>{try{console.log(`[MessageService] Attempting to connect to ${Lo}`),Ee("connecting"),V=new WebSocket(Lo),V.onopen=()=>{console.log("[MessageService] WebSocket connection established"),Ie=0,Ee("connected"),Xr(),Qr(),t(!0)},V.onmessage=e=>{try{let n=JSON.parse(e.data);es(n)}catch(n){console.error("[MessageService] Error parsing message:",n)}},V.onclose=e=>{console.warn("[MessageService] WebSocket connection closed",e),Ro(),Ee("disconnected"),e.code!==1e3&&Qt(),t(!1)},V.onerror=e=>{console.error("[MessageService] WebSocket error:",e),Ee("error"),Qt(),t(!1)}}catch(e){console.error("[MessageService] Connection error:",e),Ee("error"),Qt(),t(!1)}})}function Qr(){if(!V||V.readyState!==WebSocket.OPEN)return;let t=E(),e=be();if(!t||!e){console.warn("[MessageService] Cannot authenticate: No user or token");return}let n={type:"authenticate",payload:{userId:t.id,username:t.username,token:e}};en(n)}function en(t){if(!V||V.readyState!==WebSocket.OPEN)return console.warn("[MessageService] WebSocket not connected"),!1;try{return V.send(JSON.stringify(t)),!0}catch(e){return console.error("[MessageService] Error sending message:",e),!1}}function yt(t,e=null,n=null){if(!t||!t.trim()||!S())return!1;let o=E();if(!o)return!1;e=e||Xt;let r=Date.now().toString(36)+Math.random().toString(36).substr(2,5),s=new Date().toISOString(),i={id:r,text:t.trim(),sender:o.username,senderDisplayName:o.displayName||o.username,timestamp:s,channel:e,recipient:n},a={type:"chat_message",payload:{id:r,text:t.trim(),sender:o.id,senderUsername:o.username,timestamp:s,channelId:e,recipientId:n}},l=!1;if(V&&V.readyState===WebSocket.OPEN)try{let c=_t(a);l=en(c)}catch(c){console.warn("[MessageService] Error sending message via WebSocket:",c)}return l||(console.log("[MessageService] Using local message handling"),Dt(i),setTimeout(()=>{Io([i])},100)),d("message","Message sent",{messageId:r,channelId:e,recipientId:n,localOnly:!l}),!0}function tn(){return xt}function Xr(){Ro(),mt=setInterval(()=>{if(V&&V.readyState===WebSocket.OPEN){let t={type:"heartbeat",timestamp:new Date().toISOString()};en(t)}},Yr)}function Ro(){mt&&(clearInterval(mt),mt=null)}function Qt(){if(Ie>=Jr){console.error("[MessageService] Max reconnection attempts reached"),Ee("error");return}Ie++;let t=Gr*Math.pow(2,Ie);console.log(`[MessageService] Attempting reconnection in ${t}ms (Attempt ${Ie})`),setTimeout(()=>{ue()},t)}function es(t){try{switch(t.type){case"chat_message":let e=$t(t);Dt(e),Io([e]);break;case"authentication_response":ts(t);break;case"user_list":os(t.users);break;case"channel_list":rs(t.channels);break;case"error":console.error("[MessageService] Server error:",t.payload);break;default:console.warn("[MessageService] Unknown message type:",t.type)}}catch(e){console.error("[MessageService] Error handling message:",e)}}function ts(t){t.success?(console.log("[MessageService] Authentication successful"),d("auth","WebSocket authentication successful")):(console.error("[MessageService] Authentication failed:",t.reason),d("auth","WebSocket authentication failed",{reason:t.reason}))}function Ee(t){xt!==t&&(xt=t,ns(t))}function Ct(t){return typeof t!="function"?()=>{}:(gt.push(t),()=>{gt=gt.filter(e=>e!==t)})}function Io(t){gt.forEach(e=>{try{e(t)}catch(n){console.error("[MessageService] Error in message listener:",n)}})}function nn(t){return typeof t!="function"?()=>{}:(ft.push(t),t(xt),()=>{ft=ft.filter(e=>e!==t)})}function ns(t){ft.forEach(e=>{try{e(t)}catch(n){console.error("[MessageService] Error in connection status listener:",n)}})}function os(t){Kr.forEach(e=>{try{e(t)}catch(n){console.error("[MessageService] Error in user list listener:",n)}})}function rs(t){Zr.forEach(e=>{try{e(t)}catch(n){console.error("[MessageService] Error in channel list listener:",n)}})}function on(){return Xt}var Y={ONLINE:"online",AWAY:"away",BUSY:"busy",INVISIBLE:"invisible"};function No(){try{return is(),d("system","User service initialized"),!0}catch(t){return console.error("[CRM Extension] User service init error:",t),!1}}function is(){let t=Vt();t.length>0&&t.forEach(e=>{e.status=e.status||Y.ONLINE,e.lastSeen=e.lastSeen||new Date().toISOString()})}var Uo=[];var Ca=localStorage.getItem("crmplus_chat_active_channel")||"general";function To(){try{return ls(),d("system","Channel service initialized"),console.log("[CRM Extension] Channel service initialized"),!0}catch(t){return console.error("[CRM Extension] Error initializing channel service:",t),!1}}function ls(){let t=tt();if(t.length===0){let e={id:"general",name:"General",description:"General discussion channel",type:"public",createdAt:new Date().toISOString(),createdBy:"system"},n={id:"announcements",name:"Announcements",description:"Important announcements",type:"public",createdAt:new Date().toISOString(),createdBy:"system",readonly:!0};et(e),et(n),Uo=[e,n]}else Uo=t}var rn=class{constructor(){this.listeners=[],this.authState={authenticated:S(),user:E(),sessionStatus:ie()},this.setupAuthListener(),this.setupSessionRefresh()}notifyListeners(){let e=this.getAuthState();this.listeners.forEach(n=>{try{n(e)}catch(o){console.error("[CRM Extension] Error in auth context listener:",o)}})}setupAuthListener(){Re(e=>{this.authState={...this.authState,authenticated:e.authenticated,user:e.user},this.notifyListeners()})}setupSessionRefresh(){setInterval(()=>{this.authState.sessionStatus=ie(),this.authState.authenticated&&this.notifyListeners()},6e4)}async login(e,n){let o=await ge(e,n);return o.success&&(this.authState={authenticated:!0,user:o.user,sessionStatus:ie()},this.notifyListeners()),o}logout(e){let n=oe(e);return n&&(this.authState={authenticated:!1,user:null,sessionStatus:ie()},this.notifyListeners()),n}async register(e){return await(0,g.registerUser)(e)}async updateProfile(e){let n=await(0,g.updateUserProfile)(e);return n.success&&(this.authState={...this.authState,user:n.user},this.notifyListeners()),n}hasPermission(e){return B(e)}getAuthState(){return this.authState.sessionStatus=ie(),{...this.authState}}subscribe(e){return typeof e!="function"?(console.error("[CRM Extension] Auth context listener must be a function"),()=>{}):(this.listeners.push(e),e(this.getAuthState()),()=>{this.listeners=this.listeners.filter(n=>n!==e)})}},cs=new rn,sn=cs;var ds={server:{url:v("server_url","ws://localhost:3000"),connectionTimeout:1e4,reconnect:{maxAttempts:5,delay:5e3,useExponentialBackoff:!0},heartbeatInterval:3e4},security:{sessionTimeout:15*60*1e3,hasCryptoAPI:typeof window<"u"&&window.crypto&&window.crypto.subtle,minPasswordLength:8,enableTwoFactorAuth:!1},storage:{maxMessagesPerChannel:100,messageExpiration:24*60*60*1e3,keyPrefix:"crmplus_chat_"},ui:{theme:v("theme","light"),notifications:{enabled:v("notifications_enabled",!0),sound:v("notification_sound",!0),soundUrl:v("notification_sound_url",null)},messages:{maxLength:2e3,allowEditing:!0,editWindow:5*60*1e3,allowDeletion:!0},channels:{defaultChannel:"general"}},features:{directMessaging:!0,fileSharing:!1,messageThreading:!1,messageReactions:!0,userChannelCreation:v("user_channel_creation",!1),userStatus:!0},hipaa:{enableSessionTimeout:!0,enableAuditLogging:!0,enableMessageExpiration:!0,showPhiIndicators:!0,enableEncryption:!0},roles:{admin:{name:"Administrator",permissions:["user.create","user.read","user.update","user.delete","channel.create","channel.read","channel.update","channel.delete","channel.invite","message.delete","audit.read"]},moderator:{name:"Moderator",permissions:["user.read","channel.create","channel.read","channel.update","channel.invite","message.delete"]},user:{name:"User",permissions:["user.read","channel.read","message.create","message.read","message.update.own","message.delete.own"]}},version:{number:"1.0.0",buildDate:new Date("2025-03-18").toISOString()}};function Ne(t,e=null){try{let n=t.split("."),o=ds;for(let r of n)if(o&&typeof o=="object"&&r in o)o=o[r];else return e;return o}catch(n){return console.error("[CRM Extension] Error getting config value:",n),e}}var Ue={primary:"#343a40",secondary:"#3a444f",text:"#ffffff",accent:"#2196F3"},an=class{constructor(e,n){this.container=e,this.onLoginSuccess=typeof n=="function"?n:()=>{console.warn("[LoginForm] No login success callback provided")},this.formElement=null,this.usernameInput=null,this.passwordInput=null,this.submitButton=null,this.render=this.render.bind(this),this.handleSubmit=this.handleSubmit.bind(this),this.render()}render(){let e=document.createElement("div");e.className="login-container",this.applyStyles(e,{maxWidth:"380px",width:"100%",margin:"40px auto 0",padding:"20px",backgroundColor:"white",borderRadius:"8px",boxShadow:"0 2px 10px rgba(0,0,0,0.1)",textAlign:"center"});let n=document.createElement("h2");n.textContent="Mountain Care Pharmacy",this.applyStyles(n,{color:Ue.primary,fontSize:"24px",margin:"0 0 8px",fontWeight:"bold"});let o=document.createElement("p");o.textContent="Please log in to continue",this.applyStyles(o,{color:"#666",margin:"0 0 20px",fontSize:"14px"}),this.formElement=document.createElement("form"),this.formElement.className="login-form",this.applyStyles(this.formElement,{display:"flex",flexDirection:"column",gap:"16px"}),this.formElement.addEventListener("submit",this.handleSubmit);let r=this.createFormGroup("Username","username","text");this.usernameInput=r.querySelector("input");let s=this.createFormGroup("Password","password","password");this.passwordInput=s.querySelector("input");let i=document.createElement("div");this.applyStyles(i,{display:"flex",alignItems:"center",marginTop:"-8px"});let a=document.createElement("input");a.type="checkbox",a.id="remember-me",a.name="remember";let l=document.createElement("label");l.htmlFor="remember-me",l.textContent="Remember me",this.applyStyles(l,{fontSize:"14px",color:"#666",marginLeft:"8px",cursor:"pointer"}),i.appendChild(a),i.appendChild(l),this.submitButton=document.createElement("button"),this.submitButton.type="submit",this.submitButton.textContent="Login",this.applyStyles(this.submitButton,{backgroundColor:Ue.primary,color:Ue.text,border:"none",padding:"10px",borderRadius:"4px",fontSize:"16px",cursor:"pointer",fontWeight:"bold",width:"100%"}),this.submitButton.addEventListener("mouseover",()=>{this.submitButton.style.backgroundColor=Ue.secondary}),this.submitButton.addEventListener("mouseout",()=>{this.submitButton.style.backgroundColor=Ue.primary});let c=document.createElement("p");c.textContent="This system complies with HIPAA security requirements",this.applyStyles(c,{fontSize:"12px",color:"#666",margin:"16px 0 0"});let p=document.createElement("p");p.textContent="All communication is encrypted",this.applyStyles(p,{fontSize:"12px",color:"#666",margin:"8px 0 0"}),this.formElement.appendChild(r),this.formElement.appendChild(s),this.formElement.appendChild(i),this.formElement.appendChild(this.submitButton),e.appendChild(n),e.appendChild(o),e.appendChild(this.formElement),e.appendChild(c),e.appendChild(p),this.container.innerHTML="",this.container.appendChild(e)}createFormGroup(e,n,o){let r=document.createElement("div");this.applyStyles(r,{display:"flex",flexDirection:"column",textAlign:"left"});let s=document.createElement("label");s.htmlFor=n,s.textContent=e,this.applyStyles(s,{fontSize:"14px",color:"#666",marginBottom:"4px"});let i=document.createElement("div");this.applyStyles(i,{position:"relative"});let a=document.createElement("input");if(a.type=o,a.id=n,a.name=n,a.required=!0,this.applyStyles(a,{padding:"10px",border:"1px solid #ddd",borderRadius:"4px",width:"100%",boxSizing:"border-box",fontSize:"14px"}),o==="password"){let l=document.createElement("button");l.type="button",l.textContent="\u{1F441}\uFE0F",this.applyStyles(l,{position:"absolute",right:"8px",top:"50%",transform:"translateY(-50%)",backgroundColor:"transparent",border:"none",cursor:"pointer",fontSize:"16px",color:"#f44336"}),l.addEventListener("click",()=>{a.type=a.type==="password"?"text":"password"}),i.appendChild(l)}return i.appendChild(a),r.appendChild(s),r.appendChild(i),r}async handleSubmit(e){e.preventDefault();try{let n=this.usernameInput.value,o=this.passwordInput.value,r=e.target.remember?.checked||!1;this.submitButton.disabled=!0,this.submitButton.textContent="Logging in...",this.usernameInput.disabled=!0,this.passwordInput.disabled=!0;let s=await ge(n,o);s.success?(d("auth","Login successful",{username:n}),this.onLoginSuccess(s.user)):(alert(s.error||"Login failed. Please try again."),this.submitButton.disabled=!1,this.submitButton.textContent="Login",this.usernameInput.disabled=!1,this.passwordInput.disabled=!1)}catch(n){console.error("[CRM Extension] Login error:",n),alert("An unexpected error occurred. Please try again."),this.submitButton.disabled=!1,this.submitButton.textContent="Login",this.usernameInput.disabled=!1,this.passwordInput.disabled=!1}}applyStyles(e,n){Object.assign(e.style,n)}destroy(){this.formElement&&this.formElement.removeEventListener("submit",this.handleSubmit),this.container&&(this.container.innerHTML="")}},bt=an;var ln=class{constructor(e={}){this.options={sound:Ne("ui.notifications.sound",!0),soundUrl:Ne("ui.notifications.soundUrl",null),desktop:Ne("ui.notifications.enabled",!0),onNotificationClick:null,...e},this.notificationCount=0,this.notificationQueue=[],this.processingQueue=!1,this.enabled=!0,this.focused=document.hasFocus(),this.unsubscribeMessageListener=null,this.notificationPermission="default",this.audio=null,this.initialize=this.initialize.bind(this),this.handleMessage=this.handleMessage.bind(this),this.showNotification=this.showNotification.bind(this),this.playNotificationSound=this.playNotificationSound.bind(this),this.handleVisibilityChange=this.handleVisibilityChange.bind(this),this.processBatchedNotifications=this.processBatchedNotifications.bind(this),this.requestNotificationPermission=this.requestNotificationPermission.bind(this),this.initialize()}initialize(){try{"Notification"in window&&(this.notificationPermission=Notification.permission,this.notificationPermission!=="granted"&&this.options.desktop&&document.addEventListener("click",this.requestNotificationPermission,{once:!0})),this.options.sound&&(this.audio=new Audio(this.options.soundUrl||this.getDefaultSoundUrl()),this.audio.load()),document.addEventListener("visibilitychange",this.handleVisibilityChange),window.addEventListener("focus",()=>{this.focused=!0,this.resetNotificationCount()}),window.addEventListener("blur",()=>{this.focused=!1}),this.unsubscribeMessageListener=Ct(this.handleMessage),d("ui","Notification system initialized"),console.log("[CRM Extension] Notification system initialized")}catch(e){console.error("[CRM Extension] Error initializing notification system:",e)}}getDefaultSoundUrl(){return"data:audio/mp3;base64,SUQzBAAAAAABEVRYWFgAAAAtAAADY29tbWVudABCaWdTb3VuZEJhbmsuY29tIC8gTGFTb25vdGhlcXVlLm9yZwBURU5DAAAAHQAAA1N3aXRjaCBQbHVzIMKpIE5DSCBTb2Z0d2FyZQBUSVQyAAAABgAAAzIyMzUAVFNTRQAAAA8AAANMYXZmNTguMTYuMTAwAAAAAAAAAAAAAAD/80DEAAAAA0gAAAAATEFNRTMuMTAwVVVVVVVVVVVVVUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/zQsRbAAADSAAAAABVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/zQMSkAAADSAAAAABVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV"}requestNotificationPermission(){"Notification"in window&&this.notificationPermission!=="granted"&&Notification.requestPermission().then(e=>{this.notificationPermission=e,d("ui",`Notification permission ${e}`)})}handleVisibilityChange(){document.visibilityState==="visible"?(this.focused=!0,this.resetNotificationCount()):this.focused=!1}handleMessage(e){if(!this.enabled||!e||e.length===0)return;let n=E();if(!n)return;let o=e.filter(r=>r.sender!==n.username&&r.sender!==n.id);o.length!==0&&(this.notificationQueue.push(...o),this.notificationCount+=o.length,this.dispatchNotificationCountEvent(),this.processingQueue||this.processBatchedNotifications())}processBatchedNotifications(){if(this.notificationQueue.length===0){this.processingQueue=!1;return}this.processingQueue=!0;let e=this.notificationQueue.shift();this.focused||this.showNotification(e),this.options.sound&&this.notificationQueue.length===0&&this.playNotificationSound(),setTimeout(this.processBatchedNotifications,300)}showNotification(e){try{if(!this.options.desktop||!("Notification"in window)||this.notificationPermission!=="granted")return;let n=`New message from ${e.senderDisplayName||e.sender}`,o={body:"You have received a new message",icon:this.getIconUrl(e.sender),tag:`chat-msg-${e.id}`,requireInteraction:!1,silent:!0},r=new Notification(n,o);r.onclick=()=>{window.focus(),this.options.onNotificationClick&&typeof this.options.onNotificationClick=="function"&&this.options.onNotificationClick(e),r.close()},d("ui","Showed desktop notification",{sender:e.sender})}catch(n){console.error("[CRM Extension] Error showing notification:",n)}}playNotificationSound(){try{if(!this.options.sound||!this.audio)return;this.audio.currentTime=0,this.audio.play().catch(e=>{console.warn("[CRM Extension] Could not play notification sound:",e)})}catch(e){console.error("[CRM Extension] Error playing notification sound:",e)}}getIconUrl(e){return"data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA0OCA0OCIgd2lkdGg9IjQ4IiBoZWlnaHQ9IjQ4Ij48Y2lyY2xlIGN4PSIyNCIgY3k9IjI0IiByPSIyNCIgZmlsbD0iIzQyOTVmMyIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0yNCAyMGMzLjMgMCA2LTIuNyA2LTZzLTIuNy02LTYtNi02IDIuNy02IDYgMi43IDYgNiA2em0wIDRjLTQgMC0xMiAyLTEyIDZWMzRoMjR2LTRjMC00LTgtNi0xMi02eiIvPjwvc3ZnPg=="}getNotificationCount(){return this.notificationCount}resetNotificationCount(){this.notificationCount!==0&&(this.notificationCount=0,this.dispatchNotificationCountEvent(),d("ui","Reset notification count"))}dispatchNotificationCountEvent(){let e=new CustomEvent("chat_notification_count",{detail:{count:this.notificationCount}});window.dispatchEvent(e)}setEnabled(e){this.enabled=!!e,d("ui",`Notifications ${e?"enabled":"disabled"}`)}setSound(e,n=null){this.options.sound=!!e,e&&n&&(this.options.soundUrl=n,this.audio?(this.audio.src=n,this.audio.load()):(this.audio=new Audio(n),this.audio.load())),d("ui",`Notification sound ${e?"enabled":"disabled"}`)}showSystemNotification(e,n){try{if(!this.options.desktop||!("Notification"in window)||this.notificationPermission!=="granted")return;let o={body:n,icon:"data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA0OCA0OCIgd2lkdGg9IjQ4IiBoZWlnaHQ9IjQ4Ij48Y2lyY2xlIGN4PSIyNCIgY3k9IjI0IiByPSIyNCIgZmlsbD0iIzI4YTc0NSIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0yMCAzNGwtOS05IDMtMyA2IDYgMTQtMTQgMyAzeiIvPjwvc3ZnPg==",tag:`chat-system-${Date.now()}`,requireInteraction:!1,silent:!0},r=new Notification(e,o);r.onclick=()=>{window.focus(),r.close()},this.options.sound&&this.playNotificationSound(),d("ui","Showed system notification",{title:e})}catch(o){console.error("[CRM Extension] Error showing system notification:",o)}}destroy(){document.removeEventListener("visibilitychange",this.handleVisibilityChange),window.removeEventListener("focus",()=>{this.focused=!0}),window.removeEventListener("blur",()=>{this.focused=!1}),this.unsubscribeMessageListener&&this.unsubscribeMessageListener(),this.audio&&(this.audio.pause(),this.audio=null),d("ui","Notification system destroyed")}},cn=ln;var dn=class{constructor(e={}){this.options={user:null,connectionStatus:"disconnected",activeView:"chat",onViewSwitch:()=>{},onToggleUserList:()=>{},onToggleAdminPanel:()=>{},...e},this.headerElement=null,this.connectionIndicator=null,this.userStatusComponent=null,this.statusColors={[Y.ONLINE]:"#4CAF50",[Y.AWAY]:"#FFC107",[Y.BUSY]:"#F44336",[Y.INVISIBLE]:"#9E9E9E"},this.render=this.render.bind(this),this.updateConnectionStatus=this.updateConnectionStatus.bind(this),this.updateActiveView=this.updateActiveView.bind(this),this.handleLogout=this.handleLogout.bind(this),this.createUserAvatar=this.createUserAvatar.bind(this)}render(){this.headerElement=document.createElement("div"),this.headerElement.className="hipaa-chat-header",this.applyStyles(this.headerElement,{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"0 16px",height:"60px",backgroundColor:"#2196F3",color:"white",boxShadow:"0 2px 4px rgba(0,0,0,0.1)"});let e=document.createElement("div");this.applyStyles(e,{display:"flex",alignItems:"center"});let n=document.createElement("h1");n.textContent="MCP Chat",this.applyStyles(n,{margin:"0 20px 0 0",fontSize:"18px",fontWeight:"bold"});let o=this.createNavigationLinks();e.appendChild(n),e.appendChild(o);let r=document.createElement("div");this.connectionIndicator=this.createConnectionIndicator(this.options.connectionStatus),r.appendChild(this.connectionIndicator);let s=document.createElement("div");this.applyStyles(s,{display:"flex",alignItems:"center",gap:"15px"});let i=document.createElement("div");this.applyStyles(i,{display:"flex",alignItems:"center",gap:"10px"});let a=this.createUserAvatar(),l=this.createUserDetails();i.appendChild(a),i.appendChild(l);let c=this.createToggleUserListButton(),p=this.createUserMenu();return s.appendChild(i),s.appendChild(c),s.appendChild(p),this.headerElement.appendChild(e),this.headerElement.appendChild(r),this.headerElement.appendChild(s),this.headerElement}createNavigationLinks(){let e=document.createElement("nav");this.applyStyles(e,{display:"flex",gap:"15px"});let n=this.createNavLink("Chat",this.options.activeView==="chat",()=>{this.options.onViewSwitch("chat")}),o=null;this.options.user&&this.options.user.role==="admin"&&(o=this.createNavLink("Admin",this.options.activeView==="admin",()=>{this.options.onViewSwitch("admin")}));let r=this.createNavLink("Settings",this.options.activeView==="settings",()=>{this.options.onViewSwitch("settings")});return e.appendChild(n),o&&e.appendChild(o),e.appendChild(r),e}createUserAvatar(){let e=this.options.user;if(!e)return document.createElement("div");let n=document.createElement("div"),o=e.status||Y.ONLINE;this.applyStyles(n,{position:"relative",width:"40px",height:"40px",borderRadius:"50%",backgroundColor:this.generateAvatarColor(e.username),display:"flex",alignItems:"center",justifyContent:"center",color:"white",fontWeight:"bold",fontSize:"16px"});let r=(e.displayName||e.username||"?")[0].toUpperCase();n.textContent=r;let s=document.createElement("div");return this.applyStyles(s,{position:"absolute",bottom:"0",right:"0",width:"12px",height:"12px",borderRadius:"50%",backgroundColor:this.statusColors[o],border:"2px solid white"}),n.appendChild(s),n}generateAvatarColor(e){let n=0;for(let r=0;r<e.length;r++)n=e.charCodeAt(r)+((n<<5)-n);return`hsl(${n%360}, 70%, 60%)`}createUserDetails(){let e=this.options.user;if(!e)return document.createElement("div");let n=document.createElement("div"),o=document.createElement("div");o.textContent=e.displayName||e.username,this.applyStyles(o,{fontWeight:"bold",fontSize:"14px"});let r=document.createElement("div");return r.textContent=this.getStatusLabel(e.status),this.applyStyles(r,{fontSize:"12px",color:"#e0e0e0"}),n.appendChild(o),n.appendChild(r),n}getStatusLabel(e){switch(e){case Y.ONLINE:return"Available";case Y.AWAY:return"Away";case Y.BUSY:return"Do Not Disturb";case Y.INVISIBLE:return"Invisible";default:return"Online"}}createToggleUserListButton(){let e=document.createElement("button");return e.title="Toggle Team Members",e.innerHTML="\u{1F465}",this.applyStyles(e,{background:"transparent",border:"none",color:"white",fontSize:"20px",cursor:"pointer",padding:"5px",borderRadius:"50%",transition:"background-color 0.2s"}),e.addEventListener("click",this.options.onToggleUserList),e.addEventListener("mouseover",()=>{e.style.backgroundColor="rgba(255,255,255,0.2)"}),e.addEventListener("mouseout",()=>{e.style.backgroundColor="transparent"}),e}createUserMenu(){let e=document.createElement("div");e.className="user-menu",this.applyStyles(e,{position:"relative"});let n=document.createElement("button");this.applyStyles(n,{background:"transparent",border:"none",color:"white",cursor:"pointer",display:"flex",alignItems:"center"});let o=document.createElement("span");o.textContent="\u22EE",this.applyStyles(o,{fontSize:"20px"}),n.appendChild(o);let r=document.createElement("div");return this.applyStyles(r,{display:"none",position:"absolute",top:"100%",right:"0",backgroundColor:"white",boxShadow:"0 2px 10px rgba(0,0,0,0.1)",borderRadius:"4px",minWidth:"180px",zIndex:"1000",marginTop:"8px"}),[{label:"Profile",icon:"\u{1F464}",action:()=>console.log("Profile clicked")},{label:"Settings",icon:"\u2699\uFE0F",action:()=>this.options.onViewSwitch("settings")},{type:"divider"},{label:"Logout",icon:"\u{1F6AA}",action:this.handleLogout}].forEach(i=>{if(i.type==="divider"){let p=document.createElement("hr");this.applyStyles(p,{margin:"8px 0",border:"none",borderTop:"1px solid #e0e0e0"}),r.appendChild(p);return}let a=document.createElement("button");this.applyStyles(a,{display:"flex",alignItems:"center",width:"100%",background:"none",border:"none",padding:"10px 16px",cursor:"pointer",textAlign:"left"});let l=document.createElement("span");l.textContent=i.icon,this.applyStyles(l,{marginRight:"10px"});let c=document.createElement("span");c.textContent=i.label,a.appendChild(l),a.appendChild(c),a.addEventListener("mouseover",()=>{a.style.backgroundColor="#f5f5f5"}),a.addEventListener("mouseout",()=>{a.style.backgroundColor="transparent"}),a.addEventListener("click",()=>{i.action(),r.style.display="none"}),r.appendChild(a)}),n.addEventListener("click",i=>{i.stopPropagation(),r.style.display=r.style.display==="block"?"none":"block"}),document.addEventListener("click",()=>{r.style.display="none"}),e.appendChild(n),e.appendChild(r),e}createNavLink(e,n,o){let r=document.createElement("button");return r.textContent=e,this.applyStyles(r,{backgroundColor:"transparent",border:"none",color:"white",padding:"5px 10px",cursor:"pointer",fontSize:"14px",fontWeight:n?"bold":"normal",borderBottom:n?"2px solid white":"none",transition:"background-color 0.2s"}),r.addEventListener("click",o),r.addEventListener("mouseover",()=>{r.style.backgroundColor="rgba(255,255,255,0.2)"}),r.addEventListener("mouseout",()=>{r.style.backgroundColor="transparent"}),r}createConnectionIndicator(e){let n={connected:"#4CAF50",connecting:"#FFC107",disconnected:"#F44336",error:"#F44336"},o={connected:"Connected",connecting:"Connecting...",disconnected:"Disconnected",error:"Connection Error"},r=document.createElement("div");this.applyStyles(r,{display:"flex",alignItems:"center",gap:"8px",backgroundColor:"rgba(255, 255, 255, 0.1)",borderRadius:"16px",padding:"6px 12px"});let s=document.createElement("div");this.applyStyles(s,{width:"8px",height:"8px",borderRadius:"50%",backgroundColor:n[e]||n.error});let i=document.createElement("span");return i.textContent=o[e]||"Unknown",this.applyStyles(i,{fontSize:"12px",color:"white"}),r.appendChild(s),r.appendChild(i),r}handleLogout(){try{d("auth","User initiated logout"),oe("User initiated logout")}catch(e){console.error("Logout error:",e)}}applyStyles(e,n){Object.assign(e.style,n)}destroy(){this.headerElement&&this.headerElement.parentNode&&this.headerElement.parentNode.removeChild(this.headerElement),d("ui","Header component destroyed")}},pn=dn;function Po(t,e={}){let{currentUser:n,connectionStatus:o="connected",activeView:r="chat",onViewSwitch:s=()=>{},onToggleUserList:i=()=>{},onLogout:a=()=>{}}=e,l={primary:"#2196F3",primaryDark:"#1976D2",text:"#ffffff",textSecondary:"rgba(255, 255, 255, 0.7)",accent:"#4CAF50",warning:"#FFC107",error:"#F44336"},c=document.createElement("div");c.className="hipaa-chat-header",U(c,{backgroundColor:l.primary,color:l.text,padding:"0 20px",height:"60px",display:"flex",alignItems:"center",justifyContent:"space-between",borderTopLeftRadius:"8px",borderTopRightRadius:"8px",boxShadow:"0 2px 4px rgba(0,0,0,0.1)"});let p=document.createElement("div");U(p,{display:"flex",alignItems:"center",height:"100%"});let u=document.createElement("div");U(u,{display:"flex",alignItems:"center",marginRight:"24px"});let m=document.createElement("span");m.textContent="\u{1F4AC}",U(m,{fontSize:"24px",marginRight:"10px"});let x=document.createElement("h1");x.textContent="MCP Chat",U(x,{margin:"0",fontSize:"20px",fontWeight:"bold",letterSpacing:"0.5px"}),u.appendChild(m),u.appendChild(x),p.appendChild(u);let N=document.createElement("nav");U(N,{display:"flex",height:"100%"}),[{id:"chat",label:"Chat"},{id:"admin",label:"Admin",adminOnly:!0},{id:"settings",label:"Settings"}].forEach(w=>{if(w.adminOnly&&n?.role!=="admin")return;let k=r===w.id,L=document.createElement("div");if(L.className=`nav-item ${k?"active":""}`,U(L,{height:"100%",display:"flex",alignItems:"center",padding:"0 16px",cursor:"pointer",position:"relative",color:k?l.text:l.textSecondary,fontWeight:k?"bold":"normal"}),k){let Q=document.createElement("div");U(Q,{position:"absolute",bottom:"0",left:"0",width:"100%",height:"3px",backgroundColor:l.text}),L.appendChild(Q)}L.textContent=w.label,L.addEventListener("mouseover",()=>{k||(L.style.backgroundColor="rgba(255, 255, 255, 0.1)",L.style.color=l.text)}),L.addEventListener("mouseout",()=>{k||(L.style.backgroundColor="transparent",L.style.color=l.textSecondary)}),L.addEventListener("click",()=>{s&&s(w.id)}),N.appendChild(L)}),p.appendChild(N);let F=document.createElement("div");U(F,{display:"flex",justifyContent:"center",flex:"1"});let W=ps(o);F.appendChild(W);let b=document.createElement("div");U(b,{display:"flex",alignItems:"center",gap:"16px"});let M=document.createElement("button");M.title="Toggle Team Members",M.innerHTML="\u{1F465}",U(M,{backgroundColor:"rgba(255, 255, 255, 0.2)",border:"none",color:l.text,fontSize:"18px",cursor:"pointer",width:"36px",height:"36px",borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center"}),M.addEventListener("mouseover",()=>{M.style.backgroundColor="rgba(255, 255, 255, 0.3)"}),M.addEventListener("mouseout",()=>{M.style.backgroundColor="rgba(255, 255, 255, 0.2)"}),M.addEventListener("click",()=>{i&&i()});let R=document.createElement("div");U(R,{display:"flex",alignItems:"center",gap:"8px",cursor:"pointer",padding:"6px",borderRadius:"4px",position:"relative"}),R.addEventListener("mouseover",()=>{R.style.backgroundColor="rgba(255, 255, 255, 0.1)"}),R.addEventListener("mouseout",()=>{R.style.backgroundColor="transparent"});let T=document.createElement("div");U(T,{width:"36px",height:"36px",borderRadius:"50%",backgroundColor:"rgba(255, 255, 255, 0.3)",display:"flex",alignItems:"center",justifyContent:"center",fontWeight:"bold",fontSize:"16px"});let K=n?.displayName?.charAt(0)||n?.username?.charAt(0)||"?";T.textContent=K.toUpperCase();let Z=document.createElement("div");Z.textContent=n?.displayName||n?.username||"Guest",U(Z,{fontSize:"14px",fontWeight:"medium"});let G=document.createElement("span");G.innerHTML="&#9662;",U(G,{fontSize:"12px",marginLeft:"4px"}),R.appendChild(T),R.appendChild(Z),R.appendChild(G);let z=document.createElement("div");return z.className="user-dropdown",U(z,{position:"absolute",top:"50px",right:"0",backgroundColor:"white",boxShadow:"0 2px 10px rgba(0,0,0,0.2)",borderRadius:"4px",zIndex:"100",minWidth:"180px",display:"none"}),[{label:"Profile",icon:"\u{1F464}",onClick:()=>console.log("Profile clicked")},{label:"Preferences",icon:"\u2699\uFE0F",onClick:()=>console.log("Preferences clicked")},{type:"divider"},{label:"Logout",icon:"\u{1F6AA}",onClick:a}].forEach(w=>{if(w.type==="divider"){let re=document.createElement("div");U(re,{height:"1px",backgroundColor:"#e0e0e0",margin:"8px 0"}),z.appendChild(re);return}let k=document.createElement("div");U(k,{display:"flex",alignItems:"center",padding:"10px 16px",cursor:"pointer",color:"#333",fontSize:"14px"}),k.addEventListener("mouseover",()=>{k.style.backgroundColor="#f5f5f5"}),k.addEventListener("mouseout",()=>{k.style.backgroundColor="transparent"});let L=document.createElement("span");L.textContent=w.icon,U(L,{marginRight:"12px",fontSize:"16px"});let Q=document.createElement("span");Q.textContent=w.label,k.appendChild(L),k.appendChild(Q),w.onClick&&k.addEventListener("click",re=>{re.stopPropagation(),z.style.display="none",w.onClick()}),z.appendChild(k)}),R.addEventListener("click",w=>{w.stopPropagation(),z.style.display=z.style.display==="block"?"none":"block"}),document.addEventListener("click",()=>{z.style.display="none"}),b.appendChild(M),b.appendChild(R),b.appendChild(z),c.appendChild(p),c.appendChild(F),c.appendChild(b),t&&t.appendChild(c),c}function ps(t){let e={connected:"#4CAF50",connecting:"#FFC107",disconnected:"#F44336",error:"#F44336"},n={connected:"Connected",connecting:"Connecting...",disconnected:"Disconnected",error:"Connection Error"},o=document.createElement("div");U(o,{display:"flex",alignItems:"center",gap:"8px",backgroundColor:"rgba(255, 255, 255, 0.1)",borderRadius:"16px",padding:"6px 12px"});let r=document.createElement("div");U(r,{width:"8px",height:"8px",borderRadius:"50%",backgroundColor:e[t]||e.error});let s=document.createElement("span");return s.textContent=n[t]||"Unknown",U(s,{fontSize:"12px",fontWeight:"medium"}),o.appendChild(r),o.appendChild(s),o}function U(t,e){Object.assign(t.style,e)}function Te(t){if(!t||t.trim()==="")return!1;let e=[/\b\d{3}[-.\s]?\d{2}[-.\s]?\d{4}\b/,/\b\d{1,2}[-/]\d{1,2}[-/]\d{2,4}\b/,/\bMR[#\s]?\d{5,10}\b/i,/\bmedical[\s-]record[\s-]number\b/i,/\b\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b/,/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/,/\b\d+\s+[A-Za-z\s]+\b(?:street|st|avenue|ave|road|rd|boulevard|blvd|drive|dr|court|ct|lane|ln|way)\b/i,/\b(?:patient|chart)[\s-](?:id|number|#)[\s:]*(?:\d{3,10}|[A-Z]{1,3}\d{3,7})\b/i,/\b(?:insurance|policy)[\s-](?:id|number|#)[\s:]*(?:\d{3,12}|[A-Z]{1,3}\d{3,10})\b/i,/\bdiagnosis\b|\bdiagnosed\b|\bsymptoms\b|\bprescription\b|\bmedication\b|\bdosage\b/i,/\bpatient information\b|\bhealth information\b|\bmedical history\b|\btest results\b/i,/\ballergies\b|\bvital signs\b|\blab results\b|\bmedical conditions\b|\bimmunizations\b/i];for(let r of e)if(r.test(t))return!0;let n=["confidential","private","sensitive","hipaa","phi","pii","personal information","health record","chart","physician","doctor","patient","treatment","dob","birth date","date of birth","age","ssn","social security","medicare","medicaid","insurance","claim","authorization","consent"],o=t.toLowerCase();for(let r of n)if(o.includes(r))return!0;return!1}function un(t){if(!t||typeof t!="string")return{success:!1,error:"Message text is required"};let e=t.trim();if(e.length===0)return{success:!1,error:"Message cannot be empty"};if(e.length>2e3)return{success:!1,error:"Message cannot exceed 2000 characters"};let n=Te(e);return{success:!0,message:e,containsPHI:n}}var hn=class{constructor(e,n={}){this.container=e,this.options={channelId:null,userId:null,placeholder:"Type a message...",maxLength:2e3,showCharacterCount:!0,showPHIWarning:!0,autoFocus:!0,...n},this.inputContainerElement=null,this.textareaElement=null,this.sendButtonElement=null,this.characterCountElement=null,this.phiWarningElement=null,this.render=this.render.bind(this),this.handleInput=this.handleInput.bind(this),this.handleKeyDown=this.handleKeyDown.bind(this),this.handleSendClick=this.handleSendClick.bind(this),this.sendMessage=this.sendMessage.bind(this),this.checkPHI=this.checkPHI.bind(this),this.initialize()}initialize(){this.inputContainerElement=document.createElement("div"),this.inputContainerElement.className="message-input-container",this.applyStyles(this.inputContainerElement,{display:"flex",flexDirection:"column",width:"100%",backgroundColor:"#f9f9f9",borderTop:"1px solid #e0e0e0",padding:"10px",boxSizing:"border-box"}),this.container&&this.container.appendChild(this.inputContainerElement),this.render(),d("ui","Message input component initialized",{channelId:this.options.channelId,userId:this.options.userId})}render(){if(!this.inputContainerElement)return;if(this.inputContainerElement.innerHTML="",S()&&B("message.create")){let o=document.createElement("div");o.className="input-row",this.applyStyles(o,{display:"flex",alignItems:"flex-end"}),this.textareaElement=document.createElement("textarea"),this.textareaElement.className="message-textarea",this.textareaElement.placeholder=this.options.placeholder,this.textareaElement.maxLength=this.options.maxLength,this.applyStyles(this.textareaElement,{flex:"1",minHeight:"40px",maxHeight:"120px",padding:"10px",border:"1px solid #ddd",borderRadius:"4px",resize:"none",fontSize:"14px",fontFamily:"inherit",outline:"none"}),this.textareaElement.addEventListener("input",this.handleInput),this.textareaElement.addEventListener("keydown",this.handleKeyDown),this.sendButtonElement=document.createElement("button"),this.sendButtonElement.className="send-button",this.sendButtonElement.innerHTML="\u27A4",this.sendButtonElement.title="Send Message",this.sendButtonElement.disabled=!0,this.applyStyles(this.sendButtonElement,{marginLeft:"8px",width:"40px",height:"40px",backgroundColor:"#2196F3",color:"white",border:"none",borderRadius:"4px",cursor:"pointer",fontSize:"16px",display:"flex",alignItems:"center",justifyContent:"center",opacity:"0.7"}),this.sendButtonElement.addEventListener("click",this.handleSendClick),o.appendChild(this.textareaElement),o.appendChild(this.sendButtonElement),this.inputContainerElement.appendChild(o);let r=document.createElement("div");r.className="info-row",this.applyStyles(r,{display:"flex",justifyContent:"space-between",marginTop:"4px",fontSize:"12px",color:"#666"}),this.options.showCharacterCount&&(this.characterCountElement=document.createElement("div"),this.characterCountElement.className="character-count",this.characterCountElement.textContent=`0/${this.options.maxLength}`,r.appendChild(this.characterCountElement)),this.options.showPHIWarning&&(this.phiWarningElement=document.createElement("div"),this.phiWarningElement.className="phi-warning",this.phiWarningElement.innerHTML="\u{1F512} This message may contain PHI (Protected Health Information)",this.applyStyles(this.phiWarningElement,{color:"#bf360c",fontWeight:"bold",display:"none"}),r.appendChild(this.phiWarningElement)),this.inputContainerElement.appendChild(r),this.options.autoFocus&&this.textareaElement.focus()}else{let o=document.createElement("div");o.className="readonly-notice",this.applyStyles(o,{padding:"10px",backgroundColor:"#f0f0f0",color:"#666",borderRadius:"4px",textAlign:"center"}),S()?o.textContent="You do not have permission to send messages":o.textContent="You must be logged in to send messages",this.inputContainerElement.appendChild(o)}let n=document.createElement("div");n.className="hipaa-notice",n.innerHTML="\u{1F512} HIPAA Compliant Chat - Messages are encrypted and expire after 24 hours",this.applyStyles(n,{fontSize:"10px",color:"#666",textAlign:"center",padding:"4px",backgroundColor:"#f0f0f0",marginTop:"8px",borderRadius:"2px"}),this.inputContainerElement.appendChild(n)}handleInput(e){if(!this.textareaElement)return;let n=this.textareaElement.value.trim();this.characterCountElement&&(this.characterCountElement.textContent=`${n.length}/${this.options.maxLength}`,n.length>this.options.maxLength*.9?this.characterCountElement.style.color="#f44336":this.characterCountElement.style.color="#666"),this.sendButtonElement&&(n.length>0?(this.sendButtonElement.disabled=!1,this.sendButtonElement.style.opacity="1"):(this.sendButtonElement.disabled=!0,this.sendButtonElement.style.opacity="0.7")),this.checkPHI(n),this.autoResizeTextarea()}checkPHI(e){!this.phiWarningElement||!this.options.showPHIWarning||(Te(e)?this.phiWarningElement.style.display="block":this.phiWarningElement.style.display="none")}autoResizeTextarea(){if(!this.textareaElement)return;this.textareaElement.style.height="auto";let e=Math.min(Math.max(this.textareaElement.scrollHeight,40),120);this.textareaElement.style.height=`${e}px`}handleKeyDown(e){e.key==="Enter"&&!e.shiftKey&&(e.preventDefault(),this.sendMessage())}handleSendClick(){this.sendMessage()}sendMessage(){if(!this.textareaElement)return;let e=this.textareaElement.value.trim();if(!e)return;let n=un(e);if(!n.success){alert(n.error);return}if(this.options.channelId)yt(e,this.options.channelId);else if(this.options.userId)yt(e,null,this.options.userId);else{console.error("[CRM Extension] Cannot send message: no channel ID or user ID specified");return}this.textareaElement.value="",this.characterCountElement&&(this.characterCountElement.textContent=`0/${this.options.maxLength}`,this.characterCountElement.style.color="#666"),this.phiWarningElement&&(this.phiWarningElement.style.display="none"),this.sendButtonElement&&(this.sendButtonElement.disabled=!0,this.sendButtonElement.style.opacity="0.7"),this.autoResizeTextarea(),this.textareaElement.focus(),d("ui","Message sent",{channelId:this.options.channelId,userId:this.options.userId,containsPHI:n.containsPHI})}updateChannel(e){this.options.channelId=e,this.options.userId=null,d("ui","Message input switched to channel",{channelId:e})}updateDirectMessage(e){this.options.userId=e,this.options.channelId=null,d("ui","Message input switched to direct messages",{userId:e})}applyStyles(e,n){Object.assign(e.style,n)}destroy(){this.textareaElement&&(this.textareaElement.removeEventListener("input",this.handleInput),this.textareaElement.removeEventListener("keydown",this.handleKeyDown)),this.sendButtonElement&&this.sendButtonElement.removeEventListener("click",this.handleSendClick),this.inputContainerElement&&this.inputContainerElement.parentNode&&this.inputContainerElement.parentNode.removeChild(this.inputContainerElement),d("ui","Message input component destroyed")}},mn=hn;function Vo(t,e={}){let{showUserList:n=!0,selectedChannel:o="general",mockChannels:r=[],mockUsers:s=[],onChannelSelect:i=()=>{},onUserSelect:a=()=>{},toggleUserList:l=()=>{}}=e,c=document.createElement("div");f(c,{display:"flex",width:"100%",height:"100%",backgroundColor:"#ffffff"});let p=us(r,o,i),u=ms(o,r,l,s),m=xs(s,a);return f(p,{flex:"0 0 180px",minWidth:"160px",maxWidth:"180px"}),f(u,{flex:"1 1 auto",minWidth:"250px"}),n&&f(m,{flex:"0 0 200px",minWidth:"180px",maxWidth:"200px"}),c.appendChild(p),c.appendChild(u),n&&c.appendChild(m),t.appendChild(c),c}function us(t,e,n){let o=document.createElement("div");f(o,{height:"100%",borderRight:"1px solid #e0e0e0",display:"flex",flexDirection:"column",backgroundColor:"#f8f9fa",overflow:"hidden"});let r=document.createElement("div");f(r,{padding:"10px 12px",borderBottom:"1px solid #e0e0e0",display:"flex",justifyContent:"space-between",alignItems:"center"});let s=document.createElement("h2");s.textContent="Channels",f(s,{margin:"0",fontSize:"16px",fontWeight:"bold"});let i=document.createElement("span");i.textContent=t.length.toString(),f(i,{backgroundColor:"#e0e0e0",color:"#333",borderRadius:"12px",padding:"1px 6px",fontSize:"11px",fontWeight:"bold"}),r.appendChild(s),r.appendChild(i);let a=document.createElement("div");f(a,{flex:"1",overflowY:"auto",padding:"4px 0"});let l=t.filter(x=>x.type==="public"),c=t.filter(x=>x.type==="private");l.length>0&&Do(a,"PUBLIC CHANNELS",l,e,n),c.length>0&&Do(a,"PRIVATE CHANNELS",c,e,n);let p=document.createElement("button");f(p,{margin:"8px",padding:"6px 0",backgroundColor:"#2196F3",color:"white",border:"none",borderRadius:"4px",fontSize:"13px",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:"6px",fontWeight:"bold"});let u=document.createElement("span");u.textContent="+",f(u,{fontSize:"16px"});let m=document.createElement("span");return m.textContent="New Channel",p.appendChild(u),p.appendChild(m),p.addEventListener("mouseover",()=>{p.style.backgroundColor="#1976D2"}),p.addEventListener("mouseout",()=>{p.style.backgroundColor="#2196F3"}),o.appendChild(r),o.appendChild(a),o.appendChild(p),o}function Do(t,e,n,o,r){let s=document.createElement("div");f(s,{padding:"8px 12px 4px",fontSize:"10px",color:"#666",fontWeight:"bold",textTransform:"uppercase",letterSpacing:"0.5px"}),s.textContent=e;let i=document.createElement("div");f(i,{marginBottom:"10px"}),n.forEach(a=>{let l=hs(a,a.id===o,r);i.appendChild(l)}),t.appendChild(s),t.appendChild(i)}function hs(t,e,n){let o=document.createElement("div");f(o,{padding:"6px 12px 6px 10px",display:"flex",alignItems:"center",cursor:"pointer",fontSize:"13px",color:e?"#2196F3":"#333",backgroundColor:e?"rgba(33, 150, 243, 0.08)":"transparent",borderLeft:e?"3px solid #2196F3":"3px solid transparent"});let r=document.createElement("span");r.textContent=t.type==="public"?"\u{1F310}":"\u{1F512}",f(r,{marginRight:"8px",fontSize:"14px",opacity:"0.7"});let s=document.createElement("span");if(s.textContent=t.name,f(s,{flex:"1",fontWeight:e?"bold":"normal",whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}),t.unread&&t.unread>0){let i=document.createElement("span");i.textContent=t.unread>99?"99+":t.unread,f(i,{minWidth:"18px",height:"18px",backgroundColor:e?"#2196F3":"#f44336",color:"white",borderRadius:"9px",fontSize:"11px",fontWeight:"bold",display:"flex",alignItems:"center",justifyContent:"center",padding:"0 4px"}),o.appendChild(i)}return o.appendChild(r),o.appendChild(s),o.addEventListener("click",()=>{n(t)}),o.addEventListener("mouseover",()=>{e||(o.style.backgroundColor="rgba(0, 0, 0, 0.05)")}),o.addEventListener("mouseout",()=>{e||(o.style.backgroundColor="transparent")}),o}function ms(t,e,n,o){let r=document.createElement("div");f(r,{flex:"1",display:"flex",flexDirection:"column",backgroundColor:"#fff",width:"100%"});let s=e.find(p=>p.id===t)||{id:"general",name:"General",type:"public"},i=gs(s,n),a=fs(s),l=document.createElement("div");f(l,{width:"100%"});let c=new mn(l,{channelId:s.id,placeholder:`Message #${s.name}`,maxLength:2e3});return r.appendChild(i),r.appendChild(a),r.appendChild(l),r}function gs(t,e){let n=document.createElement("div");f(n,{padding:"10px 12px",borderBottom:"1px solid #e0e0e0",display:"flex",justifyContent:"space-between",alignItems:"center",backgroundColor:"#fff",width:"100%"});let o=document.createElement("div");f(o,{display:"flex",alignItems:"center",gap:"8px"});let r=document.createElement("span");r.textContent=t.type==="public"?"\u{1F310}":"\u{1F512}",f(r,{fontSize:"16px"});let s=document.createElement("div");s.textContent=t.name,f(s,{fontSize:"16px",fontWeight:"bold"});let i=document.createElement("span");i.textContent=t.type==="public"?"Public":"Private",f(i,{fontSize:"10px",padding:"2px 8px",borderRadius:"10px",backgroundColor:t.type==="public"?"#e3f2fd":"#fff3e0",color:t.type==="public"?"#1565c0":"#e65100"}),o.appendChild(r),o.appendChild(s),o.appendChild(i);let a=document.createElement("div");f(a,{display:"flex",gap:"8px"});let l=Bo("\u{1F50D}","Search in channel"),c=Bo("\u{1F465}","Toggle team members");return c.addEventListener("click",e),a.appendChild(l),a.appendChild(c),n.appendChild(o),n.appendChild(a),n}function Bo(t,e){let n=document.createElement("button");return n.textContent=t,n.title=e,f(n,{width:"28px",height:"28px",borderRadius:"4px",backgroundColor:"transparent",border:"none",cursor:"pointer",fontSize:"14px",display:"flex",alignItems:"center",justifyContent:"center"}),n.addEventListener("mouseover",()=>{n.style.backgroundColor="#f5f5f5"}),n.addEventListener("mouseout",()=>{n.style.backgroundColor="transparent"}),n}function fs(t){let e=document.createElement("div");f(e,{flex:"1",overflowY:"auto",padding:"20px",display:"flex",flexDirection:"column",gap:"12px",width:"100%",minHeight:"200px"});let n=document.createElement("div");f(n,{margin:"auto",textAlign:"center",color:"#666",padding:"20px",backgroundColor:"#f8f9fa",borderRadius:"8px",maxWidth:"80%"});let o=document.createElement("div");o.textContent="\u{1F4AC}",f(o,{fontSize:"48px",marginBottom:"12px"});let r=document.createElement("div");r.textContent=`Welcome to #${t.name}`,f(r,{fontSize:"18px",fontWeight:"bold",marginBottom:"8px"});let s=document.createElement("div");return s.textContent="This is the start of your conversation. Messages are encrypted and will expire after 24 hours.",f(s,{fontSize:"14px"}),n.appendChild(o),n.appendChild(r),n.appendChild(s),e.appendChild(n),e}function xs(t,e){let n=document.createElement("div");f(n,{height:"100%",borderLeft:"1px solid #e0e0e0",display:"flex",flexDirection:"column",backgroundColor:"#f8f9fa"});let o=document.createElement("div");f(o,{padding:"10px 12px",borderBottom:"1px solid #e0e0e0",display:"flex",justifyContent:"space-between",alignItems:"center"});let r=document.createElement("h2");r.textContent="Team Members",f(r,{margin:"0",fontSize:"16px",fontWeight:"bold"});let s=document.createElement("span");s.textContent=t.length.toString(),f(s,{backgroundColor:"#e0e0e0",color:"#333",borderRadius:"12px",padding:"1px 6px",fontSize:"11px",fontWeight:"bold"}),o.appendChild(r),o.appendChild(s);let i=document.createElement("div");f(i,{padding:"8px 12px",borderBottom:"1px solid #e0e0e0"});let a=document.createElement("div");f(a,{display:"flex",alignItems:"center",backgroundColor:"white",borderRadius:"16px",border:"1px solid #ddd",padding:"0 10px"});let l=document.createElement("span");l.textContent="\u{1F50D}",f(l,{fontSize:"12px",color:"#666",marginRight:"6px"});let c=document.createElement("input");c.type="text",c.placeholder="Search users...",f(c,{width:"100%",padding:"6px 0",border:"none",borderRadius:"16px",fontSize:"13px",outline:"none"}),a.appendChild(l),a.appendChild(c),i.appendChild(a);let p=document.createElement("div");f(p,{flex:"1",overflowY:"auto",padding:"4px 0"});let u=t.filter(A=>A.status==="online"),m=t.filter(A=>A.status==="away"),x=t.filter(A=>A.status==="dnd"),N=t.filter(A=>A.status==="offline"||!A.status);return u.length>0&&Et(p,"Online",u,e),m.length>0&&Et(p,"Away",m,e),x.length>0&&Et(p,"Do Not Disturb",x,e),N.length>0&&Et(p,"Offline",N,e),n.appendChild(o),n.appendChild(i),n.appendChild(p),n}function Et(t,e,n,o){let r=document.createElement("div");f(r,{padding:"8px 12px 4px",fontSize:"10px",color:"#666",fontWeight:"bold",textTransform:"uppercase",letterSpacing:"0.5px"}),r.textContent=`${e} \u2014 ${n.length}`;let s=document.createElement("div");f(s,{marginBottom:"10px"}),n.forEach(i=>{let a=ys(i,i.status==="online",o);s.appendChild(a)}),t.appendChild(r),t.appendChild(s)}function ys(t,e,n){let o=document.createElement("div");f(o,{display:"flex",alignItems:"center",padding:"6px 12px",cursor:"pointer",opacity:e?"1":"0.7"});let r=document.createElement("div");f(r,{width:"6px",height:"6px",borderRadius:"50%",marginRight:"8px"}),t.status==="online"?r.style.backgroundColor="#4CAF50":t.status==="away"?r.style.backgroundColor="#FFC107":t.status==="dnd"?r.style.backgroundColor="#F44336":r.style.backgroundColor="#9E9E9E";let s=document.createElement("div"),i=(t.displayName||t.username).charAt(0).toUpperCase();s.textContent=i;let a=Cs(t.username),l=`hsl(${a}, 70%, 80%)`,c=`hsl(${a}, 70%, 30%)`;f(s,{width:"28px",height:"28px",borderRadius:"50%",backgroundColor:l,color:c,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:"bold",fontSize:"14px",marginRight:"8px"});let p=document.createElement("div");f(p,{flex:"1"});let u=document.createElement("div");if(u.textContent=t.displayName||t.username,f(u,{fontWeight:"medium",fontSize:"13px"}),t.role==="admin"||t.role==="moderator"){let x=document.createElement("span");x.textContent=t.role,f(x,{fontSize:"9px",backgroundColor:t.role==="admin"?"#f44336":"#2196F3",color:"white",padding:"1px 4px",borderRadius:"8px",marginLeft:"4px",textTransform:"uppercase",fontWeight:"bold"}),u.appendChild(x)}if(t.statusMessage){let x=document.createElement("div");x.textContent=t.statusMessage,f(x,{fontSize:"11px",color:"#666",marginTop:"1px"}),p.appendChild(x)}p.appendChild(u);let m=document.createElement("button");return m.innerHTML="\u{1F4AC}",m.title="Message",f(m,{backgroundColor:"transparent",border:"none",cursor:"pointer",fontSize:"14px",padding:"2px",borderRadius:"4px"}),m.addEventListener("mouseover",()=>{m.style.backgroundColor="rgba(0, 0, 0, 0.05)"}),m.addEventListener("mouseout",()=>{m.style.backgroundColor="transparent"}),m.addEventListener("click",x=>{x.stopPropagation(),n(t)}),o.addEventListener("click",()=>{n(t)}),o.addEventListener("mouseover",()=>{o.style.backgroundColor="rgba(0, 0, 0, 0.05)"}),o.addEventListener("mouseout",()=>{o.style.backgroundColor="transparent"}),o.appendChild(r),o.appendChild(s),o.appendChild(p),o.appendChild(m),o}function Cs(t){let e=0;for(let n=0;n<t.length;n++)e=t.charCodeAt(n)+((e<<5)-e);return e%360}function f(t,e){Object.assign(t.style,e)}function Fo(t,e={}){let{currentUser:n=null}=e;if(!(n&&n.role==="admin"))return bs(t);let r=document.createElement("div");C(r,{display:"flex",flexDirection:"column",width:"100%",height:"100%",backgroundColor:"#f5f7f9",padding:"20px"});let s=Es();r.appendChild(s);let i=document.createElement("div");C(i,{display:"flex",borderBottom:"1px solid #dee2e6",marginBottom:"20px"});let a=[{id:"users",label:"Users",icon:"\u{1F465}"},{id:"channels",label:"Channels",icon:"\u{1F310}"},{id:"roles",label:"Roles & Permissions",icon:"\u{1F512}"},{id:"audit",label:"Audit Log",icon:"\u{1F4CB}"}],l="users";a.forEach(p=>{let u=Ss(p,p.id===l);i.appendChild(u)}),r.appendChild(i);let c=document.createElement("div");switch(C(c,{flex:"1",backgroundColor:"#ffffff",borderRadius:"4px",padding:"20px",boxShadow:"0 1px 3px rgba(0,0,0,0.1)",overflow:"auto"}),l){case"users":zo(c);break;case"channels":Ls(c);break;case"roles":As(c);break;case"audit":Rs(c);break;default:zo(c)}return r.appendChild(c),t.appendChild(r),r}function bs(t){let e=document.createElement("div");C(e,{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",width:"100%",padding:"20px",textAlign:"center",color:"#721c24",backgroundColor:"#f8d7da"});let n=document.createElement("div");n.innerHTML="\u26D4",C(n,{fontSize:"48px",marginBottom:"16px"});let o=document.createElement("h3");o.textContent="Access Denied",C(o,{margin:"0 0 10px 0",fontSize:"24px"});let r=document.createElement("p");return r.textContent="Administrator privileges are required to access this area.",e.appendChild(n),e.appendChild(o),e.appendChild(r),t.appendChild(e),e}function Es(){let t=document.createElement("div");C(t,{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"20px"});let e=document.createElement("h2");e.textContent="Admin Panel",C(e,{margin:"0",fontSize:"24px",fontWeight:"bold",color:"#333"});let n=document.createElement("p");n.textContent="Manage users, channels, and permissions",C(n,{margin:"0",color:"#666",fontSize:"14px"});let o=document.createElement("div");return o.appendChild(e),o.appendChild(n),t.appendChild(o),t}function Ss(t,e){let n=document.createElement("div");C(n,{padding:"12px 16px",cursor:"pointer",borderBottom:e?"2px solid #2196F3":"2px solid transparent",color:e?"#2196F3":"#666",fontWeight:e?"bold":"normal",display:"flex",alignItems:"center",gap:"8px"});let o=document.createElement("span");o.textContent=t.icon;let r=document.createElement("span");return r.textContent=t.label,n.appendChild(o),n.appendChild(r),n.addEventListener("mouseover",()=>{e||(n.style.color="#333",n.style.borderBottom="2px solid #ddd")}),n.addEventListener("mouseout",()=>{e||(n.style.color="#666",n.style.borderBottom="2px solid transparent")}),n}function zo(t){let e=ws();t.appendChild(e);let n=vs();t.appendChild(n)}function ws(){let t=document.createElement("div");C(t,{display:"flex",justifyContent:"space-between",marginBottom:"15px",padding:"15px",backgroundColor:"#f8f9fa",borderRadius:"4px",border:"1px solid #dee2e6"});let e=document.createElement("div");C(e,{display:"flex",alignItems:"center",flex:"1",marginRight:"15px"});let n=document.createElement("span");n.textContent="\u{1F50D}",C(n,{marginRight:"8px"});let o=document.createElement("input");o.type="text",o.placeholder="Search users...",C(o,{flex:"1",padding:"8px 12px",border:"1px solid #ced4da",borderRadius:"4px",fontSize:"14px"}),e.appendChild(n),e.appendChild(o);let r=document.createElement("div");C(r,{display:"flex",gap:"10px"});let s=document.createElement("button");C(s,{backgroundColor:"#28a745",color:"white",border:"none",borderRadius:"4px",padding:"8px 12px",fontSize:"14px",cursor:"pointer",display:"flex",alignItems:"center",gap:"6px"});let i=document.createElement("span");i.textContent="+",s.appendChild(i);let a=document.createElement("span");a.textContent="Create User",s.appendChild(a);let l=document.createElement("button");C(l,{backgroundColor:"#6c757d",color:"white",border:"none",borderRadius:"4px",padding:"8px 12px",fontSize:"14px",cursor:"pointer",display:"flex",alignItems:"center",gap:"6px"});let c=document.createElement("span");c.textContent="\u2191",l.appendChild(c);let p=document.createElement("span");return p.textContent="Import",l.appendChild(p),r.appendChild(s),r.appendChild(l),t.appendChild(e),t.appendChild(r),t}function vs(){let t=document.createElement("div");C(t,{backgroundColor:"#ffffff",border:"1px solid #dee2e6",borderRadius:"4px",overflow:"hidden"});let e=document.createElement("table");C(e,{width:"100%",borderCollapse:"collapse",fontSize:"14px"});let n=document.createElement("thead");C(n,{backgroundColor:"#f8f9fa",fontWeight:"bold"});let o=document.createElement("tr");["Username","Display Name","Role","Status","Last Login","Actions"].forEach(l=>{let c=document.createElement("th");c.textContent=l,C(c,{padding:"12px 15px",textAlign:"left",borderBottom:"2px solid #dee2e6"}),o.appendChild(c)}),n.appendChild(o),e.appendChild(n);let s=document.createElement("tbody");[{username:"admin",displayName:"Administrator",role:"admin",status:"online",lastLogin:"2023-04-15T08:30:00Z"},{username:"john.doe",displayName:"John Doe",role:"user",status:"online",lastLogin:"2023-04-15T09:15:00Z"},{username:"jane.smith",displayName:"Jane Smith",role:"moderator",status:"away",lastLogin:"2023-04-14T17:45:00Z"},{username:"support",displayName:"Support Team",role:"moderator",status:"dnd",lastLogin:"2023-04-15T10:00:00Z"}].forEach(l=>{let c=ks(l);s.appendChild(c)}),e.appendChild(s),t.appendChild(e);let a=Ms(1,1,4);return t.appendChild(a),t}function ks(t){let e=document.createElement("tr");e.addEventListener("mouseover",()=>{e.style.backgroundColor="#f8f9fa"}),e.addEventListener("mouseout",()=>{e.style.backgroundColor=""});let n=document.createElement("td");n.textContent=t.username,C(n,{padding:"12px 15px",borderBottom:"1px solid #dee2e6"});let o=document.createElement("td");o.textContent=t.displayName,C(o,{padding:"12px 15px",borderBottom:"1px solid #dee2e6"});let r=document.createElement("td"),s=document.createElement("span");s.textContent=t.role||"user";let i="#6c757d";t.role==="admin"?i="#dc3545":t.role==="moderator"&&(i="#ffc107"),C(s,{backgroundColor:i,color:"white",padding:"3px 8px",borderRadius:"12px",fontSize:"12px",fontWeight:"bold",textTransform:"uppercase"}),r.appendChild(s),C(r,{padding:"12px 15px",borderBottom:"1px solid #dee2e6"});let a=document.createElement("td"),l=document.createElement("span");l.textContent=t.status||"offline";let c="#6c757d";t.status==="online"?c="#28a745":t.status==="away"?c="#ffc107":t.status==="dnd"&&(c="#dc3545"),C(l,{backgroundColor:c,color:"white",padding:"3px 8px",borderRadius:"12px",fontSize:"12px"}),a.appendChild(l),C(a,{padding:"12px 15px",borderBottom:"1px solid #dee2e6"});let p=document.createElement("td");p.textContent=Is(t.lastLogin),C(p,{padding:"12px 15px",borderBottom:"1px solid #dee2e6"});let u=document.createElement("td");C(u,{padding:"12px 15px",borderBottom:"1px solid #dee2e6"});let m=document.createElement("div");C(m,{display:"flex",gap:"5px"});let x=gn("\u270F\uFE0F","Edit user"),N=gn("\u{1F511}","Reset password"),A=gn("\u{1F5D1}\uFE0F","Delete user");return m.appendChild(x),m.appendChild(N),m.appendChild(A),u.appendChild(m),e.appendChild(n),e.appendChild(o),e.appendChild(r),e.appendChild(a),e.appendChild(p),e.appendChild(u),e}function gn(t,e){let n=document.createElement("button");return n.textContent=t,n.title=e,C(n,{width:"28px",height:"28px",borderRadius:"4px",border:"1px solid #dee2e6",backgroundColor:"white",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"14px"}),n.addEventListener("mouseover",()=>{n.style.backgroundColor="#f8f9fa"}),n.addEventListener("mouseout",()=>{n.style.backgroundColor="white"}),n}function Ms(t,e,n){let o=document.createElement("div");C(o,{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"10px 15px",backgroundColor:"#f8f9fa",borderTop:"1px solid #dee2e6"});let r=document.createElement("div");r.textContent=`Showing ${n} of ${n} users`,C(r,{fontSize:"14px",color:"#6c757d"});let s=document.createElement("div");C(s,{display:"flex",gap:"5px",alignItems:"center"});let i=document.createElement("button");i.textContent="\u27E8\u27E8",i.title="First Page",C(i,{padding:"5px 10px",border:"1px solid #dee2e6",borderRadius:"4px",backgroundColor:"white",cursor:"pointer",opacity:"0.5"}),i.disabled=!0;let a=document.createElement("button");a.textContent="\u27E8",a.title="Previous Page",C(a,{padding:"5px 10px",border:"1px solid #dee2e6",borderRadius:"4px",backgroundColor:"white",cursor:"pointer",opacity:"0.5"}),a.disabled=!0;let l=document.createElement("span");l.textContent=`Page ${t} of ${e}`,C(l,{padding:"0 10px",fontSize:"14px"});let c=document.createElement("button");c.textContent="\u27E9",c.title="Next Page",C(c,{padding:"5px 10px",border:"1px solid #dee2e6",borderRadius:"4px",backgroundColor:"white",cursor:"pointer",opacity:"0.5"}),c.disabled=!0;let p=document.createElement("button");return p.textContent="\u27E9\u27E9",p.title="Last Page",C(p,{padding:"5px 10px",border:"1px solid #dee2e6",borderRadius:"4px",backgroundColor:"white",cursor:"pointer",opacity:"0.5"}),p.disabled=!0,s.appendChild(i),s.appendChild(a),s.appendChild(l),s.appendChild(c),s.appendChild(p),o.appendChild(r),o.appendChild(s),o}function Ls(t){let e=document.createElement("div");C(e,{textAlign:"center",padding:"20px",color:"#666"}),e.textContent="Channel management interface would go here",t.appendChild(e)}function As(t){let e=document.createElement("div");C(e,{textAlign:"center",padding:"20px",color:"#666"}),e.textContent="Roles and permissions management interface would go here",t.appendChild(e)}function Rs(t){let e=document.createElement("div");C(e,{textAlign:"center",padding:"20px",color:"#666"}),e.textContent="Audit log interface would go here",t.appendChild(e)}function Is(t){if(!t)return"Never";try{return new Date(t).toLocaleString()}catch{return t}}function C(t,e){Object.assign(t.style,e)}function Oo(t,e={}){let{onLogout:n=()=>console.log("Logout not implemented")}=e,o=document.createElement("div");$(o,{display:"flex",flexDirection:"column",width:"100%",height:"100%",padding:"20px",backgroundColor:"#ffffff",overflowY:"auto"});let r=document.createElement("div");$(r,{marginBottom:"24px",borderBottom:"1px solid #e0e0e0",paddingBottom:"16px"});let s=document.createElement("h2");return s.textContent="Settings",$(s,{margin:"0",fontSize:"20px",color:"#333"}),r.appendChild(s),o.appendChild(r),[{title:"Appearance",icon:"\u{1F3A8}",description:"Customize the look and feel of the chat.",settings:[{name:"Theme",type:"select",options:["Light","Dark","System"],defaultValue:"Light"},{name:"Font Size",type:"select",options:["Small","Medium","Large"],defaultValue:"Small"}]},{title:"Privacy & Security",icon:"\u{1F512}",description:"Manage security and privacy settings.",settings:[{name:"Change Password",type:"button",label:"Change Password"},{name:"Two-Factor Authentication",type:"checkbox"}]},{title:"Account",icon:"\u{1F464}",description:"Manage your account settings.",settings:[{name:"Logout",type:"logout",label:"Sign Out",description:"Log out of your account"}]}].forEach(a=>{let l=Ns(a,n);o.appendChild(l)}),t.appendChild(o),o}function Ns(t,e){let n=document.createElement("div");$(n,{marginBottom:"24px",padding:"16px",backgroundColor:"#f8f9fa",borderRadius:"8px"});let o=document.createElement("div");$(o,{display:"flex",alignItems:"center",marginBottom:"12px"});let r=document.createElement("span");r.textContent=t.icon,$(r,{fontSize:"20px",marginRight:"8px"});let s=document.createElement("h3");if(s.textContent=t.title,$(s,{margin:"0",fontSize:"16px",color:"#333"}),o.appendChild(r),o.appendChild(s),t.description){let i=document.createElement("p");i.textContent=t.description,$(i,{margin:"0 0 16px 0",fontSize:"14px",color:"#666"}),n.appendChild(o),n.appendChild(i)}if(t.settings&&t.settings.length){let i=document.createElement("div");$(i,{display:"flex",flexDirection:"column",gap:"12px"}),t.settings.forEach(a=>{let l=Us(a,e);i.appendChild(l)}),n.appendChild(i)}return n}function Us(t,e){let n=document.createElement("div");$(n,{display:"flex",alignItems:"center",justifyContent:"space-between"});let o=document.createElement("div");$(o,{display:"flex",flexDirection:"column"});let r=document.createElement("label");r.textContent=t.name,$(r,{fontSize:"14px",color:"#333"}),o.appendChild(r);let s;switch(t.type){case"select":s=document.createElement("select"),$(s,{padding:"8px",border:"1px solid #ddd",borderRadius:"4px",width:"120px"}),t.options&&t.options.length&&t.options.forEach(i=>{let a=document.createElement("option");a.value=i,a.textContent=i,i===t.defaultValue&&(a.selected=!0),s.appendChild(a)});break;case"checkbox":s=document.createElement("input"),s.type="checkbox";break;case"button":s=document.createElement("button"),s.textContent=t.label,$(s,{padding:"8px 12px",backgroundColor:"#fff",color:"#333",border:"1px solid #ddd",borderRadius:"4px",cursor:"pointer"});break;case"logout":s=document.createElement("button"),s.textContent=t.label,$(s,{padding:"8px 12px",backgroundColor:"#dc3545",color:"white",border:"none",borderRadius:"4px",cursor:"pointer"}),s.addEventListener("mouseover",()=>{s.style.backgroundColor="#c82333"}),s.addEventListener("mouseout",()=>{s.style.backgroundColor="#dc3545"}),s.addEventListener("click",e);break;default:s=document.createElement("span"),s.textContent="Unsupported setting type"}return n.appendChild(o),n.appendChild(s),n}function $(t,e){Object.assign(t.style,e)}var fn=class{constructor(e){this.container=e,this.appElement=null,this.headerComponent=null,this.loginFormComponent=null,this.notificationSystem=null,this.connectionStatus="connected",this.currentView="chat",this.showUserList=!0,this.selectedChannel="general",this.mockData={},this.unsubscribeConnectionStatus=null,this.render=this.render.bind(this),this.handleConnectionStatusChange=this.handleConnectionStatusChange.bind(this),this.handleLoginSuccess=this.handleLoginSuccess.bind(this),this.handleChannelSelect=this.handleChannelSelect.bind(this),this.handleUserSelect=this.handleUserSelect.bind(this),this.switchView=this.switchView.bind(this),this.toggleUserList=this.toggleUserList.bind(this),this.toggleChatVisibility=this.toggleChatVisibility.bind(this),this.handleLogout=this.handleLogout.bind(this),this.initialize()}async initialize(){try{let e=document.createElement("div");e.className="hipaa-chat-wrapper",e.id="hipaa-chat-container",this.applyStyles(e,{position:"fixed",bottom:"20px",right:"20px",zIndex:"9999",width:"700px",height:"500px",boxSizing:"border-box",display:"none"}),this.container&&this.container.parentNode?this.container.parentNode.replaceChild(e,this.container):document.body.appendChild(e),this.container=e,this.appElement=document.createElement("div"),this.appElement.className="hipaa-chat-app",this.applyStyles(this.appElement,{display:"flex",flexDirection:"column",width:"100%",height:"100%",overflow:"hidden",fontFamily:'-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, "Open Sans", "Helvetica Neue", sans-serif',borderRadius:"8px",boxShadow:"0 4px 12px rgba(0, 0, 0, 0.3)",color:"#333",backgroundColor:"#fff"}),this.container.appendChild(this.appElement),this.mockData=this.setupMockData(),window.toggleChatUI=this.toggleChatVisibility,console.log("[CRM Extension] toggleChatUI registered globally",typeof window.toggleChatUI),_o()||await X(),this.unsubscribeConnectionStatus=nn(this.handleConnectionStatusChange),this.connectionStatus=tn(),this.notificationSystem=new cn,S()&&ue(),this.render(),d("system","Application initialized")}catch(e){console.error("[AppContainer] Initialization error:",e),this.renderErrorState(e)}}toggleChatVisibility(){if(!this.container)return;console.log("[CRM Extension] toggleChatVisibility called");let e=this.container.style.display,n=e==="none"||e===""?"flex":"none";this.container.style.display=n,n==="flex"&&this.render(),console.log(`[CRM Extension] Chat container toggled to: ${this.container.style.display}`)}handleConnectionStatusChange(e){try{this.connectionStatus=e,this.render(),d("system",`Connection status changed: ${e}`)}catch(n){console.error("[AppContainer] Connection status change error:",n)}}handleLoginSuccess(e){try{if(console.log("[AppContainer] Login success handler called",e),!e||!e.username){console.error("[AppContainer] Invalid user object received");return}ue(),this.render(),d("auth","User logged in successfully",{username:e.username,userId:e.id,role:e.role})}catch(n){console.error("[AppContainer] Login success handler error:",n),alert("An error occurred during login. Please try again.")}}handleChannelSelect(e){try{console.log(`[AppContainer] Channel selected: ${e.id}`),this.selectedChannel=e.id,this.render()}catch(n){console.error("[AppContainer] Channel selection error:",n)}}handleUserSelect(e){try{console.log(`[AppContainer] Selected user for direct message: ${e.username}`),d("ui","Selected user for direct message",{targetUser:e.username})}catch(n){console.error("[AppContainer] User selection error:",n)}}switchView(e){try{this.currentView!==e&&(this.currentView=e,this.render(),d("ui",`Switched to ${e} view`))}catch(n){console.error("[AppContainer] View switch error:",n)}}toggleUserList(){try{this.showUserList=!this.showUserList,this.render(),d("ui",`${this.showUserList?"Showed":"Hid"} user list`)}catch(e){console.error("[AppContainer] Toggle user list error:",e)}}handleLogout(){try{oe(),this.currentView="chat",this.showUserList=!0,this.selectedChannel="general",d("auth","User logged out"),this.appElement&&(this.appElement.innerHTML=""),this.loginFormComponent=new bt(this.appElement,this.handleLoginSuccess)}catch(e){console.error("[AppContainer] Logout error:",e)}}render(){try{if(console.log("Rendering application, authenticated:",S()),!this.appElement)return;if(this.appElement.innerHTML="",!S()){this.loginFormComponent=new bt(this.appElement,this.handleLoginSuccess);return}let n=E();if(console.log("Current user:",n),!n){console.error("[AppContainer] No current user found"),this.handleLogout();return}let o;try{o=Po(null,{currentUser:n,connectionStatus:this.connectionStatus,activeView:this.currentView,onViewSwitch:this.switchView,onToggleUserList:this.toggleUserList,onLogout:this.handleLogout})}catch(s){console.warn("[AppContainer] Error using createCustomHeader, falling back to Header component:",s),this.headerComponent=new pn({user:n,connectionStatus:this.connectionStatus,activeView:this.currentView,onViewSwitch:this.switchView,onToggleUserList:this.toggleUserList}),o=this.headerComponent.render()}this.appElement.appendChild(o);let r=document.createElement("div");r.className="app-content",this.applyStyles(r,{display:"flex",flex:"1",overflow:"hidden",backgroundColor:"#f5f7f9",width:"100%"});try{this.currentView==="chat"?Vo(r,{showUserList:this.showUserList,selectedChannel:this.selectedChannel,mockChannels:this.mockData.channels,mockUsers:this.mockData.users,onChannelSelect:this.handleChannelSelect,onUserSelect:this.handleUserSelect,toggleUserList:this.toggleUserList}):this.currentView==="admin"?Fo(r,{currentUser:n}):this.currentView==="settings"&&Oo(r,{onLogout:this.handleLogout})}catch(s){console.error("[AppContainer] Error rendering view:",s),r.innerHTML='<div style="padding: 20px; text-align: center;">Error loading view. Please try again.</div>'}this.appElement.appendChild(r)}catch(e){console.error("[AppContainer] Render error:",e),this.renderErrorState(e)}}renderErrorState(e){if(!this.appElement)return;this.appElement.innerHTML="";let n=document.createElement("div");this.applyStyles(n,{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",padding:"20px",textAlign:"center",backgroundColor:"#f8d7da",color:"#721c24"});let o=document.createElement("div");o.textContent="\u26A0\uFE0F",this.applyStyles(o,{fontSize:"48px",marginBottom:"16px"});let r=document.createElement("h2");r.textContent="Application Initialization Failed";let s=document.createElement("p");s.textContent=e.message||"An unexpected error occurred.";let i=document.createElement("button");i.textContent="Retry",this.applyStyles(i,{backgroundColor:"#007bff",color:"white",border:"none",padding:"10px 20px",borderRadius:"4px",marginTop:"16px",cursor:"pointer"}),i.addEventListener("click",()=>this.initialize()),n.appendChild(o),n.appendChild(r),n.appendChild(s),n.appendChild(i),this.appElement.appendChild(n)}applyStyles(e,n){Object.assign(e.style,n)}destroy(){try{this.unsubscribeConnectionStatus&&this.unsubscribeConnectionStatus(),this.notificationSystem&&this.notificationSystem.destroy(),this.appElement&&this.appElement.parentNode&&this.appElement.parentNode.removeChild(this.appElement),window.toggleChatUI===this.toggleChatVisibility&&delete window.toggleChatUI,d("system","Application destroyed")}catch(e){console.error("[AppContainer] Destruction error:",e)}}},xn=fn;var yn=null;function q(){try{if(document.getElementById("hipaa-chat-container"))return console.log("[CRM Extension] Chat UI already initialized"),!0;console.log("[CRM Extension] Initializing Chat UI");let t=document.createElement("div");return t.id="hipaa-chat-container",Object.assign(t.style,{position:"fixed",bottom:"20px",right:"20px",width:"400px",height:"500px",backgroundColor:"#f0f8ff",borderRadius:"8px",boxShadow:"0 4px 12px rgba(0, 0, 0, 0.3)",zIndex:"10000",overflow:"hidden",border:"2px solid #2196F3",display:"none"}),document.body.appendChild(t),yn=new xn(t),window.toggleChatUI=function(){console.log("[CRM Extension] toggleChatUI called");let e=document.getElementById("hipaa-chat-container");if(!e){console.error("[CRM Extension] Chat container not found");return}let n=e.style.display!=="none";if(e.style.display=n?"none":"flex",console.log(`[CRM Extension] Chat container toggled to: ${e.style.display}`),!n&&yn)try{yn.render()}catch(o){console.error("[CRM Extension] Error rendering chat app:",o)}},d("system","Chat UI initialized"),!0}catch(t){return console.error("[CRM Extension] Error initializing Chat UI:",t),!1}}var Cn=!1,qo=[];async function X(){if(Cn)return console.log("[CRM Extension] Chat system already initialized"),!0;try{if(console.log("[CRM Extension] Initializing HIPAA-compliant chat system"),!io())throw new Error("Failed to initialize storage");if(await nt(),!lt())throw new Error("Failed to initialize auth service");if(!No())throw new Error("Failed to initialize user service");if(!To())throw new Error("Failed to initialize channel service");if(!Ao())throw new Error("Failed to initialize message service");return q(),d("system","HIPAA-compliant chat system initialized"),Cn=!0,console.log("[CRM Extension] HIPAA-compliant chat system initialized successfully"),sn.getAuthState().authenticated&&ue(),!0}catch(t){return console.error("[CRM Extension] Failed to initialize chat system:",t),d("error","Failed to initialize chat system",{error:t.message}),!1}}function Go(){let t=Xe(on());setInterval(()=>{getConnectionStatus()==="disconnected"&&(console.log("[CRM Extension] Attempting to reconnect chat"),ue())},3e4),d("system","Chat monitoring initialized")}function _o(){return Cn}function Jo(t){typeof t=="function"&&!qo.includes(t)&&qo.push(t)}function Pe(t,e,n={}){let o=document.createElement("div");o.className="group";let r=document.createElement("span");r.className="label",r.textContent=`${e}:`,o.appendChild(r);let s=document.createElement("span");if(s.id=`${t}-display`,s.className="clickable-value",n.initialValue&&s.setAttribute("data-value",n.initialValue),n.icon){let l=document.createElement("span");l.className="btn-icon",l.innerHTML=n.icon,s.appendChild(l)}let i=document.createElement("span");i.textContent=n.initialValue||"",i.id=`${t}-text`,s.appendChild(i);let a=async()=>{let l=s.getAttribute("data-value")||i.textContent.trim();l&&l!==""?await we(l)?y(`Copied ${e}: ${l}`):y(`Failed to copy ${e.toLowerCase()}`):y(`No ${e.toLowerCase()} available to copy`)};return s.addEventListener("click",()=>{n.onClick?n.onClick(s):a()}),s.title=`Click to copy ${e.toLowerCase()} to clipboard`,o.appendChild(s),o}function Yo(){let t=document.createElement("div");return t.className="group",t.id="crm-actions-group",t}function Ko(){let t=document.createElement("div");t.className="dropdown",t.id="crm-tags-dropdown";let e=document.createElement("button");e.className="dropdown-btn",e.textContent="Tags",e.addEventListener("click",h=>{h.stopPropagation(),document.querySelectorAll(".dropdown.show").forEach(Mn=>{Mn!==t&&Mn.classList.remove("show")}),t.classList.toggle("show")});let n=document.createElement("div");if(n.className="dropdown-content",n.style.padding="10px",!document.getElementById("tags-dropdown-styles")){let h=document.createElement("style");h.id="tags-dropdown-styles",h.textContent=`
      .nested-dropdown {
        margin-bottom: 8px;
        width: 100%;
        position: relative;
      }
      .nested-dropdown-btn {
        width: 100%;
        text-align: left;
        padding: 8px 12px;
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 3px;
        cursor: pointer;
        font-weight: bold;
        font-size: 13px;
        color: #e6e6e6;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .nested-dropdown-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      .nested-dropdown-btn:after {
        content: "\u25BC";
        font-size: 8px;
        color: #e6e6e6;
      }
      .nested-dropdown-content {
        display: none;
        padding: 5px 0 5px 10px;
        margin-top: 3px !important;
      }
      .nested-dropdown.open .nested-dropdown-content {
        display: block;
      }
      
      /* Button-style tag options */
      .tag-btn {
        display: block;
        width: 100%;
        padding: 8px 12px;
        margin-bottom: 8px;
        background-color: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 4px;
        text-align: left;
        font-size: 13px;
        color: #e6e6e6;
        cursor: pointer;
        transition: all 0.2s ease;
        font-weight: normal;
      }
      .tag-btn:hover {
        background-color: rgba(255, 255, 255, 0.15);
        border-color: rgba(255, 255, 255, 0.2);
      }
      .tag-btn:active {
        background-color: rgba(255, 255, 255, 0.2);
      }
    `,document.head.appendChild(h)}let o=document.createElement("button");o.className="tag-btn",o.textContent="Opt-in",o.addEventListener("click",()=>{Zo("opt-in"),t.classList.remove("show")}),n.appendChild(o);let r=document.createElement("button");r.className="tag-btn",r.textContent="Refill-Sema-Inj",r.addEventListener("click",()=>{I("refill-sema-inj"),t.classList.remove("show")}),n.appendChild(r);let s=document.createElement("button");s.className="tag-btn",s.textContent="Refill-Tirz-Inj",s.addEventListener("click",()=>{I("refill-tirz-inj"),t.classList.remove("show")}),n.appendChild(s);let i=document.createElement("div");i.className="nested-dropdown";let a=document.createElement("button");a.className="nested-dropdown-btn",a.textContent="Vial-Semaglutide";let l=document.createElement("div");l.className="nested-dropdown-content",a.addEventListener("click",h=>{h.stopPropagation(),i.classList.toggle("open")});let c=document.createElement("button");c.className="tag-btn",c.textContent="Vial-Sema-B12",c.addEventListener("click",h=>{h.stopPropagation(),P(),I("vial-sema-b12")}),l.appendChild(c);let p=document.createElement("button");p.className="tag-btn",p.textContent="Vial-Sema-B6",p.addEventListener("click",h=>{h.stopPropagation(),P(),I("vial-sema-b6")}),l.appendChild(p);let u=document.createElement("button");u.className="tag-btn",u.textContent="Vial-Sema-Lipo",u.addEventListener("click",h=>{h.stopPropagation(),P(),I("vial-sema-lipo")}),l.appendChild(u);let m=document.createElement("button");m.className="tag-btn",m.textContent="Vial-Sema-NAD+",m.addEventListener("click",h=>{h.stopPropagation(),P(),I("vial-sema-nad+")}),l.appendChild(m),i.appendChild(a),i.appendChild(l),n.appendChild(i);let x=document.createElement("div");x.className="nested-dropdown";let N=document.createElement("button");N.className="nested-dropdown-btn",N.textContent="Vial-Tirzepatide";let A=document.createElement("div");A.className="nested-dropdown-content",N.addEventListener("click",h=>{h.stopPropagation(),x.classList.toggle("open")});let F=document.createElement("button");F.className="tag-btn",F.textContent="Vial-Tirz-Cyano",F.addEventListener("click",h=>{h.stopPropagation(),P(),I("vial-tirz-cyano")}),A.appendChild(F);let W=document.createElement("button");W.className="tag-btn",W.textContent="Vial-Tirz-NAD+",W.addEventListener("click",h=>{h.stopPropagation(),P(),I("vial-tirz-nad+")}),A.appendChild(W);let b=document.createElement("button");b.className="tag-btn",b.textContent="Vial-Tirz-Pyr",b.addEventListener("click",h=>{h.stopPropagation(),P(),I("vial-tirz-pyridoxine")}),A.appendChild(b),x.appendChild(N),x.appendChild(A),n.appendChild(x);let M=document.createElement("div");M.className="nested-dropdown";let R=document.createElement("button");R.className="nested-dropdown-btn",R.textContent="NP-Semaglutide";let T=document.createElement("div");T.className="nested-dropdown-content",R.addEventListener("click",h=>{h.stopPropagation(),M.classList.toggle("open")});let K=document.createElement("button");K.className="tag-btn",K.textContent="NP-Sema 0.125",K.addEventListener("click",h=>{h.stopPropagation(),P(),I("np-sema-0.125ml-inj")}),T.appendChild(K);let Z=document.createElement("button");Z.className="tag-btn",Z.textContent="NP-Sema 0.25",Z.addEventListener("click",h=>{h.stopPropagation(),P(),I("np-sema-0.25ml-inj")}),T.appendChild(Z);let G=document.createElement("button");G.className="tag-btn",G.textContent="NP-Sema 0.5",G.addEventListener("click",h=>{h.stopPropagation(),P(),I("np-sema-0.5ml-inj")}),T.appendChild(G);let z=document.createElement("button");z.className="tag-btn",z.textContent="NP-Sema 0.75",z.addEventListener("click",h=>{h.stopPropagation(),P(),I("np-sema-0.75ml-inj")}),T.appendChild(z);let he=document.createElement("button");he.className="tag-btn",he.textContent="NP-Sema 1.0",he.addEventListener("click",h=>{h.stopPropagation(),P(),I("np-sema-1.0ml-inj")}),T.appendChild(he);let w=document.createElement("button");w.className="tag-btn",w.textContent="NP-Sema 1.25",w.addEventListener("click",h=>{h.stopPropagation(),P(),I("np-sema-1.25ml-inj")}),T.appendChild(w);let k=document.createElement("button");k.className="tag-btn",k.textContent="NP-Sema 1.5",k.addEventListener("click",h=>{h.stopPropagation(),P(),I("np-sema-1.5ml-inj")}),T.appendChild(k);let L=document.createElement("button");L.className="tag-btn",L.textContent="NP-Sema 2.0",L.addEventListener("click",h=>{h.stopPropagation(),P(),I("np-sema-2.0ml-inj")}),T.appendChild(L),M.appendChild(R),M.appendChild(T),n.appendChild(M);let Q=document.createElement("div");Q.className="nested-dropdown";let re=document.createElement("button");re.className="nested-dropdown-btn",re.textContent="NP-Tirzepatide";let de=document.createElement("div");de.className="nested-dropdown-content",re.addEventListener("click",h=>{h.stopPropagation(),Q.classList.toggle("open")});let Ve=document.createElement("button");Ve.className="tag-btn",Ve.textContent="NP-Tirz 0.25",Ve.addEventListener("click",h=>{h.stopPropagation(),P(),I("np-tirz-0.25ml-inj")}),de.appendChild(Ve);let ze=document.createElement("button");ze.className="tag-btn",ze.textContent="NP-Tirz 0.5",ze.addEventListener("click",h=>{h.stopPropagation(),P(),I("np-tirz-0.5ml-inj")}),de.appendChild(ze);let Fe=document.createElement("button");Fe.className="tag-btn",Fe.textContent="NP-Tirz 0.75",Fe.addEventListener("click",h=>{h.stopPropagation(),P(),I("np-tirz-0.75ml-inj")}),de.appendChild(Fe);let Oe=document.createElement("button");Oe.className="tag-btn",Oe.textContent="NP-Tirz 1.0",Oe.addEventListener("click",h=>{h.stopPropagation(),P(),I("np-tirz-1.0ml-inj")}),de.appendChild(Oe);let _e=document.createElement("button");_e.className="tag-btn",_e.textContent="NP-Tirz 1.25",_e.addEventListener("click",h=>{h.stopPropagation(),P(),I("np-tirz-1.25ml-inj")}),de.appendChild(_e);let $e=document.createElement("button");return $e.className="tag-btn",$e.textContent="NP-Tirz 1.5",$e.addEventListener("click",h=>{h.stopPropagation(),P(),I("np-tirz-1.5ml-inj")}),de.appendChild($e),Q.appendChild(re),Q.appendChild(de),n.appendChild(Q),t.appendChild(e),t.appendChild(n),t}function P(){document.querySelectorAll(".dropdown.show").forEach(t=>t.classList.remove("show")),document.querySelectorAll(".nested-dropdown.open").forEach(t=>t.classList.remove("open"))}async function I(t){try{let[e,n]=await Promise.all([It(),Nt()]);console.log("[CRM Extension] Cleanup completed:"),console.log(`- Tags: ${e.removed}/${e.total} removed`),console.log(`- Automations: ${n.removed}/${n.total} removed`),Zo(t)}catch(e){console.error("[CRM Extension] Error during cleanup:",e),y("Error during cleanup. Please try again.")}}function Zo(t){let e=pi();e?(e.focus(),setTimeout(()=>{e.value=t,e.dispatchEvent(new Event("input",{bubbles:!0})),setTimeout(()=>{let n=document.querySelectorAll(".v-list-item, .dropdown-item, .select-option, li"),o=!1;for(let r of n)if(r.textContent.toLowerCase().includes(t)){r.click(),o=!0,y(`Selected tag: ${t}`);break}if(!o){let r=document.querySelectorAll("*");for(let s of r)if(s.textContent.trim().toLowerCase()===t){s.click(),o=!0,y(`Selected tag: ${t}`);break}o||e.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",code:"Enter",keyCode:13,which:13,bubbles:!0}))}},300)},300)):y("Tags field not found")}function pi(){let t=document.querySelector('input[placeholder="Add Tags"]');if(t)return t;let e=Array.from(document.querySelectorAll("input[placeholder]")).filter(s=>s.placeholder.toLowerCase().includes("tag"));if(e.length>0)return e[0];let n=document.querySelectorAll(".tag-input, .tags-input, .tag-container");for(let s of n){let i=s.querySelector("input");if(i)return i}if(t=document.querySelector('input[placeholder="smartList.bulkTags.addTags"]'),t)return t;let o=document.querySelectorAll(".hl-text-input");if(o.length>0)return o[0];console.error("[CRM Extension] Could not find tag input field with any strategy");let r=document.querySelectorAll("input");return console.log("[CRM Extension] All inputs on page:",r),null}var ae={"Sema/B12 Refill - Step 2":"Refill - Semaglutide/B12 Injection Refill Order - (Step 2)","Sema/B12 Vial - Step 2":"Semaglutide/B12 Vial Order - (Step 2)","Sema/B6 Vial - Step 2":"Semaglutide/B6 Vial Order - (Step 2)","Sema/Lipo Vial - Step 2":"Semaglutide/Lipo Vial Order - (Step 2)","Sema/NAD+ Vial - Step 2":"Semaglutide/NAD+ Vial Order - (Step 2)","Tirz/B6 Refill - Step 2":"Syringe - Tirzepatide/Pyridoxine Injection Order - (Step 2)","Tirz/B12 Vial - Step 2":"Tirzepatide/Cyano Vial Order - (Step 2)","Tirz/NAD+ Vial - Step 2":"Tirzepatide/NAD+ Vial Order - (Step 2)","Tirz/B6 Vial - Step 2":"Tirzepatide/Pyridoxine Vial Order - (Step 2)"};function Qo(){let t=document.createElement("div");t.className="dropdown",t.id="crm-automation-dropdown";let e=document.createElement("button");e.className="dropdown-btn",e.textContent="Automation",e.addEventListener("click",b=>{b.stopPropagation(),document.querySelectorAll(".dropdown.show").forEach(M=>{M!==t&&M.classList.remove("show")}),t.classList.toggle("show")});let n=document.createElement("div");if(n.className="dropdown-content",n.style.padding="10px",!document.getElementById("automation-dropdown-styles")){let b=document.createElement("style");b.id="automation-dropdown-styles",b.textContent=`
      .nested-dropdown {
        margin-bottom: 8px;
        width: 100%;
        position: relative;
      }
      .nested-dropdown-btn {
        width: 100%;
        text-align: left;
        padding: 8px 12px;
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 3px;
        cursor: pointer;
        font-weight: bold;
        font-size: 13px;
        color: #e6e6e6;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .nested-dropdown-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      .nested-dropdown-btn:after {
        content: "\u25BC";
        font-size: 8px;
        color: #e6e6e6;
      }
      .nested-dropdown-content {
        display: none;
        padding: 5px 0 5px 10px;
        margin-top: 3px !important;
      }
      .nested-dropdown.open .nested-dropdown-content {
        display: block;
      }
      
      /* Button-style options */
      .automation-btn {
        display: block;
        width: 100%;
        padding: 8px 12px;
        margin-bottom: 8px;
        background-color: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 4px;
        text-align: left;
        font-size: 13px;
        color: #e6e6e6;
        cursor: pointer;
        transition: all 0.2s ease;
        font-weight: normal;
      }
      .automation-btn:hover {
        background-color: rgba(255, 255, 255, 0.15);
        border-color: rgba(255, 255, 255, 0.2);
      }
      .automation-btn:active {
        background-color: rgba(255, 255, 255, 0.2);
      }
    `,document.head.appendChild(b)}let o=document.createElement("div");o.className="nested-dropdown";let r=document.createElement("button");r.className="nested-dropdown-btn",r.textContent="Semaglutide (Step 2)";let s=document.createElement("div");s.className="nested-dropdown-content",r.addEventListener("click",b=>{b.stopPropagation(),o.classList.toggle("open")});let i=document.createElement("button");i.className="automation-btn",i.textContent="Sema/B12 Refill - Step 2",i.addEventListener("click",b=>{b.stopPropagation(),le(),setTimeout(()=>{ce(ae["Sema/B12 Refill - Step 2"])},300)}),s.appendChild(i);let a=document.createElement("button");a.className="automation-btn",a.textContent="Sema/B12 Vial - Step 2",a.addEventListener("click",b=>{b.stopPropagation(),le(),setTimeout(()=>{ce(ae["Sema/B12 Vial - Step 2"])},300)}),s.appendChild(a);let l=document.createElement("button");l.className="automation-btn",l.textContent="Sema/B6 Vial - Step 2",l.addEventListener("click",b=>{b.stopPropagation(),le(),setTimeout(()=>{ce(ae["Sema/B6 Vial - Step 2"])},300)}),s.appendChild(l);let c=document.createElement("button");c.className="automation-btn",c.textContent="Sema/Lipo Vial - Step 2",c.addEventListener("click",b=>{b.stopPropagation(),le(),setTimeout(()=>{ce(ae["Sema/Lipo Vial - Step 2"])},300)}),s.appendChild(c);let p=document.createElement("button");p.className="automation-btn",p.textContent="Sema/NAD+ Vial - Step 2",p.addEventListener("click",b=>{b.stopPropagation(),le(),setTimeout(()=>{ce(ae["Sema/NAD+ Vial - Step 2"])},300)}),s.appendChild(p),o.appendChild(r),o.appendChild(s),n.appendChild(o);let u=document.createElement("div");u.className="nested-dropdown";let m=document.createElement("button");m.className="nested-dropdown-btn",m.textContent="Tirzepatide (Step 2)";let x=document.createElement("div");x.className="nested-dropdown-content",m.addEventListener("click",b=>{b.stopPropagation(),u.classList.toggle("open")});let N=document.createElement("button");N.className="automation-btn",N.textContent="Tirz/B6 Refill - Step 2",N.addEventListener("click",b=>{b.stopPropagation(),le(),setTimeout(()=>{ce(ae["Tirz/B6 Refill - Step 2"])},300)}),x.appendChild(N);let A=document.createElement("button");A.className="automation-btn",A.textContent="Tirz/B12 Vial - Step 2",A.addEventListener("click",b=>{b.stopPropagation(),le(),setTimeout(()=>{ce(ae["Tirz/B12 Vial - Step 2"])},300)}),x.appendChild(A);let F=document.createElement("button");F.className="automation-btn",F.textContent="Tirz/NAD+ Vial - Step 2",F.addEventListener("click",b=>{b.stopPropagation(),le(),setTimeout(()=>{ce(ae["Tirz/NAD+ Vial - Step 2"])},300)}),x.appendChild(F);let W=document.createElement("button");return W.className="automation-btn",W.textContent="Tirz/B6 Vial - Step 2",W.addEventListener("click",b=>{b.stopPropagation(),le(),setTimeout(()=>{ce(ae["Tirz/B6 Vial - Step 2"])},300)}),x.appendChild(W),u.appendChild(m),u.appendChild(x),n.appendChild(u),t.appendChild(e),t.appendChild(n),t}function le(){document.querySelectorAll(".dropdown.show").forEach(t=>t.classList.remove("show")),document.querySelectorAll(".nested-dropdown.open").forEach(t=>t.classList.remove("open"))}function ce(t){try{console.log(`[CRM Extension] Starting workflow for "${t}"`),y(`Starting workflow for "${t}"`);let e=Array.from(document.querySelectorAll("button.btn.btn-light2.btn-xs")).find(n=>n.textContent.trim().includes("Add"));if(!e){console.error("[CRM Extension] Add Automation button not found"),y("Add Automation button not found");return}console.log("[CRM Extension] Found Add button, clicking it"),e.click(),setTimeout(()=>{let n=document.querySelector('input[placeholder="Type to search"]');if(!n){console.error("[CRM Extension] Search input not found"),y("Search input not found");return}console.log("[CRM Extension] Found search input, entering 'step 2'"),n.focus(),n.value="step 2",n.dispatchEvent(new Event("input",{bubbles:!0})),setTimeout(()=>{let o=[".v-list",".dropdown-menu",".v-select-list",".vs__dropdown-menu",'[role="listbox"]',"ul",".v-menu__content"],r=null;for(let c of o){let p=document.querySelector(c);if(p&&p.querySelector("li, .v-list-item, .dropdown-item")&&p.scrollHeight>p.clientHeight){r=p,console.log(`[CRM Extension] Found scrollable dropdown container: ${c}`);break}}if(!r){let c=document.querySelector('.modal, dialog, [role="dialog"]');if(c){let p=Array.from(c.querySelectorAll("*")).filter(u=>u.scrollHeight>u.clientHeight&&u.clientHeight>50);p.length>0&&(r=p[0],console.log("[CRM Extension] Found scrollable element via fallback method"))}}if(!r){console.error("[CRM Extension] Could not find scrollable container"),y("Could not find dropdown container");return}console.log("[CRM Extension] Starting scroll wheel simulation"),console.log(`[CRM Extension] Container dimensions: ${r.scrollHeight}x${r.clientHeight}`);let s=0,i=20,a=!1;function l(){if(a||s>=i){a||(console.error("[CRM Extension] Max scroll attempts reached without finding match"),y("Option not found after scrolling"));return}s++,console.log(`[CRM Extension] Scroll attempt ${s}/${i}`);let c=new WheelEvent("wheel",{deltaY:100,bubbles:!0});r.dispatchEvent(c),r.scrollTop+=100,console.log(`[CRM Extension] Scrolled to position: ${r.scrollTop}/${r.scrollHeight}`),setTimeout(()=>{let p=r.querySelectorAll('li, .v-list-item, .dropdown-item, [role="option"]');console.log(`[CRM Extension] Found ${p.length} options after scrolling`);for(let u of p){if(!u.textContent)continue;let m=u.textContent.trim();if(m===t&&!m.includes("Provider Paid")&&!m.includes("New Patient")){console.log(`[CRM Extension] Found exact matching option: "${m}"`);try{u.scrollIntoView({block:"center"}),setTimeout(()=>{u.click(),a=!0,setTimeout(()=>{let x=Array.from(document.querySelectorAll("button")).find(N=>N.textContent.trim()==="Add");x?(console.log("[CRM Extension] Clicking Add button in dialog"),x.click(),y(`Added "${t}" workflow`)):(console.error("[CRM Extension] Add button in dialog not found"),y("Add button in dialog not found"))},1e3)},300)}catch(x){console.error("[CRM Extension] Error clicking option:",x)}break}}if(!a){if(r.scrollHeight-r.scrollTop<=r.clientHeight+20){console.log("[CRM Extension] Reached bottom of dropdown without finding match"),y(`Reached end without finding "${t}"`);return}setTimeout(l,500)}},500)}l()},1500)},1e3)}catch(e){console.error("[CRM Extension] Error in workflow:",e),y(`Error in workflow: ${e.message}`)}}function Xo(){let t=document.createElement("div");return t.className="group",t.id="crm-dropdowns-group",t.appendChild(Qo()),t.appendChild(Ko()),document.addEventListener("click",e=>{document.querySelectorAll(".dropdown").forEach(o=>{o.contains(e.target)||(o.classList.remove("show"),o.querySelectorAll(".nested-dropdown").forEach(s=>{s.classList.remove("open")}))})}),ui(),t}function ui(){if(document.getElementById("custom-dropdown-styles"))return;let t=document.createElement("style");t.id="custom-dropdown-styles",t.textContent=`
    /* Improved dropdown positioning */
    .dropdown {
      position: relative !important;
      margin-right: 8px !important; /* Ensure space between dropdowns, reduced for tighter layout */
    }
    
    .dropdown:last-child {
      margin-right: 0 !important; /* Remove margin from the last dropdown */
    }
    
    .dropdown-content {
      position: absolute !important;
      background-color: #2F3A4B; /* Match toolbar background color */
      min-width: 220px !important; /* Increased width */
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.3);
      z-index: 999;
      border-radius: 4px;
      margin-top: 5px !important; /* Add space between button and dropdown */
      left: 0;
      top: 100% !important; /* Position below the button */
      display: none;
      border: 1px solid rgba(255, 255, 255, 0.1); /* Subtle border */
    }
    
    /* Ensure right-aligned dropdowns don't overflow */
    #crm-tags-dropdown .dropdown-content {
      right: 0;
      left: auto; /* Override left positioning for Tags dropdown */
    }
    
    .dropdown.show .dropdown-content {
      display: block;
    }
    
    /* Improved nested dropdown positioning */
    .nested-dropdown-content {
      margin-top: 3px !important;
      background-color: #2F3A4B; /* Match toolbar background color */
      border-radius: 4px;
      padding: 5px !important;
    }
    
    /* Style dropdown items */
    .dropdown-item {
      color: #e6e6e6; /* White text for visibility */
      padding: 10px 14px !important; /* Increased padding */
      text-decoration: none;
      display: block;
      font-size: 14px;
      cursor: pointer;
      border-radius: 3px;
      font-weight: normal;
    }
    
    .dropdown-item:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
    
    /* Fix for Vial-Sema and Vial-Tirz nested dropdowns */
    .nested-dropdown-btn {
      text-align: left !important;
      padding: 8px 12px !important;
      background-color: rgba(255, 255, 255, 0.1) !important;
      border: 1px solid rgba(255, 255, 255, 0.15) !important;
      color: #e6e6e6 !important;
      font-weight: bold !important;
    }
    
    .nested-dropdown-btn:hover {
      background-color: rgba(255, 255, 255, 0.2) !important;
    }
    
    /* Force visibility for Tags dropdown */
    #crm-tags-dropdown {
      display: flex !important;
    }
    
    #crm-tags-dropdown .dropdown-content {
      min-width: 220px !important;
    }
  `,document.head.appendChild(t)}function er(){let t=document.createElement("div");t.className="group",t.id="crm-settings-group",t.style.position="relative";let e=document.createElement("button");e.className="btn",e.id="crm-settings-btn";let n=document.createElement("span");n.className="btn-icon",n.innerHTML="\u2699\uFE0F",e.appendChild(n);let o=document.createElement("span");o.textContent="Settings",e.appendChild(o);let r=mi();if(e.addEventListener("click",s=>{s.stopPropagation(),r.classList.toggle("show")}),document.addEventListener("click",s=>{s.target!==e&&!e.contains(s.target)&&s.target!==r&&!r.contains(s.target)&&r.classList.remove("show")}),!document.getElementById("settings-dropdown-styles")){let s=document.createElement("style");s.id="settings-dropdown-styles",s.textContent=`
      #mcp-crm-settings-dropdown {
        display: none;
        position: absolute;
        top: calc(100% + 5px); /* Position below the button with 5px gap */
        right: 0;
        z-index: 1000;
        min-width: 230px;
        background-color: #2F3A4B;
        border-radius: 4px;
        border: 1px solid rgba(255, 255, 255, 0.1);
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
        overflow: hidden;
      }
      
      #mcp-crm-settings-dropdown.show {
        display: block;
      }
      
      .settings-header {
        padding: 10px;
        background-color: rgba(255, 255, 255, 0.1);
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        font-weight: bold;
        color: #e6e6e6;
      }
      
      .settings-body {
        padding: 10px;
        color: #e6e6e6;
      }
      
      .setting-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
        font-size: 13px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        padding-bottom: 10px;
      }
      
      .setting-item:last-child {
        margin-bottom: 0;
        border-bottom: none;
        padding-bottom: 0;
      }
      
      .setting-label {
        color: #e6e6e6;
        font-weight: normal;
      }
      
      /* Toggle switch styles */
      .switch {
        position: relative;
        display: inline-block;
        width: 40px;
        height: 20px;
      }
      
      .switch input {
        opacity: 0;
        width: 0;
        height: 0;
      }
      
      .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #555;
        transition: .4s;
        border-radius: 34px;
      }
      
      .slider:before {
        position: absolute;
        content: "";
        height: 16px;
        width: 16px;
        left: 2px;
        bottom: 2px;
        background-color: white;
        transition: .4s;
        border-radius: 50%;
      }
      
      input:checked + .slider {
        background-color: #2196F3;
      }
      
      input:focus + .slider {
        box-shadow: 0 0 1px #2196F3;
      }
      
      input:checked + .slider:before {
        transform: translateX(20px);
      }
      
      /* Version info styles */
      .version-info {
        border-top: 1px solid rgba(255, 255, 255, 0.1);
        margin-top: 10px;
        padding-top: 10px;
        font-size: 12px;
        color: #e6e6e6;
      }
      
      .version-info p {
        margin: 5px 0;
        color: #e6e6e6;
      }
      
      .version-number {
        font-weight: 600;
        color: #e6e6e6;
      }
      
      .check-updates-btn {
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 3px;
        padding: 4px 8px;
        margin-top: 5px;
        font-size: 11px;
        cursor: pointer;
        transition: background-color 0.2s;
        width: 100%;
        text-align: center;
        color: #e6e6e6;
      }
      
      .check-updates-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      
      .check-updates-btn:disabled {
        opacity: 0.6;
        cursor: not-allowed;
      }
      
      #crm-update-status {
        margin: 5px 0 0 0;
        padding: 3px 6px;
        font-size: 11px;
        border-radius: 3px;
        background-color: rgba(255, 255, 255, 0.05);
        text-align: center;
        transition: all 0.3s ease;
        color: #e6e6e6;
      }
      
      #last-update-check {
        font-size: 11px;
        margin: 5px 0;
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        color: #e6e6e6;
      }
      
      .check-status {
        font-size: 10px;
        margin-left: 5px;
        padding: 1px 4px;
        border-radius: 3px;
        font-weight: normal;
      }
      
      .loading-text {
        font-style: italic;
        color: #aaa;
      }
      
      /* Section styles */
      .setting-section {
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      }
      
      .setting-section-title {
        font-size: 12px;
        font-weight: bold;
        color: #e6e6e6;
        margin-bottom: 10px;
      }
    `,document.head.appendChild(s)}return t.appendChild(e),t.appendChild(r),t}function hi(t){try{(typeof browser<"u"?browser:chrome).runtime.sendMessage({action:"getLastUpdateCheck"}).then(n=>{if(n&&n.success&&n.lastUpdateCheck){let o=n.lastUpdateCheck,r="",s="";o.success?o.status==="update_available"?(r="Update available",s="#4CAF50"):o.status==="no_update"?(r="No updates needed",s="#2196F3"):o.status==="throttled"?(r="Check throttled",s="#FF9800"):(r="Completed",s="#2196F3"):(r="Failed",s="#F44336"),t.innerHTML=`Last Check: <span class="version-number">${o.formattedTime}</span> <span class="check-status" style="color:${s};font-size:10px;margin-left:5px;">${r}</span>`}else t.innerHTML='Last Check: <span class="version-number">No checks recorded</span>'}).catch(n=>{console.error("[CRM Extension] Error fetching last update check:",n),t.innerHTML='Last Check: <span class="version-number">Unknown</span>'})}catch(e){console.error("[CRM Extension] Error in fetchLastUpdateCheckInfo:",e),t.innerHTML='Last Check: <span class="version-number">Error</span>'}}function mi(){let t=document.createElement("div");t.id="mcp-crm-settings-dropdown";let e=document.createElement("div");e.className="settings-header",e.textContent="CRM+ Settings",t.appendChild(e);let n=document.createElement("div");if(n.className="settings-body",t.appendChild(n),!document.getElementById("collapsible-settings-styles")){let a=document.createElement("style");a.id="collapsible-settings-styles",a.textContent=`
      .setting-section {
        margin-bottom: 8px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        padding-bottom: 0; /* No bottom padding when collapsed */
      }
      
      .setting-section-title {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 13px;
        font-weight: bold;
        color: #e6e6e6;
        padding: 8px 0;
        cursor: pointer;
        user-select: none;
      }
      
      .setting-section-title:after {
        content: "\u25BC";
        font-size: 8px;
        color: #e6e6e6;
        transition: transform 0.2s ease;
      }
      
      .setting-section.collapsed .setting-section-title:after {
        transform: rotate(-90deg);
      }
      
      .setting-section-content {
        max-height: 500px;
        overflow: hidden;
        transition: max-height 0.3s ease, opacity 0.2s ease, margin-bottom 0.3s ease;
        opacity: 1;
        margin-bottom: 10px;
      }
      
      .setting-section.collapsed .setting-section-content {
        max-height: 0;
        opacity: 0;
        margin-bottom: 0;
      }
    `,document.head.appendChild(a)}let o=bn("General Settings");o.content.appendChild(fe("Show Header Bar","crmplus_headerBarVisible",a=>{let l=document.getElementById("mcp-crm-header");l&&(l.style.display=a?"flex":"none",document.body.style.paddingTop=a?"32px":"0"),y(`Header bar: ${a?"Visible":"Hidden"}`)},!0)),o.content.appendChild(fe("Show Provider-Paid Alerts","crmplus_showProviderPaidAlerts",a=>{y(`Provider-Paid alerts: ${a?"Enabled":"Disabled"}`)},!0)),n.appendChild(o.section);let r=bn("External Links");r.content.appendChild(fe("Show ShipStation Link","crmplus_showShipStation",a=>{let l=document.querySelector(".shipstation-link");l&&(l.style.display=a?"flex":"none"),y(`ShipStation link: ${a?"Visible":"Hidden"}`)},!0)),r.content.appendChild(fe("Show Stripe Link","crmplus_showStripe",a=>{let l=document.querySelector(".stripe-link");l&&(l.style.display=a?"flex":"none"),y(`Stripe link: ${a?"Visible":"Hidden"}`)},!0)),r.content.appendChild(fe("Show Webmail Link","crmplus_showWebmail",a=>{let l=document.querySelector(".webmail-link");l&&(l.style.display=a?"flex":"none"),y(`Webmail link: ${a?"Visible":"Hidden"}`)},!0)),n.appendChild(r.section);let s=bn("Features");s.content.appendChild(fe("Auto-copy phone number on page load","crmplus_autoCopyPhone",a=>{y(`Auto-copy phone: ${a?"Enabled":"Disabled"}`)},!1)),s.content.appendChild(fe("CRM Automation","crmplus_automationEnabled",a=>{[document.getElementById("crm-automation-dropdown"),document.getElementById("crm-tags-dropdown")].forEach(c=>{c?(c.style.display=a?"flex":"none",console.log(`[CRM Extension] Changed visibility for ${c.id}: ${a?"visible":"hidden"}`)):console.error("[CRM Extension] Could not find automation element to toggle")}),y(`CRM Automation: ${a?"Enabled":"Disabled"}`)},!0)),n.appendChild(s.section);let i=gi();return n.appendChild(i),t}function bn(t,e=!1){let n=document.createElement("div");n.className="setting-section"+(e?" collapsed":"");let o=document.createElement("div");o.className="setting-section-title",o.textContent=t,o.addEventListener("click",()=>{n.classList.toggle("collapsed")}),n.appendChild(o);let r=document.createElement("div");return r.className="setting-section-content",n.appendChild(r),{section:n,content:r}}function gi(){let t=document.createElement("div");t.className="version-info";let e="Loading...",n="Loading...";try{let l=(typeof browser<"u"?browser:chrome).runtime.getManifest();if(l&&l.version&&(e=l.version,e.includes("."))){let c=e.split(".");if(c.length===3&&c[0].length===4){let p=c[0],u=c[1],m=c[2];n=`${u}/${m}/${p}`}}}catch(a){console.error("[CRM Extension] Error fetching version:",a),e="Unknown",n="Unknown"}let o=document.createElement("p");o.innerHTML=`Version: <span class="version-number">${e}</span>`,t.appendChild(o);let r=document.createElement("p");r.innerHTML=`Last Updated: <span class="version-number">${n}</span>`,t.appendChild(r);let s=document.createElement("p");s.id="last-update-check",s.innerHTML='Last Check: <span class="loading-text">Loading...</span>',t.appendChild(s),hi(s);let i=document.createElement("button");return i.className="check-updates-btn",i.textContent="Check for Updates",i.addEventListener("click",()=>{let a=typeof browser<"u"?browser:chrome;i.disabled=!0,i.textContent="Checking...",y("Checking for updates...");let l=document.getElementById("crm-update-status");l||(l=document.createElement("p"),l.id="crm-update-status",l.style.fontSize="11px",l.style.marginTop="5px",l.style.color="#e6e6e6",l.textContent="",t.appendChild(l)),a.runtime.sendMessage({action:"checkForUpdates"}).then(c=>{if(c&&c.success){y("Update check completed"),c.updateStatus==="update_available"?(l.textContent=`Update available (${c.updateVersion})`,l.style.color="#4CAF50"):c.updateStatus==="no_update"?(l.textContent="You have the latest version",l.style.color="#2196F3"):c.updateStatus==="throttled"?(l.textContent="Update check throttled, try again later",l.style.color="#FF9800"):c.updateStatus==="error"?(l.textContent="Error checking for updates",l.style.color="#F44336"):(l.textContent="Update check initiated",l.style.color="#e6e6e6");let p=document.getElementById("last-update-check");if(p&&c.lastCheck){let u=c.lastCheck,m="",x="";u.success?u.status==="update_available"?(m="Update available",x="#4CAF50"):u.status==="no_update"?(m="No updates needed",x="#2196F3"):u.status==="throttled"?(m="Check throttled",x="#FF9800"):(m="Completed",x="#2196F3"):(m="Failed",x="#F44336"),p.innerHTML=`Last Check: <span class="version-number">${u.formattedTime}</span> <span class="check-status" style="color:${x};font-size:10px;margin-left:5px;">${m}</span>`}}else y("Error checking for updates"),l.textContent="Update check failed",l.style.color="#F44336";i.disabled=!1,i.textContent="Check for Updates"}).catch(c=>{console.error("[CRM Extension] Error sending update check message:",c),y("Error checking for updates"),l.textContent="Connection failed",l.style.color="#F44336",i.disabled=!1,i.textContent="Check for Updates"})}),t.appendChild(i),t}function fe(t,e,n,o=!1){let r=document.createElement("div");r.className="setting-item";let s=document.createElement("div");s.className="setting-label",s.textContent=t,r.appendChild(s);let i=document.createElement("label");i.className="switch";let a=document.createElement("input");a.type="checkbox";let l=localStorage.getItem(e),c=l!==null?l==="true":o;l===null&&localStorage.setItem(e,o.toString()),a.checked=c,a.addEventListener("change",()=>{let u=a.checked;localStorage.setItem(e,u.toString()),n&&typeof n=="function"&&n(u)});let p=document.createElement("span");return p.className="slider",i.appendChild(a),i.appendChild(p),r.appendChild(i),r}function tr(){if(document.getElementById("mcp-crm-header-styles"))return;let t=document.createElement("style");t.id="mcp-crm-header-styles",t.textContent=`
    #mcp-crm-header {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 32px;
      background-color: #2F3A4B;
      display: flex;
      align-items: center;
      padding: 0 15px;
      font-family: 'Segoe UI', 'Roboto', sans-serif;
      font-size: 12px;
      z-index: 999999;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    }
    
    #mcp-crm-header .group {
      display: flex;
      align-items: center;
      margin-right: 15px;
      border-right: 1px solid rgba(255, 255, 255, 0.1);
      padding-right: 15px;
    }
    
    #mcp-crm-header .group:last-child {
      border-right: none;
      margin-right: 0; /* Remove margin from the last group (Settings) */
    }
    
    /* Special styling for dropdowns group to match other elements' spacing */
    #crm-dropdowns-group {
      margin-right: 15px; /* Same spacing as other elements */
      padding-right: 15px; /* Same padding as other elements */
    }
    
    /* Ensure settings is positioned at the far right */
    #crm-settings-btn {
      margin-right: 0;
    }
    
    #mcp-crm-header .spacer {
      flex-grow: 1;
    }
    
    #mcp-crm-header .label {
      color: #8a9cad;
      margin-right: 6px;
      font-weight: 500;
    }
    
    #mcp-crm-header .value {
      color: #e6e6e6;
      font-weight: 600;
    }
    
    #mcp-crm-header .clickable-value {
      color: #e6e6e6;
      font-weight: 600;
      cursor: pointer;
      background-color: rgba(255, 255, 255, 0.05);
      padding: 2px 8px;
      border-radius: 3px;
      transition: background-color 0.2s;
      display: inline-flex;
      align-items: center;
    }
    
    #mcp-crm-header .clickable-value:hover {
      background-color: rgba(255, 255, 255, 0.15);
    }
    
    #mcp-crm-header .btn-icon {
      margin-right: 4px;
      font-size: 10px;
    }
    
    /* Logo link styling */
    #mcp-crm-header .logo-link {
      display: flex;
      align-items: center;
      text-decoration: none;
      transition: all 0.2s ease;
    }
    
    #mcp-crm-header .logo-link:hover {
      opacity: 0.85;
    }
    
    #mcp-crm-header .logo-icon {
      width: 16px;
      height: 16px;
      margin-right: 6px;
    }
    
    #mcp-crm-header .logo {
      font-weight: bold;
      color: white;
      font-size: 14px;
    }
    
    #mcp-crm-header .external-link {
      text-decoration: none;
      color: #e6e6e6;
      display: flex;
      align-items: center;
      transition: all 0.2s ease;
      margin-right: 10px;
    }
    
    #mcp-crm-header .external-link:hover {
      background: rgba(255, 255, 255, 0.2);
      transform: translateY(-1px);
    }
    
    #mcp-crm-header .ext-link-icon {
      font-size: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    /* Styling for text links with icons */
    #mcp-crm-header .text-link {
      text-decoration: none;
      margin-right: 4px; /* Reduced margin between buttons */
      font-size: 12px;
      padding: 3px 6px; /* Reduced horizontal padding to make buttons skinnier */
      border-radius: 3px;
      color: #e6e6e6;
      display: flex;
      align-items: center;
      justify-content: center; /* Center content horizontally */
      white-space: nowrap; /* Prevent text wrapping */
      min-width: 68px; /* Set minimum width to keep consistency */
    }
    
    #mcp-crm-header .text-link:hover {
      background-color: rgba(255, 255, 255, 0.15);
    }
    
    #mcp-crm-header .text-link .link-icon {
      margin-right: 4px; /* Slightly reduced margin for tighter look */
      width: 16px;
      height: 16px;
      vertical-align: middle;
      flex-shrink: 0; /* Prevent icon from shrinking */
    }
    
    /* Add a specific class for each button to fine-tune widths if needed */
    #mcp-crm-header .shipstation-link {
      min-width: 92px;
    }
    
    #mcp-crm-header .stripe-link {
      min-width: 65px;
    }
    
    #mcp-crm-header .webmail-link {
      min-width: 78px;
    }
    
    #mcp-crm-header .btn {
      color: #e6e6e6;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 3px;
      padding: 4px 8px;
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      margin-right: 8px;
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
    }
    
    #mcp-crm-header .btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    #mcp-crm-header .btn:active {
      background-color: rgba(255, 255, 255, 0.3);
    }
    
    #mcp-crm-header .btn:last-child {
      margin-right: 0;
    }
    
    /* Dropdown styling */
    .dropdown {
      position: relative;
      display: inline-block;
      margin-right: 8px;
    }
    
    .dropdown-btn {
      color: #e6e6e6;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 3px;
      padding: 4px 8px;
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
      justify-content: space-between;
      min-width: 100px;
    }
    
    .dropdown-btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .dropdown-btn:after {
      content: "\u25BC";
      font-size: 8px;
      margin-left: 5px;
    }
    
    .dropdown-content {
      display: none;
      position: absolute;
      background-color: #2F3A4B;
      min-width: 180px;
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.3);
      z-index: 1000000;
      border-radius: 4px;
      border: 1px solid rgba(255, 255, 255, 0.1);
      margin-top: 2px;
      left: 0;
    }
    
    .dropdown.show .dropdown-content {
      display: block;
    }
    
    .dropdown-item {
      color: #e6e6e6;
      padding: 8px 12px;
      text-decoration: none;
      display: block;
      font-size: 12px;
      cursor: pointer;
      font-weight: normal;
    }
    
    .dropdown-item:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
    
    /* Nested Dropdown styling */
    .nested-dropdown {
      margin-bottom: 5px;
      width: 100%;
    }
    
    .nested-dropdown-btn {
      width: 100%;
      text-align: left;
      padding: 6px 10px;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 3px;
      cursor: pointer;
      font-weight: bold;
      font-size: 12px;
      color: #e6e6e6;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .nested-dropdown-btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .nested-dropdown-btn:after {
      content: "\u25BC";
      font-size: 8px;
      color: #e6e6e6;
    }
    
    .nested-dropdown-content {
      display: none;
      padding: 5px 0 5px 10px;
      background-color: #2F3A4B;
    }
    
    .nested-dropdown.open .nested-dropdown-content {
      display: block;
    }
    
    .nested-dropdown-item {
      display: block;
      padding: 5px 10px;
      color: #e6e6e6;
      text-decoration: none;
      font-size: 12px;
      cursor: pointer;
      border-radius: 3px;
      font-weight: normal;
    }
    
    .nested-dropdown-item:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
    
    /* Settings dropdown styling */
    #mcp-crm-settings-dropdown {
      position: absolute;
      top: 32px;
      right: 15px;
      background-color: #2F3A4B;
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 4px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.3);
      min-width: 200px;
      z-index: 1000000;
      display: none;
      color: #e6e6e6;
    }
    
    #mcp-crm-settings-dropdown.show {
      display: block;
    }
    
    #mcp-crm-settings-dropdown .settings-header {
      background-color: rgba(255, 255, 255, 0.1);
      color: #e6e6e6;
      padding: 8px 12px;
      font-weight: bold;
      border-top-left-radius: 3px;
      border-top-right-radius: 3px;
    }
    
    #mcp-crm-settings-dropdown .settings-body {
      padding: 10px;
    }
    
    #mcp-crm-settings-dropdown .setting-item {
      display: flex;
      align-items: center;
      margin-bottom: 8px;
      padding-bottom: 8px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    #mcp-crm-settings-dropdown .setting-item:last-child {
      margin-bottom: 0;
      padding-bottom: 0;
      border-bottom: none;
    }
    
    #mcp-crm-settings-dropdown .setting-label {
      flex-grow: 1;
      font-size: 13px;
      color: #e6e6e6;
    }
    
    /* Toggle switch styling */
    .switch {
      position: relative;
      display: inline-block;
      width: 40px;
      height: 20px;
    }
    
    .switch input { 
      opacity: 0;
      width: 0;
      height: 0;
    }
    
    .slider {
      position: absolute;
      cursor: pointer;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: #555;
      transition: .4s;
      border-radius: 34px;
    }
    
    .slider:before {
      position: absolute;
      content: "";
      height: 16px;
      width: 16px;
      left: 2px;
      bottom: 2px;
      background-color: white;
      transition: .4s;
      border-radius: 50%;
    }
    
    input:checked + .slider {
      background-color: #2196F3;
    }
    
    input:checked + .slider:before {
      transform: translateX(20px);
    }
    
    /* Version info section in settings */
    .version-info {
      border-top: 1px solid rgba(255, 255, 255, 0.1);
      margin-top: 10px;
      padding-top: 10px;
      font-size: 12px;
      color: #e6e6e6;
    }
    
    .version-info p {
      margin: 5px 0;
    }
    
    .version-number {
      font-weight: 600;
      color: #e6e6e6;
    }
    
    .check-updates-btn {
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 3px;
      padding: 4px 8px;
      margin-top: 5px;
      font-size: 11px;
      cursor: pointer;
      transition: background-color 0.2s;
      width: 100%;
      text-align: center;
      color: #e6e6e6;
    }
    
    .check-updates-btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .check-updates-btn:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
  `,document.head.appendChild(t)}function or(){let t=document.createElement("div");t.className="dropdown",t.id="crm-history-dropdown";let e=document.createElement("button");e.className="dropdown-btn",e.textContent="History",e.addEventListener("click",a=>{a.stopPropagation(),document.querySelectorAll(".dropdown.show").forEach(l=>{l!==t&&l.classList.remove("show")}),t.classList.toggle("show"),t.classList.contains("show")&&nr(t)});let n=document.createElement("div");if(n.className="dropdown-content",n.id="crm-history-content",n.style.width="300px",n.style.maxHeight="400px",n.style.overflowY="auto",n.style.right="0",n.style.left="auto",!document.getElementById("history-dropdown-styles")){let a=document.createElement("style");a.id="history-dropdown-styles",a.textContent=`
      #crm-history-dropdown .dropdown-content {
        padding: 0;
        right: 0;
        left: auto;
      }
      
      /* For small screens, make sure the dropdown doesn't extend beyond viewport */
      @media screen and (max-width: 768px) {
        #crm-history-dropdown .dropdown-content {
          right: 0;
          left: auto;
          max-width: 100vw;
          width: 280px; /* Slightly smaller on small screens */
        }
      }
      
      .history-header {
        padding: 10px;
        background-color: rgba(255, 255, 255, 0.1);
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      
      .history-title {
        font-weight: bold;
        color: #e6e6e6;
        font-size: 14px;
      }
      
      .history-clear-btn {
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 3px;
        padding: 2px 6px;
        font-size: 11px;
        cursor: pointer;
        color: #e6e6e6;
        transition: background-color 0.2s;
      }
      
      .history-clear-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      
      .history-empty {
        padding: 20px;
        text-align: center;
        color: #aaa;
        font-style: italic;
        font-size: 13px;
      }
      
      .history-item {
        padding: 10px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        cursor: pointer;
        transition: background-color 0.2s;
      }
      
      .history-item:hover {
        background-color: rgba(255, 255, 255, 0.1);
      }
      
      .history-item:last-child {
        border-bottom: none;
      }
      
      .history-item-row {
        display: flex;
        margin-bottom: 3px;
        width: 100%;
      }
      
      .history-item-time {
        color: #aaa;
        font-size: 11px;
        width: 60px;
        flex-shrink: 0;
        margin-right: 5px;
      }
      
      .history-item-name {
        font-weight: bold;
        color: #e6e6e6;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        flex-grow: 1;
      }
      
      .history-item-phone {
        color: #ccc;
        font-size: 12px;
        margin-left: 65px; /* Align with name (time width + margin) */
      }
    `,document.head.appendChild(a)}let o=document.createElement("div");o.className="history-header";let r=document.createElement("div");r.className="history-title",r.textContent="Recent Patients",o.appendChild(r);let s=document.createElement("button");s.className="history-clear-btn",s.textContent="Clear All",s.addEventListener("click",a=>{a.stopPropagation(),Xn(),nr(t),y("History cleared")}),o.appendChild(s),n.appendChild(o);let i=document.createElement("div");return i.className="history-empty",i.textContent="No patient history yet",n.appendChild(i),t.appendChild(e),t.appendChild(n),t}function nr(t){let e=t.querySelector("#crm-history-content");if(!e)return;let n=Qn(),o=e.querySelector(".history-header");if(e.innerHTML="",o&&e.appendChild(o),n.length===0){let r=document.createElement("div");r.className="history-empty",r.textContent="No patient history yet",e.appendChild(r);return}n.forEach(r=>{let s=document.createElement("div");s.className="history-item",s.addEventListener("click",()=>{window.location.href=r.url,t.classList.remove("show")});let i=document.createElement("div");i.className="history-item-row";let a=document.createElement("div");a.className="history-item-time",a.textContent=eo(r.timestamp);let l=document.createElement("div");if(l.className="history-item-name",l.textContent=r.patientName||"Unknown Patient",i.appendChild(a),i.appendChild(l),s.appendChild(i),r.phoneNumber){let c=document.createElement("div");c.className="history-item-phone",c.textContent=r.phoneNumber,s.appendChild(c)}e.appendChild(s)})}var fi=!1;function Sn(){try{if(document.getElementById("mcp-crm-header")){console.log("[uiHeaderBar] Toolbar already exists.");return}tr();let t=document.createElement("div");t.id="mcp-crm-header";let e=localStorage.getItem("crmplus_headerBarVisible")!=="false";console.log("[CRM Extension] Header visibility setting:",e),t.style.display=e?"flex":"none";let n=typeof browser<"u"?browser:chrome,o=w=>n.runtime.getURL(w),r=document.createElement("div");r.className="group";let s=document.createElement("a");s.href="https://app.mtncarerx.com/",s.className="logo-link";let i=document.createElement("img");i.src=o("assets/mcp-favicon.ico"),i.alt="",i.className="logo-icon",s.appendChild(i);let a=document.createElement("span");a.className="logo",a.textContent="CRM+",s.appendChild(a),r.appendChild(s);let l=document.createElement("div");l.className="group external-links";let c=En("ShipStation","https://ship15.shipstation.com/onboard","shipstation-link",o("assets/shipstation-favicon.ico"));l.appendChild(c);let p=En("Stripe","https://dashboard.stripe.com/login","stripe-link",o("assets/stripe-favicon.ico"));l.appendChild(p);let u=En("Webmail","https://p3plzcpnl506102.prod.phx3.secureserver.net:2096/cpsess5640910985/webmail/jupiter/index.html?login=1&post_login=89371011642013","webmail-link",o("assets/webmail-favicon.ico"));l.appendChild(u);let m=Pe("name","Name"),x=Pe("phone","Phone",{icon:"\u{1F4DE}",initialValue:"",onClick:async w=>{Tn(w)}}),N=Pe("dob","DOB"),A=Pe("srxid","SRx ID"),F=Yo(),W=Xo(),b=document.createElement("div");b.className="spacer";let M=document.createElement("div");M.className="group right-buttons",M.style.borderRight="none",M.style.display="flex",M.style.marginRight="0";let R=document.createElement("button");R.className="chat-button btn",R.title="Mountain Care Chat",R.style.marginRight="8px";let T=document.createElement("div");T.style.display="flex",T.style.alignItems="center",T.style.justifyContent="center";let K=document.createElement("span");K.className="icon",K.innerHTML="\u{1F4AC}",K.style.marginRight="4px";let Z=document.createElement("span");Z.textContent="Chat";let G=document.createElement("span");G.className="badge",Object.assign(G.style,{position:"absolute",top:"0",right:"0",backgroundColor:"#f44336",color:"white",fontSize:"12px",fontWeight:"bold",padding:"2px 6px",borderRadius:"50%",display:"none"}),T.appendChild(K),T.appendChild(Z),R.appendChild(T),R.appendChild(G),R.addEventListener("click",function(){if(console.log("[CRM Extension] Chat button clicked"),typeof window.toggleChatUI=="function")window.toggleChatUI();else{console.error("[CRM Extension] toggleChatUI function not available");let w=document.getElementById("hipaa-chat-container");if(w)w.style.display=w.style.display==="none"?"flex":"none",console.log("[CRM Extension] Toggled chat container visibility as fallback");else{console.error("[CRM Extension] Chat container not found");try{typeof X=="function"&&X().then(()=>{typeof window.toggleChatUI=="function"&&window.toggleChatUI()})}catch(k){console.error("[CRM Extension] Failed to initialize chat:",k)}}}});let z=or();M.appendChild(R),M.appendChild(z);let he=er();t.appendChild(r),t.appendChild(l),t.appendChild(m),t.appendChild(x),t.appendChild(N),t.appendChild(A),t.appendChild(W),t.appendChild(F),t.appendChild(b),t.appendChild(M),t.appendChild(he),document.body.appendChild(t),document.body.style.paddingTop=e?"32px":"0",setTimeout(()=>{try{let w=localStorage.getItem("crmplus_automationEnabled")==="true";[document.getElementById("crm-automation-dropdown"),document.getElementById("crm-tags-dropdown")].forEach(L=>{L&&(L.style.display=w?"flex":"none",console.log(`[CRM Extension] Initial visibility for ${L.id}: ${w?"visible":"hidden"}`))})}catch(w){console.error("[CRM Extension] Error setting initial automation visibility:",w)}},100),te(),Dn(),zn(),Un(),_n(),Kn(),X(),Go(),Jo(w=>{if(w.length>0){let k=w[0];y(`New message from ${k.sender}: ${k.text.substring(0,30)}${k.text.length>30?"...":""}`,3e3)}}),window.addEventListener("popstate",function(){console.log("[CRM Extension] Navigation detected, clearing phone display"),te()}),xi()||te(),fi=!0,console.log("[CRM Extension] Header successfully initialized")}catch(t){console.error("[CRM Extension] Critical error creating toolbar:",t);try{let e=document.getElementById("mcp-crm-header");e&&(e.style.display="flex")}catch(e){console.error("[CRM Extension] Failed to recover toolbar:",e)}}}function En(t,e,n="",o=""){let r=document.createElement("a");r.href=e,r.target="_blank",r.className=`text-link btn ${n}`,r.rel="noopener noreferrer";let s=document.createElement("div");if(s.style.display="flex",s.style.alignItems="center",s.style.justifyContent="center",s.style.width="100%",o){let a=document.createElement("img");a.src=o,a.alt="",a.className="link-icon",a.style.width="16px",a.style.height="16px",a.style.marginRight="4px",s.appendChild(a)}let i=document.createElement("span");return i.textContent=t,s.appendChild(i),r.appendChild(s),r}function xi(){let t=window.location.href;return[/\/patient\/\d+/i,/\/contact\/\d+/i,/\/profile\/\d+/i,/[?&]patient_id=\d+/i,/[?&]contact_id=\d+/i].some(o=>o.test(t))?!0:['input[name="contact.phone"]','input[name="contact.first_name"]','input[name="contact.last_name"]','input[name="contact.date_of_birth"]',".patient-info",".contact-details",".patient-header",".patient-profile"].some(o=>document.querySelector(o)!==null)}function wn(t){try{let e=document.getElementById("mcp-crm-header");if(e){console.log(`[CRM Extension] Setting header visibility to: ${t}`),e.style.display=t?"flex":"none";let n=document.body.classList.contains("has-alert");return t?(document.body.style.paddingTop=n?"72px":"32px",document.body.classList.remove("no-header")):(document.body.style.paddingTop=n?"40px":"0",document.body.classList.add("no-header")),localStorage.setItem("crmplus_headerBarVisible",t.toString()),!0}else if(t)return console.log("[CRM Extension] Header not found but should be visible, creating it"),Sn(),!0;return!1}catch(e){return console.error("[CRM Extension] Error toggling header visibility:",e),!1}}function rr(){if(!(localStorage.getItem("crmplus_autoCopyPhone")==="true")){console.log("[CRM Extension] Auto-copy phone is disabled");return}let e=()=>{let o=He();if(o){let r=Rt(o);r&&we(r).then(s=>{if(s)return y("Phone number auto-copied: "+r),!0})}return!1};if(e())return;let n=new MutationObserver((o,r)=>{e()&&r.disconnect()});n.observe(document.body,{childList:!0,subtree:!0,attributes:!0,characterData:!0}),setTimeout(()=>{n.disconnect(),e()},5e3)}var sr=!1,De=new Set,St="",kn=!1,wt=null,vn=null;function ar(){sr||(yi(),Ci(),sr=!0,console.log("[CRM Extension] Alert system initialized"))}function yi(){if(document.getElementById("crm-alert-styles"))return;let t=document.createElement("style");t.id="crm-alert-styles",t.textContent=`
    .crm-alert-banner {
      position: fixed;
      top: 32px; /* Positioned right below the header bar */
      left: 0;
      right: 0;
      width: 100%;
      padding: 4px 15px; /* Reduced vertical padding for smaller height */
      font-size: 13px;
      font-weight: 500;
      z-index: 999990;
      display: flex;
      align-items: center;
      justify-content: center; /* Center contents horizontally */
      transition: all 0.3s ease;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
      transform: translateY(-100%);
      opacity: 0;
      height: 25px; /* Fixed height at 3/4 of original (approx) */
    }
    
    .crm-alert-banner.show {
      transform: translateY(0);
      opacity: 1;
    }
    
    .crm-alert-banner .alert-icon {
      margin-right: 8px;
      font-size: 16px;
    }
    
    .crm-alert-banner .alert-message {
      text-align: center; /* Center the text */
      margin: 0 auto; /* Center with auto margins */
      flex-grow: 0; /* Don't grow to fill space */
    }
    
    /* Provider Paid specific alert styling */
    .crm-alert-banner.provider-paid {
      background-color: #FFAB40; /* Orange */
      color: #5F4200;
      border-bottom: 1px solid #FF9100;
    }
    
    /* Adjust body padding to accommodate the alert banner */
    body.has-alert {
      padding-top: 72px !important; /* 32px (header) + approx alert height */
    }
    
    /* When header is hidden but alert is visible */
    body.no-header.has-alert {
      padding-top: 25px !important; /* Just the alert height */
    }
    
    /* Multiple alerts stacking */
    .crm-alert-banner.second-alert {
      top: 57px;
    }
    
    .crm-alert-banner.third-alert {
      top: 82px;
    }
    
    /* Countdown timer styling */
    .countdown-timer {
      margin-left: 5px;
      font-size: 11px;
      opacity: 0.75;
      background-color: rgba(0, 0, 0, 0.1);
      padding: 1px 4px;
      border-radius: 3px;
      min-width: 30px;
      text-align: center;
    }
  `,document.head.appendChild(t)}function ir(){let t=window.location.href,e=[/\/patient\/(\d+)/i,/\/contact\/(\d+)/i,/\/profile\/(\d+)/i,/[?&]patient_id=(\d+)/i,/[?&]contact_id=(\d+)/i];for(let n of e){let o=t.match(n);if(o&&o[1])return o[1]}return""}function Ci(){St=ir(),vt(),wt&&wt.disconnect(),wt=new MutationObserver(t=>{for(let e of t)e.type==="childList"&&vt(),e.type==="attributes"&&(e.target.classList.contains("tag")||e.target.classList.contains("tag-label")||e.target.classList.contains("provider-paid"))&&vt()}),wt.observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["class","data-tag"]}),vn&&clearInterval(vn),vn=setInterval(()=>{let t=ir();t!==St&&(console.log("[CRM Extension] Navigation detected, patient changed from",St,"to",t),St=t,kn=!1,kt("provider-paid"),setTimeout(vt,1e3))},1e3)}function vt(){if(!(localStorage.getItem("crmplus_showProviderPaidAlerts")!=="false")){kt("provider-paid");return}bi()?kn||Ei():kt("provider-paid")}function bi(){let t=document.querySelectorAll(".tag, .tag-label, .pill, .badge");for(let r of t)if(r.textContent.toLowerCase().includes("provider-paid"))return r;let e=document.querySelectorAll(".provider-paid");if(e.length>0)return e[0];let n=document.querySelectorAll('[data-tag="provider-paid"], [data-tag-name="provider-paid"]');if(n.length>0)return n[0];let o=document.querySelectorAll(".tags-container, .tag-list, .tags");for(let r of o)if(r.textContent.toLowerCase().includes("provider-paid"))return r;return null}function Ei(){if(De.has("provider-paid"))return;kn=!0;let t=document.createElement("div");t.className="crm-alert-banner provider-paid",t.id="provider-paid-alert",t.setAttribute("data-alert-type","provider-paid");let e=document.createElement("span");e.className="alert-icon",e.innerHTML="\u26A0\uFE0F",t.appendChild(e);let n=document.createElement("span");n.className="alert-message",n.textContent="This patient has Provider Paid status. Special billing rules apply.";let o=document.createElement("span");o.className="countdown-timer",o.textContent="30",n.appendChild(o),t.appendChild(n),document.body.appendChild(t),Si(t),setTimeout(()=>{t.classList.add("show"),document.body.classList.add("has-alert")},10),De.add("provider-paid");let r=document.getElementById("mcp-crm-header");r&&r.style.display==="none"?document.body.classList.add("no-header"):document.body.classList.remove("no-header"),console.log("[CRM Extension] Provider Paid alert shown");let s=15,i=setInterval(()=>{s--,o&&(o.textContent=s),s<=0&&(clearInterval(i),kt("provider-paid"))},1e3)}function Si(t){let e=De.size;e===1?t.classList.add("second-alert"):e===2&&t.classList.add("third-alert")}function kt(t){let e=document.querySelector(`.crm-alert-banner[data-alert-type="${t}"]`);e&&(e.classList.remove("show"),De.delete(t),setTimeout(()=>{e.parentNode&&e.parentNode.removeChild(e),De.size===0&&document.body.classList.remove("has-alert"),wi()},300))}function wi(){document.querySelectorAll(".crm-alert-banner").forEach((e,n)=>{e.classList.remove("second-alert","third-alert"),n===1?e.classList.add("second-alert"):n===2&&e.classList.add("third-alert")})}console.log("[CRM Extension] Content script injected.");var Be=typeof browser<"u"?browser:chrome;Be.runtime.sendMessage({action:"loadSettings"}).then(t=>{t&&t.success&&(console.log("[CRM Extension] Settings loaded from browser storage on startup:",t.settings),document.getElementById("mcp-crm-header")||xe())}).catch(t=>{console.error("[CRM Extension] Error requesting settings on startup:",t)});localStorage.getItem("crmplus_headerBarVisible")===null?(console.log("[CRM Extension] No local toolbar visibility setting, requesting from browser storage"),Be.runtime.sendMessage({action:"loadSettings"}).then(t=>{t&&t.success?(console.log("[CRM Extension] Settings loaded from browser storage:",t.settings),xe()):(console.error("[CRM Extension] Failed to load settings, using defaults"),localStorage.setItem("crmplus_headerBarVisible","true"),xe())}).catch(t=>{console.error("[CRM Extension] Error requesting settings:",t),localStorage.setItem("crmplus_headerBarVisible","true"),xe()})):(console.log("[CRM Extension] Using existing localStorage settings"),xe());function xe(){let t=localStorage.getItem("crmplus_headerBarVisible")!=="false";console.log("[CRM Extension] Header visibility setting on init:",t);try{console.log("[CRM Extension] Creating fixed header..."),Sn(),wn(t)}catch(e){console.error("[CRM Extension] Error creating fixed header:",e)}try{An(e=>{console.log(`[CRM Extension] Intercepted console message: ${e}`)})}catch(e){console.error("[CRM Extension] Error initializing console monitor:",e)}try{rr()}catch(e){console.error("[CRM Extension] Error initializing auto phone copy:",e)}try{ar()}catch(e){console.error("[CRM Extension] Error initializing alert system:",e)}try{$n()}catch(e){console.error("[CRM Extension] Error initializing tag removal system:",e)}try{Wn()}catch(e){console.error("[CRM Extension] Error initializing automation removal system:",e)}te();try{X().then(()=>{console.log("[CRM Extension] Chat system initialized successfully"),setTimeout(()=>{typeof q=="function"?(q(),console.log("[CRM Extension] Explicitly initialized Chat UI")):console.error("[CRM Extension] initChatUI function not found")},500)})}catch(e){console.error("[CRM Extension] Error initializing chat system:",e)}}document.addEventListener("click",function(t){if(t.target.closest(".chat-button")&&(console.log("[CRM Extension] Chat button clicked (global event listener)"),console.log("window.toggleChatUI exists:",typeof window.toggleChatUI=="function"),console.log("Chat container exists:",!!document.getElementById("hipaa-chat-container")),!document.getElementById("hipaa-chat-container"))){console.log("[CRM Extension] Chat container not found, initializing chat UI...");try{typeof q=="function"&&(q(),setTimeout(()=>{if(typeof window.toggleChatUI=="function")window.toggleChatUI();else{let n=document.getElementById("hipaa-chat-container");n&&(n.style.display=n.style.display==="none"?"flex":"none")}},100))}catch(n){console.error("[CRM Extension] Error initializing chat UI:",n)}}});Be.runtime.onMessage.addListener((t,e,n)=>{if(console.log("[CRM Extension] Received message:",t),t.action==="toggleHeaderVisibility"){console.log("[CRM Extension] Toggling header visibility to:",t.isVisible);try{let o=wn(t.isVisible);localStorage.setItem("crmplus_headerBarVisible",t.isVisible.toString()),Be.runtime.sendMessage({action:"syncSettings"}).catch(r=>console.error("[CRM Extension] Error syncing settings:",r)),n({success:o})}catch(o){console.error("[CRM Extension] Error toggling header visibility:",o),n({success:!1,error:o.message})}return!0}if(t.action==="initializeChat"){try{X().then(()=>{typeof q=="function"?(q(),n({success:!0})):n({success:!1,error:"initChatUI function not found"})})}catch(o){console.error("[CRM Extension] Error initializing chat:",o),n({success:!1,error:o.message})}return!0}return!1});document.addEventListener("DOMContentLoaded",()=>{if(console.log("[CRM Extension] DOM fully loaded, checking visibility setting"),document.getElementById("mcp-crm-header")||Be.runtime.sendMessage({action:"loadSettings"}).then(t=>{t&&t.success&&xe()}).catch(()=>{localStorage.setItem("crmplus_headerBarVisible","true"),xe()}),!document.getElementById("hipaa-chat-container"))try{X().then(()=>{typeof q=="function"&&q()})}catch(t){console.error("[CRM Extension] Error initializing chat on DOMContentLoaded:",t)}});try{window.addEventListener("load",()=>{console.log("[CRM Extension] Window loaded, initializing chat..."),X().then(()=>{typeof q=="function"&&q()})})}catch(t){console.error("[CRM Extension] Critical error initializing chat on window.load:",t)}})();
