(()=>{function ht(e){if(window.__crmConsoleMonitor)return;window.__crmConsoleMonitor=!0;let t=console.log,n=console.error,o=console.warn;console.log=function(...r){t.apply(console,r),!(typeof r[0]=="string"&&r[0].includes("[CRM Extension]"))&&je(r,"log",e)},console.error=function(...r){n.apply(console,r),!(typeof r[0]=="string"&&r[0].includes("[CRM Extension]"))&&je(r,"error",e)},console.warn=function(...r){o.apply(console,r),!(typeof r[0]=="string"&&r[0].includes("[CRM Extension]"))&&je(r,"warn",e)}}function je(e,t,n){let o=e.join(" ");["error","failed","unauthorized","critical"].some(s=>o.toLowerCase().includes(s))&&n(o)}var mt=window.location.href,ee="";function ve(){if(!gt())return"";let e=document.querySelector('input[name="contact.phone"]');if(e&&e.value.trim()!=="")return e.value.trim();let t=document.querySelector(".phone-number .number");if(t&&t.textContent.trim()!=="")return t.textContent.trim();let n=['input[placeholder="Phone"]','input[placeholder="Phone Number"]',".patient-info .phone",".contact-info .phone","span.phone",'label[for*="phone"]',".phone-display",'div[data-field="phone"]','span[data-field="phone_number"]'];for(let o of n){let r=document.querySelector(o);if(r)if(r.tagName==="INPUT"){let s=r.value.trim();if(s)return s}else if(r.tagName==="LABEL"){let s=r.getAttribute("for");if(s){let a=document.getElementById(s);if(a&&a.value.trim())return a.value.trim()}let i=r.parentElement?.querySelector("input");if(i&&i.value.trim())return i.value.trim()}else{let s=r.textContent.trim();if(s)return s}}return""}function gt(){let e=window.location.href;return[/\/patient\/\d+/i,/\/contact\/\d+/i,/\/profile\/\d+/i,/[?&]patient_id=\d+/i,/[?&]contact_id=\d+/i].some(o=>o.test(e))?!0:['input[name="contact.phone"]','input[name="contact.first_name"]','input[name="contact.last_name"]','input[name="contact.date_of_birth"]',".patient-info",".contact-details",".patient-header",".patient-profile"].some(o=>document.querySelector(o)!==null)}function ft(e){try{let t=e?In(e):"";if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("phone",t);else{let n=document.getElementById("phone-text");if(n){n.textContent=t;let o=document.getElementById("phone-display");o&&(e?o.setAttribute("data-value",e):o.removeAttribute("data-value"))}}}catch(t){console.error("[CRM Extension] Error updating phone display:",t)}}function V(){ee="",ft("");try{let e=document.getElementById("phone-display");e&&e.removeAttribute("data-value")}catch(e){console.error("[CRM Extension] Error clearing phone display:",e)}}function In(e){if(!e)return"";let t=e.replace(/\D/g,"");if(t.length===0)return"";if(t.length===10)return`(${t.substring(0,3)}) ${t.substring(3,6)}-${t.substring(6)}`;if(t.length===11&&t.startsWith("1"))return`(${t.substring(1,4)}) ${t.substring(4,7)}-${t.substring(7)}`;if(t.length>4){let n="";for(let o=0;o<t.length;o+=3)if(o+4>=t.length&&t.length%3!==0){n+=" "+t.substring(o);break}else n+=" "+t.substring(o,o+3);return n.trim()}return t.replace(/(\d{3})/g,"$1 ").trim()}function Se(){try{if(!gt())return ee&&V(),!1;let e=ve();return e?(e!==ee&&(ee=e,ft(e)),!0):(ee&&V(),!1)}catch(e){return console.error("[CRM Extension] Error detecting phone number:",e),!1}}function yt(){V(),Se();let e=setInterval(()=>{let t=window.location.href;t!==mt&&(console.log("[CRM Extension] URL changed, resetting phone detection"),mt=t,V()),Se()},200);try{let t=new MutationObserver(o=>{Se()}),n=document.body;t.observe(n,{childList:!0,subtree:!0,characterData:!0,attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] Phone number mutation observer active")}catch(t){console.error("[CRM Extension] Error setting up phone mutation observer:",t)}}function xt(e){let t=ve();if(!t){u("No phone number found");return}let n=He(t);if(!n){u("Invalid phone number format");return}e.setAttribute("data-value",t),te(n).then(o=>{u(o?"Copied: "+n:"Failed to copy phone number")})}function He(e){if(!e)return"";let t=e.replace(/\D/g,"");return t.length<7?"":"+1"+t}async function te(e){if(navigator.clipboard&&navigator.clipboard.writeText)try{return await navigator.clipboard.writeText(e),!0}catch(t){console.warn("Clipboard API failed, trying fallback method:",t)}try{let t=document.createElement("textarea");t.value=e,t.style.position="fixed",t.style.top="0",t.style.left="0",t.style.opacity="0",t.style.pointerEvents="none",document.body.appendChild(t),t.focus(),t.select();let n=document.execCommand("copy");return document.body.removeChild(t),n}catch(t){return console.error("All clipboard methods failed:",t),!1}}function u(e,t=2e3){let n=document.getElementById("crm-plus-toast-container");n||(n=document.createElement("div"),n.id="crm-plus-toast-container",n.style.position="fixed",n.style.bottom="20px",n.style.right="20px",n.style.zIndex="100000",document.body.appendChild(n));let o=document.createElement("div");o.textContent=e,o.style.background="#333",o.style.color="#fff",o.style.padding="10px",o.style.borderRadius="5px",o.style.marginTop="10px",o.style.boxShadow="0 2px 5px rgba(0,0,0,0.2)",o.style.transition="opacity 0.5s, transform 0.5s",o.style.opacity="0",o.style.transform="translateY(20px)",n.appendChild(o),o.offsetWidth,o.style.opacity="1",o.style.transform="translateY(0)",setTimeout(()=>{o.style.opacity="0",o.style.transform="translateY(20px)",setTimeout(()=>{o.parentNode&&o.parentNode.removeChild(o),n.childNodes.length===0&&document.body.removeChild(n)},500)},t)}var Ct=window.location.href;function ne(e){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("name",e);else{let t=document.getElementById("name-text");if(t){t.textContent=e;let n=document.getElementById("name-display");n&&n.setAttribute("data-value",e)}}}catch(t){console.error("[CRM Extension] Error updating name display:",t)}}function Me(){try{let e=document.querySelector('input[name="contact.first_name"]'),t=document.querySelector('input[name="contact.last_name"]');if(e&&e.value&&t&&t.value){let r=`${e.value} ${t.value}`;return ne(r),!0}let n=document.querySelectorAll(".patient-name, .contact-name, h1.name, .customer-name");for(let r of n)if(r&&r.textContent&&r.textContent.trim()!==""){let s=r.textContent.trim();return ne(s),!0}let o=["span.name",".profile-name","h2.name",".contact-header .name",'div[data-field="name"]',".patient-info .name"];for(let r of o){let s=document.querySelector(r);if(s&&s.textContent&&s.textContent.trim()!==""){let i=s.textContent.trim();return ne(i),!0}}return!1}catch(e){return console.error("[CRM Extension] Error detecting name:",e),!1}}function bt(){Me();let e=setInterval(()=>{let t=window.location.href;t!==Ct&&(console.log("[CRM Extension] URL changed, resetting name detection"),Ct=t,ne(""),Me());let n=document.getElementById("name-text");n&&(n.textContent==="Loading..."||!n.textContent)&&Me()},1e3);try{let t=new MutationObserver(o=>{o.some(s=>s.addedNodes.length>5||s.removedNodes.length>5)&&(console.log("[CRM Extension] Significant DOM changes detected, rechecking name"),ne(""),Me())}),n=document.querySelector("main")||document.body;t.observe(n,{childList:!0,subtree:!0})}catch(t){console.error("[CRM Extension] Error setting up navigation observer for name:",t)}}var Et=window.location.href;function Le(e){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("dob",e);else{let t=document.getElementById("dob-text");if(t){t.textContent=e;let n=document.getElementById("dob-display");n&&n.setAttribute("data-value",e)}}}catch(t){console.error("[CRM Extension] Error updating DOB display:",t)}}function wt(e){if(!e)return"";if(e.match(/^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2}(st|nd|rd|th)?\s+\d{4}$/))try{let t=e.match(/(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+(\d{1,2})(st|nd|rd|th)?\s+(\d{4})/);if(t){let n=t[1],o=t[2],r=t[4];return`${(["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"].indexOf(n)+1).toString().padStart(2,"0")}/${o.toString().padStart(2,"0")}/${r}`}}catch(t){console.error("[CRM Extension] Error parsing date:",t)}try{let t=new Date(e);if(!isNaN(t.getTime()))return`${(t.getMonth()+1).toString().padStart(2,"0")}/${t.getDate().toString().padStart(2,"0")}/${t.getFullYear()}`}catch(t){console.error("[CRM Extension] Error parsing date as Date object:",t)}return e}function ke(){try{let e=document.querySelector('input[name="contact.date_of_birth"]');if(e&&e.value){let n=wt(e.value);return Le(n),!0}let t=[".dob",".patient-dob",".contact-dob",'span[data-field="date_of_birth"]','div[data-field="dob"]',".patient-info .dob",".contact-info .dob"];for(let n of t){let o=document.querySelector(n);if(o&&o.textContent&&o.textContent.trim()!==""){let r=wt(o.textContent.trim());return Le(r),!0}}return!1}catch(e){return console.error("[CRM Extension] Error detecting DOB:",e),!1}}function St(){ke();let e=setInterval(()=>{let t=window.location.href;t!==Et&&(console.log("[CRM Extension] URL changed, resetting DOB detection"),Et=t,Le(""),ke());let n=document.getElementById("dob-text");n&&(n.textContent==="Loading..."||!n.textContent)&&ke()},1e3);try{let t=new MutationObserver(o=>{o.some(s=>s.addedNodes.length>5||s.removedNodes.length>5)&&(console.log("[CRM Extension] Significant DOM changes detected, rechecking DOB"),Le(""),ke())}),n=document.querySelector("main")||document.body;t.observe(n,{childList:!0,subtree:!0})}catch(t){console.error("[CRM Extension] Error setting up navigation observer for DOB:",t)}}var vt=window.location.href,Ae="";function Mt(e){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("srxid",e);else{let t=document.getElementById("srxid-text");if(t){t.textContent=e;let n=document.getElementById("srxid-display");n&&n.setAttribute("data-value",e)}}}catch(t){console.error("[CRM Extension] Error updating SRx ID display:",t)}}function oe(){try{let e=document.querySelector('input[name="contact.srx_id"]');if(e&&e.value){let t=e.value.trim();if(t&&/^\d+$/.test(t))return t!==Ae&&(console.log("[CRM Extension] Found SRx ID from contact.srx_id input:",t),Ae=t,Mt(t)),!0}return!!Ae}catch(e){return console.error("[CRM Extension] Error detecting SRx ID:",e),!1}}function kt(){oe();let e=setInterval(()=>{let t=window.location.href;t!==vt&&(console.log("[CRM Extension] URL changed, resetting SRx ID detection"),vt=t,Ae="",Mt(""),oe()),oe()},500);try{new MutationObserver(n=>{let o=!1;for(let r of n){if(r.target.tagName==="INPUT"&&r.target.name==="contact.srx_id"||r.target.querySelector&&r.target.querySelector('input[name="contact.srx_id"]')){o=!0;break}if(r.addedNodes.length>0){for(let s of r.addedNodes)if(s.nodeType===1&&s.querySelector&&(s.tagName==="INPUT"&&s.name==="contact.srx_id"||s.querySelector('input[name="contact.srx_id"]'))){o=!0;break}}}o&&oe()}).observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] SRx ID mutation observer active")}catch(t){console.error("[CRM Extension] Error setting up observer for SRx ID:",t)}setTimeout(()=>{try{let t=document.querySelector('input[name="contact.srx_id"]');t&&(new MutationObserver(o=>{oe()}).observe(t,{attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] Direct input observer attached to contact.srx_id"))}catch(t){console.error("[CRM Extension] Error setting up direct input observer:",t)}},1e3)}var Ie=["np-tirz-1.5ml-inj","refill-sema-inj","refill-tirz-inj","vial-sema-b12","vial-sema-b6","vial-sema-lipo","vial-sema-nad+","vial-tirz-cyano","vial-tirz-nad+","vial-tirz-pyridoxine","np-sema-0.125ml-inj","np-sema-0.25ml-inj","np-sema-0.5ml-inj","np-sema-0.75ml-inj","np-sema-1.0ml-inj","np-sema-1.25ml-inj","np-sema-1.5ml-inj","np-sema-2.0ml-inj","np-tirz-0.25ml-inj","np-tirz-0.5ml-inj","np-tirz-0.75ml-inj","np-tirz-1.0ml-inj","np-tirz-1.25ml-inj"],N=[];function Lt(){console.log("[CRM Extension] Tag removal system initialized")}function Rn(){N=[];try{let e=document.querySelectorAll(".tag, .tag-label, .pill, .badge");for(let r of e){let s=r.textContent.trim().toLowerCase();Ie.some(i=>s.includes(i))&&N.push({element:r,text:s})}let t=document.querySelectorAll("[data-tag]");for(let r of t){let s=r.getAttribute("data-tag").toLowerCase();Ie.some(i=>s.includes(i))&&N.push({element:r,text:s})}let n=document.querySelectorAll(".tags-container, .tag-list, .tags");for(let r of n){let s=r.querySelectorAll("*");for(let i of s)if(i.nodeType===1){let a=i.textContent.trim().toLowerCase();Ie.some(l=>a.includes(l))&&(N.some(l=>l.element===i)||N.push({element:i,text:a}))}}let o=document.querySelectorAll("*[class]");for(let r of o){let s=r.className.toLowerCase();s&&typeof s=="string"&&Ie.some(i=>s.includes(i))&&(N.some(i=>i.element===r)||N.push({element:r,text:r.textContent.trim().toLowerCase()}))}return console.log(`[CRM Extension] Found ${N.length} removable tags`),N}catch(e){return console.error("[CRM Extension] Error detecting tags:",e),[]}}function Nn(e){try{let t=e.querySelector('.close, .remove, .delete, .tag-remove, [aria-label="Remove"], .x-button');if(t)return console.log("[CRM Extension] Found close button in tag, clicking it"),t.click(),!0;let n=e.parentElement;if(n){let s=n.querySelector('.close, .remove, .delete, .tag-remove, [aria-label="Remove"], .x-button');if(s)return console.log("[CRM Extension] Found close button as sibling, clicking it"),s.click(),!0}let o=[...Array.from(e.querySelectorAll("*")),...Array.from(n?n.children:[])];for(let s of o){let i=s.textContent.trim();if(i==="\xD7"||i==="x"||i==="\u2715"||i==="\u2716"||i==="X")return console.log("[CRM Extension] Found X button by text content, clicking it"),s.click(),!0;if(s.className&&(s.className.includes("close")||s.className.includes("delete")||s.className.includes("remove")||s.className.includes("x-button")))return console.log("[CRM Extension] Found X button by class name, clicking it"),s.click(),!0;if(s.classList&&(s.classList.contains("fa-times")||s.classList.contains("fa-close")||s.classList.contains("icon-close")||s.classList.contains("icon-remove")))return console.log("[CRM Extension] Found X button by icon class, clicking it"),s.click(),!0}if(e.tagName==="BUTTON"||e.tagName==="A"||e.getAttribute("role")==="button"||window.getComputedStyle(e).cursor==="pointer")return console.log("[CRM Extension] Tag appears to be clickable, clicking it"),e.click(),!0;let r=n;for(let s=0;s<3&&r;s++){let i=r.querySelectorAll("button, span, i, div");for(let a of i){let l=a.textContent.trim();if(l==="\xD7"||l==="x"||l==="\u2715"||l==="\u2716"||l==="X"||a.classList.contains("fa-times")||a.classList.contains("fa-close")||a.classList.contains("close")||a.classList.contains("remove"))return console.log("[CRM Extension] Found X button in parent container, clicking it"),a.click(),!0}r=r.parentElement}return console.log("[CRM Extension] No method found to remove tag:",e),!1}catch(t){return console.error("[CRM Extension] Error removing tag:",t),!1}}function qe(){return new Promise((e,t)=>{try{let r=function(s){if(s>=N.length){console.log(`[CRM Extension] Removed ${n}/${o} tags`),e({success:!0,message:`Removed ${n} of ${o} tags`,removed:n,total:o});return}let i=N[s];console.log(`[CRM Extension] Removing tag: ${i.text}`),Nn(i.element)&&n++,setTimeout(()=>{r(s+1)},300)};Rn();let n=0,o=N.length;if(o===0){console.log("[CRM Extension] No removable tags found"),e({success:!0,message:"No tags to remove",removed:0,total:0});return}console.log(`[CRM Extension] Attempting to remove ${o} tags`),r(0)}catch(n){console.error("[CRM Extension] Error in removeAllTags:",n),t(n)}})}var Tn=["Workflow - New Patient - Semaglutide 0.125ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 0.25ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 0.5ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 0.75ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 1.0ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 1.25ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 1.5ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 2.0ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 0.25ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 0.5ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 0.75ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 1.0ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 1.25ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 1.5ml Onboarding - (Step 1)","Workflow - Refill - Semaglutide/B12 Injection Refill Order - (Step 1)","Workflow - Semaglutide/B12 Vial Order - (Step 1)","Workflow - Semaglutide/B6 Vial Order - (Step 1)","Workflow - Semaglutide/Lipo Vial Order - (Step 1)","Workflow - Semaglutide/NAD+ Vial Order - (Step 1)","Workflow - Syringe - Tirzepatide/Pyridoxine Injection Order - (Step 1)","Workflow - Tirzepatide/Cyano Vial Order - (Step 1)","Workflow - Tirzepatide/NAD+ Vial Order - (Step 1)","Workflow - Tirzepatide/Pyridoxine Vial Order - (Step 1)"],Re=[];function P(e){try{if(e&&typeof e.getBoundingClientRect=="function")return e.getBoundingClientRect()}catch{}return{top:0,bottom:0,left:0,right:0,width:0,height:0}}function Rt(){console.log("[CRM Extension] Automation removal system initialized")}function Un(){Re=[];try{let e=Nt("Active");return e?(Re=(e.workflows.length?e.workflows:Vn(e.label)).filter(n=>{if(!n)return!1;let o=(n.textContent||"").trim();return o.includes("Workflow")&&Tn.some(r=>o.includes(r))}),console.log(`[CRM Extension] Found ${Re.length} automation(s) in Active section.`),Re):(console.log("[CRM Extension] Active section not found."),[])}catch(e){return console.error("[CRM Extension] Error detecting automations:",e),[]}}function Vn(e){let t=P(e).bottom,n=null,o=Nt("Past");return o&&o.label&&(n=P(o.label).top),Array.from(document.querySelectorAll('div[id^="workflow_"], div[data-workflow-id]')).filter(s=>{let i=P(s);return!(i.top<t||n&&i.top>=n)})}function Nt(e){try{let n=Array.from(document.querySelectorAll("div.py-2")).find(s=>(s.textContent||"").trim()===e);if(n)return{label:n,workflows:e==="Active"?Pn(n):Bn(n)};let o=e==="Active"?'[data-automation="Active"], #automation-active':'[data-automation="Past"], #automation-past',r=document.querySelector(o);return r?{label:r,workflows:[]}:null}catch(t){return console.error(`[CRM Extension] Error finding section for "${e}":`,t),null}}function Pn(e){let t=P(e).bottom,o=Array.from(document.querySelectorAll("div.py-2")).find(i=>(i.textContent||"").trim()==="Past"),r=o?P(o).top:null;return Array.from(document.querySelectorAll('div[id^="workflow_"], div[data-workflow-id]')).filter(i=>{let a=P(i);return a.top>t&&(!r||a.top<r)})}function Bn(e){let t=P(e).bottom;return Array.from(document.querySelectorAll('div[id^="workflow_"], div[data-workflow-id]')).filter(o=>P(o).top>t)}function Dn(e){if(!e)return console.error("[CRM Extension] removeAutomation called with undefined element."),!1;try{let t=P(e),n=t.width>0&&t.height>0,o=t.top>=0&&t.left>=0&&t.bottom<=(window.innerHeight||document.documentElement.clientHeight);return!n||!o?(e.scrollIntoView({behavior:"smooth",block:"center"}),new Promise(r=>{setTimeout(()=>r(At(e)),500)})):At(e)}catch(t){return console.error("[CRM Extension] Error removing automation:",t),!1}}function At(e){if(!e)return!1;try{let t=e.querySelectorAll("i.icon-close, i.icon.icon-close");if(t.length)return t[0].click(),!0}catch(t){console.error("[CRM Extension] Error in Strategy 1:",t)}try{let t=e.querySelectorAll("a");for(let n of t){let o=(n.textContent||"").trim();if(o==="\xD7"||o.toLowerCase()==="x")return n.click(),!0}}catch(t){console.error("[CRM Extension] Error in Strategy 2:",t)}try{let t=e.querySelectorAll('button, .btn, [role="button"]');for(let n of t)if((n.textContent||"").toLowerCase().includes("manage"))return n.click(),setTimeout(()=>{document.querySelectorAll(".dropdown-menu .dropdown-item, .menu-item").forEach(s=>{let i=(s.textContent||"").toLowerCase();(i.includes("remove")||i.includes("delete"))&&s.click()})},300),!0}catch(t){console.error("[CRM Extension] Error in Strategy 3:",t)}if(e.id&&e.id.startsWith("workflow_")){let t=e.id;try{let n=`#${t} i.icon-close, #${t} i.icon.icon-close`,o=document.querySelector(n);if(o)return o.click(),!0;n=`#${t} .remove, #${t} .close`;let r=document.querySelector(n);if(r)return r.click(),!0}catch(n){console.error("[CRM Extension] Error in Strategy 4:",n)}}try{let t=e.querySelectorAll("span");for(let n of t){let o=(n.textContent||"").trim();if(o==="\xD7"||o.toLowerCase()==="x")return n.click(),!0}}catch(t){console.error("[CRM Extension] Error in Strategy 5:",t)}try{let t=e.nextElementSibling,n=0;for(;t&&n<3;){if(t.classList&&(t.classList.contains("close")||t.classList.contains("remove"))||t.textContent&&(t.textContent.trim()==="\xD7"||t.textContent.trim().toLowerCase()==="x"))return t.click(),!0;let o=t.querySelector("i.icon-close, i.icon.icon-close");if(o)return o.click(),!0;t=t.nextElementSibling,n++}}catch(t){console.error("[CRM Extension] Error in Strategy 6:",t)}try{let t=P(e),n=t.right-10,o=t.top+t.height/2,r=document.elementsFromPoint(n,o);for(let i of r)if(i!==e)return i.click(),!0;let s=new MouseEvent("click",{view:window,bubbles:!0,cancelable:!0,clientX:n,clientY:o});return(r[0]||document.elementFromPoint(n,o))?.dispatchEvent(s),!0}catch(t){console.error("[CRM Extension] Error in Strategy 7:",t)}return console.error("[CRM Extension] No method found to remove automation:",e),!1}function It(){return new Promise(e=>{setTimeout(()=>{if(document.querySelectorAll('.modal, [role="dialog"], .dialog').length){let n=document.querySelectorAll('.modal .btn-primary, .modal .btn-danger, .modal .confirm-btn, [role="dialog"] .btn-primary, .modal button, [role="dialog"] button');for(let r of n){let s=(r.textContent||"").trim().toLowerCase();if(["delete","remove","yes","confirm","ok","continue"].includes(s)){r.click(),e(!0);return}}let o=document.querySelectorAll('.modal button, [role="dialog"] button, .dialog button');if(o.length){o[o.length-1].click(),e(!0);return}}e(!1)},500)})}function We(){return new Promise((e,t)=>{try{let s=function(i){if(i>=r){e({success:!0,message:`Removed ${o} of ${r} automations`,removed:o,total:r});return}let a=n[i],l=Dn(a.element);l instanceof Promise?l.then(p=>{p&&o++,It().then(()=>setTimeout(()=>s(i+1),1e3))}):(l&&o++,It().then(()=>setTimeout(()=>s(i+1),1e3)))},n=Un();if(!n.length){console.log("[CRM Extension] No automations to remove."),e({success:!0,message:"No automations to remove",removed:0,total:0});return}let o=0,r=n.length;s(0)}catch(n){console.error("[CRM Extension] Error in removeAllAutomations:",n),t(n)}})}var w=[];var Ne="crmplus_history";function Pt(){Bt(),_n(),Fn(),window.addEventListener("storage",zn),console.log("[CRM Extension] History tracking initialized")}function Bt(){try{let e=localStorage.getItem(Ne);if(e){w=JSON.parse(e);let t=Date.now();w=w.filter(n=>t-n.timestamp<144e5),Ge()}}catch(e){console.error("[CRM Extension] Error loading history:",e),w=[]}}function Ge(){try{localStorage.setItem(Ne,JSON.stringify(w))}catch(e){console.error("[CRM Extension] Error saving history:",e)}}function zn(e){if(e.key===Ne)try{e.newValue?(w=JSON.parse(e.newValue),console.log("[CRM Extension] History updated from another tab")):(w=[],console.log("[CRM Extension] History cleared from another tab"))}catch(t){console.error("[CRM Extension] Error processing cross-tab history update:",t)}}function _n(){let e=window.location.href;setInterval(()=>{let o=window.location.href;o!==e&&(e=o,re(o))},500),re(window.location.href);let t=history.pushState;history.pushState=function(){t.apply(this,arguments),re(window.location.href)};let n=history.replaceState;history.replaceState=function(){n.apply(this,arguments),re(window.location.href)},window.addEventListener("popstate",()=>{re(window.location.href)})}function re(e){if(!e)return;let t=e.match(/\/detail\/([^/]+)/);if(t&&t[1]){let n=t[1];setTimeout(()=>{let o=Tt(),r=Ut();o&&o!=="Unknown Patient"?Vt(n,o,r,e):(console.log("[CRM Extension] Patient name not found yet, retrying in 3 seconds..."),setTimeout(()=>{let s=Tt(),i=Ut();s&&s!=="Unknown Patient"?Vt(n,s,i,e):console.log("[CRM Extension] Could not retrieve patient info after retry, not adding to history")},3e3))},5e3)}}function Tt(){let e=document.getElementById("name-text");if(e&&e.textContent&&e.textContent.trim()!=="")return e.textContent.trim();let t=document.querySelector('input[name="contact.first_name"]'),n=document.querySelector('input[name="contact.last_name"]');if(t&&t.value&&n&&n.value)return`${t.value} ${n.value}`.trim();let o=[".patient-name",".contact-name","h1.name",".customer-name","span.name",".profile-name","h2.name",".contact-header .name",'div[data-field="name"]',".patient-info .name"];for(let r of o){let s=document.querySelector(r);if(s&&s.textContent&&s.textContent.trim()!=="")return s.textContent.trim()}return"Unknown Patient"}function Ut(){let e=document.getElementById("phone-text");if(e&&e.textContent&&e.textContent.trim()!=="")return e.textContent.trim();let t=document.querySelector('input[name="contact.phone"]');if(t&&t.value.trim()!=="")return t.value.trim();let n=[".phone-number .number",'input[placeholder="Phone"]','input[placeholder="Phone Number"]',".patient-info .phone",".contact-info .phone","span.phone",'div[data-field="phone"]','span[data-field="phone_number"]'];for(let o of n){let r=document.querySelector(o);if(r)if(r.tagName==="INPUT"){let s=r.value.trim();if(s)return s}else{let s=r.textContent.trim();if(s)return s}}return""}function Vt(e,t,n,o){let s=Date.now(),i=w.findIndex(a=>a.patientId===e);if(i!==-1){let a=w[i];a.timestamp=s,a.patientName=t,a.phoneNumber=n,w.splice(i,1),w.unshift(a)}else w.unshift({patientId:e,patientName:t,phoneNumber:n,url:o,timestamp:s}),w.length>20&&w.pop();Ge()}function Fn(){setInterval(()=>{let e=Date.now(),t=0;w=w.filter(n=>{let o=e-n.timestamp<144e5;return o||t++,o}),t>0&&(console.log(`[CRM Extension] Removed ${t} expired history entries`),Ge())},5*60*1e3)}function Dt(){Bt();let e=Date.now();return w=w.filter(t=>e-t.timestamp<144e5),[...w]}function zt(){w=[],localStorage.removeItem(Ne),console.log("[CRM Extension] History cleared")}function _t(e){return new Date(e).toLocaleString("en-US",{hour:"numeric",minute:"2-digit",hour12:!0})}var Ft="crmplus_chat_audit_log";function c(e,t,n={}){try{let o={timestamp:new Date().toISOString(),category:e,action:t,details:n,username:localStorage.getItem("crmplus_chat_username")||"Unknown",browser:On(),ip:"127.0.0.1"},r=Ot();return r.unshift(o),r.length>1e3&&(r.length=1e3),localStorage.setItem(Ft,JSON.stringify(r)),!0}catch(o){return console.error("[CRM Extension] Error logging audit event:",o),!1}}function Ot(){try{let e=localStorage.getItem(Ft);return e?JSON.parse(e):[]}catch(e){return console.error("[CRM Extension] Error getting audit log:",e),[]}}function On(){let e=navigator.userAgent,t="Unknown Browser";return e.includes("Firefox")?t="Firefox":e.includes("Edg")?t="Edge":e.includes("Chrome")?t="Chrome":e.includes("Safari")&&(t="Safari"),t}var Te="crmplus_chat_",jt=`${Te}messages`,_r=`${Te}channels`,Fr=`${Te}users`,Ht=`${Te}settings`,$t=100,Or=24*60*60*1e3;function qt(e){try{if(!e||!e.id)return!1;let t=e.channel||"general",n={...e,stored:Date.now()},o=$n(),r=o[t]||[],s=r.findIndex(i=>i.id===e.id);return s>=0?r[s]=n:r.unshift(n),r.length>$t&&(r.length=$t),o[t]=r,localStorage.setItem(jt,JSON.stringify(o)),c("storage",`Message saved from ${e.sender}`,{messageId:e.id,channel:t}),!0}catch(t){return console.error("[CRM Extension] Error saving message:",t),c("storage","Error saving message",{error:t.message}),!1}}function $n(){try{let e=localStorage.getItem(jt);return e?JSON.parse(e):{}}catch(e){return console.error("[CRM Extension] Error getting messages map:",e),c("storage","Error getting messages map",{error:e.message}),{}}}function Ue(e,t){try{if(!e)return!1;let n=Wt();return n[e]=t,localStorage.setItem(Ht,JSON.stringify(n)),c("storage",`Setting saved: ${e}`),!0}catch(n){return console.error("[CRM Extension] Error saving setting:",n),c("storage","Error saving setting",{error:n.message}),!1}}function L(e,t=null){try{let n=Wt();return e in n?n[e]:t}catch(n){return console.error("[CRM Extension] Error getting setting:",n),c("storage","Error getting setting",{error:n.message}),t}}function Wt(){try{let e=localStorage.getItem(Ht);return e?JSON.parse(e):{}}catch(e){return console.error("[CRM Extension] Error getting settings:",e),c("storage","Error getting settings",{error:e.message}),{}}}var Je=null,jn=null,Hn=typeof window<"u"&&window.crypto&&window.crypto.subtle;function Gt(e){let t=new ArrayBuffer(e.length),n=new Uint8Array(t);for(let o=0;o<e.length;o++)n[o]=e.charCodeAt(o);return t}function qn(e){return String.fromCharCode.apply(null,new Uint8Array(e))}async function Wn(e){try{let t=Gt(atob(e.encryptedData)),n=Gt(atob(e.iv)),o=new Uint8Array(n),r=await window.crypto.subtle.decrypt({name:"AES-GCM",iv:o,tagLength:128},Je,t),s=qn(r);return JSON.parse(s)}catch(t){throw console.error("[CRM Extension] Error decrypting with Web Crypto API:",t),t}}function Gn(e){try{let t=Jn(e.encryptedData,Je);return JSON.parse(t)}catch(t){throw console.error("[CRM Extension] Error in legacy decryption:",t),t}}function Jn(e,t){let n="";for(let o=0;o<e.length;o++){let r=e.charCodeAt(o)^t.charCodeAt(o%t.length);n+=String.fromCharCode(r)}return btoa(n)}async function Ye(e){try{if(!e||!e.encrypted)return e;if(!Je||!jn)throw new Error("Encryption keys not available");return e.encryptionMethod==="AES-GCM"&&Hn?await Wn(e):Gn(e)}catch(t){return console.error("[CRM Extension] Error decrypting message:",t),c("security","Decryption error",{error:t.message}),{id:e.id||Yn(),sender:e.sender||"Unknown",text:"[Encrypted message - unable to decrypt]",timestamp:e.timestamp||new Date().toISOString(),type:e.type||"chat",channel:e.channel||"general"}}}function Yn(){return Date.now().toString(36)+Math.random().toString(36).substr(2,5)}var Jt="crmplus_chat_auth_token",Pe="crmplus_chat_user_info",Ve=15*60*1e3,g=null,H=null,Be=Date.now(),D=null,Ke=[],se={username:"CBarnett",password:"Admin123",role:"admin",displayName:"Admin"};function Kn(){Be=Date.now(),D&&clearTimeout(D),b()&&Ze()}function Ze(){D&&clearTimeout(D),b()&&(D=setTimeout(()=>{let e=Date.now()-Be;if(e>=Ve)c("auth","Session timed out due to inactivity",{username:g?.username,inactiveTime:Math.round(e/1e3)+" seconds"}),ie("Session timed out due to inactivity");else{let t=Ve-e;D=setTimeout(Ze,t)}},Ve))}async function Qe(e,t){try{if(!e||!t)throw new Error("Username and password are required");c("auth","Login attempt",{username:e});let o=(localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000").replace("ws://","http://").replace("wss://","https://"),r=null;if(e===se.username&&t===se.password)r={success:!0,token:"admin_"+Date.now().toString(36)+Math.random().toString(36).substr(2),user:{id:"admin_"+Math.random().toString(36).substr(2),username:se.username,role:se.role,displayName:se.displayName,isAdmin:!0}};else try{let s=await fetch(`${o}/auth/login`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username:e,password:t})});if(!s.ok){let i=await s.json();throw new Error(i.message||"Login failed")}r=await s.json()}catch(s){if(console.error("[CRM Extension] Server auth error:",s),L("allow_local_auth",!1)){let a=L("local_users",[]).find(l=>l.username===e);if(a&&a.password===t)r={success:!0,token:"local_"+Date.now().toString(36)+Math.random().toString(36).substr(2),user:{id:a.id||"user_"+Math.random().toString(36).substr(2),username:a.username,role:a.role||"user",displayName:a.displayName||a.username,isLocal:!0}};else throw new Error("Invalid username or password")}else throw new Error("Server authentication failed")}if(!r||!r.success)throw new Error("Authentication failed");return H=r.token,g=r.user,localStorage.setItem(Jt,H),localStorage.setItem(Pe,JSON.stringify(g)),Kn(),Ze(),c("auth","Login successful",{username:g.username,role:g.role}),De(),{success:!0,user:g}}catch(n){return c("auth","Login failed",{username:e,error:n.message}),console.error("[CRM Extension] Login error:",n),{success:!1,error:n.message}}}function ie(e="User logout"){try{if(!b())return!1;c("auth","Logout",{username:g?.username,reason:e}),H=null;let t=g;return g=null,localStorage.removeItem(Jt),localStorage.removeItem(Pe),D&&(clearTimeout(D),D=null),De(t),!0}catch(t){return console.error("[CRM Extension] Logout error:",t),!1}}async function Xe(e){try{if(!b()||g.role!=="admin")return{success:!1,error:"Administrator privileges required to create users"};if(!e.username||!e.password)throw new Error("Username and password are required");c("auth","User registration attempt",{username:e.username,createdBy:g.username});let n=(localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000").replace("ws://","http://").replace("wss://","https://");try{let o=await fetch(`${n}/auth/register`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${H}`},body:JSON.stringify(e)});if(!o.ok){let s=await o.json();throw new Error(s.message||"Registration failed")}let r=await o.json();return c("auth","User registration successful",{username:e.username,createdBy:g.username,role:e.role||"user"}),{success:!0,user:r.user}}catch(o){if(console.error("[CRM Extension] Server registration error:",o),L("allow_local_auth",!1)){let r={id:"user_"+Date.now().toString(36),username:e.username,password:e.password,role:e.role||"user",displayName:e.displayName||e.username,createdAt:new Date().toISOString(),createdBy:g.id},s=L("local_users",[]);if(s.some(i=>i.username===r.username))throw new Error("Username already exists");return s.push(r),Ue("local_users",s),c("auth","Local user registration successful",{username:e.username,createdBy:g.username,role:e.role||"user",isLocal:!0}),{success:!0,user:{id:r.id,username:r.username,role:r.role,displayName:r.displayName,isLocal:!0}}}else throw new Error("Server registration failed: "+o.message)}}catch(t){return c("auth","User registration failed",{username:e.username,error:t.message}),console.error("[CRM Extension] Registration error:",t),{success:!1,error:t.message}}}function b(){return!!H&&!!g}function S(){return g}function ze(){return H}function G(){if(!b())return{authenticated:!1,timeRemaining:0,lastActivity:null};let e=Date.now()-Be,t=Math.max(0,Ve-e);return{authenticated:!0,timeRemaining:t,lastActivity:Be,formattedTimeRemaining:Zn(t)}}function Zn(e){let t=Math.floor(e/6e4),n=Math.floor(e%6e4/1e3);return t>0?`${t}m ${n}s`:`${n}s`}function et(e){typeof e=="function"&&!Ke.includes(e)&&Ke.push(e)}function De(e=null){let t={authenticated:b(),user:g,prevUser:e,token:H};Ke.forEach(n=>{try{n(t)}catch(o){console.error("[CRM Extension] Error in auth listener:",o)}})}async function tt(e){try{if(!b())throw new Error("User must be authenticated to update profile");let n=(localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000").replace("ws://","http://").replace("wss://","https://");try{let o=await fetch(`${n}/auth/profile`,{method:"PUT",headers:{"Content-Type":"application/json",Authorization:`Bearer ${H}`},body:JSON.stringify(e)});if(!o.ok){let s=await o.json();throw new Error(s.message||"Profile update failed")}let r=await o.json();return g={...g,...r.user},localStorage.setItem(Pe,JSON.stringify(g)),c("auth","Profile updated",{username:g.username,updatedFields:Object.keys(e).join(", ")}),De(),{success:!0,user:g}}catch(o){if(console.error("[CRM Extension] Server profile update error:",o),L("allow_local_auth",!1)&&g.isLocal){let r=L("local_users",[]),s=r.findIndex(i=>i.id===g.id);if(s>=0){let i={...r[s],displayName:e.displayName||r[s].displayName};return r[s]=i,Ue("local_users",r),g={...g,displayName:i.displayName},localStorage.setItem(Pe,JSON.stringify(g)),c("auth","Local profile updated",{username:g.username,updatedFields:Object.keys(e).join(", "),isLocal:!0}),De(),{success:!0,user:g}}}throw new Error("Server profile update failed: "+o.message)}}catch(t){return c("auth","Profile update failed",{error:t.message}),console.error("[CRM Extension] Profile update error:",t),{success:!1,error:t.message}}}function z(e){return!b()||!g.role?!1:g.role==="admin"?!0:g.role==="moderator"?["user.view","channel.create","channel.view","channel.update","channel.invite","message.delete","message.create","message.view"].includes(e):["user.view","channel.view","message.create","message.view","message.update.own","message.delete.own"].includes(e)}var v=null,nt="disconnected",Yt=localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000",ae=0,Xn=5,eo=5e3,Q=null,to=3e4,no=[],oo=[],ro=[],so=[],Kt="general";function le(){return new Promise(e=>{if(v&&(v.readyState===WebSocket.OPEN||v.readyState===WebSocket.CONNECTING)){console.log("[CRM Extension] WebSocket is already connected or connecting"),Z("connected"),e(!0);return}try{console.log(`[CRM Extension] Connecting to WebSocket server: ${Yt}`),v=new WebSocket(Yt),Z("connecting"),v.onopen=()=>{console.log("[CRM Extension] WebSocket connection established"),Z("connected"),ae=0,io(),ao(),c("system","Connected to chat server"),e(!0)},v.onmessage=t=>{co(t.data)},v.onclose=t=>{console.log(`[CRM Extension] WebSocket connection closed: ${t.code} - ${t.reason}`),Z("disconnected"),Q&&(clearInterval(Q),Q=null),c("system",`Disconnected from chat server: ${t.code}`),t.code!==1e3&&t.code!==1001&&lo(),e(!1)},v.onerror=t=>{console.error("[CRM Extension] WebSocket error:",t),Z("error"),c("system","WebSocket error occurred",{error:"Connection error"}),e(!1)}}catch(t){console.error("[CRM Extension] Error connecting to WebSocket server:",t),Z("error"),c("system","Failed to connect to chat server",{error:t.message}),e(!1)}})}function Z(e){nt!==e&&(nt=e,mo())}function io(){if(!v||v.readyState!==WebSocket.OPEN)return;let e=ze(),t=S();if(!e||!t)return;let n={type:"auth",token:e,username:t.username,timestamp:new Date().toISOString()};v.send(JSON.stringify(n)),c("system","Sent authentication request")}function ao(){Q&&clearInterval(Q),Q=setInterval(()=>{if(v&&v.readyState===WebSocket.OPEN){let e={type:"heartbeat",timestamp:new Date().toISOString()};v.send(JSON.stringify(e))}},to)}function lo(){if(ae>=Xn){console.log("[CRM Extension] Maximum reconnection attempts reached");return}ae++;let e=eo*Math.pow(1.5,ae-1);console.log(`[CRM Extension] Attempting to reconnect in ${e}ms (attempt ${ae})`),setTimeout(()=>{le()},e)}function co(e){try{let t=JSON.parse(e);switch(t.type){case"chat":po(t);break;case"user_list":uo(t.users);break;case"channel_list":ho(t.channels);break;case"auth_response":t.success?(console.log("[CRM Extension] Authentication successful"),c("system","Authentication successful"),Qt(),Xt(Kt)):(console.error("[CRM Extension] Authentication failed:",t.reason),c("system","Authentication failed",{reason:t.reason}));break;case"error":console.error("[CRM Extension] Server error:",t.message),c("error",`Server error: ${t.message}`);break;case"heartbeat_response":break;default:console.log("[CRM Extension] Unknown message type:",t.type)}}catch(t){console.error("[CRM Extension] Error parsing WebSocket message:",t)}}function po(e){let t=e;if(e.encrypted)try{t=Ye(e)}catch(n){console.error("[CRM Extension] Failed to decrypt message:",n),t={...e,text:"[Encrypted message - unable to decrypt]"}}qt(t),c("message",`Received message from ${e.sender}`,{messageId:e.id,channel:e.channel||"general"}),go([t])}function uo(e){fo(e)}function ho(e){yo(e)}function Zt(e){if(!v||v.readyState!==WebSocket.OPEN)return console.error("[CRM Extension] WebSocket is not connected"),!1;try{return v.send(JSON.stringify(e)),!0}catch(t){return console.error("[CRM Extension] Error sending message:",t),!1}}function mo(){so.forEach(e=>{try{e(nt)}catch(t){console.error("[CRM Extension] Error in connection status listener:",t)}})}function go(e){no.forEach(t=>{try{t(e)}catch(n){console.error("[CRM Extension] Error in message listener:",n)}})}function fo(e){oo.forEach(t=>{try{t(e)}catch(n){console.error("[CRM Extension] Error in user list listener:",n)}})}function yo(e){ro.forEach(t=>{try{t(e)}catch(n){console.error("[CRM Extension] Error in channel list listener:",n)}})}function Qt(){if(!b())return;let e={type:"channel_list_request",timestamp:new Date().toISOString()};Zt(e)}function Xt(e){if(!e||!b())return;Kt=e,localStorage.setItem("crmplus_chat_active_channel",e);let t={type:"channel_join",channel:e,timestamp:new Date().toISOString()};Zt(t),c("system",`Switched to channel: ${e}`)}var is=localStorage.getItem("crmplus_chat_active_channel")||"general";var ot=class{constructor(){this.listeners=[],this.authState={authenticated:b(),user:S(),sessionStatus:G()},this.setupAuthListener(),this.setupSessionRefresh()}notifyListeners(){let t=this.getAuthState();this.listeners.forEach(n=>{try{n(t)}catch(o){console.error("[CRM Extension] Error in auth context listener:",o)}})}setupAuthListener(){et(t=>{this.authState={...this.authState,authenticated:t.authenticated,user:t.user},this.notifyListeners()})}setupSessionRefresh(){setInterval(()=>{this.authState.sessionStatus=G(),this.authState.authenticated&&this.notifyListeners()},6e4)}async login(t,n){let o=await Qe(t,n);return o.success&&(this.authState={authenticated:!0,user:o.user,sessionStatus:G()},this.notifyListeners()),o}logout(t){let n=ie(t);return n&&(this.authState={authenticated:!1,user:null,sessionStatus:G()},this.notifyListeners()),n}async register(t){return await Xe(t)}async updateProfile(t){let n=await tt(t);return n.success&&(this.authState={...this.authState,user:n.user},this.notifyListeners()),n}hasPermission(t){return z(t)}getAuthState(){return this.authState.sessionStatus=G(),{...this.authState}}subscribe(t){return typeof t!="function"?(console.error("[CRM Extension] Auth context listener must be a function"),()=>{}):(this.listeners.push(t),t(this.getAuthState()),()=>{this.listeners=this.listeners.filter(n=>n!==t)})}},ds=new ot;var hs={server:{url:L("server_url","ws://localhost:3000"),connectionTimeout:1e4,reconnect:{maxAttempts:5,delay:5e3,useExponentialBackoff:!0},heartbeatInterval:3e4},security:{sessionTimeout:15*60*1e3,hasCryptoAPI:typeof window<"u"&&window.crypto&&window.crypto.subtle,minPasswordLength:8,enableTwoFactorAuth:!1},storage:{maxMessagesPerChannel:100,messageExpiration:24*60*60*1e3,keyPrefix:"crmplus_chat_"},ui:{theme:L("theme","light"),notifications:{enabled:L("notifications_enabled",!0),sound:L("notification_sound",!0),soundUrl:L("notification_sound_url",null)},messages:{maxLength:2e3,allowEditing:!0,editWindow:5*60*1e3,allowDeletion:!0},channels:{defaultChannel:"general"}},features:{directMessaging:!0,fileSharing:!1,messageThreading:!1,messageReactions:!0,userChannelCreation:L("user_channel_creation",!1),userStatus:!0},hipaa:{enableSessionTimeout:!0,enableAuditLogging:!0,enableMessageExpiration:!0,showPhiIndicators:!0,enableEncryption:!0},roles:{admin:{name:"Administrator",permissions:["user.create","user.read","user.update","user.delete","channel.create","channel.read","channel.update","channel.delete","channel.invite","message.delete","audit.read"]},moderator:{name:"Moderator",permissions:["user.read","channel.create","channel.read","channel.update","channel.invite","message.delete"]},user:{name:"User",permissions:["user.read","channel.read","message.create","message.read","message.update.own","message.delete.own"]}},version:{number:"1.0.0",buildDate:new Date("2025-03-18").toISOString()}};var un=[];function hn(){let e=getChannelMessages(getActiveChannel());setInterval(()=>{getConnectionStatus()==="disconnected"&&(console.log("[CRM Extension] Attempting to reconnect chat"),le())},3e4),c("system","Chat monitoring initialized")}function mn(e){typeof e=="function"&&!un.includes(e)&&un.push(e)}function gn(e){let t=document.createElement("button");t.className="chat-button",t.innerHTML='<span class="icon">\u{1F4AC}</span><span class="badge" style="display:none">0</span>',t.title="HIPAA-Compliant Chat",Object.assign(t.style,{position:"relative",padding:"8px",backgroundColor:"transparent",border:"none",cursor:"pointer",fontSize:"20px"});let n=t.querySelector(".badge");return Object.assign(n.style,{position:"absolute",top:"0",right:"0",backgroundColor:"#f44336",color:"white",fontSize:"12px",fontWeight:"bold",padding:"2px 6px",borderRadius:"50%",display:"none"}),t.addEventListener("click",()=>{typeof window.toggleChatUI=="function"&&window.toggleChatUI()}),window.addEventListener("chat_notification_count",o=>{let r=o.detail.count;r>0?(n.textContent=r>99?"99+":r,n.style.display="block"):n.style.display="none"}),e&&e.appendChild(t),t}function ce(e,t,n={}){let o=document.createElement("div");o.className="group";let r=document.createElement("span");r.className="label",r.textContent=`${t}:`,o.appendChild(r);let s=document.createElement("span");if(s.id=`${e}-display`,s.className="clickable-value",n.initialValue&&s.setAttribute("data-value",n.initialValue),n.icon){let l=document.createElement("span");l.className="btn-icon",l.innerHTML=n.icon,s.appendChild(l)}let i=document.createElement("span");i.textContent=n.initialValue||"",i.id=`${e}-text`,s.appendChild(i);let a=async()=>{let l=s.getAttribute("data-value")||i.textContent.trim();l&&l!==""?await te(l)?u(`Copied ${t}: ${l}`):u(`Failed to copy ${t.toLowerCase()}`):u(`No ${t.toLowerCase()} available to copy`)};return s.addEventListener("click",()=>{n.onClick?n.onClick(s):a()}),s.title=`Click to copy ${t.toLowerCase()} to clipboard`,o.appendChild(s),o}function fn(){let e=document.createElement("div");return e.className="group",e.id="crm-actions-group",e}function yn(){let e=document.createElement("div");e.className="dropdown",e.id="crm-tags-dropdown";let t=document.createElement("button");t.className="dropdown-btn",t.textContent="Tags",t.addEventListener("click",d=>{d.stopPropagation(),document.querySelectorAll(".dropdown.show").forEach(ut=>{ut!==e&&ut.classList.remove("show")}),e.classList.toggle("show")});let n=document.createElement("div");if(n.className="dropdown-content",n.style.padding="10px",!document.getElementById("tags-dropdown-styles")){let d=document.createElement("style");d.id="tags-dropdown-styles",d.textContent=`
      .nested-dropdown {
        margin-bottom: 8px;
        width: 100%;
        position: relative;
      }
      .nested-dropdown-btn {
        width: 100%;
        text-align: left;
        padding: 8px 12px;
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 3px;
        cursor: pointer;
        font-weight: bold;
        font-size: 13px;
        color: #e6e6e6;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .nested-dropdown-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      .nested-dropdown-btn:after {
        content: "\u25BC";
        font-size: 8px;
        color: #e6e6e6;
      }
      .nested-dropdown-content {
        display: none;
        padding: 5px 0 5px 10px;
        margin-top: 3px !important;
      }
      .nested-dropdown.open .nested-dropdown-content {
        display: block;
      }
      
      /* Button-style tag options */
      .tag-btn {
        display: block;
        width: 100%;
        padding: 8px 12px;
        margin-bottom: 8px;
        background-color: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 4px;
        text-align: left;
        font-size: 13px;
        color: #e6e6e6;
        cursor: pointer;
        transition: all 0.2s ease;
        font-weight: normal;
      }
      .tag-btn:hover {
        background-color: rgba(255, 255, 255, 0.15);
        border-color: rgba(255, 255, 255, 0.2);
      }
      .tag-btn:active {
        background-color: rgba(255, 255, 255, 0.2);
      }
    `,document.head.appendChild(d)}let o=document.createElement("button");o.className="tag-btn",o.textContent="Opt-in",o.addEventListener("click",()=>{xn("opt-in"),e.classList.remove("show")}),n.appendChild(o);let r=document.createElement("button");r.className="tag-btn",r.textContent="Refill-Sema-Inj",r.addEventListener("click",()=>{C("refill-sema-inj"),e.classList.remove("show")}),n.appendChild(r);let s=document.createElement("button");s.className="tag-btn",s.textContent="Refill-Tirz-Inj",s.addEventListener("click",()=>{C("refill-tirz-inj"),e.classList.remove("show")}),n.appendChild(s);let i=document.createElement("div");i.className="nested-dropdown";let a=document.createElement("button");a.className="nested-dropdown-btn",a.textContent="Vial-Semaglutide";let l=document.createElement("div");l.className="nested-dropdown-content",a.addEventListener("click",d=>{d.stopPropagation(),i.classList.toggle("open")});let p=document.createElement("button");p.className="tag-btn",p.textContent="Vial-Sema-B12",p.addEventListener("click",d=>{d.stopPropagation(),E(),C("vial-sema-b12")}),l.appendChild(p);let f=document.createElement("button");f.className="tag-btn",f.textContent="Vial-Sema-B6",f.addEventListener("click",d=>{d.stopPropagation(),E(),C("vial-sema-b6")}),l.appendChild(f);let m=document.createElement("button");m.className="tag-btn",m.textContent="Vial-Sema-Lipo",m.addEventListener("click",d=>{d.stopPropagation(),E(),C("vial-sema-lipo")}),l.appendChild(m);let x=document.createElement("button");x.className="tag-btn",x.textContent="Vial-Sema-NAD+",x.addEventListener("click",d=>{d.stopPropagation(),E(),C("vial-sema-nad+")}),l.appendChild(x),i.appendChild(a),i.appendChild(l),n.appendChild(i);let y=document.createElement("div");y.className="nested-dropdown";let A=document.createElement("button");A.className="nested-dropdown-btn",A.textContent="Vial-Tirzepatide";let I=document.createElement("div");I.className="nested-dropdown-content",A.addEventListener("click",d=>{d.stopPropagation(),y.classList.toggle("open")});let T=document.createElement("button");T.className="tag-btn",T.textContent="Vial-Tirz-Cyano",T.addEventListener("click",d=>{d.stopPropagation(),E(),C("vial-tirz-cyano")}),I.appendChild(T);let U=document.createElement("button");U.className="tag-btn",U.textContent="Vial-Tirz-NAD+",U.addEventListener("click",d=>{d.stopPropagation(),E(),C("vial-tirz-nad+")}),I.appendChild(U);let h=document.createElement("button");h.className="tag-btn",h.textContent="Vial-Tirz-Pyr",h.addEventListener("click",d=>{d.stopPropagation(),E(),C("vial-tirz-pyridoxine")}),I.appendChild(h),y.appendChild(A),y.appendChild(I),n.appendChild(y);let M=document.createElement("div");M.className="nested-dropdown";let W=document.createElement("button");W.className="nested-dropdown-btn",W.textContent="NP-Semaglutide";let R=document.createElement("div");R.className="nested-dropdown-content",W.addEventListener("click",d=>{d.stopPropagation(),M.classList.toggle("open")});let K=document.createElement("button");K.className="tag-btn",K.textContent="NP-Sema 0.125",K.addEventListener("click",d=>{d.stopPropagation(),E(),C("np-sema-0.125ml-inj")}),R.appendChild(K);let k=document.createElement("button");k.className="tag-btn",k.textContent="NP-Sema 0.25",k.addEventListener("click",d=>{d.stopPropagation(),E(),C("np-sema-0.25ml-inj")}),R.appendChild(k);let B=document.createElement("button");B.className="tag-btn",B.textContent="NP-Sema 0.5",B.addEventListener("click",d=>{d.stopPropagation(),E(),C("np-sema-0.5ml-inj")}),R.appendChild(B);let $=document.createElement("button");$.className="tag-btn",$.textContent="NP-Sema 0.75",$.addEventListener("click",d=>{d.stopPropagation(),E(),C("np-sema-0.75ml-inj")}),R.appendChild($);let ue=document.createElement("button");ue.className="tag-btn",ue.textContent="NP-Sema 1.0",ue.addEventListener("click",d=>{d.stopPropagation(),E(),C("np-sema-1.0ml-inj")}),R.appendChild(ue);let he=document.createElement("button");he.className="tag-btn",he.textContent="NP-Sema 1.25",he.addEventListener("click",d=>{d.stopPropagation(),E(),C("np-sema-1.25ml-inj")}),R.appendChild(he);let me=document.createElement("button");me.className="tag-btn",me.textContent="NP-Sema 1.5",me.addEventListener("click",d=>{d.stopPropagation(),E(),C("np-sema-1.5ml-inj")}),R.appendChild(me);let ge=document.createElement("button");ge.className="tag-btn",ge.textContent="NP-Sema 2.0",ge.addEventListener("click",d=>{d.stopPropagation(),E(),C("np-sema-2.0ml-inj")}),R.appendChild(ge),M.appendChild(W),M.appendChild(R),n.appendChild(M);let X=document.createElement("div");X.className="nested-dropdown";let fe=document.createElement("button");fe.className="nested-dropdown-btn",fe.textContent="NP-Tirzepatide";let j=document.createElement("div");j.className="nested-dropdown-content",fe.addEventListener("click",d=>{d.stopPropagation(),X.classList.toggle("open")});let ye=document.createElement("button");ye.className="tag-btn",ye.textContent="NP-Tirz 0.25",ye.addEventListener("click",d=>{d.stopPropagation(),E(),C("np-tirz-0.25ml-inj")}),j.appendChild(ye);let xe=document.createElement("button");xe.className="tag-btn",xe.textContent="NP-Tirz 0.5",xe.addEventListener("click",d=>{d.stopPropagation(),E(),C("np-tirz-0.5ml-inj")}),j.appendChild(xe);let Ce=document.createElement("button");Ce.className="tag-btn",Ce.textContent="NP-Tirz 0.75",Ce.addEventListener("click",d=>{d.stopPropagation(),E(),C("np-tirz-0.75ml-inj")}),j.appendChild(Ce);let be=document.createElement("button");be.className="tag-btn",be.textContent="NP-Tirz 1.0",be.addEventListener("click",d=>{d.stopPropagation(),E(),C("np-tirz-1.0ml-inj")}),j.appendChild(be);let Ee=document.createElement("button");Ee.className="tag-btn",Ee.textContent="NP-Tirz 1.25",Ee.addEventListener("click",d=>{d.stopPropagation(),E(),C("np-tirz-1.25ml-inj")}),j.appendChild(Ee);let we=document.createElement("button");return we.className="tag-btn",we.textContent="NP-Tirz 1.5",we.addEventListener("click",d=>{d.stopPropagation(),E(),C("np-tirz-1.5ml-inj")}),j.appendChild(we),X.appendChild(fe),X.appendChild(j),n.appendChild(X),e.appendChild(t),e.appendChild(n),e}function E(){document.querySelectorAll(".dropdown.show").forEach(e=>e.classList.remove("show")),document.querySelectorAll(".nested-dropdown.open").forEach(e=>e.classList.remove("open"))}async function C(e){try{let[t,n]=await Promise.all([qe(),We()]);console.log("[CRM Extension] Cleanup completed:"),console.log(`- Tags: ${t.removed}/${t.total} removed`),console.log(`- Automations: ${n.removed}/${n.total} removed`),xn(e)}catch(t){console.error("[CRM Extension] Error during cleanup:",t),u("Error during cleanup. Please try again.")}}function xn(e){let t=gr();t?(t.focus(),setTimeout(()=>{t.value=e,t.dispatchEvent(new Event("input",{bubbles:!0})),setTimeout(()=>{let n=document.querySelectorAll(".v-list-item, .dropdown-item, .select-option, li"),o=!1;for(let r of n)if(r.textContent.toLowerCase().includes(e)){r.click(),o=!0,u(`Selected tag: ${e}`);break}if(!o){let r=document.querySelectorAll("*");for(let s of r)if(s.textContent.trim().toLowerCase()===e){s.click(),o=!0,u(`Selected tag: ${e}`);break}o||t.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",code:"Enter",keyCode:13,which:13,bubbles:!0}))}},300)},300)):u("Tags field not found")}function gr(){let e=document.querySelector('input[placeholder="Add Tags"]');if(e)return e;let t=Array.from(document.querySelectorAll("input[placeholder]")).filter(s=>s.placeholder.toLowerCase().includes("tag"));if(t.length>0)return t[0];let n=document.querySelectorAll(".tag-input, .tags-input, .tag-container");for(let s of n){let i=s.querySelector("input");if(i)return i}if(e=document.querySelector('input[placeholder="smartList.bulkTags.addTags"]'),e)return e;let o=document.querySelectorAll(".hl-text-input");if(o.length>0)return o[0];console.error("[CRM Extension] Could not find tag input field with any strategy");let r=document.querySelectorAll("input");return console.log("[CRM Extension] All inputs on page:",r),null}var _={"Sema/B12 Refill - Step 2":"Refill - Semaglutide/B12 Injection Refill Order - (Step 2)","Sema/B12 Vial - Step 2":"Semaglutide/B12 Vial Order - (Step 2)","Sema/B6 Vial - Step 2":"Semaglutide/B6 Vial Order - (Step 2)","Sema/Lipo Vial - Step 2":"Semaglutide/Lipo Vial Order - (Step 2)","Sema/NAD+ Vial - Step 2":"Semaglutide/NAD+ Vial Order - (Step 2)","Tirz/B6 Refill - Step 2":"Syringe - Tirzepatide/Pyridoxine Injection Order - (Step 2)","Tirz/B12 Vial - Step 2":"Tirzepatide/Cyano Vial Order - (Step 2)","Tirz/NAD+ Vial - Step 2":"Tirzepatide/NAD+ Vial Order - (Step 2)","Tirz/B6 Vial - Step 2":"Tirzepatide/Pyridoxine Vial Order - (Step 2)"};function Cn(){let e=document.createElement("div");e.className="dropdown",e.id="crm-automation-dropdown";let t=document.createElement("button");t.className="dropdown-btn",t.textContent="Automation",t.addEventListener("click",h=>{h.stopPropagation(),document.querySelectorAll(".dropdown.show").forEach(M=>{M!==e&&M.classList.remove("show")}),e.classList.toggle("show")});let n=document.createElement("div");if(n.className="dropdown-content",n.style.padding="10px",!document.getElementById("automation-dropdown-styles")){let h=document.createElement("style");h.id="automation-dropdown-styles",h.textContent=`
      .nested-dropdown {
        margin-bottom: 8px;
        width: 100%;
        position: relative;
      }
      .nested-dropdown-btn {
        width: 100%;
        text-align: left;
        padding: 8px 12px;
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 3px;
        cursor: pointer;
        font-weight: bold;
        font-size: 13px;
        color: #e6e6e6;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .nested-dropdown-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      .nested-dropdown-btn:after {
        content: "\u25BC";
        font-size: 8px;
        color: #e6e6e6;
      }
      .nested-dropdown-content {
        display: none;
        padding: 5px 0 5px 10px;
        margin-top: 3px !important;
      }
      .nested-dropdown.open .nested-dropdown-content {
        display: block;
      }
      
      /* Button-style options */
      .automation-btn {
        display: block;
        width: 100%;
        padding: 8px 12px;
        margin-bottom: 8px;
        background-color: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 4px;
        text-align: left;
        font-size: 13px;
        color: #e6e6e6;
        cursor: pointer;
        transition: all 0.2s ease;
        font-weight: normal;
      }
      .automation-btn:hover {
        background-color: rgba(255, 255, 255, 0.15);
        border-color: rgba(255, 255, 255, 0.2);
      }
      .automation-btn:active {
        background-color: rgba(255, 255, 255, 0.2);
      }
    `,document.head.appendChild(h)}let o=document.createElement("div");o.className="nested-dropdown";let r=document.createElement("button");r.className="nested-dropdown-btn",r.textContent="Semaglutide (Step 2)";let s=document.createElement("div");s.className="nested-dropdown-content",r.addEventListener("click",h=>{h.stopPropagation(),o.classList.toggle("open")});let i=document.createElement("button");i.className="automation-btn",i.textContent="Sema/B12 Refill - Step 2",i.addEventListener("click",h=>{h.stopPropagation(),F(),setTimeout(()=>{O(_["Sema/B12 Refill - Step 2"])},300)}),s.appendChild(i);let a=document.createElement("button");a.className="automation-btn",a.textContent="Sema/B12 Vial - Step 2",a.addEventListener("click",h=>{h.stopPropagation(),F(),setTimeout(()=>{O(_["Sema/B12 Vial - Step 2"])},300)}),s.appendChild(a);let l=document.createElement("button");l.className="automation-btn",l.textContent="Sema/B6 Vial - Step 2",l.addEventListener("click",h=>{h.stopPropagation(),F(),setTimeout(()=>{O(_["Sema/B6 Vial - Step 2"])},300)}),s.appendChild(l);let p=document.createElement("button");p.className="automation-btn",p.textContent="Sema/Lipo Vial - Step 2",p.addEventListener("click",h=>{h.stopPropagation(),F(),setTimeout(()=>{O(_["Sema/Lipo Vial - Step 2"])},300)}),s.appendChild(p);let f=document.createElement("button");f.className="automation-btn",f.textContent="Sema/NAD+ Vial - Step 2",f.addEventListener("click",h=>{h.stopPropagation(),F(),setTimeout(()=>{O(_["Sema/NAD+ Vial - Step 2"])},300)}),s.appendChild(f),o.appendChild(r),o.appendChild(s),n.appendChild(o);let m=document.createElement("div");m.className="nested-dropdown";let x=document.createElement("button");x.className="nested-dropdown-btn",x.textContent="Tirzepatide (Step 2)";let y=document.createElement("div");y.className="nested-dropdown-content",x.addEventListener("click",h=>{h.stopPropagation(),m.classList.toggle("open")});let A=document.createElement("button");A.className="automation-btn",A.textContent="Tirz/B6 Refill - Step 2",A.addEventListener("click",h=>{h.stopPropagation(),F(),setTimeout(()=>{O(_["Tirz/B6 Refill - Step 2"])},300)}),y.appendChild(A);let I=document.createElement("button");I.className="automation-btn",I.textContent="Tirz/B12 Vial - Step 2",I.addEventListener("click",h=>{h.stopPropagation(),F(),setTimeout(()=>{O(_["Tirz/B12 Vial - Step 2"])},300)}),y.appendChild(I);let T=document.createElement("button");T.className="automation-btn",T.textContent="Tirz/NAD+ Vial - Step 2",T.addEventListener("click",h=>{h.stopPropagation(),F(),setTimeout(()=>{O(_["Tirz/NAD+ Vial - Step 2"])},300)}),y.appendChild(T);let U=document.createElement("button");return U.className="automation-btn",U.textContent="Tirz/B6 Vial - Step 2",U.addEventListener("click",h=>{h.stopPropagation(),F(),setTimeout(()=>{O(_["Tirz/B6 Vial - Step 2"])},300)}),y.appendChild(U),m.appendChild(x),m.appendChild(y),n.appendChild(m),e.appendChild(t),e.appendChild(n),e}function F(){document.querySelectorAll(".dropdown.show").forEach(e=>e.classList.remove("show")),document.querySelectorAll(".nested-dropdown.open").forEach(e=>e.classList.remove("open"))}function O(e){try{console.log(`[CRM Extension] Starting workflow for "${e}"`),u(`Starting workflow for "${e}"`);let t=Array.from(document.querySelectorAll("button.btn.btn-light2.btn-xs")).find(n=>n.textContent.trim().includes("Add"));if(!t){console.error("[CRM Extension] Add Automation button not found"),u("Add Automation button not found");return}console.log("[CRM Extension] Found Add button, clicking it"),t.click(),setTimeout(()=>{let n=document.querySelector('input[placeholder="Type to search"]');if(!n){console.error("[CRM Extension] Search input not found"),u("Search input not found");return}console.log("[CRM Extension] Found search input, entering 'step 2'"),n.focus(),n.value="step 2",n.dispatchEvent(new Event("input",{bubbles:!0})),setTimeout(()=>{let o=[".v-list",".dropdown-menu",".v-select-list",".vs__dropdown-menu",'[role="listbox"]',"ul",".v-menu__content"],r=null;for(let p of o){let f=document.querySelector(p);if(f&&f.querySelector("li, .v-list-item, .dropdown-item")&&f.scrollHeight>f.clientHeight){r=f,console.log(`[CRM Extension] Found scrollable dropdown container: ${p}`);break}}if(!r){let p=document.querySelector('.modal, dialog, [role="dialog"]');if(p){let f=Array.from(p.querySelectorAll("*")).filter(m=>m.scrollHeight>m.clientHeight&&m.clientHeight>50);f.length>0&&(r=f[0],console.log("[CRM Extension] Found scrollable element via fallback method"))}}if(!r){console.error("[CRM Extension] Could not find scrollable container"),u("Could not find dropdown container");return}console.log("[CRM Extension] Starting scroll wheel simulation"),console.log(`[CRM Extension] Container dimensions: ${r.scrollHeight}x${r.clientHeight}`);let s=0,i=20,a=!1;function l(){if(a||s>=i){a||(console.error("[CRM Extension] Max scroll attempts reached without finding match"),u("Option not found after scrolling"));return}s++,console.log(`[CRM Extension] Scroll attempt ${s}/${i}`);let p=new WheelEvent("wheel",{deltaY:100,bubbles:!0});r.dispatchEvent(p),r.scrollTop+=100,console.log(`[CRM Extension] Scrolled to position: ${r.scrollTop}/${r.scrollHeight}`),setTimeout(()=>{let f=r.querySelectorAll('li, .v-list-item, .dropdown-item, [role="option"]');console.log(`[CRM Extension] Found ${f.length} options after scrolling`);for(let m of f){if(!m.textContent)continue;let x=m.textContent.trim();if(x===e&&!x.includes("Provider Paid")&&!x.includes("New Patient")){console.log(`[CRM Extension] Found exact matching option: "${x}"`);try{m.scrollIntoView({block:"center"}),setTimeout(()=>{m.click(),a=!0,setTimeout(()=>{let y=Array.from(document.querySelectorAll("button")).find(A=>A.textContent.trim()==="Add");y?(console.log("[CRM Extension] Clicking Add button in dialog"),y.click(),u(`Added "${e}" workflow`)):(console.error("[CRM Extension] Add button in dialog not found"),u("Add button in dialog not found"))},1e3)},300)}catch(y){console.error("[CRM Extension] Error clicking option:",y)}break}}if(!a){if(r.scrollHeight-r.scrollTop<=r.clientHeight+20){console.log("[CRM Extension] Reached bottom of dropdown without finding match"),u(`Reached end without finding "${e}"`);return}setTimeout(l,500)}},500)}l()},1500)},1e3)}catch(t){console.error("[CRM Extension] Error in workflow:",t),u(`Error in workflow: ${t.message}`)}}function bn(){let e=document.createElement("div");return e.className="group",e.id="crm-dropdowns-group",e.appendChild(Cn()),e.appendChild(yn()),document.addEventListener("click",t=>{document.querySelectorAll(".dropdown").forEach(o=>{o.contains(t.target)||(o.classList.remove("show"),o.querySelectorAll(".nested-dropdown").forEach(s=>{s.classList.remove("open")}))})}),fr(),e}function fr(){if(document.getElementById("custom-dropdown-styles"))return;let e=document.createElement("style");e.id="custom-dropdown-styles",e.textContent=`
    /* Improved dropdown positioning */
    .dropdown {
      position: relative !important;
      margin-right: 8px !important; /* Ensure space between dropdowns, reduced for tighter layout */
    }
    
    .dropdown:last-child {
      margin-right: 0 !important; /* Remove margin from the last dropdown */
    }
    
    .dropdown-content {
      position: absolute !important;
      background-color: #2F3A4B; /* Match toolbar background color */
      min-width: 220px !important; /* Increased width */
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.3);
      z-index: 999;
      border-radius: 4px;
      margin-top: 5px !important; /* Add space between button and dropdown */
      left: 0;
      top: 100% !important; /* Position below the button */
      display: none;
      border: 1px solid rgba(255, 255, 255, 0.1); /* Subtle border */
    }
    
    /* Ensure right-aligned dropdowns don't overflow */
    #crm-tags-dropdown .dropdown-content {
      right: 0;
      left: auto; /* Override left positioning for Tags dropdown */
    }
    
    .dropdown.show .dropdown-content {
      display: block;
    }
    
    /* Improved nested dropdown positioning */
    .nested-dropdown-content {
      margin-top: 3px !important;
      background-color: #2F3A4B; /* Match toolbar background color */
      border-radius: 4px;
      padding: 5px !important;
    }
    
    /* Style dropdown items */
    .dropdown-item {
      color: #e6e6e6; /* White text for visibility */
      padding: 10px 14px !important; /* Increased padding */
      text-decoration: none;
      display: block;
      font-size: 14px;
      cursor: pointer;
      border-radius: 3px;
      font-weight: normal;
    }
    
    .dropdown-item:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
    
    /* Fix for Vial-Sema and Vial-Tirz nested dropdowns */
    .nested-dropdown-btn {
      text-align: left !important;
      padding: 8px 12px !important;
      background-color: rgba(255, 255, 255, 0.1) !important;
      border: 1px solid rgba(255, 255, 255, 0.15) !important;
      color: #e6e6e6 !important;
      font-weight: bold !important;
    }
    
    .nested-dropdown-btn:hover {
      background-color: rgba(255, 255, 255, 0.2) !important;
    }
    
    /* Force visibility for Tags dropdown */
    #crm-tags-dropdown {
      display: flex !important;
    }
    
    #crm-tags-dropdown .dropdown-content {
      min-width: 220px !important;
    }
  `,document.head.appendChild(e)}function En(){let e=document.createElement("div");e.className="group",e.id="crm-settings-group",e.style.position="relative";let t=document.createElement("button");t.className="btn",t.id="crm-settings-btn";let n=document.createElement("span");n.className="btn-icon",n.innerHTML="\u2699\uFE0F",t.appendChild(n);let o=document.createElement("span");o.textContent="Settings",t.appendChild(o);let r=xr();if(t.addEventListener("click",s=>{s.stopPropagation(),r.classList.toggle("show")}),document.addEventListener("click",s=>{s.target!==t&&!t.contains(s.target)&&s.target!==r&&!r.contains(s.target)&&r.classList.remove("show")}),!document.getElementById("settings-dropdown-styles")){let s=document.createElement("style");s.id="settings-dropdown-styles",s.textContent=`
      #mcp-crm-settings-dropdown {
        display: none;
        position: absolute;
        top: calc(100% + 5px); /* Position below the button with 5px gap */
        right: 0;
        z-index: 1000;
        min-width: 230px;
        background-color: #2F3A4B;
        border-radius: 4px;
        border: 1px solid rgba(255, 255, 255, 0.1);
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
        overflow: hidden;
      }
      
      #mcp-crm-settings-dropdown.show {
        display: block;
      }
      
      .settings-header {
        padding: 10px;
        background-color: rgba(255, 255, 255, 0.1);
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        font-weight: bold;
        color: #e6e6e6;
      }
      
      .settings-body {
        padding: 10px;
        color: #e6e6e6;
      }
      
      .setting-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
        font-size: 13px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        padding-bottom: 10px;
      }
      
      .setting-item:last-child {
        margin-bottom: 0;
        border-bottom: none;
        padding-bottom: 0;
      }
      
      .setting-label {
        color: #e6e6e6;
        font-weight: normal;
      }
      
      /* Toggle switch styles */
      .switch {
        position: relative;
        display: inline-block;
        width: 40px;
        height: 20px;
      }
      
      .switch input {
        opacity: 0;
        width: 0;
        height: 0;
      }
      
      .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #555;
        transition: .4s;
        border-radius: 34px;
      }
      
      .slider:before {
        position: absolute;
        content: "";
        height: 16px;
        width: 16px;
        left: 2px;
        bottom: 2px;
        background-color: white;
        transition: .4s;
        border-radius: 50%;
      }
      
      input:checked + .slider {
        background-color: #2196F3;
      }
      
      input:focus + .slider {
        box-shadow: 0 0 1px #2196F3;
      }
      
      input:checked + .slider:before {
        transform: translateX(20px);
      }
      
      /* Version info styles */
      .version-info {
        border-top: 1px solid rgba(255, 255, 255, 0.1);
        margin-top: 10px;
        padding-top: 10px;
        font-size: 12px;
        color: #e6e6e6;
      }
      
      .version-info p {
        margin: 5px 0;
        color: #e6e6e6;
      }
      
      .version-number {
        font-weight: 600;
        color: #e6e6e6;
      }
      
      .check-updates-btn {
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 3px;
        padding: 4px 8px;
        margin-top: 5px;
        font-size: 11px;
        cursor: pointer;
        transition: background-color 0.2s;
        width: 100%;
        text-align: center;
        color: #e6e6e6;
      }
      
      .check-updates-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      
      .check-updates-btn:disabled {
        opacity: 0.6;
        cursor: not-allowed;
      }
      
      #crm-update-status {
        margin: 5px 0 0 0;
        padding: 3px 6px;
        font-size: 11px;
        border-radius: 3px;
        background-color: rgba(255, 255, 255, 0.05);
        text-align: center;
        transition: all 0.3s ease;
        color: #e6e6e6;
      }
      
      #last-update-check {
        font-size: 11px;
        margin: 5px 0;
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        color: #e6e6e6;
      }
      
      .check-status {
        font-size: 10px;
        margin-left: 5px;
        padding: 1px 4px;
        border-radius: 3px;
        font-weight: normal;
      }
      
      .loading-text {
        font-style: italic;
        color: #aaa;
      }
      
      /* Section styles */
      .setting-section {
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      }
      
      .setting-section-title {
        font-size: 12px;
        font-weight: bold;
        color: #e6e6e6;
        margin-bottom: 10px;
      }
    `,document.head.appendChild(s)}return e.appendChild(t),e.appendChild(r),e}function yr(e){try{(typeof browser<"u"?browser:chrome).runtime.sendMessage({action:"getLastUpdateCheck"}).then(n=>{if(n&&n.success&&n.lastUpdateCheck){let o=n.lastUpdateCheck,r="",s="";o.success?o.status==="update_available"?(r="Update available",s="#4CAF50"):o.status==="no_update"?(r="No updates needed",s="#2196F3"):o.status==="throttled"?(r="Check throttled",s="#FF9800"):(r="Completed",s="#2196F3"):(r="Failed",s="#F44336"),e.innerHTML=`Last Check: <span class="version-number">${o.formattedTime}</span> <span class="check-status" style="color:${s};font-size:10px;margin-left:5px;">${r}</span>`}else e.innerHTML='Last Check: <span class="version-number">No checks recorded</span>'}).catch(n=>{console.error("[CRM Extension] Error fetching last update check:",n),e.innerHTML='Last Check: <span class="version-number">Unknown</span>'})}catch(t){console.error("[CRM Extension] Error in fetchLastUpdateCheckInfo:",t),e.innerHTML='Last Check: <span class="version-number">Error</span>'}}function xr(){let e=document.createElement("div");e.id="mcp-crm-settings-dropdown";let t=document.createElement("div");t.className="settings-header",t.textContent="CRM+ Settings",e.appendChild(t);let n=document.createElement("div");if(n.className="settings-body",e.appendChild(n),!document.getElementById("collapsible-settings-styles")){let a=document.createElement("style");a.id="collapsible-settings-styles",a.textContent=`
      .setting-section {
        margin-bottom: 8px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        padding-bottom: 0; /* No bottom padding when collapsed */
      }
      
      .setting-section-title {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 13px;
        font-weight: bold;
        color: #e6e6e6;
        padding: 8px 0;
        cursor: pointer;
        user-select: none;
      }
      
      .setting-section-title:after {
        content: "\u25BC";
        font-size: 8px;
        color: #e6e6e6;
        transition: transform 0.2s ease;
      }
      
      .setting-section.collapsed .setting-section-title:after {
        transform: rotate(-90deg);
      }
      
      .setting-section-content {
        max-height: 500px;
        overflow: hidden;
        transition: max-height 0.3s ease, opacity 0.2s ease, margin-bottom 0.3s ease;
        opacity: 1;
        margin-bottom: 10px;
      }
      
      .setting-section.collapsed .setting-section-content {
        max-height: 0;
        opacity: 0;
        margin-bottom: 0;
      }
    `,document.head.appendChild(a)}let o=it("General Settings");o.content.appendChild(J("Show Header Bar","crmplus_headerBarVisible",a=>{let l=document.getElementById("mcp-crm-header");l&&(l.style.display=a?"flex":"none",document.body.style.paddingTop=a?"32px":"0"),u(`Header bar: ${a?"Visible":"Hidden"}`)},!0)),o.content.appendChild(J("Show Provider-Paid Alerts","crmplus_showProviderPaidAlerts",a=>{u(`Provider-Paid alerts: ${a?"Enabled":"Disabled"}`)},!0)),n.appendChild(o.section);let r=it("External Links");r.content.appendChild(J("Show ShipStation Link","crmplus_showShipStation",a=>{let l=document.querySelector(".shipstation-link");l&&(l.style.display=a?"flex":"none"),u(`ShipStation link: ${a?"Visible":"Hidden"}`)},!0)),r.content.appendChild(J("Show Stripe Link","crmplus_showStripe",a=>{let l=document.querySelector(".stripe-link");l&&(l.style.display=a?"flex":"none"),u(`Stripe link: ${a?"Visible":"Hidden"}`)},!0)),r.content.appendChild(J("Show Webmail Link","crmplus_showWebmail",a=>{let l=document.querySelector(".webmail-link");l&&(l.style.display=a?"flex":"none"),u(`Webmail link: ${a?"Visible":"Hidden"}`)},!0)),n.appendChild(r.section);let s=it("Features");s.content.appendChild(J("Auto-copy phone number on page load","crmplus_autoCopyPhone",a=>{u(`Auto-copy phone: ${a?"Enabled":"Disabled"}`)},!1)),s.content.appendChild(J("CRM Automation","crmplus_automationEnabled",a=>{[document.getElementById("crm-automation-dropdown"),document.getElementById("crm-tags-dropdown")].forEach(p=>{p?(p.style.display=a?"flex":"none",console.log(`[CRM Extension] Changed visibility for ${p.id}: ${a?"visible":"hidden"}`)):console.error("[CRM Extension] Could not find automation element to toggle")}),u(`CRM Automation: ${a?"Enabled":"Disabled"}`)},!0)),n.appendChild(s.section);let i=Cr();return n.appendChild(i),e}function it(e,t=!1){let n=document.createElement("div");n.className="setting-section"+(t?" collapsed":"");let o=document.createElement("div");o.className="setting-section-title",o.textContent=e,o.addEventListener("click",()=>{n.classList.toggle("collapsed")}),n.appendChild(o);let r=document.createElement("div");return r.className="setting-section-content",n.appendChild(r),{section:n,content:r}}function Cr(){let e=document.createElement("div");e.className="version-info";let t="Loading...",n="Loading...";try{let l=(typeof browser<"u"?browser:chrome).runtime.getManifest();if(l&&l.version&&(t=l.version,t.includes("."))){let p=t.split(".");if(p.length===3&&p[0].length===4){let f=p[0],m=p[1],x=p[2];n=`${m}/${x}/${f}`}}}catch(a){console.error("[CRM Extension] Error fetching version:",a),t="Unknown",n="Unknown"}let o=document.createElement("p");o.innerHTML=`Version: <span class="version-number">${t}</span>`,e.appendChild(o);let r=document.createElement("p");r.innerHTML=`Last Updated: <span class="version-number">${n}</span>`,e.appendChild(r);let s=document.createElement("p");s.id="last-update-check",s.innerHTML='Last Check: <span class="loading-text">Loading...</span>',e.appendChild(s),yr(s);let i=document.createElement("button");return i.className="check-updates-btn",i.textContent="Check for Updates",i.addEventListener("click",()=>{let a=typeof browser<"u"?browser:chrome;i.disabled=!0,i.textContent="Checking...",u("Checking for updates...");let l=document.getElementById("crm-update-status");l||(l=document.createElement("p"),l.id="crm-update-status",l.style.fontSize="11px",l.style.marginTop="5px",l.style.color="#e6e6e6",l.textContent="",e.appendChild(l)),a.runtime.sendMessage({action:"checkForUpdates"}).then(p=>{if(p&&p.success){u("Update check completed"),p.updateStatus==="update_available"?(l.textContent=`Update available (${p.updateVersion})`,l.style.color="#4CAF50"):p.updateStatus==="no_update"?(l.textContent="You have the latest version",l.style.color="#2196F3"):p.updateStatus==="throttled"?(l.textContent="Update check throttled, try again later",l.style.color="#FF9800"):p.updateStatus==="error"?(l.textContent="Error checking for updates",l.style.color="#F44336"):(l.textContent="Update check initiated",l.style.color="#e6e6e6");let f=document.getElementById("last-update-check");if(f&&p.lastCheck){let m=p.lastCheck,x="",y="";m.success?m.status==="update_available"?(x="Update available",y="#4CAF50"):m.status==="no_update"?(x="No updates needed",y="#2196F3"):m.status==="throttled"?(x="Check throttled",y="#FF9800"):(x="Completed",y="#2196F3"):(x="Failed",y="#F44336"),f.innerHTML=`Last Check: <span class="version-number">${m.formattedTime}</span> <span class="check-status" style="color:${y};font-size:10px;margin-left:5px;">${x}</span>`}}else u("Error checking for updates"),l.textContent="Update check failed",l.style.color="#F44336";i.disabled=!1,i.textContent="Check for Updates"}).catch(p=>{console.error("[CRM Extension] Error sending update check message:",p),u("Error checking for updates"),l.textContent="Connection failed",l.style.color="#F44336",i.disabled=!1,i.textContent="Check for Updates"})}),e.appendChild(i),e}function J(e,t,n,o=!1){let r=document.createElement("div");r.className="setting-item";let s=document.createElement("div");s.className="setting-label",s.textContent=e,r.appendChild(s);let i=document.createElement("label");i.className="switch";let a=document.createElement("input");a.type="checkbox";let l=localStorage.getItem(t),p=l!==null?l==="true":o;l===null&&localStorage.setItem(t,o.toString()),a.checked=p,a.addEventListener("change",()=>{let m=a.checked;localStorage.setItem(t,m.toString()),n&&typeof n=="function"&&n(m)});let f=document.createElement("span");return f.className="slider",i.appendChild(a),i.appendChild(f),r.appendChild(i),r}function wn(){if(document.getElementById("mcp-crm-header-styles"))return;let e=document.createElement("style");e.id="mcp-crm-header-styles",e.textContent=`
    #mcp-crm-header {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 32px;
      background-color: #2F3A4B;
      display: flex;
      align-items: center;
      padding: 0 15px;
      font-family: 'Segoe UI', 'Roboto', sans-serif;
      font-size: 12px;
      z-index: 999999;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    }
    
    #mcp-crm-header .group {
      display: flex;
      align-items: center;
      margin-right: 15px;
      border-right: 1px solid rgba(255, 255, 255, 0.1);
      padding-right: 15px;
    }
    
    #mcp-crm-header .group:last-child {
      border-right: none;
      margin-right: 0; /* Remove margin from the last group (Settings) */
    }
    
    /* Special styling for dropdowns group to match other elements' spacing */
    #crm-dropdowns-group {
      margin-right: 15px; /* Same spacing as other elements */
      padding-right: 15px; /* Same padding as other elements */
    }
    
    /* Ensure settings is positioned at the far right */
    #crm-settings-btn {
      margin-right: 0;
    }
    
    #mcp-crm-header .spacer {
      flex-grow: 1;
    }
    
    #mcp-crm-header .label {
      color: #8a9cad;
      margin-right: 6px;
      font-weight: 500;
    }
    
    #mcp-crm-header .value {
      color: #e6e6e6;
      font-weight: 600;
    }
    
    #mcp-crm-header .clickable-value {
      color: #e6e6e6;
      font-weight: 600;
      cursor: pointer;
      background-color: rgba(255, 255, 255, 0.05);
      padding: 2px 8px;
      border-radius: 3px;
      transition: background-color 0.2s;
      display: inline-flex;
      align-items: center;
    }
    
    #mcp-crm-header .clickable-value:hover {
      background-color: rgba(255, 255, 255, 0.15);
    }
    
    #mcp-crm-header .btn-icon {
      margin-right: 4px;
      font-size: 10px;
    }
    
    /* Logo link styling */
    #mcp-crm-header .logo-link {
      display: flex;
      align-items: center;
      text-decoration: none;
      transition: all 0.2s ease;
    }
    
    #mcp-crm-header .logo-link:hover {
      opacity: 0.85;
    }
    
    #mcp-crm-header .logo-icon {
      width: 16px;
      height: 16px;
      margin-right: 6px;
    }
    
    #mcp-crm-header .logo {
      font-weight: bold;
      color: white;
      font-size: 14px;
    }
    
    #mcp-crm-header .external-link {
      text-decoration: none;
      color: #e6e6e6;
      display: flex;
      align-items: center;
      transition: all 0.2s ease;
      margin-right: 10px;
    }
    
    #mcp-crm-header .external-link:hover {
      background: rgba(255, 255, 255, 0.2);
      transform: translateY(-1px);
    }
    
    #mcp-crm-header .ext-link-icon {
      font-size: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    /* Styling for text links with icons */
    #mcp-crm-header .text-link {
      text-decoration: none;
      margin-right: 4px; /* Reduced margin between buttons */
      font-size: 12px;
      padding: 3px 6px; /* Reduced horizontal padding to make buttons skinnier */
      border-radius: 3px;
      color: #e6e6e6;
      display: flex;
      align-items: center;
      justify-content: center; /* Center content horizontally */
      white-space: nowrap; /* Prevent text wrapping */
      min-width: 68px; /* Set minimum width to keep consistency */
    }
    
    #mcp-crm-header .text-link:hover {
      background-color: rgba(255, 255, 255, 0.15);
    }
    
    #mcp-crm-header .text-link .link-icon {
      margin-right: 4px; /* Slightly reduced margin for tighter look */
      width: 16px;
      height: 16px;
      vertical-align: middle;
      flex-shrink: 0; /* Prevent icon from shrinking */
    }
    
    /* Add a specific class for each button to fine-tune widths if needed */
    #mcp-crm-header .shipstation-link {
      min-width: 92px;
    }
    
    #mcp-crm-header .stripe-link {
      min-width: 65px;
    }
    
    #mcp-crm-header .webmail-link {
      min-width: 78px;
    }
    
    #mcp-crm-header .btn {
      color: #e6e6e6;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 3px;
      padding: 4px 8px;
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      margin-right: 8px;
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
    }
    
    #mcp-crm-header .btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    #mcp-crm-header .btn:active {
      background-color: rgba(255, 255, 255, 0.3);
    }
    
    #mcp-crm-header .btn:last-child {
      margin-right: 0;
    }
    
    /* Dropdown styling */
    .dropdown {
      position: relative;
      display: inline-block;
      margin-right: 8px;
    }
    
    .dropdown-btn {
      color: #e6e6e6;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 3px;
      padding: 4px 8px;
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
      justify-content: space-between;
      min-width: 100px;
    }
    
    .dropdown-btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .dropdown-btn:after {
      content: "\u25BC";
      font-size: 8px;
      margin-left: 5px;
    }
    
    .dropdown-content {
      display: none;
      position: absolute;
      background-color: #2F3A4B;
      min-width: 180px;
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.3);
      z-index: 1000000;
      border-radius: 4px;
      border: 1px solid rgba(255, 255, 255, 0.1);
      margin-top: 2px;
      left: 0;
    }
    
    .dropdown.show .dropdown-content {
      display: block;
    }
    
    .dropdown-item {
      color: #e6e6e6;
      padding: 8px 12px;
      text-decoration: none;
      display: block;
      font-size: 12px;
      cursor: pointer;
      font-weight: normal;
    }
    
    .dropdown-item:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
    
    /* Nested Dropdown styling */
    .nested-dropdown {
      margin-bottom: 5px;
      width: 100%;
    }
    
    .nested-dropdown-btn {
      width: 100%;
      text-align: left;
      padding: 6px 10px;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 3px;
      cursor: pointer;
      font-weight: bold;
      font-size: 12px;
      color: #e6e6e6;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .nested-dropdown-btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .nested-dropdown-btn:after {
      content: "\u25BC";
      font-size: 8px;
      color: #e6e6e6;
    }
    
    .nested-dropdown-content {
      display: none;
      padding: 5px 0 5px 10px;
      background-color: #2F3A4B;
    }
    
    .nested-dropdown.open .nested-dropdown-content {
      display: block;
    }
    
    .nested-dropdown-item {
      display: block;
      padding: 5px 10px;
      color: #e6e6e6;
      text-decoration: none;
      font-size: 12px;
      cursor: pointer;
      border-radius: 3px;
      font-weight: normal;
    }
    
    .nested-dropdown-item:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
    
    /* Settings dropdown styling */
    #mcp-crm-settings-dropdown {
      position: absolute;
      top: 32px;
      right: 15px;
      background-color: #2F3A4B;
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 4px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.3);
      min-width: 200px;
      z-index: 1000000;
      display: none;
      color: #e6e6e6;
    }
    
    #mcp-crm-settings-dropdown.show {
      display: block;
    }
    
    #mcp-crm-settings-dropdown .settings-header {
      background-color: rgba(255, 255, 255, 0.1);
      color: #e6e6e6;
      padding: 8px 12px;
      font-weight: bold;
      border-top-left-radius: 3px;
      border-top-right-radius: 3px;
    }
    
    #mcp-crm-settings-dropdown .settings-body {
      padding: 10px;
    }
    
    #mcp-crm-settings-dropdown .setting-item {
      display: flex;
      align-items: center;
      margin-bottom: 8px;
      padding-bottom: 8px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    #mcp-crm-settings-dropdown .setting-item:last-child {
      margin-bottom: 0;
      padding-bottom: 0;
      border-bottom: none;
    }
    
    #mcp-crm-settings-dropdown .setting-label {
      flex-grow: 1;
      font-size: 13px;
      color: #e6e6e6;
    }
    
    /* Toggle switch styling */
    .switch {
      position: relative;
      display: inline-block;
      width: 40px;
      height: 20px;
    }
    
    .switch input { 
      opacity: 0;
      width: 0;
      height: 0;
    }
    
    .slider {
      position: absolute;
      cursor: pointer;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: #555;
      transition: .4s;
      border-radius: 34px;
    }
    
    .slider:before {
      position: absolute;
      content: "";
      height: 16px;
      width: 16px;
      left: 2px;
      bottom: 2px;
      background-color: white;
      transition: .4s;
      border-radius: 50%;
    }
    
    input:checked + .slider {
      background-color: #2196F3;
    }
    
    input:checked + .slider:before {
      transform: translateX(20px);
    }
    
    /* Version info section in settings */
    .version-info {
      border-top: 1px solid rgba(255, 255, 255, 0.1);
      margin-top: 10px;
      padding-top: 10px;
      font-size: 12px;
      color: #e6e6e6;
    }
    
    .version-info p {
      margin: 5px 0;
    }
    
    .version-number {
      font-weight: 600;
      color: #e6e6e6;
    }
    
    .check-updates-btn {
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 3px;
      padding: 4px 8px;
      margin-top: 5px;
      font-size: 11px;
      cursor: pointer;
      transition: background-color 0.2s;
      width: 100%;
      text-align: center;
      color: #e6e6e6;
    }
    
    .check-updates-btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .check-updates-btn:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
  `,document.head.appendChild(e)}function vn(){let e=document.createElement("div");e.className="dropdown",e.id="crm-history-dropdown";let t=document.createElement("button");t.className="dropdown-btn",t.textContent="History",t.addEventListener("click",a=>{a.stopPropagation(),document.querySelectorAll(".dropdown.show").forEach(l=>{l!==e&&l.classList.remove("show")}),e.classList.toggle("show"),e.classList.contains("show")&&Sn(e)});let n=document.createElement("div");if(n.className="dropdown-content",n.id="crm-history-content",n.style.width="300px",n.style.maxHeight="400px",n.style.overflowY="auto",n.style.right="0",n.style.left="auto",!document.getElementById("history-dropdown-styles")){let a=document.createElement("style");a.id="history-dropdown-styles",a.textContent=`
      #crm-history-dropdown .dropdown-content {
        padding: 0;
        right: 0;
        left: auto;
      }
      
      /* For small screens, make sure the dropdown doesn't extend beyond viewport */
      @media screen and (max-width: 768px) {
        #crm-history-dropdown .dropdown-content {
          right: 0;
          left: auto;
          max-width: 100vw;
          width: 280px; /* Slightly smaller on small screens */
        }
      }
      
      .history-header {
        padding: 10px;
        background-color: rgba(255, 255, 255, 0.1);
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      
      .history-title {
        font-weight: bold;
        color: #e6e6e6;
        font-size: 14px;
      }
      
      .history-clear-btn {
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 3px;
        padding: 2px 6px;
        font-size: 11px;
        cursor: pointer;
        color: #e6e6e6;
        transition: background-color 0.2s;
      }
      
      .history-clear-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      
      .history-empty {
        padding: 20px;
        text-align: center;
        color: #aaa;
        font-style: italic;
        font-size: 13px;
      }
      
      .history-item {
        padding: 10px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        cursor: pointer;
        transition: background-color 0.2s;
      }
      
      .history-item:hover {
        background-color: rgba(255, 255, 255, 0.1);
      }
      
      .history-item:last-child {
        border-bottom: none;
      }
      
      .history-item-row {
        display: flex;
        margin-bottom: 3px;
        width: 100%;
      }
      
      .history-item-time {
        color: #aaa;
        font-size: 11px;
        width: 60px;
        flex-shrink: 0;
        margin-right: 5px;
      }
      
      .history-item-name {
        font-weight: bold;
        color: #e6e6e6;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        flex-grow: 1;
      }
      
      .history-item-phone {
        color: #ccc;
        font-size: 12px;
        margin-left: 65px; /* Align with name (time width + margin) */
      }
    `,document.head.appendChild(a)}let o=document.createElement("div");o.className="history-header";let r=document.createElement("div");r.className="history-title",r.textContent="Recent Patients",o.appendChild(r);let s=document.createElement("button");s.className="history-clear-btn",s.textContent="Clear All",s.addEventListener("click",a=>{a.stopPropagation(),zt(),Sn(e),u("History cleared")}),o.appendChild(s),n.appendChild(o);let i=document.createElement("div");return i.className="history-empty",i.textContent="No patient history yet",n.appendChild(i),e.appendChild(t),e.appendChild(n),e}function Sn(e){let t=e.querySelector("#crm-history-content");if(!t)return;let n=Dt(),o=t.querySelector(".history-header");if(t.innerHTML="",o&&t.appendChild(o),n.length===0){let r=document.createElement("div");r.className="history-empty",r.textContent="No patient history yet",t.appendChild(r);return}n.forEach(r=>{let s=document.createElement("div");s.className="history-item",s.addEventListener("click",()=>{window.location.href=r.url,e.classList.remove("show")});let i=document.createElement("div");i.className="history-item-row";let a=document.createElement("div");a.className="history-item-time",a.textContent=_t(r.timestamp);let l=document.createElement("div");if(l.className="history-item-name",l.textContent=r.patientName||"Unknown Patient",i.appendChild(a),i.appendChild(l),s.appendChild(i),r.phoneNumber){let p=document.createElement("div");p.className="history-item-phone",p.textContent=r.phoneNumber,s.appendChild(p)}t.appendChild(s)})}var br=!1;function lt(){try{if(document.getElementById("mcp-crm-header")){console.log("[uiHeaderBar] Toolbar already exists.");return}wn();let e=document.createElement("div");e.id="mcp-crm-header";let t=localStorage.getItem("crmplus_headerBarVisible")!=="false";console.log("[CRM Extension] Header visibility setting:",t),e.style.display=t?"flex":"none";let n=typeof browser<"u"?browser:chrome,o=k=>n.runtime.getURL(k),r=document.createElement("div");r.className="group";let s=document.createElement("a");s.href="https://app.mtncarerx.com/",s.className="logo-link";let i=document.createElement("img");i.src=o("assets/mcp-favicon.ico"),i.alt="",i.className="logo-icon",s.appendChild(i);let a=document.createElement("span");a.className="logo",a.textContent="CRM+",s.appendChild(a),r.appendChild(s);let l=document.createElement("div");l.className="group external-links";let p=at("ShipStation","https://ship15.shipstation.com/onboard","shipstation-link",o("assets/shipstation-favicon.ico"));l.appendChild(p);let f=at("Stripe","https://dashboard.stripe.com/login","stripe-link",o("assets/stripe-favicon.ico"));l.appendChild(f);let m=at("Webmail","https://p3plzcpnl506102.prod.phx3.secureserver.net:2096/cpsess5640910985/webmail/jupiter/index.html?login=1&post_login=89371011642013","webmail-link",o("assets/webmail-favicon.ico"));l.appendChild(m);let x=ce("name","Name"),y=ce("phone","Phone",{icon:"\u{1F4DE}",initialValue:"",onClick:async k=>{xt(k)}}),A=ce("dob","DOB"),I=ce("srxid","SRx ID"),T=fn(),U=bn(),h=document.createElement("div");h.className="spacer";let M=document.createElement("div");M.className="group right-buttons",M.style.borderRight="none",M.style.display="flex",M.style.marginRight="0";let W=gn();W.style.marginRight="8px";let R=vn();M.appendChild(W),M.appendChild(R);let K=En();e.appendChild(r),e.appendChild(l),e.appendChild(x),e.appendChild(y),e.appendChild(A),e.appendChild(I),e.appendChild(U),e.appendChild(T),e.appendChild(h),e.appendChild(M),e.appendChild(K),document.body.appendChild(e),document.body.style.paddingTop=t?"32px":"0",setTimeout(()=>{try{let k=localStorage.getItem("crmplus_automationEnabled")==="true";[document.getElementById("crm-automation-dropdown"),document.getElementById("crm-tags-dropdown")].forEach($=>{$&&($.style.display=k?"flex":"none",console.log(`[CRM Extension] Initial visibility for ${$.id}: ${k?"visible":"hidden"}`))})}catch(k){console.error("[CRM Extension] Error setting initial automation visibility:",k)}},100),V(),bt(),St(),yt(),kt(),Pt(),initChatSystem(),hn(),mn(k=>{if(k.length>0){let B=k[0];u(`New message from ${B.sender}: ${B.text.substring(0,30)}${B.text.length>30?"...":""}`,3e3)}}),window.addEventListener("popstate",function(){console.log("[CRM Extension] Navigation detected, clearing phone display"),V()}),Er()||V(),br=!0,console.log("[CRM Extension] Header successfully initialized")}catch(e){console.error("[CRM Extension] Critical error creating toolbar:",e);try{let t=document.getElementById("mcp-crm-header");t&&(t.style.display="flex")}catch(t){console.error("[CRM Extension] Failed to recover toolbar:",t)}}}function at(e,t,n="",o=""){let r=document.createElement("a");r.href=t,r.target="_blank",r.className=`text-link btn ${n}`,r.rel="noopener noreferrer";let s=document.createElement("div");if(s.style.display="flex",s.style.alignItems="center",s.style.justifyContent="center",s.style.width="100%",o){let a=document.createElement("img");a.src=o,a.alt="",a.className="link-icon",a.style.width="16px",a.style.height="16px",a.style.marginRight="4px",s.appendChild(a)}let i=document.createElement("span");return i.textContent=e,s.appendChild(i),r.appendChild(s),r}function Er(){let e=window.location.href;return[/\/patient\/\d+/i,/\/contact\/\d+/i,/\/profile\/\d+/i,/[?&]patient_id=\d+/i,/[?&]contact_id=\d+/i].some(o=>o.test(e))?!0:['input[name="contact.phone"]','input[name="contact.first_name"]','input[name="contact.last_name"]','input[name="contact.date_of_birth"]',".patient-info",".contact-details",".patient-header",".patient-profile"].some(o=>document.querySelector(o)!==null)}function ct(e){try{let t=document.getElementById("mcp-crm-header");if(t){console.log(`[CRM Extension] Setting header visibility to: ${e}`),t.style.display=e?"flex":"none";let n=document.body.classList.contains("has-alert");return e?(document.body.style.paddingTop=n?"72px":"32px",document.body.classList.remove("no-header")):(document.body.style.paddingTop=n?"40px":"0",document.body.classList.add("no-header")),localStorage.setItem("crmplus_headerBarVisible",e.toString()),!0}else if(e)return console.log("[CRM Extension] Header not found but should be visible, creating it"),lt(),!0;return!1}catch(t){return console.error("[CRM Extension] Error toggling header visibility:",t),!1}}function Mn(){if(!(localStorage.getItem("crmplus_autoCopyPhone")==="true")){console.log("[CRM Extension] Auto-copy phone is disabled");return}let t=()=>{let o=ve();if(o){let r=He(o);r&&te(r).then(s=>{if(s)return u("Phone number auto-copied: "+r),!0})}return!1};if(t())return;let n=new MutationObserver((o,r)=>{t()&&r.disconnect()});n.observe(document.body,{childList:!0,subtree:!0,attributes:!0,characterData:!0}),setTimeout(()=>{n.disconnect(),t()},5e3)}var kn=!1,de=new Set,_e="",pt=!1,Fe=null,dt=null;function An(){kn||(wr(),Sr(),kn=!0,console.log("[CRM Extension] Alert system initialized"))}function wr(){if(document.getElementById("crm-alert-styles"))return;let e=document.createElement("style");e.id="crm-alert-styles",e.textContent=`
    .crm-alert-banner {
      position: fixed;
      top: 32px; /* Positioned right below the header bar */
      left: 0;
      right: 0;
      width: 100%;
      padding: 4px 15px; /* Reduced vertical padding for smaller height */
      font-size: 13px;
      font-weight: 500;
      z-index: 999990;
      display: flex;
      align-items: center;
      justify-content: center; /* Center contents horizontally */
      transition: all 0.3s ease;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
      transform: translateY(-100%);
      opacity: 0;
      height: 25px; /* Fixed height at 3/4 of original (approx) */
    }
    
    .crm-alert-banner.show {
      transform: translateY(0);
      opacity: 1;
    }
    
    .crm-alert-banner .alert-icon {
      margin-right: 8px;
      font-size: 16px;
    }
    
    .crm-alert-banner .alert-message {
      text-align: center; /* Center the text */
      margin: 0 auto; /* Center with auto margins */
      flex-grow: 0; /* Don't grow to fill space */
    }
    
    /* Provider Paid specific alert styling */
    .crm-alert-banner.provider-paid {
      background-color: #FFAB40; /* Orange */
      color: #5F4200;
      border-bottom: 1px solid #FF9100;
    }
    
    /* Adjust body padding to accommodate the alert banner */
    body.has-alert {
      padding-top: 72px !important; /* 32px (header) + approx alert height */
    }
    
    /* When header is hidden but alert is visible */
    body.no-header.has-alert {
      padding-top: 25px !important; /* Just the alert height */
    }
    
    /* Multiple alerts stacking */
    .crm-alert-banner.second-alert {
      top: 57px;
    }
    
    .crm-alert-banner.third-alert {
      top: 82px;
    }
    
    /* Countdown timer styling */
    .countdown-timer {
      margin-left: 5px;
      font-size: 11px;
      opacity: 0.75;
      background-color: rgba(0, 0, 0, 0.1);
      padding: 1px 4px;
      border-radius: 3px;
      min-width: 30px;
      text-align: center;
    }
  `,document.head.appendChild(e)}function Ln(){let e=window.location.href,t=[/\/patient\/(\d+)/i,/\/contact\/(\d+)/i,/\/profile\/(\d+)/i,/[?&]patient_id=(\d+)/i,/[?&]contact_id=(\d+)/i];for(let n of t){let o=e.match(n);if(o&&o[1])return o[1]}return""}function Sr(){_e=Ln(),Oe(),Fe&&Fe.disconnect(),Fe=new MutationObserver(e=>{for(let t of e)t.type==="childList"&&Oe(),t.type==="attributes"&&(t.target.classList.contains("tag")||t.target.classList.contains("tag-label")||t.target.classList.contains("provider-paid"))&&Oe()}),Fe.observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["class","data-tag"]}),dt&&clearInterval(dt),dt=setInterval(()=>{let e=Ln();e!==_e&&(console.log("[CRM Extension] Navigation detected, patient changed from",_e,"to",e),_e=e,pt=!1,$e("provider-paid"),setTimeout(Oe,1e3))},1e3)}function Oe(){if(!(localStorage.getItem("crmplus_showProviderPaidAlerts")!=="false")){$e("provider-paid");return}vr()?pt||Mr():$e("provider-paid")}function vr(){let e=document.querySelectorAll(".tag, .tag-label, .pill, .badge");for(let r of e)if(r.textContent.toLowerCase().includes("provider-paid"))return r;let t=document.querySelectorAll(".provider-paid");if(t.length>0)return t[0];let n=document.querySelectorAll('[data-tag="provider-paid"], [data-tag-name="provider-paid"]');if(n.length>0)return n[0];let o=document.querySelectorAll(".tags-container, .tag-list, .tags");for(let r of o)if(r.textContent.toLowerCase().includes("provider-paid"))return r;return null}function Mr(){if(de.has("provider-paid"))return;pt=!0;let e=document.createElement("div");e.className="crm-alert-banner provider-paid",e.id="provider-paid-alert",e.setAttribute("data-alert-type","provider-paid");let t=document.createElement("span");t.className="alert-icon",t.innerHTML="\u26A0\uFE0F",e.appendChild(t);let n=document.createElement("span");n.className="alert-message",n.textContent="This patient has Provider Paid status. Special billing rules apply.";let o=document.createElement("span");o.className="countdown-timer",o.textContent="30",n.appendChild(o),e.appendChild(n),document.body.appendChild(e),kr(e),setTimeout(()=>{e.classList.add("show"),document.body.classList.add("has-alert")},10),de.add("provider-paid");let r=document.getElementById("mcp-crm-header");r&&r.style.display==="none"?document.body.classList.add("no-header"):document.body.classList.remove("no-header"),console.log("[CRM Extension] Provider Paid alert shown");let s=15,i=setInterval(()=>{s--,o&&(o.textContent=s),s<=0&&(clearInterval(i),$e("provider-paid"))},1e3)}function kr(e){let t=de.size;t===1?e.classList.add("second-alert"):t===2&&e.classList.add("third-alert")}function $e(e){let t=document.querySelector(`.crm-alert-banner[data-alert-type="${e}"]`);t&&(t.classList.remove("show"),de.delete(e),setTimeout(()=>{t.parentNode&&t.parentNode.removeChild(t),de.size===0&&document.body.classList.remove("has-alert"),Lr()},300))}function Lr(){document.querySelectorAll(".crm-alert-banner").forEach((t,n)=>{t.classList.remove("second-alert","third-alert"),n===1?t.classList.add("second-alert"):n===2&&t.classList.add("third-alert")})}console.log("[CRM Extension] Content script injected.");var pe=typeof browser<"u"?browser:chrome;pe.runtime.sendMessage({action:"loadSettings"}).then(e=>{e&&e.success&&(console.log("[CRM Extension] Settings loaded from browser storage on startup:",e.settings),document.getElementById("mcp-crm-header")||Y())}).catch(e=>{console.error("[CRM Extension] Error requesting settings on startup:",e)});localStorage.getItem("crmplus_headerBarVisible")===null?(console.log("[CRM Extension] No local toolbar visibility setting, requesting from browser storage"),pe.runtime.sendMessage({action:"loadSettings"}).then(e=>{e&&e.success?(console.log("[CRM Extension] Settings loaded from browser storage:",e.settings),Y()):(console.error("[CRM Extension] Failed to load settings, using defaults"),localStorage.setItem("crmplus_headerBarVisible","true"),Y())}).catch(e=>{console.error("[CRM Extension] Error requesting settings:",e),localStorage.setItem("crmplus_headerBarVisible","true"),Y()})):(console.log("[CRM Extension] Using existing localStorage settings"),Y());function Y(){let e=localStorage.getItem("crmplus_headerBarVisible")!=="false";console.log("[CRM Extension] Header visibility setting on init:",e);try{console.log("[CRM Extension] Creating fixed header..."),lt(),ct(e)}catch(t){console.error("[CRM Extension] Error creating fixed header:",t)}try{ht(t=>{console.log(`[CRM Extension] Intercepted console message: ${t}`)})}catch(t){console.error("[CRM Extension] Error initializing console monitor:",t)}try{Mn()}catch(t){console.error("[CRM Extension] Error initializing auto phone copy:",t)}try{An()}catch(t){console.error("[CRM Extension] Error initializing alert system:",t)}try{Lt()}catch(t){console.error("[CRM Extension] Error initializing tag removal system:",t)}try{Rt()}catch(t){console.error("[CRM Extension] Error initializing automation removal system:",t)}V()}pe.runtime.onMessage.addListener((e,t,n)=>{if(console.log("[CRM Extension] Received message:",e),e.action==="toggleHeaderVisibility"){console.log("[CRM Extension] Toggling header visibility to:",e.isVisible);try{let o=ct(e.isVisible);localStorage.setItem("crmplus_headerBarVisible",e.isVisible.toString()),pe.runtime.sendMessage({action:"syncSettings"}).catch(r=>console.error("[CRM Extension] Error syncing settings:",r)),n({success:o})}catch(o){console.error("[CRM Extension] Error toggling header visibility:",o),n({success:!1,error:o.message})}return!0}return!1});document.addEventListener("DOMContentLoaded",()=>{console.log("[CRM Extension] DOM fully loaded, checking visibility setting"),document.getElementById("mcp-crm-header")||pe.runtime.sendMessage({action:"loadSettings"}).then(e=>{e&&e.success&&Y()}).catch(()=>{localStorage.setItem("crmplus_headerBarVisible","true"),Y()})});})();
