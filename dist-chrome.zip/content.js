(()=>{function j(e){if(window.__crmConsoleMonitor)return;window.__crmConsoleMonitor=!0;let t=console.log,o=console.error,n=console.warn;console.log=function(...r){t.apply(console,r),!(typeof r[0]=="string"&&r[0].includes("[CRM Extension]"))&&F(r,"log",e)},console.error=function(...r){o.apply(console,r),!(typeof r[0]=="string"&&r[0].includes("[CRM Extension]"))&&F(r,"error",e)},console.warn=function(...r){n.apply(console,r),!(typeof r[0]=="string"&&r[0].includes("[CRM Extension]"))&&F(r,"warn",e)}}function F(e,t,o){let n=e.join(" ");["error","failed","unauthorized","critical"].some(i=>n.toLowerCase().includes(i))&&o(n)}var J=window.location.href,N="";function z(){if(!W())return"";let e=document.querySelector('input[name="contact.phone"]');if(e&&e.value.trim()!=="")return e.value.trim();let t=document.querySelector(".phone-number .number");if(t&&t.textContent.trim()!=="")return t.textContent.trim();let o=['input[placeholder="Phone"]','input[placeholder="Phone Number"]',".patient-info .phone",".contact-info .phone","span.phone",'label[for*="phone"]',".phone-display",'div[data-field="phone"]','span[data-field="phone_number"]'];for(let n of o){let r=document.querySelector(n);if(r)if(r.tagName==="INPUT"){let i=r.value.trim();if(i)return i}else if(r.tagName==="LABEL"){let i=r.getAttribute("for");if(i){let p=document.getElementById(i);if(p&&p.value.trim())return p.value.trim()}let l=r.parentElement?.querySelector("input");if(l&&l.value.trim())return l.value.trim()}else{let i=r.textContent.trim();if(i)return i}}return""}function W(){let e=window.location.href;return[/\/patient\/\d+/i,/\/contact\/\d+/i,/\/profile\/\d+/i,/[?&]patient_id=\d+/i,/[?&]contact_id=\d+/i].some(n=>n.test(e))?!0:['input[name="contact.phone"]','input[name="contact.first_name"]','input[name="contact.last_name"]','input[name="contact.date_of_birth"]',".patient-info",".contact-details",".patient-header",".patient-profile"].some(n=>document.querySelector(n)!==null)}function Y(e){try{let t=e?fe(e):"";if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("phone",t);else{let o=document.getElementById("phone-text");if(o){o.textContent=t;let n=document.getElementById("phone-display");n&&(e?n.setAttribute("data-value",e):n.removeAttribute("data-value"))}}}catch(t){console.error("[CRM Extension] Error updating phone display:",t)}}function C(){N="",Y("");try{let e=document.getElementById("phone-display");e&&e.removeAttribute("data-value")}catch(e){console.error("[CRM Extension] Error clearing phone display:",e)}}function fe(e){if(!e)return"";let t=e.replace(/\D/g,"");if(t.length===0)return"";if(t.length===10)return`(${t.substring(0,3)}) ${t.substring(3,6)}-${t.substring(6)}`;if(t.length===11&&t.startsWith("1"))return`(${t.substring(1,4)}) ${t.substring(4,7)}-${t.substring(7)}`;if(t.length>4){let o="";for(let n=0;n<t.length;n+=3)if(n+4>=t.length&&t.length%3!==0){o+=" "+t.substring(n);break}else o+=" "+t.substring(n,n+3);return o.trim()}return t.replace(/(\d{3})/g,"$1 ").trim()}function B(){try{if(!W())return N&&C(),!1;let e=z();return e?(e!==N&&(N=e,Y(e)),!0):(N&&C(),!1)}catch(e){return console.error("[CRM Extension] Error detecting phone number:",e),!1}}function K(){C(),B();let e=setInterval(()=>{let t=window.location.href;t!==J&&(console.log("[CRM Extension] URL changed, resetting phone detection"),J=t,C()),B()},200);try{let t=new MutationObserver(n=>{B()}),o=document.body;t.observe(o,{childList:!0,subtree:!0,characterData:!0,attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] Phone number mutation observer active")}catch(t){console.error("[CRM Extension] Error setting up phone mutation observer:",t)}}function X(e){let t=z();if(!t){d("No phone number found");return}let o=O(t);if(!o){d("Invalid phone number format");return}e.setAttribute("data-value",t),I(o).then(n=>{d(n?"Copied: "+o:"Failed to copy phone number")})}function O(e){if(!e)return"";let t=e.replace(/\D/g,"");return t.length<7?"":"+1"+t}async function I(e){if(navigator.clipboard&&navigator.clipboard.writeText)try{return await navigator.clipboard.writeText(e),!0}catch(t){console.warn("Clipboard API failed, trying fallback method:",t)}try{let t=document.createElement("textarea");t.value=e,t.style.position="fixed",t.style.top="0",t.style.left="0",t.style.opacity="0",t.style.pointerEvents="none",document.body.appendChild(t),t.focus(),t.select();let o=document.execCommand("copy");return document.body.removeChild(t),o}catch(t){return console.error("All clipboard methods failed:",t),!1}}function d(e,t=2e3){let o=document.getElementById("crm-plus-toast-container");o||(o=document.createElement("div"),o.id="crm-plus-toast-container",o.style.position="fixed",o.style.bottom="20px",o.style.right="20px",o.style.zIndex="100000",document.body.appendChild(o));let n=document.createElement("div");n.textContent=e,n.style.background="#333",n.style.color="#fff",n.style.padding="10px",n.style.borderRadius="5px",n.style.marginTop="10px",n.style.boxShadow="0 2px 5px rgba(0,0,0,0.2)",n.style.transition="opacity 0.5s, transform 0.5s",n.style.opacity="0",n.style.transform="translateY(20px)",o.appendChild(n),n.offsetWidth,n.style.opacity="1",n.style.transform="translateY(0)",setTimeout(()=>{n.style.opacity="0",n.style.transform="translateY(20px)",setTimeout(()=>{n.parentNode&&n.parentNode.removeChild(n),o.childNodes.length===0&&document.body.removeChild(o)},500)},t)}var Q=window.location.href;function A(e){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("name",e);else{let t=document.getElementById("name-text");if(t){t.textContent=e;let o=document.getElementById("name-display");o&&o.setAttribute("data-value",e)}}}catch(t){console.error("[CRM Extension] Error updating name display:",t)}}function P(){try{let e=document.querySelector('input[name="contact.first_name"]'),t=document.querySelector('input[name="contact.last_name"]');if(e&&e.value&&t&&t.value){let r=`${e.value} ${t.value}`;return A(r),!0}let o=document.querySelectorAll(".patient-name, .contact-name, h1.name, .customer-name");for(let r of o)if(r&&r.textContent&&r.textContent.trim()!==""){let i=r.textContent.trim();return A(i),!0}let n=["span.name",".profile-name","h2.name",".contact-header .name",'div[data-field="name"]',".patient-info .name"];for(let r of n){let i=document.querySelector(r);if(i&&i.textContent&&i.textContent.trim()!==""){let l=i.textContent.trim();return A(l),!0}}return!1}catch(e){return console.error("[CRM Extension] Error detecting name:",e),!1}}function Z(){P();let e=setInterval(()=>{let t=window.location.href;t!==Q&&(console.log("[CRM Extension] URL changed, resetting name detection"),Q=t,A(""),P());let o=document.getElementById("name-text");o&&(o.textContent==="Loading..."||!o.textContent)&&P()},1e3);try{let t=new MutationObserver(n=>{n.some(i=>i.addedNodes.length>5||i.removedNodes.length>5)&&(console.log("[CRM Extension] Significant DOM changes detected, rechecking name"),A(""),P())}),o=document.querySelector("main")||document.body;t.observe(o,{childList:!0,subtree:!0})}catch(t){console.error("[CRM Extension] Error setting up navigation observer for name:",t)}}var ee=window.location.href;function $(e){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("dob",e);else{let t=document.getElementById("dob-text");if(t){t.textContent=e;let o=document.getElementById("dob-display");o&&o.setAttribute("data-value",e)}}}catch(t){console.error("[CRM Extension] Error updating DOB display:",t)}}function te(e){if(!e)return"";if(e.match(/^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2}(st|nd|rd|th)?\s+\d{4}$/))try{let t=e.match(/(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+(\d{1,2})(st|nd|rd|th)?\s+(\d{4})/);if(t){let o=t[1],n=t[2],r=t[4];return`${(["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"].indexOf(o)+1).toString().padStart(2,"0")}/${n.toString().padStart(2,"0")}/${r}`}}catch(t){console.error("[CRM Extension] Error parsing date:",t)}try{let t=new Date(e);if(!isNaN(t.getTime()))return`${(t.getMonth()+1).toString().padStart(2,"0")}/${t.getDate().toString().padStart(2,"0")}/${t.getFullYear()}`}catch(t){console.error("[CRM Extension] Error parsing date as Date object:",t)}return e}function V(){try{let e=document.querySelector('input[name="contact.date_of_birth"]');if(e&&e.value){let o=te(e.value);return $(o),!0}let t=[".dob",".patient-dob",".contact-dob",'span[data-field="date_of_birth"]','div[data-field="dob"]',".patient-info .dob",".contact-info .dob"];for(let o of t){let n=document.querySelector(o);if(n&&n.textContent&&n.textContent.trim()!==""){let r=te(n.textContent.trim());return $(r),!0}}return!1}catch(e){return console.error("[CRM Extension] Error detecting DOB:",e),!1}}function oe(){V();let e=setInterval(()=>{let t=window.location.href;t!==ee&&(console.log("[CRM Extension] URL changed, resetting DOB detection"),ee=t,$(""),V());let o=document.getElementById("dob-text");o&&(o.textContent==="Loading..."||!o.textContent)&&V()},1e3);try{let t=new MutationObserver(n=>{n.some(i=>i.addedNodes.length>5||i.removedNodes.length>5)&&(console.log("[CRM Extension] Significant DOM changes detected, rechecking DOB"),$(""),V())}),o=document.querySelector("main")||document.body;t.observe(o,{childList:!0,subtree:!0})}catch(t){console.error("[CRM Extension] Error setting up navigation observer for DOB:",t)}}var ne=window.location.href,_="";function re(e){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("srxid",e);else{let t=document.getElementById("srxid-text");if(t){t.textContent=e;let o=document.getElementById("srxid-display");o&&o.setAttribute("data-value",e)}}}catch(t){console.error("[CRM Extension] Error updating SRx ID display:",t)}}function L(){try{let e=document.querySelector('input[name="contact.srx_id"]');if(e&&e.value){let t=e.value.trim();if(t&&/^\d+$/.test(t))return t!==_&&(console.log("[CRM Extension] Found SRx ID from contact.srx_id input:",t),_=t,re(t)),!0}return!!_}catch(e){return console.error("[CRM Extension] Error detecting SRx ID:",e),!1}}function ie(){L();let e=setInterval(()=>{let t=window.location.href;t!==ne&&(console.log("[CRM Extension] URL changed, resetting SRx ID detection"),ne=t,_="",re(""),L()),L()},500);try{new MutationObserver(o=>{let n=!1;for(let r of o){if(r.target.tagName==="INPUT"&&r.target.name==="contact.srx_id"||r.target.querySelector&&r.target.querySelector('input[name="contact.srx_id"]')){n=!0;break}if(r.addedNodes.length>0){for(let i of r.addedNodes)if(i.nodeType===1&&i.querySelector&&(i.tagName==="INPUT"&&i.name==="contact.srx_id"||i.querySelector('input[name="contact.srx_id"]'))){n=!0;break}}}n&&L()}).observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] SRx ID mutation observer active")}catch(t){console.error("[CRM Extension] Error setting up observer for SRx ID:",t)}setTimeout(()=>{try{let t=document.querySelector('input[name="contact.srx_id"]');t&&(new MutationObserver(n=>{L()}).observe(t,{attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] Direct input observer attached to contact.srx_id"))}catch(t){console.error("[CRM Extension] Error setting up direct input observer:",t)}},1e3)}function T(e,t,o={}){let n=document.createElement("div");n.className="group";let r=document.createElement("span");r.className="label",r.textContent=`${t}:`,n.appendChild(r);let i=document.createElement("span");if(i.id=`${e}-display`,i.className="clickable-value",o.initialValue&&i.setAttribute("data-value",o.initialValue),o.icon){let s=document.createElement("span");s.className="btn-icon",s.innerHTML=o.icon,i.appendChild(s)}let l=document.createElement("span");l.textContent=o.initialValue||"",l.id=`${e}-text`,i.appendChild(l);let p=async()=>{let s=i.getAttribute("data-value")||l.textContent.trim();s&&s!==""?await I(s)?d(`Copied ${t}: ${s}`):d(`Failed to copy ${t.toLowerCase()}`):d(`No ${t.toLowerCase()} available to copy`)};return i.addEventListener("click",()=>{o.onClick?o.onClick(i):p()}),i.title=`Click to copy ${t.toLowerCase()} to clipboard`,n.appendChild(i),n}function ae(){let e=document.createElement("div");return e.className="group",e.id="crm-actions-group",e}function se(){let e=document.createElement("div");e.className="dropdown",e.id="crm-tags-dropdown";let t=document.createElement("button");t.className="dropdown-btn",t.textContent="Tags",t.addEventListener("click",a=>{a.stopPropagation(),document.querySelectorAll(".dropdown.show").forEach(R=>{R!==e&&R.classList.remove("show")}),e.classList.toggle("show")});let o=document.createElement("div");if(o.className="dropdown-content",o.style.padding="10px",!document.getElementById("tags-dropdown-styles")){let a=document.createElement("style");a.id="tags-dropdown-styles",a.textContent=`
      .nested-dropdown {
        margin-bottom: 8px;
        width: 100%;
        position: relative;
      }
      .nested-dropdown-btn {
        width: 100%;
        text-align: left;
        padding: 8px 12px;
        background-color: #f1f1f1;
        border: 1px solid #ddd;
        border-radius: 3px;
        cursor: pointer;
        font-weight: bold;
        font-size: 13px;
        color: #333;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .nested-dropdown-btn:hover {
        background-color: #e1e1e1;
      }
      .nested-dropdown-btn:after {
        content: "\u25BC";
        font-size: 8px;
      }
      .nested-dropdown-content {
        display: none;
        padding: 5px 0 5px 10px;
        margin-top: 3px !important;
      }
      .nested-dropdown.open .nested-dropdown-content {
        display: block;
      }
      
      /* Button-style tag options */
      .tag-btn {
        display: block;
        width: 100%;
        padding: 8px 12px;
        margin-bottom: 8px;
        background-color: #f8f9fa;
        border: 1px solid #dee2e6;
        border-radius: 4px;
        text-align: left;
        font-size: 13px;
        color: #0d6efd;
        cursor: pointer;
        transition: all 0.2s ease;
      }
      .tag-btn:hover {
        background-color: #f1f8ff;
        border-color: #0d6efd;
      }
      .tag-btn:active {
        background-color: #e2e6ea;
      }
    `,document.head.appendChild(a)}let n=document.createElement("button");n.className="tag-btn",n.textContent="Refill-Sema-Inj",n.addEventListener("click",()=>{w("refill-sema-inj"),e.classList.remove("show")}),o.appendChild(n);let r=document.createElement("button");r.className="tag-btn",r.textContent="Refill-Tirz-Inj",r.addEventListener("click",()=>{w("refill-tirz-inj"),e.classList.remove("show")}),o.appendChild(r);let i=document.createElement("div");i.className="nested-dropdown";let l=document.createElement("button");l.className="nested-dropdown-btn",l.textContent="Vial-Sema";let p=document.createElement("div");p.className="nested-dropdown-content",l.addEventListener("click",a=>{a.stopPropagation(),i.classList.toggle("open")});let s=document.createElement("button");s.className="tag-btn",s.textContent="Vial-Sema-B12",s.addEventListener("click",a=>{a.stopPropagation(),S(),setTimeout(()=>{w("vial-sema-b12")},300)}),p.appendChild(s);let c=document.createElement("button");c.className="tag-btn",c.textContent="Vial-Sema-B6",c.addEventListener("click",a=>{a.stopPropagation(),S(),setTimeout(()=>{w("vial-sema-b6")},300)}),p.appendChild(c);let m=document.createElement("button");m.className="tag-btn",m.textContent="Vial-Sema-Lipo",m.addEventListener("click",a=>{a.stopPropagation(),S(),setTimeout(()=>{w("vial-sema-lipo")},300)}),p.appendChild(m);let u=document.createElement("button");u.className="tag-btn",u.textContent="Vial-Sema-NAD+",u.addEventListener("click",a=>{a.stopPropagation(),S(),setTimeout(()=>{w("vial-sema-nad+")},300)}),p.appendChild(u),i.appendChild(l),i.appendChild(p),o.appendChild(i);let f=document.createElement("div");f.className="nested-dropdown";let g=document.createElement("button");g.className="nested-dropdown-btn",g.textContent="Vial-Tirz";let h=document.createElement("div");h.className="nested-dropdown-content",g.addEventListener("click",a=>{a.stopPropagation(),f.classList.toggle("open")});let x=document.createElement("button");x.className="tag-btn",x.textContent="Vial-Tirz-Cyano",x.addEventListener("click",a=>{a.stopPropagation(),S(),setTimeout(()=>{w("vial-tirz-cyano")},300)}),h.appendChild(x);let b=document.createElement("button");b.className="tag-btn",b.textContent="Vial-Tirz-NAD+",b.addEventListener("click",a=>{a.stopPropagation(),S(),setTimeout(()=>{w("vial-tirz-nad+")},300)}),h.appendChild(b);let y=document.createElement("button");return y.className="tag-btn",y.textContent="Vial-Tirz-Pyr",y.addEventListener("click",a=>{a.stopPropagation(),S(),setTimeout(()=>{w("vial-tirz-pyridoxine")},300)}),h.appendChild(y),f.appendChild(g),f.appendChild(h),o.appendChild(f),e.appendChild(t),e.appendChild(o),e}function S(){document.querySelectorAll(".dropdown.show").forEach(e=>e.classList.remove("show")),document.querySelectorAll(".nested-dropdown.open").forEach(e=>e.classList.remove("open"))}function w(e){let t=ge();t?(t.focus(),setTimeout(()=>{t.value=e,t.dispatchEvent(new Event("input",{bubbles:!0})),setTimeout(()=>{let o=document.querySelectorAll(".v-list-item, .dropdown-item, .select-option, li"),n=!1;for(let r of o)if(r.textContent.toLowerCase().includes(e)){r.click(),n=!0,d(`Selected tag: ${e}`);break}if(!n){let r=document.querySelectorAll("*");for(let i of r)if(i.textContent.trim().toLowerCase()===e){i.click(),n=!0,d(`Selected tag: ${e}`);break}n||t.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",code:"Enter",keyCode:13,which:13,bubbles:!0}))}},300)},300)):d("Tags field not found")}function ge(){let e=document.querySelector('input[placeholder="Add Tags"]');if(e)return e;let t=Array.from(document.querySelectorAll("input[placeholder]")).filter(i=>i.placeholder.toLowerCase().includes("tag"));if(t.length>0)return t[0];let o=document.querySelectorAll(".tag-input, .tags-input, .tag-container");for(let i of o){let l=i.querySelector("input");if(l)return l}if(e=document.querySelector('input[placeholder="smartList.bulkTags.addTags"]'),e)return e;let n=document.querySelectorAll(".hl-text-input");if(n.length>0)return n[0];console.error("[CRM Extension] Could not find tag input field with any strategy");let r=document.querySelectorAll("input");return console.log("[CRM Extension] All inputs on page:",r),null}var E={"Sema/B12 Refill - Step 2":"Refill - Semaglutide/B12 Injection Refill Order - (Step 2)","Sema/B12 Vial - Step 2":"Semaglutide/B12 Vial Order - (Step 2)","Sema/B6 Vial - Step 2":"Semaglutide/B6 Vial Order - (Step 2)","Sema/Lipo Vial - Step 2":"Semaglutide/Lipo Vial Order - (Step 2)","Sema/NAD+ Vial - Step 2":"Semaglutide/NAD+ Vial Order - (Step 2)","Tirz/B6 Refill - Step 2":"Syringe - Tirzepatide/Pyridoxine Injection Order - (Step 2)","Tirz/B12 Vial - Step 2":"Tirzepatide/Cyano Vial Order - (Step 2)","Tirz/NAD+ Vial - Step 2":"Tirzepatide/NAD+ Vial Order - (Step 2)","Tirz/B6 Vial - Step 2":"Tirzepatide/Pyridoxine Vial Order - (Step 2)"};function le(){let e=document.createElement("div");e.className="dropdown",e.id="crm-automation-dropdown";let t=document.createElement("button");t.className="dropdown-btn",t.textContent="Automation",t.addEventListener("click",a=>{a.stopPropagation(),document.querySelectorAll(".dropdown.show").forEach(R=>{R!==e&&R.classList.remove("show")}),e.classList.toggle("show")});let o=document.createElement("div");if(o.className="dropdown-content",o.style.padding="10px",!document.getElementById("automation-dropdown-styles")){let a=document.createElement("style");a.id="automation-dropdown-styles",a.textContent=`
      .nested-dropdown {
        margin-bottom: 8px;
        width: 100%;
        position: relative;
      }
      .nested-dropdown-btn {
        width: 100%;
        text-align: left;
        padding: 8px 12px;
        background-color: #f1f1f1;
        border: 1px solid #ddd;
        border-radius: 3px;
        cursor: pointer;
        font-weight: bold;
        font-size: 13px;
        color: #333;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .nested-dropdown-btn:hover {
        background-color: #e1e1e1;
      }
      .nested-dropdown-btn:after {
        content: "\u25BC";
        font-size: 8px;
      }
      .nested-dropdown-content {
        display: none;
        padding: 5px 0 5px 10px;
        margin-top: 3px !important;
      }
      .nested-dropdown.open .nested-dropdown-content {
        display: block;
      }
      
      /* Button-style options */
      .automation-btn {
        display: block;
        width: 100%;
        padding: 8px 12px;
        margin-bottom: 8px;
        background-color: #f8f9fa;
        border: 1px solid #dee2e6;
        border-radius: 4px;
        text-align: left;
        font-size: 13px;
        color: #0d6efd;
        cursor: pointer;
        transition: all 0.2s ease;
      }
      .automation-btn:hover {
        background-color: #f1f8ff;
        border-color: #0d6efd;
      }
      .automation-btn:active {
        background-color: #e2e6ea;
      }
    `,document.head.appendChild(a)}let n=document.createElement("div");n.className="nested-dropdown";let r=document.createElement("button");r.className="nested-dropdown-btn",r.textContent="Sema";let i=document.createElement("div");i.className="nested-dropdown-content",r.addEventListener("click",a=>{a.stopPropagation(),n.classList.toggle("open")});let l=document.createElement("button");l.className="automation-btn",l.textContent="Sema/B12 Refill - Step 2",l.addEventListener("click",a=>{a.stopPropagation(),v(),setTimeout(()=>{k(E["Sema/B12 Refill - Step 2"])},300)}),i.appendChild(l);let p=document.createElement("button");p.className="automation-btn",p.textContent="Sema/B12 Vial - Step 2",p.addEventListener("click",a=>{a.stopPropagation(),v(),setTimeout(()=>{k(E["Sema/B12 Vial - Step 2"])},300)}),i.appendChild(p);let s=document.createElement("button");s.className="automation-btn",s.textContent="Sema/B6 Vial - Step 2",s.addEventListener("click",a=>{a.stopPropagation(),v(),setTimeout(()=>{k(E["Sema/B6 Vial - Step 2"])},300)}),i.appendChild(s);let c=document.createElement("button");c.className="automation-btn",c.textContent="Sema/Lipo Vial - Step 2",c.addEventListener("click",a=>{a.stopPropagation(),v(),setTimeout(()=>{k(E["Sema/Lipo Vial - Step 2"])},300)}),i.appendChild(c);let m=document.createElement("button");m.className="automation-btn",m.textContent="Sema/NAD+ Vial - Step 2",m.addEventListener("click",a=>{a.stopPropagation(),v(),setTimeout(()=>{k(E["Sema/NAD+ Vial - Step 2"])},300)}),i.appendChild(m),n.appendChild(r),n.appendChild(i),o.appendChild(n);let u=document.createElement("div");u.className="nested-dropdown";let f=document.createElement("button");f.className="nested-dropdown-btn",f.textContent="Tirz";let g=document.createElement("div");g.className="nested-dropdown-content",f.addEventListener("click",a=>{a.stopPropagation(),u.classList.toggle("open")});let h=document.createElement("button");h.className="automation-btn",h.textContent="Tirz/B6 Refill - Step 2",h.addEventListener("click",a=>{a.stopPropagation(),v(),setTimeout(()=>{k(E["Tirz/B6 Refill - Step 2"])},300)}),g.appendChild(h);let x=document.createElement("button");x.className="automation-btn",x.textContent="Tirz/B12 Vial - Step 2",x.addEventListener("click",a=>{a.stopPropagation(),v(),setTimeout(()=>{k(E["Tirz/B12 Vial - Step 2"])},300)}),g.appendChild(x);let b=document.createElement("button");b.className="automation-btn",b.textContent="Tirz/NAD+ Vial - Step 2",b.addEventListener("click",a=>{a.stopPropagation(),v(),setTimeout(()=>{k(E["Tirz/NAD+ Vial - Step 2"])},300)}),g.appendChild(b);let y=document.createElement("button");return y.className="automation-btn",y.textContent="Tirz/B6 Vial - Step 2",y.addEventListener("click",a=>{a.stopPropagation(),v(),setTimeout(()=>{k(E["Tirz/B6 Vial - Step 2"])},300)}),g.appendChild(y),u.appendChild(f),u.appendChild(g),o.appendChild(u),e.appendChild(t),e.appendChild(o),e}function v(){document.querySelectorAll(".dropdown.show").forEach(e=>e.classList.remove("show")),document.querySelectorAll(".nested-dropdown.open").forEach(e=>e.classList.remove("open"))}function k(e){try{console.log(`[CRM Extension] Starting workflow for "${e}"`),d(`Starting workflow for "${e}"`);let t=Array.from(document.querySelectorAll("button.btn.btn-light2.btn-xs")).find(o=>o.textContent.trim().includes("Add"));if(!t){console.error("[CRM Extension] Add Automation button not found"),d("Add Automation button not found");return}console.log("[CRM Extension] Found Add button, clicking it"),t.click(),setTimeout(()=>{let o=document.querySelector('input[placeholder="Type to search"]');if(!o){console.error("[CRM Extension] Search input not found"),d("Search input not found");return}console.log("[CRM Extension] Found search input, entering 'step 2'"),o.focus(),o.value="step 2",o.dispatchEvent(new Event("input",{bubbles:!0})),setTimeout(()=>{let n=[".v-list",".dropdown-menu",".v-select-list",".vs__dropdown-menu",'[role="listbox"]',"ul",".v-menu__content"],r=null;for(let c of n){let m=document.querySelector(c);if(m&&m.querySelector("li, .v-list-item, .dropdown-item")&&m.scrollHeight>m.clientHeight){r=m,console.log(`[CRM Extension] Found scrollable dropdown container: ${c}`);break}}if(!r){let c=document.querySelector('.modal, dialog, [role="dialog"]');if(c){let m=Array.from(c.querySelectorAll("*")).filter(u=>u.scrollHeight>u.clientHeight&&u.clientHeight>50);m.length>0&&(r=m[0],console.log("[CRM Extension] Found scrollable element via fallback method"))}}if(!r){console.error("[CRM Extension] Could not find scrollable container"),d("Could not find dropdown container");return}console.log("[CRM Extension] Starting scroll wheel simulation"),console.log(`[CRM Extension] Container dimensions: ${r.scrollHeight}x${r.clientHeight}`);let i=0,l=20,p=!1;function s(){if(p||i>=l){p||(console.error("[CRM Extension] Max scroll attempts reached without finding match"),d("Option not found after scrolling"));return}i++,console.log(`[CRM Extension] Scroll attempt ${i}/${l}`);let c=new WheelEvent("wheel",{deltaY:100,bubbles:!0});r.dispatchEvent(c),r.scrollTop+=100,console.log(`[CRM Extension] Scrolled to position: ${r.scrollTop}/${r.scrollHeight}`),setTimeout(()=>{let m=r.querySelectorAll('li, .v-list-item, .dropdown-item, [role="option"]');console.log(`[CRM Extension] Found ${m.length} options after scrolling`);for(let u of m){if(!u.textContent)continue;let f=u.textContent.trim();if(f===e&&!f.includes("Provider Paid")&&!f.includes("New Patient")){console.log(`[CRM Extension] Found exact matching option: "${f}"`);try{u.scrollIntoView({block:"center"}),setTimeout(()=>{u.click(),p=!0,setTimeout(()=>{let g=Array.from(document.querySelectorAll("button")).find(h=>h.textContent.trim()==="Add");g?(console.log("[CRM Extension] Clicking Add button in dialog"),g.click(),d(`Added "${e}" workflow`)):(console.error("[CRM Extension] Add button in dialog not found"),d("Add button in dialog not found"))},1e3)},300)}catch(g){console.error("[CRM Extension] Error clicking option:",g)}break}}if(!p){if(r.scrollHeight-r.scrollTop<=r.clientHeight+20){console.log("[CRM Extension] Reached bottom of dropdown without finding match"),d(`Reached end without finding "${e}"`);return}setTimeout(s,500)}},500)}s()},1500)},1e3)}catch(t){console.error("[CRM Extension] Error in workflow:",t),d(`Error in workflow: ${t.message}`)}}function ce(){let e=document.createElement("div");return e.className="group",e.id="crm-dropdowns-group",e.appendChild(le()),e.appendChild(se()),document.addEventListener("click",t=>{document.querySelectorAll(".dropdown").forEach(n=>{n.contains(t.target)||(n.classList.remove("show"),n.querySelectorAll(".nested-dropdown").forEach(i=>{i.classList.remove("open")}))})}),he(),e}function he(){if(document.getElementById("custom-dropdown-styles"))return;let e=document.createElement("style");e.id="custom-dropdown-styles",e.textContent=`
    /* Improved dropdown positioning */
    .dropdown {
      position: relative !important;
    }
    
    .dropdown-content {
      position: absolute !important;
      background-color: #f9f9f9;
      min-width: 220px !important; /* Increased width */
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
      z-index: 999;
      border-radius: 4px;
      margin-top: 5px !important; /* Add space between button and dropdown */
      left: 0;
      top: 100% !important; /* Position below the button */
      display: none;
    }
    
    .dropdown.show .dropdown-content {
      display: block;
    }
    
    /* Improved nested dropdown positioning */
    .nested-dropdown-content {
      margin-top: 3px !important;
    }
    
    /* Style dropdown items */
    .dropdown-item {
      color: #333;
      padding: 10px 14px !important; /* Increased padding */
      text-decoration: none;
      display: block;
      font-size: 14px;
      cursor: pointer;
      border-radius: 3px;
    }
    
    .dropdown-item:hover {
      background-color: #f1f1f1;
    }
    
    /* Fix for Vial-Sema and Vial-Tirz nested dropdowns */
    .nested-dropdown-btn {
      text-align: left !important;
      padding: 8px 12px !important;
    }
    
    /* Force visibility for Tags dropdown */
    #crm-tags-dropdown {
      display: flex !important;
    }
    
    #crm-tags-dropdown .dropdown-content {
      min-width: 220px !important;
    }
  `,document.head.appendChild(e)}function pe(){let e=document.createElement("div");e.className="group",e.style.position="relative";let t=document.createElement("button");t.className="btn",t.id="crm-settings-btn";let o=document.createElement("span");o.className="btn-icon",o.innerHTML="\u2699\uFE0F",t.appendChild(o);let n=document.createElement("span");n.textContent="Settings",t.appendChild(n);let r=xe();if(t.addEventListener("click",i=>{i.stopPropagation(),r.classList.toggle("show")}),document.addEventListener("click",i=>{i.target!==t&&!t.contains(i.target)&&i.target!==r&&!r.contains(i.target)&&r.classList.remove("show")}),!document.getElementById("settings-dropdown-styles")){let i=document.createElement("style");i.id="settings-dropdown-styles",i.textContent=`
      #mcp-crm-settings-dropdown {
        display: none;
        position: absolute;
        top: calc(100% + 5px); /* Position below the button with 5px gap */
        right: 0;
        z-index: 1000;
        min-width: 230px;
        background-color: #fff;
        border-radius: 4px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
        overflow: hidden;
      }
      
      #mcp-crm-settings-dropdown.show {
        display: block;
      }
      
      .settings-header {
        padding: 10px;
        background-color: #f5f5f5;
        border-bottom: 1px solid #ddd;
        font-weight: bold;
        color: #333;
      }
      
      .settings-body {
        padding: 10px;
      }
      
      .setting-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
        font-size: 13px;
      }
      
      .setting-item:last-child {
        margin-bottom: 0;
      }
      
      /* Toggle switch styles */
      .switch {
        position: relative;
        display: inline-block;
        width: 40px;
        height: 20px;
      }
      
      .switch input {
        opacity: 0;
        width: 0;
        height: 0;
      }
      
      .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        transition: .4s;
        border-radius: 34px;
      }
      
      .slider:before {
        position: absolute;
        content: "";
        height: 16px;
        width: 16px;
        left: 2px;
        bottom: 2px;
        background-color: white;
        transition: .4s;
        border-radius: 50%;
      }
      
      input:checked + .slider {
        background-color: #2196F3;
      }
      
      input:focus + .slider {
        box-shadow: 0 0 1px #2196F3;
      }
      
      input:checked + .slider:before {
        transform: translateX(20px);
      }
      
      /* Version info styles */
      .version-info {
        border-top: 1px solid #eee;
        margin-top: 10px;
        padding-top: 10px;
        font-size: 12px;
        color: #777;
      }
      
      .version-info p {
        margin: 5px 0;
      }
      
      .version-number {
        font-weight: 600;
        color: #333;
      }
      
      .check-updates-btn {
        background-color: #f1f1f1;
        border: 1px solid #ddd;
        border-radius: 3px;
        padding: 4px 8px;
        margin-top: 5px;
        font-size: 11px;
        cursor: pointer;
        transition: background-color 0.2s;
        width: 100%;
        text-align: center;
      }
      
      .check-updates-btn:hover {
        background-color: #e1e1e1;
      }
      
      .check-updates-btn:disabled {
        opacity: 0.6;
        cursor: not-allowed;
      }
      
      #crm-update-status {
        margin: 5px 0 0 0;
        padding: 3px 6px;
        font-size: 11px;
        border-radius: 3px;
        background-color: #f9f9f9;
        text-align: center;
        transition: all 0.3s ease;
      }
      
      #last-update-check {
        font-size: 11px;
        margin: 5px 0;
        display: flex;
        align-items: center;
        flex-wrap: wrap;
      }
      
      .check-status {
        font-size: 10px;
        margin-left: 5px;
        padding: 1px 4px;
        border-radius: 3px;
        font-weight: normal;
      }
      
      .loading-text {
        font-style: italic;
        color: #999;
      }
    `,document.head.appendChild(i)}return e.appendChild(t),e.appendChild(r),e}function be(e){try{(typeof browser<"u"?browser:chrome).runtime.sendMessage({action:"getLastUpdateCheck"}).then(o=>{if(o&&o.success&&o.lastUpdateCheck){let n=o.lastUpdateCheck,r="",i="";n.success?n.status==="update_available"?(r="Update available",i="#4CAF50"):n.status==="no_update"?(r="No updates needed",i="#2196F3"):n.status==="throttled"?(r="Check throttled",i="#FF9800"):(r="Completed",i="#2196F3"):(r="Failed",i="#F44336"),e.innerHTML=`Last Check: <span class="version-number">${n.formattedTime}</span> <span class="check-status" style="color:${i};font-size:10px;margin-left:5px;">${r}</span>`}else e.innerHTML='Last Check: <span class="version-number">No checks recorded</span>'}).catch(o=>{console.error("[CRM Extension] Error fetching last update check:",o),e.innerHTML='Last Check: <span class="version-number">Unknown</span>'})}catch(t){console.error("[CRM Extension] Error in fetchLastUpdateCheckInfo:",t),e.innerHTML='Last Check: <span class="version-number">Error</span>'}}function xe(){let e=document.createElement("div");e.id="mcp-crm-settings-dropdown";let t=document.createElement("div");t.className="settings-header",t.textContent="CRM+ Settings",e.appendChild(t);let o=document.createElement("div");o.className="settings-body",e.appendChild(o),o.appendChild(de("Auto-copy phone number on page load","crmplus_autoCopyPhone",r=>{d(`Auto-copy phone: ${r?"Enabled":"Disabled"}`)})),o.appendChild(de("CRM Automation","crmplus_automationEnabled",r=>{[document.getElementById("crm-automation-dropdown"),document.getElementById("crm-tags-dropdown")].forEach(l=>{l?(l.style.display=r?"flex":"none",console.log(`[CRM Extension] Changed visibility for ${l.id}: ${r?"visible":"hidden"}`)):console.error("[CRM Extension] Could not find automation element to toggle")}),d(`CRM Automation: ${r?"Enabled":"Disabled"}`)}));let n=ye();return o.appendChild(n),e}function ye(){let e=document.createElement("div");e.className="version-info";let t="Loading...",o="Loading...";try{let s=(typeof browser<"u"?browser:chrome).runtime.getManifest();if(s&&s.version&&(t=s.version,t.includes("."))){let c=t.split(".");if(c.length===3&&c[0].length===4){let m=c[0],u=c[1],f=c[2];o=`${u}/${f}/${m}`}}}catch(p){console.error("[CRM Extension] Error fetching version:",p),t="Unknown",o="Unknown"}let n=document.createElement("p");n.innerHTML=`Version: <span class="version-number">${t}</span>`,e.appendChild(n);let r=document.createElement("p");r.innerHTML=`Last Updated: <span class="version-number">${o}</span>`,e.appendChild(r);let i=document.createElement("p");i.id="last-update-check",i.innerHTML='Last Check: <span class="loading-text">Loading...</span>',e.appendChild(i),be(i);let l=document.createElement("button");return l.className="check-updates-btn",l.textContent="Check for Updates",l.addEventListener("click",()=>{let p=typeof browser<"u"?browser:chrome;l.disabled=!0,l.textContent="Checking...",d("Checking for updates...");let s=document.getElementById("crm-update-status");s||(s=document.createElement("p"),s.id="crm-update-status",s.style.fontSize="11px",s.style.marginTop="5px",s.style.color="#666",s.textContent="",e.appendChild(s)),p.runtime.sendMessage({action:"checkForUpdates"}).then(c=>{if(c&&c.success){d("Update check completed"),c.updateStatus==="update_available"?(s.textContent=`Update available (${c.updateVersion})`,s.style.color="#4CAF50"):c.updateStatus==="no_update"?(s.textContent="You have the latest version",s.style.color="#2196F3"):c.updateStatus==="throttled"?(s.textContent="Update check throttled, try again later",s.style.color="#FF9800"):c.updateStatus==="error"?(s.textContent="Error checking for updates",s.style.color="#F44336"):(s.textContent="Update check initiated",s.style.color="#666");let m=document.getElementById("last-update-check");if(m&&c.lastCheck){let u=c.lastCheck,f="",g="";u.success?u.status==="update_available"?(f="Update available",g="#4CAF50"):u.status==="no_update"?(f="No updates needed",g="#2196F3"):u.status==="throttled"?(f="Check throttled",g="#FF9800"):(f="Completed",g="#2196F3"):(f="Failed",g="#F44336"),m.innerHTML=`Last Check: <span class="version-number">${u.formattedTime}</span> <span class="check-status" style="color:${g};font-size:10px;margin-left:5px;">${f}</span>`}}else d("Error checking for updates"),s.textContent="Update check failed",s.style.color="#F44336";l.disabled=!1,l.textContent="Check for Updates"}).catch(c=>{console.error("[CRM Extension] Error sending update check message:",c),d("Error checking for updates"),s.textContent="Connection failed",s.style.colorstatusElement.style.color="#F44336",l.disabled=!1,l.textContent="Check for Updates"})}),e.appendChild(l),e}function de(e,t,o){let n=document.createElement("div");n.className="setting-item";let r=document.createElement("div");r.className="setting-label",r.textContent=e,n.appendChild(r);let i=document.createElement("label");i.className="switch";let l=document.createElement("input");l.type="checkbox";let p=localStorage.getItem(t)==="true";l.checked=p,l.addEventListener("change",()=>{let c=l.checked;localStorage.setItem(t,c),o&&typeof o=="function"&&o(c)});let s=document.createElement("span");return s.className="slider",i.appendChild(l),i.appendChild(s),n.appendChild(i),n}function ue(){if(document.getElementById("mcp-crm-header-styles"))return;let e=document.createElement("style");e.id="mcp-crm-header-styles",e.textContent=`
    #mcp-crm-header {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 32px;
      background-color: #2F3A4B;
      display: flex;
      align-items: center;
      padding: 0 15px;
      font-family: 'Segoe UI', 'Roboto', sans-serif;
      font-size: 12px;
      z-index: 999999;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    }
    
    #mcp-crm-header .group {
      display: flex;
      align-items: center;
      margin-right: 15px;
      border-right: 1px solid rgba(255, 255, 255, 0.1);
      padding-right: 15px;
    }
    
    #mcp-crm-header .group:last-child {
      border-right: none;
    }
    
    #mcp-crm-header .spacer {
      flex-grow: 1;
    }
    
    #mcp-crm-header .label {
      color: #8a9cad;
      margin-right: 6px;
      font-weight: 500;
    }
    
    #mcp-crm-header .value {
      color: #e6e6e6;
      font-weight: 600;
    }
    
    #mcp-crm-header .clickable-value {
      color: #e6e6e6;
      font-weight: 600;
      cursor: pointer;
      background-color: rgba(255, 255, 255, 0.05);
      padding: 2px 8px;
      border-radius: 3px;
      transition: background-color 0.2s;
      display: inline-flex;
      align-items: center;
    }
    
    #mcp-crm-header .clickable-value:hover {
      background-color: rgba(255, 255, 255, 0.15);
    }
    
    #mcp-crm-header .btn-icon {
      margin-right: 4px;
      font-size: 10px;
    }
    
external-link:hover {
      background: rgba(255, 255, 255, 0.2);
      transform: translateY(-1px);
    }
    
    #mcp-crm-header .ext-link-icon {
      font-size: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    #mcp-crm-header .btn {
      color: #e6e6e6;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 3px;
      padding: 4px 8px;
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      margin-right: 8px;
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
    }
    
    #mcp-crm-header .btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    #mcp-crm-header .btn:active {
      background-color: rgba(255, 255, 255, 0.3);
    }
    
    #mcp-crm-header .btn:last-child {
      margin-right: 0;
    }
    
    #mcp-crm-header .logo {
      font-weight: bold;
      color: white;
      font-size: 14px;
      margin-right: 15px;
    }
    
    /* Dropdown styling */
    .dropdown {
      position: relative;
      display: inline-block;
      margin-right: 8px;
    }
    
    .dropdown-btn {
      color: #e6e6e6;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 3px;
      padding: 4px 8px;
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
      justify-content: space-between;
      min-width: 100px;
    }
    
    .dropdown-btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .dropdown-btn:after {
      content: "\u25BC";
      font-size: 8px;
      margin-left: 5px;
    }
    
    .dropdown-content {
      display: none;
      position: absolute;
      background-color: #fff;
      min-width: 180px;
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
      z-index: 1000000;
      border-radius: 4px;
      margin-top: 2px;
      left: 0;
    }
    
    .dropdown.show .dropdown-content {
      display: block;
    }
    
    .dropdown-item {
      color: #333;
      padding: 8px 12px;
      text-decoration: none;
      display: block;
      font-size: 12px;
      cursor: pointer;
    }
    
    .dropdown-item:hover {
      background-color: #f1f1f1;
    }
    
    /* Nested Dropdown styling */
    .nested-dropdown {
      margin-bottom: 5px;
      width: 100%;
    }
    
    .nested-dropdown-btn {
      width: 100%;
      text-align: left;
      padding: 6px 10px;
      background-color: #f1f1f1;
      border: 1px solid #ddd;
      border-radius: 3px;
      cursor: pointer;
      font-weight: bold;
      font-size: 12px;
      color: #333;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .nested-dropdown-btn:hover {
      background-color: #e1e1e1;
    }
    
    .nested-dropdown-btn:after {
      content: "\u25BC";
      font-size: 8px;
    }
    
    .nested-dropdown-content {
      display: none;
      padding: 5px 0 5px 10px;
    }
    
    .nested-dropdown.open .nested-dropdown-content {
      display: block;
    }
    
    .nested-dropdown-item {
      display: block;
      padding: 5px 10px;
      color: #333;
      text-decoration: none;
      font-size: 12px;
      cursor: pointer;
      border-radius: 3px;
    }
    
    .nested-dropdown-item:hover {
      background-color: #e8e8e8;
    }
    
    /* Settings dropdown styling */
    #mcp-crm-settings-dropdown {
      position: absolute;
      top: 32px;
      right: 15px;
      background-color: #fff;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.2);
      min-width: 200px;
      z-index: 1000000;
      display: none;
    }
    
    #mcp-crm-settings-dropdown.show {
      display: block;
    }
    
    #mcp-crm-settings-dropdown .settings-header {
      background-color: #2F3A4B;
      color: white;
      padding: 8px 12px;
      font-weight: bold;
      border-top-left-radius: 3px;
      border-top-right-radius: 3px;
    }
    
    #mcp-crm-settings-dropdown .settings-body {
      padding: 10px;
    }
    
    #mcp-crm-settings-dropdown .setting-item {
      display: flex;
      align-items: center;
      margin-bottom: 8px;
      padding-bottom: 8px;
      border-bottom: 1px solid #eee;
    }
    
    #mcp-crm-settings-dropdown .setting-item:last-child {
      margin-bottom: 0;
      padding-bottom: 0;
      border-bottom: none;
    }
    
    #mcp-crm-settings-dropdown .setting-label {
      flex-grow: 1;
      font-size: 13px;
      color: #333;
    }
    
    /* Toggle switch styling */
    .switch {
      position: relative;
      display: inline-block;
      width: 40px;
      height: 20px;
    }
    
    .switch input { 
      opacity: 0;
      width: 0;
      height: 0;
    }
    
    .slider {
      position: absolute;
      cursor: pointer;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: #ccc;
      transition: .4s;
      border-radius: 34px;
    }
    
    .slider:before {
      position: absolute;
      content: "";
      height: 16px;
      width: 16px;
      left: 2px;
      bottom: 2px;
      background-color: white;
      transition: .4s;
      border-radius: 50%;
    }
    
    input:checked + .slider {
      background-color: #2F3A4B;
    }
    
    input:checked + .slider:before {
      transform: translateX(20px);
    }
  `,document.head.appendChild(e)}var Ce=!1;function H(){try{if(document.getElementById("mcp-crm-header")){console.log("[uiHeaderBar] Toolbar already exists.");return}ue();let e=document.createElement("div");e.id="mcp-crm-header";let t=localStorage.getItem("crmplus_headerBarVisible")!=="false";console.log("[CRM Extension] Header visibility setting:",t),e.style.display=t?"flex":"none";let o=document.createElement("div");o.className="group";let n=document.createElement("div");n.className="logo",n.textContent="CRM+",o.appendChild(n);let r=document.createElement("div");r.className="group external-links";let i=typeof browser<"u"?browser:chrome,l=a=>i.runtime.getURL(a),p=U("ShipStation","https://ship15.shipstation.com/onboard",`<img src="${l("assets/shipstation-icon.png")}" alt="ShipStation" width="24" height="24">`);r.appendChild(p);let s=U("Stripe","https://dashboard.stripe.com/login",`<img src="${l("assets/stripe-icon.png")}" alt="Stripe" width="24" height="24">`);r.appendChild(s);let c=U("Webmail","https://p3plzcpnl506102.prod.phx3.secureserver.net:2096/cpsess5640910985/webmail/jupiter/index.html?login=1&post_login=89371011642013",`<img src="${l("assets/webmail-icon.png")}" alt="Webmail" width="24" height="24">`);r.appendChild(c);let m=T("name","Name"),u=T("phone","Phone",{icon:"\u{1F4DE}",initialValue:"",onClick:async a=>{X(a)}}),f=T("dob","DOB"),g=T("srxid","SRx ID"),h=ae(),x=ce(),b=document.createElement("div");b.className="spacer";let y=pe();e.appendChild(o),e.appendChild(r),e.appendChild(m),e.appendChild(u),e.appendChild(f),e.appendChild(g),e.appendChild(h),e.appendChild(x),e.appendChild(b),e.appendChild(y),document.body.appendChild(e),document.body.style.paddingTop=t?"32px":"0",setTimeout(()=>{try{let a=localStorage.getItem("crmplus_automationEnabled")==="true";[document.getElementById("crm-automation-dropdown"),document.getElementById("crm-tags-dropdown")].forEach(q=>{q&&(q.style.display=a?"flex":"none",console.log(`[CRM Extension] Initial visibility for ${q.id}: ${a?"visible":"hidden"}`))})}catch(a){console.error("[CRM Extension] Error setting initial automation visibility:",a)}},100),C(),Z(),oe(),K(),ie(),window.addEventListener("popstate",function(){console.log("[CRM Extension] Navigation detected, clearing phone display"),C()}),we()||C(),Ce=!0,console.log("[CRM Extension] Header successfully initialized")}catch(e){console.error("[CRM Extension] Critical error creating toolbar:",e);try{let t=document.getElementById("mcp-crm-header");t&&(t.style.display="flex")}catch(t){console.error("[CRM Extension] Failed to recover toolbar:",t)}}}function U(e,t,o){let n=document.createElement("a");n.href=t,n.target="_blank",n.className="external-link",n.title=e,n.setAttribute("aria-label",e),n.rel="noopener noreferrer";let r=document.createElement("span");return r.className="ext-link-icon",r.innerHTML=o,n.appendChild(r),n}function we(){let e=window.location.href;return[/\/patient\/\d+/i,/\/contact\/\d+/i,/\/profile\/\d+/i,/[?&]patient_id=\d+/i,/[?&]contact_id=\d+/i].some(n=>n.test(e))?!0:['input[name="contact.phone"]','input[name="contact.first_name"]','input[name="contact.last_name"]','input[name="contact.date_of_birth"]',".patient-info",".contact-details",".patient-header",".patient-profile"].some(n=>document.querySelector(n)!==null)}function G(e){try{let t=document.getElementById("mcp-crm-header");return t?(console.log(`[CRM Extension] Setting header visibility to: ${e}`),t.style.display=e?"flex":"none",document.body.style.paddingTop=e?"32px":"0",localStorage.setItem("crmplus_headerBarVisible",e.toString()),!0):e?(console.log("[CRM Extension] Header not found but should be visible, creating it"),H(),!0):!1}catch(t){return console.error("[CRM Extension] Error toggling header visibility:",t),!1}}function me(){if(!(localStorage.getItem("crmplus_autoCopyPhone")==="true")){console.log("[CRM Extension] Auto-copy phone is disabled");return}let t=()=>{let n=z();if(n){let r=O(n);r&&I(r).then(i=>{if(i)return d("Phone number auto-copied: "+r),!0})}return!1};if(t())return;let o=new MutationObserver((n,r)=>{t()&&r.disconnect()});o.observe(document.body,{childList:!0,subtree:!0,attributes:!0,characterData:!0}),setTimeout(()=>{o.disconnect(),t()},5e3)}console.log("[CRM Extension] Content script injected.");var D=typeof browser<"u"?browser:chrome;D.runtime.sendMessage({action:"loadSettings"}).then(e=>{e&&e.success&&(console.log("[CRM Extension] Settings loaded from browser storage on startup:",e.settings),document.getElementById("mcp-crm-header")||M())}).catch(e=>{console.error("[CRM Extension] Error requesting settings on startup:",e)});localStorage.getItem("crmplus_headerBarVisible")===null?(console.log("[CRM Extension] No local toolbar visibility setting, requesting from browser storage"),D.runtime.sendMessage({action:"loadSettings"}).then(e=>{e&&e.success?(console.log("[CRM Extension] Settings loaded from browser storage:",e.settings),M()):(console.error("[CRM Extension] Failed to load settings, using defaults"),localStorage.setItem("crmplus_headerBarVisible","true"),M())}).catch(e=>{console.error("[CRM Extension] Error requesting settings:",e),localStorage.setItem("crmplus_headerBarVisible","true"),M()})):(console.log("[CRM Extension] Using existing localStorage settings"),M());function M(){let e=localStorage.getItem("crmplus_headerBarVisible")!=="false";console.log("[CRM Extension] Header visibility setting on init:",e);try{console.log("[CRM Extension] Creating fixed header..."),H(),G(e)}catch(t){console.error("[CRM Extension] Error creating fixed header:",t)}try{j(t=>{console.log(`[CRM Extension] Intercepted console message: ${t}`)})}catch(t){console.error("[CRM Extension] Error initializing console monitor:",t)}try{me()}catch(t){console.error("[CRM Extension] Error initializing auto phone copy:",t)}C()}D.runtime.onMessage.addListener((e,t,o)=>{if(console.log("[CRM Extension] Received message:",e),e.action==="toggleHeaderVisibility"){console.log("[CRM Extension] Toggling header visibility to:",e.isVisible);try{let n=G(e.isVisible);localStorage.setItem("crmplus_headerBarVisible",e.isVisible.toString()),D.runtime.sendMessage({action:"syncSettings"}).catch(r=>console.error("[CRM Extension] Error syncing settings:",r)),o({success:n})}catch(n){console.error("[CRM Extension] Error toggling header visibility:",n),o({success:!1,error:n.message})}return!0}return!1});document.addEventListener("DOMContentLoaded",()=>{console.log("[CRM Extension] DOM fully loaded, checking visibility setting"),document.getElementById("mcp-crm-header")||D.runtime.sendMessage({action:"loadSettings"}).then(e=>{e&&e.success&&M()}).catch(()=>{localStorage.setItem("crmplus_headerBarVisible","true"),M()})});})();
