(()=>{function Ye(e){if(window.__crmConsoleMonitor)return;window.__crmConsoleMonitor=!0;let t=console.log,n=console.error,o=console.warn;console.log=function(...r){t.apply(console,r),!(typeof r[0]=="string"&&r[0].includes("[CRM Extension]"))&&Me(r,"log",e)},console.error=function(...r){n.apply(console,r),!(typeof r[0]=="string"&&r[0].includes("[CRM Extension]"))&&Me(r,"error",e)},console.warn=function(...r){o.apply(console,r),!(typeof r[0]=="string"&&r[0].includes("[CRM Extension]"))&&Me(r,"warn",e)}}function Me(e,t,n){let o=e.join(" ");["error","failed","unauthorized","critical"].some(i=>o.toLowerCase().includes(i))&&n(o)}var Je=window.location.href,_="";function le(){if(!Ke())return"";let e=document.querySelector('input[name="contact.phone"]');if(e&&e.value.trim()!=="")return e.value.trim();let t=document.querySelector(".phone-number .number");if(t&&t.textContent.trim()!=="")return t.textContent.trim();let n=['input[placeholder="Phone"]','input[placeholder="Phone Number"]',".patient-info .phone",".contact-info .phone","span.phone",'label[for*="phone"]',".phone-display",'div[data-field="phone"]','span[data-field="phone_number"]'];for(let o of n){let r=document.querySelector(o);if(r)if(r.tagName==="INPUT"){let i=r.value.trim();if(i)return i}else if(r.tagName==="LABEL"){let i=r.getAttribute("for");if(i){let s=document.getElementById(i);if(s&&s.value.trim())return s.value.trim()}let a=r.parentElement?.querySelector("input");if(a&&a.value.trim())return a.value.trim()}else{let i=r.textContent.trim();if(i)return i}}return""}function Ke(){let e=window.location.href;return[/\/patient\/\d+/i,/\/contact\/\d+/i,/\/profile\/\d+/i,/[?&]patient_id=\d+/i,/[?&]contact_id=\d+/i].some(o=>o.test(e))?!0:['input[name="contact.phone"]','input[name="contact.first_name"]','input[name="contact.last_name"]','input[name="contact.date_of_birth"]',".patient-info",".contact-details",".patient-header",".patient-profile"].some(o=>document.querySelector(o)!==null)}function Ze(e){try{let t=e?Zt(e):"";if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("phone",t);else{let n=document.getElementById("phone-text");if(n){n.textContent=t;let o=document.getElementById("phone-display");o&&(e?o.setAttribute("data-value",e):o.removeAttribute("data-value"))}}}catch(t){console.error("[CRM Extension] Error updating phone display:",t)}}function R(){_="",Ze("");try{let e=document.getElementById("phone-display");e&&e.removeAttribute("data-value")}catch(e){console.error("[CRM Extension] Error clearing phone display:",e)}}function Zt(e){if(!e)return"";let t=e.replace(/\D/g,"");if(t.length===0)return"";if(t.length===10)return`(${t.substring(0,3)}) ${t.substring(3,6)}-${t.substring(6)}`;if(t.length===11&&t.startsWith("1"))return`(${t.substring(1,4)}) ${t.substring(4,7)}-${t.substring(7)}`;if(t.length>4){let n="";for(let o=0;o<t.length;o+=3)if(o+4>=t.length&&t.length%3!==0){n+=" "+t.substring(o);break}else n+=" "+t.substring(o,o+3);return n.trim()}return t.replace(/(\d{3})/g,"$1 ").trim()}function ce(){try{if(!Ke())return _&&R(),!1;let e=le();return e?(e!==_&&(_=e,Ze(e)),!0):(_&&R(),!1)}catch(e){return console.error("[CRM Extension] Error detecting phone number:",e),!1}}function Qe(){R(),ce();let e=setInterval(()=>{let t=window.location.href;t!==Je&&(console.log("[CRM Extension] URL changed, resetting phone detection"),Je=t,R()),ce()},200);try{let t=new MutationObserver(o=>{ce()}),n=document.body;t.observe(n,{childList:!0,subtree:!0,characterData:!0,attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] Phone number mutation observer active")}catch(t){console.error("[CRM Extension] Error setting up phone mutation observer:",t)}}function et(e){let t=le();if(!t){u("No phone number found");return}let n=Re(t);if(!n){u("Invalid phone number format");return}e.setAttribute("data-value",t),H(n).then(o=>{u(o?"Copied: "+n:"Failed to copy phone number")})}function Re(e){if(!e)return"";let t=e.replace(/\D/g,"");return t.length<7?"":"+1"+t}async function H(e){if(navigator.clipboard&&navigator.clipboard.writeText)try{return await navigator.clipboard.writeText(e),!0}catch(t){console.warn("Clipboard API failed, trying fallback method:",t)}try{let t=document.createElement("textarea");t.value=e,t.style.position="fixed",t.style.top="0",t.style.left="0",t.style.opacity="0",t.style.pointerEvents="none",document.body.appendChild(t),t.focus(),t.select();let n=document.execCommand("copy");return document.body.removeChild(t),n}catch(t){return console.error("All clipboard methods failed:",t),!1}}function u(e,t=2e3){let n=document.getElementById("crm-plus-toast-container");n||(n=document.createElement("div"),n.id="crm-plus-toast-container",n.style.position="fixed",n.style.bottom="20px",n.style.right="20px",n.style.zIndex="100000",document.body.appendChild(n));let o=document.createElement("div");o.textContent=e,o.style.background="#333",o.style.color="#fff",o.style.padding="10px",o.style.borderRadius="5px",o.style.marginTop="10px",o.style.boxShadow="0 2px 5px rgba(0,0,0,0.2)",o.style.transition="opacity 0.5s, transform 0.5s",o.style.opacity="0",o.style.transform="translateY(20px)",n.appendChild(o),o.offsetWidth,o.style.opacity="1",o.style.transform="translateY(0)",setTimeout(()=>{o.style.opacity="0",o.style.transform="translateY(20px)",setTimeout(()=>{o.parentNode&&o.parentNode.removeChild(o),n.childNodes.length===0&&document.body.removeChild(n)},500)},t)}var tt=window.location.href;function U(e){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("name",e);else{let t=document.getElementById("name-text");if(t){t.textContent=e;let n=document.getElementById("name-display");n&&n.setAttribute("data-value",e)}}}catch(t){console.error("[CRM Extension] Error updating name display:",t)}}function de(){try{let e=document.querySelector('input[name="contact.first_name"]'),t=document.querySelector('input[name="contact.last_name"]');if(e&&e.value&&t&&t.value){let r=`${e.value} ${t.value}`;return U(r),!0}let n=document.querySelectorAll(".patient-name, .contact-name, h1.name, .customer-name");for(let r of n)if(r&&r.textContent&&r.textContent.trim()!==""){let i=r.textContent.trim();return U(i),!0}let o=["span.name",".profile-name","h2.name",".contact-header .name",'div[data-field="name"]',".patient-info .name"];for(let r of o){let i=document.querySelector(r);if(i&&i.textContent&&i.textContent.trim()!==""){let a=i.textContent.trim();return U(a),!0}}return!1}catch(e){return console.error("[CRM Extension] Error detecting name:",e),!1}}function nt(){de();let e=setInterval(()=>{let t=window.location.href;t!==tt&&(console.log("[CRM Extension] URL changed, resetting name detection"),tt=t,U(""),de());let n=document.getElementById("name-text");n&&(n.textContent==="Loading..."||!n.textContent)&&de()},1e3);try{let t=new MutationObserver(o=>{o.some(i=>i.addedNodes.length>5||i.removedNodes.length>5)&&(console.log("[CRM Extension] Significant DOM changes detected, rechecking name"),U(""),de())}),n=document.querySelector("main")||document.body;t.observe(n,{childList:!0,subtree:!0})}catch(t){console.error("[CRM Extension] Error setting up navigation observer for name:",t)}}var ot=window.location.href;function me(e){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("dob",e);else{let t=document.getElementById("dob-text");if(t){t.textContent=e;let n=document.getElementById("dob-display");n&&n.setAttribute("data-value",e)}}}catch(t){console.error("[CRM Extension] Error updating DOB display:",t)}}function rt(e){if(!e)return"";if(e.match(/^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2}(st|nd|rd|th)?\s+\d{4}$/))try{let t=e.match(/(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+(\d{1,2})(st|nd|rd|th)?\s+(\d{4})/);if(t){let n=t[1],o=t[2],r=t[4];return`${(["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"].indexOf(n)+1).toString().padStart(2,"0")}/${o.toString().padStart(2,"0")}/${r}`}}catch(t){console.error("[CRM Extension] Error parsing date:",t)}try{let t=new Date(e);if(!isNaN(t.getTime()))return`${(t.getMonth()+1).toString().padStart(2,"0")}/${t.getDate().toString().padStart(2,"0")}/${t.getFullYear()}`}catch(t){console.error("[CRM Extension] Error parsing date as Date object:",t)}return e}function pe(){try{let e=document.querySelector('input[name="contact.date_of_birth"]');if(e&&e.value){let n=rt(e.value);return me(n),!0}let t=[".dob",".patient-dob",".contact-dob",'span[data-field="date_of_birth"]','div[data-field="dob"]',".patient-info .dob",".contact-info .dob"];for(let n of t){let o=document.querySelector(n);if(o&&o.textContent&&o.textContent.trim()!==""){let r=rt(o.textContent.trim());return me(r),!0}}return!1}catch(e){return console.error("[CRM Extension] Error detecting DOB:",e),!1}}function it(){pe();let e=setInterval(()=>{let t=window.location.href;t!==ot&&(console.log("[CRM Extension] URL changed, resetting DOB detection"),ot=t,me(""),pe());let n=document.getElementById("dob-text");n&&(n.textContent==="Loading..."||!n.textContent)&&pe()},1e3);try{let t=new MutationObserver(o=>{o.some(i=>i.addedNodes.length>5||i.removedNodes.length>5)&&(console.log("[CRM Extension] Significant DOM changes detected, rechecking DOB"),me(""),pe())}),n=document.querySelector("main")||document.body;t.observe(n,{childList:!0,subtree:!0})}catch(t){console.error("[CRM Extension] Error setting up navigation observer for DOB:",t)}}var at=window.location.href,ue="";function st(e){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("srxid",e);else{let t=document.getElementById("srxid-text");if(t){t.textContent=e;let n=document.getElementById("srxid-display");n&&n.setAttribute("data-value",e)}}}catch(t){console.error("[CRM Extension] Error updating SRx ID display:",t)}}function j(){try{let e=document.querySelector('input[name="contact.srx_id"]');if(e&&e.value){let t=e.value.trim();if(t&&/^\d+$/.test(t))return t!==ue&&(console.log("[CRM Extension] Found SRx ID from contact.srx_id input:",t),ue=t,st(t)),!0}return!!ue}catch(e){return console.error("[CRM Extension] Error detecting SRx ID:",e),!1}}function ct(){j();let e=setInterval(()=>{let t=window.location.href;t!==at&&(console.log("[CRM Extension] URL changed, resetting SRx ID detection"),at=t,ue="",st(""),j()),j()},500);try{new MutationObserver(n=>{let o=!1;for(let r of n){if(r.target.tagName==="INPUT"&&r.target.name==="contact.srx_id"||r.target.querySelector&&r.target.querySelector('input[name="contact.srx_id"]')){o=!0;break}if(r.addedNodes.length>0){for(let i of r.addedNodes)if(i.nodeType===1&&i.querySelector&&(i.tagName==="INPUT"&&i.name==="contact.srx_id"||i.querySelector('input[name="contact.srx_id"]'))){o=!0;break}}}o&&j()}).observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] SRx ID mutation observer active")}catch(t){console.error("[CRM Extension] Error setting up observer for SRx ID:",t)}setTimeout(()=>{try{let t=document.querySelector('input[name="contact.srx_id"]');t&&(new MutationObserver(o=>{j()}).observe(t,{attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] Direct input observer attached to contact.srx_id"))}catch(t){console.error("[CRM Extension] Error setting up direct input observer:",t)}},1e3)}var ge=["np-tirz-1.5ml-inj","refill-sema-inj","refill-tirz-inj","vial-sema-b12","vial-sema-b6","vial-sema-lipo","vial-sema-nad+","vial-tirz-cyano","vial-tirz-nad+","vial-tirz-pyridoxine","np-sema-0.125ml-inj","np-sema-0.25ml-inj","np-sema-0.5ml-inj","np-sema-0.75ml-inj","np-sema-1.0ml-inj","np-sema-1.25ml-inj","np-sema-1.5ml-inj","np-sema-2.0ml-inj","np-tirz-0.25ml-inj","np-tirz-0.5ml-inj","np-tirz-0.75ml-inj","np-tirz-1.0ml-inj","np-tirz-1.25ml-inj"],M=[];function lt(){console.log("[CRM Extension] Tag removal system initialized")}function Qt(){M=[];try{let e=document.querySelectorAll(".tag, .tag-label, .pill, .badge");for(let r of e){let i=r.textContent.trim().toLowerCase();ge.some(a=>i.includes(a))&&M.push({element:r,text:i})}let t=document.querySelectorAll("[data-tag]");for(let r of t){let i=r.getAttribute("data-tag").toLowerCase();ge.some(a=>i.includes(a))&&M.push({element:r,text:i})}let n=document.querySelectorAll(".tags-container, .tag-list, .tags");for(let r of n){let i=r.querySelectorAll("*");for(let a of i)if(a.nodeType===1){let s=a.textContent.trim().toLowerCase();ge.some(c=>s.includes(c))&&(M.some(c=>c.element===a)||M.push({element:a,text:s}))}}let o=document.querySelectorAll("*[class]");for(let r of o){let i=r.className.toLowerCase();i&&typeof i=="string"&&ge.some(a=>i.includes(a))&&(M.some(a=>a.element===r)||M.push({element:r,text:r.textContent.trim().toLowerCase()}))}return console.log(`[CRM Extension] Found ${M.length} removable tags`),M}catch(e){return console.error("[CRM Extension] Error detecting tags:",e),[]}}function en(e){try{let t=e.querySelector('.close, .remove, .delete, .tag-remove, [aria-label="Remove"], .x-button');if(t)return console.log("[CRM Extension] Found close button in tag, clicking it"),t.click(),!0;let n=e.parentElement;if(n){let i=n.querySelector('.close, .remove, .delete, .tag-remove, [aria-label="Remove"], .x-button');if(i)return console.log("[CRM Extension] Found close button as sibling, clicking it"),i.click(),!0}let o=[...Array.from(e.querySelectorAll("*")),...Array.from(n?n.children:[])];for(let i of o){let a=i.textContent.trim();if(a==="\xD7"||a==="x"||a==="\u2715"||a==="\u2716"||a==="X")return console.log("[CRM Extension] Found X button by text content, clicking it"),i.click(),!0;if(i.className&&(i.className.includes("close")||i.className.includes("delete")||i.className.includes("remove")||i.className.includes("x-button")))return console.log("[CRM Extension] Found X button by class name, clicking it"),i.click(),!0;if(i.classList&&(i.classList.contains("fa-times")||i.classList.contains("fa-close")||i.classList.contains("icon-close")||i.classList.contains("icon-remove")))return console.log("[CRM Extension] Found X button by icon class, clicking it"),i.click(),!0}if(e.tagName==="BUTTON"||e.tagName==="A"||e.getAttribute("role")==="button"||window.getComputedStyle(e).cursor==="pointer")return console.log("[CRM Extension] Tag appears to be clickable, clicking it"),e.click(),!0;let r=n;for(let i=0;i<3&&r;i++){let a=r.querySelectorAll("button, span, i, div");for(let s of a){let c=s.textContent.trim();if(c==="\xD7"||c==="x"||c==="\u2715"||c==="\u2716"||c==="X"||s.classList.contains("fa-times")||s.classList.contains("fa-close")||s.classList.contains("close")||s.classList.contains("remove"))return console.log("[CRM Extension] Found X button in parent container, clicking it"),s.click(),!0}r=r.parentElement}return console.log("[CRM Extension] No method found to remove tag:",e),!1}catch(t){return console.error("[CRM Extension] Error removing tag:",t),!1}}function Ae(){return new Promise((e,t)=>{try{let r=function(i){if(i>=M.length){console.log(`[CRM Extension] Removed ${n}/${o} tags`),e({success:!0,message:`Removed ${n} of ${o} tags`,removed:n,total:o});return}let a=M[i];console.log(`[CRM Extension] Removing tag: ${a.text}`),en(a.element)&&n++,setTimeout(()=>{r(i+1)},300)};Qt();let n=0,o=M.length;if(o===0){console.log("[CRM Extension] No removable tags found"),e({success:!0,message:"No tags to remove",removed:0,total:0});return}console.log(`[CRM Extension] Attempting to remove ${o} tags`),r(0)}catch(n){console.error("[CRM Extension] Error in removeAllTags:",n),t(n)}})}var tn=["Workflow - New Patient - Semaglutide 0.125ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 0.25ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 0.5ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 0.75ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 1.0ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 1.25ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 1.5ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 2.0ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 0.25ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 0.5ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 0.75ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 1.0ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 1.25ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 1.5ml Onboarding - (Step 1)","Workflow - Refill - Semaglutide/B12 Injection Refill Order - (Step 1)","Workflow - Semaglutide/B12 Vial Order - (Step 1)","Workflow - Semaglutide/B6 Vial Order - (Step 1)","Workflow - Semaglutide/Lipo Vial Order - (Step 1)","Workflow - Semaglutide/NAD+ Vial Order - (Step 1)","Workflow - Syringe - Tirzepatide/Pyridoxine Injection Order - (Step 1)","Workflow - Tirzepatide/Cyano Vial Order - (Step 1)","Workflow - Tirzepatide/NAD+ Vial Order - (Step 1)","Workflow - Tirzepatide/Pyridoxine Vial Order - (Step 1)"],he=[];function A(e){try{if(e&&typeof e.getBoundingClientRect=="function")return e.getBoundingClientRect()}catch{}return{top:0,bottom:0,left:0,right:0,width:0,height:0}}function mt(){console.log("[CRM Extension] Automation removal system initialized")}function nn(){he=[];try{let e=ut("Active");return e?(he=(e.workflows.length?e.workflows:on(e.label)).filter(n=>{if(!n)return!1;let o=(n.textContent||"").trim();return o.includes("Workflow")&&tn.some(r=>o.includes(r))}),console.log(`[CRM Extension] Found ${he.length} automation(s) in Active section.`),he):(console.log("[CRM Extension] Active section not found."),[])}catch(e){return console.error("[CRM Extension] Error detecting automations:",e),[]}}function on(e){let t=A(e).bottom,n=null,o=ut("Past");return o&&o.label&&(n=A(o.label).top),Array.from(document.querySelectorAll('div[id^="workflow_"], div[data-workflow-id]')).filter(i=>{let a=A(i);return!(a.top<t||n&&a.top>=n)})}function ut(e){try{let n=Array.from(document.querySelectorAll("div.py-2")).find(i=>(i.textContent||"").trim()===e);if(n)return{label:n,workflows:e==="Active"?rn(n):an(n)};let o=e==="Active"?'[data-automation="Active"], #automation-active':'[data-automation="Past"], #automation-past',r=document.querySelector(o);return r?{label:r,workflows:[]}:null}catch(t){return console.error(`[CRM Extension] Error finding section for "${e}":`,t),null}}function rn(e){let t=A(e).bottom,o=Array.from(document.querySelectorAll("div.py-2")).find(a=>(a.textContent||"").trim()==="Past"),r=o?A(o).top:null;return Array.from(document.querySelectorAll('div[id^="workflow_"], div[data-workflow-id]')).filter(a=>{let s=A(a);return s.top>t&&(!r||s.top<r)})}function an(e){let t=A(e).bottom;return Array.from(document.querySelectorAll('div[id^="workflow_"], div[data-workflow-id]')).filter(o=>A(o).top>t)}function sn(e){if(!e)return console.error("[CRM Extension] removeAutomation called with undefined element."),!1;try{let t=A(e),n=t.width>0&&t.height>0,o=t.top>=0&&t.left>=0&&t.bottom<=(window.innerHeight||document.documentElement.clientHeight);return!n||!o?(e.scrollIntoView({behavior:"smooth",block:"center"}),new Promise(r=>{setTimeout(()=>r(dt(e)),500)})):dt(e)}catch(t){return console.error("[CRM Extension] Error removing automation:",t),!1}}function dt(e){if(!e)return!1;try{let t=e.querySelectorAll("i.icon-close, i.icon.icon-close");if(t.length)return t[0].click(),!0}catch(t){console.error("[CRM Extension] Error in Strategy 1:",t)}try{let t=e.querySelectorAll("a");for(let n of t){let o=(n.textContent||"").trim();if(o==="\xD7"||o.toLowerCase()==="x")return n.click(),!0}}catch(t){console.error("[CRM Extension] Error in Strategy 2:",t)}try{let t=e.querySelectorAll('button, .btn, [role="button"]');for(let n of t)if((n.textContent||"").toLowerCase().includes("manage"))return n.click(),setTimeout(()=>{document.querySelectorAll(".dropdown-menu .dropdown-item, .menu-item").forEach(i=>{let a=(i.textContent||"").toLowerCase();(a.includes("remove")||a.includes("delete"))&&i.click()})},300),!0}catch(t){console.error("[CRM Extension] Error in Strategy 3:",t)}if(e.id&&e.id.startsWith("workflow_")){let t=e.id;try{let n=`#${t} i.icon-close, #${t} i.icon.icon-close`,o=document.querySelector(n);if(o)return o.click(),!0;n=`#${t} .remove, #${t} .close`;let r=document.querySelector(n);if(r)return r.click(),!0}catch(n){console.error("[CRM Extension] Error in Strategy 4:",n)}}try{let t=e.querySelectorAll("span");for(let n of t){let o=(n.textContent||"").trim();if(o==="\xD7"||o.toLowerCase()==="x")return n.click(),!0}}catch(t){console.error("[CRM Extension] Error in Strategy 5:",t)}try{let t=e.nextElementSibling,n=0;for(;t&&n<3;){if(t.classList&&(t.classList.contains("close")||t.classList.contains("remove"))||t.textContent&&(t.textContent.trim()==="\xD7"||t.textContent.trim().toLowerCase()==="x"))return t.click(),!0;let o=t.querySelector("i.icon-close, i.icon.icon-close");if(o)return o.click(),!0;t=t.nextElementSibling,n++}}catch(t){console.error("[CRM Extension] Error in Strategy 6:",t)}try{let t=A(e),n=t.right-10,o=t.top+t.height/2,r=document.elementsFromPoint(n,o);for(let a of r)if(a!==e)return a.click(),!0;let i=new MouseEvent("click",{view:window,bubbles:!0,cancelable:!0,clientX:n,clientY:o});return(r[0]||document.elementFromPoint(n,o))?.dispatchEvent(i),!0}catch(t){console.error("[CRM Extension] Error in Strategy 7:",t)}return console.error("[CRM Extension] No method found to remove automation:",e),!1}function pt(){return new Promise(e=>{setTimeout(()=>{if(document.querySelectorAll('.modal, [role="dialog"], .dialog').length){let n=document.querySelectorAll('.modal .btn-primary, .modal .btn-danger, .modal .confirm-btn, [role="dialog"] .btn-primary, .modal button, [role="dialog"] button');for(let r of n){let i=(r.textContent||"").trim().toLowerCase();if(["delete","remove","yes","confirm","ok","continue"].includes(i)){r.click(),e(!0);return}}let o=document.querySelectorAll('.modal button, [role="dialog"] button, .dialog button');if(o.length){o[o.length-1].click(),e(!0);return}}e(!1)},500)})}function Te(){return new Promise((e,t)=>{try{let i=function(a){if(a>=r){e({success:!0,message:`Removed ${o} of ${r} automations`,removed:o,total:r});return}let s=n[a],c=sn(s.element);c instanceof Promise?c.then(l=>{l&&o++,pt().then(()=>setTimeout(()=>i(a+1),1e3))}):(c&&o++,pt().then(()=>setTimeout(()=>i(a+1),1e3)))},n=nn();if(!n.length){console.log("[CRM Extension] No automations to remove."),e({success:!0,message:"No automations to remove",removed:0,total:0});return}let o=0,r=n.length;i(0)}catch(n){console.error("[CRM Extension] Error in removeAllAutomations:",n),t(n)}})}var w=[];var fe="crmplus_history";function bt(){xt(),ln(),dn(),window.addEventListener("storage",cn),console.log("[CRM Extension] History tracking initialized")}function xt(){try{let e=localStorage.getItem(fe);if(e){w=JSON.parse(e);let t=Date.now();w=w.filter(n=>t-n.timestamp<144e5),Le()}}catch(e){console.error("[CRM Extension] Error loading history:",e),w=[]}}function Le(){try{localStorage.setItem(fe,JSON.stringify(w))}catch(e){console.error("[CRM Extension] Error saving history:",e)}}function cn(e){if(e.key===fe)try{e.newValue?(w=JSON.parse(e.newValue),console.log("[CRM Extension] History updated from another tab")):(w=[],console.log("[CRM Extension] History cleared from another tab"))}catch(t){console.error("[CRM Extension] Error processing cross-tab history update:",t)}}function ln(){let e=window.location.href;setInterval(()=>{let o=window.location.href;o!==e&&(e=o,W(o))},500),W(window.location.href);let t=history.pushState;history.pushState=function(){t.apply(this,arguments),W(window.location.href)};let n=history.replaceState;history.replaceState=function(){n.apply(this,arguments),W(window.location.href)},window.addEventListener("popstate",()=>{W(window.location.href)})}function W(e){if(!e)return;let t=e.match(/\/detail\/([^/]+)/);if(t&&t[1]){let n=t[1];setTimeout(()=>{let o=gt(),r=ht();o&&o!=="Unknown Patient"?ft(n,o,r,e):(console.log("[CRM Extension] Patient name not found yet, retrying in 3 seconds..."),setTimeout(()=>{let i=gt(),a=ht();i&&i!=="Unknown Patient"?ft(n,i,a,e):console.log("[CRM Extension] Could not retrieve patient info after retry, not adding to history")},3e3))},5e3)}}function gt(){let e=document.getElementById("name-text");if(e&&e.textContent&&e.textContent.trim()!=="")return e.textContent.trim();let t=document.querySelector('input[name="contact.first_name"]'),n=document.querySelector('input[name="contact.last_name"]');if(t&&t.value&&n&&n.value)return`${t.value} ${n.value}`.trim();let o=[".patient-name",".contact-name","h1.name",".customer-name","span.name",".profile-name","h2.name",".contact-header .name",'div[data-field="name"]',".patient-info .name"];for(let r of o){let i=document.querySelector(r);if(i&&i.textContent&&i.textContent.trim()!=="")return i.textContent.trim()}return"Unknown Patient"}function ht(){let e=document.getElementById("phone-text");if(e&&e.textContent&&e.textContent.trim()!=="")return e.textContent.trim();let t=document.querySelector('input[name="contact.phone"]');if(t&&t.value.trim()!=="")return t.value.trim();let n=[".phone-number .number",'input[placeholder="Phone"]','input[placeholder="Phone Number"]',".patient-info .phone",".contact-info .phone","span.phone",'div[data-field="phone"]','span[data-field="phone_number"]'];for(let o of n){let r=document.querySelector(o);if(r)if(r.tagName==="INPUT"){let i=r.value.trim();if(i)return i}else{let i=r.textContent.trim();if(i)return i}}return""}function ft(e,t,n,o){let i=Date.now(),a=w.findIndex(s=>s.patientId===e);if(a!==-1){let s=w[a];s.timestamp=i,s.patientName=t,s.phoneNumber=n,w.splice(a,1),w.unshift(s)}else w.unshift({patientId:e,patientName:t,phoneNumber:n,url:o,timestamp:i}),w.length>20&&w.pop();Le()}function dn(){setInterval(()=>{let e=Date.now(),t=0;w=w.filter(n=>{let o=e-n.timestamp<144e5;return o||t++,o}),t>0&&(console.log(`[CRM Extension] Removed ${t} expired history entries`),Le())},5*60*1e3)}function yt(){xt();let e=Date.now();return w=w.filter(t=>e-t.timestamp<144e5),[...w]}function Ct(){w=[],localStorage.removeItem(fe),console.log("[CRM Extension] History cleared")}function wt(e){return new Date(e).toLocaleString("en-US",{hour:"numeric",minute:"2-digit",hour12:!0})}var z=[],be=new Map,xe=[],Ie=null,vt=[],Et=[];function ye(e){if(!e||!e.text)return;if(e.conversationId)if(!be.has(e.conversationId))be.set(e.conversationId,{id:e.conversationId,name:e.sender,lastMessage:e.text,lastTimestamp:e.timestamp,messages:[e],unreadCount:e.isRead?0:1});else{let n=be.get(e.conversationId);n.lastMessage=e.text,n.lastTimestamp=e.timestamp,e.sender&&e.sender.trim()!==""&&(n.name=e.sender),n.messages.push(e),e.isRead||(n.unreadCount=(n.unreadCount||0)+1),n.messages.length>50&&(n.messages=n.messages.slice(-50))}let t=!0;if(Ie)try{let n=new Date(e.timestamp).getTime(),o=new Date(Ie).getTime();t=n>o}catch{}t&&(Ie=e.timestamp),z.unshift(e),z.length>100&&(z=z.slice(0,100)),t&&pn([e])}function kt(e){for(let t of e){let n=z.findIndex(o=>o.id===t.id);n>=0&&(z[n].isRead=t.isRead,z[n].element=t.element)}}function G(e){return typeof e!="function"?()=>{}:(xe.push(e),()=>{xe=xe.filter(t=>t!==e)})}function pn(e){if(e.length!==0)for(let t of xe)try{t(e)}catch(n){console.error("[CRM Extension] Error in message listener callback:",n)}}function Pe(e=5){return z.slice(0,e)}function De(){return Array.from(be.values()).sort((e,t)=>{try{return new Date(t.lastTimestamp).getTime()-new Date(e.lastTimestamp).getTime()}catch{return 0}})}function Be(){return[...vt]}function ze(){return[...Et]}function St(e,t){return t==="channel"?vt.find(n=>n.id===e):t==="dm"?Et.find(n=>n.id===e):null}function Nt(e=3,t=1e3){return new Promise(n=>{let o=0;function r(){let i=mn();i?n(i):o<e?(o++,console.log(`[CRM Extension] Chat container not found, retry ${o}/${e} in ${t}ms`),setTimeout(r,t)):n(null)}r()})}function mn(){let e=document.getElementById("crm-chat-dropdown");if(e)return e;let t=[".single-chat-wrapper",".chat-message","[data-v-38d322f9]",'[class*="single-chat-wrapper"]','[class*="chat-message"]',".message-list",".chat-list",".conversation-list"];for(let o of t)try{let r=document.querySelectorAll(o);if(r&&r.length>0){let i=r[0].parentElement;for(;i&&i.tagName!=="BODY";){if(i.querySelectorAll(o).length>=r.length)return i;i=i.parentElement}return r[0].parentElement||r[0]}}catch{}let n=document.querySelectorAll('.date-header, [class*="date-header"]');return n.length>0?n[0].parentElement:null}function Ce(){let e=un();if(e.length>0){let t=e.filter(n=>!0);if(t.length>0){for(let n of t)ye(n);console.log(`[CRM Extension] Found ${t.length} new chat messages`)}}kt(e)}function un(){let e=[],t=[".chat-message",'[class*="chat-message"]',".messageListItem",".single-chat",'[class*="message"]','[class*="chat"]'],n=[];for(let o of t){let r=document.querySelectorAll(o);if(r.length>0){n=Array.from(r);break}}for(let o of n)try{let r=gn(o);r&&r.sender&&r.text&&e.push(r)}catch(r){console.error("[CRM Extension] Error extracting message data:",r)}return e}function gn(e){let t=e.dataset?.id||`msg-${Date.now()}-${Math.random().toString(36).substr(2,9)}`,n="",o=e.querySelector('.username, [class*="username"]');if(o)n=o.textContent.trim();else{let d=e.querySelector('.header, [class*="header"]');d&&(n=d.textContent.trim())}let r="",i=e.querySelector('.messageContent, [class*="messageContent"], .markup, [class*="markup"], .contents, [class*="contents"]');if(i)r=i.textContent.trim();else{let d=e.cloneNode(!0),m=d.querySelectorAll('.username, .timestamp, [class*="username"], [class*="timestamp"]');for(let g of m)g&&g.parentNode&&g.parentNode.removeChild(g);r=d.textContent.trim()}let a="",s=e.querySelector('.timestamp, [class*="timestamp"], time, [datetime]');s&&(a=s.getAttribute("datetime")||s.textContent.trim()),a||(a=new Date().toISOString());let c=e.classList.contains("unread")||e.parentElement?.classList.contains("unread")||!!e.querySelector('.unread, [class*="unread"]'),l=e.dataset?.conversationId;if(!l){let d=e.parentElement;for(let m=0;m<3&&d;m++){if(d.dataset?.conversationId){l=d.dataset.conversationId;break}d=d.parentElement}!l&&n?l=`conversation-${n.replace(/\s+/g,"-").toLowerCase()}`:l=`unknown-conversation-${Date.now()}`}return{id:t,conversationId:l,sender:n,text:r,timestamp:a,isRead:!c,element:e}}function Mt(e){if(e&&e.element)try{e.element.scrollIntoView({behavior:"smooth",block:"center"});let t=e.element.style.backgroundColor;e.element.style.backgroundColor="rgba(33, 150, 243, 0.2)",e.element.style.transition="background-color 1s",setTimeout(()=>{e.element.style.backgroundColor=t},2e3)}catch(t){console.error("[CRM Extension] Error scrolling to message:",t)}}var hn=null;function Tt(){let e=XMLHttpRequest.prototype.open,t=XMLHttpRequest.prototype.send;if(XMLHttpRequest.prototype.open=function(n,o,...r){return this._crmUrl=o,e.apply(this,[n,o,...r])},XMLHttpRequest.prototype.send=function(n){return this._crmUrl&&Rt(this._crmUrl)&&this.addEventListener("load",function(){try{if(this.responseType===""||this.responseType==="text"){let o=this.responseText;o&&o.length>0&&At(o)}}catch(o){console.error("[CRM Extension] Error processing XHR response:",o)}}),t.apply(this,arguments)},window.fetch){let n=window.fetch;window.fetch=function(o,r){let i=typeof o=="string"?o:o.url;return Rt(i)?n.apply(this,arguments).then(a=>(a.clone().text().then(c=>{c&&c.length>0&&At(c)}).catch(c=>{console.error("[CRM Extension] Error processing fetch response:",c)}),a)):n.apply(this,arguments)}}return console.log("[CRM Extension] Network monitoring set up for chat activity"),hn}function Rt(e){if(!e)return!1;let t=e.toLowerCase();return t.includes("firestore")||t.includes("highlevel-backend")||t.includes("database")||t.includes("projects")&&t.includes("documents")}function At(e){try{if(!e.includes("documentChange")&&!e.includes("notification_data"))return;let t=e.match(/\[\[\d+,\[(\{.*?\})\]\]\]/g)||[];for(let n of t)try{let o=n.replace(/^\[\[\d+,\[/,"").replace(/\]\]\]$/,""),r=JSON.parse(o);if(r.documentChange&&r.documentChange.document){let i=r.documentChange.document;if(i.fields&&i.fields.notification_data&&i.fields.notification_data.mapValue&&i.fields.notification_data.mapValue.fields){let a=i.fields.notification_data.mapValue.fields;if(i.fields.type&&i.fields.type.stringValue==="sms"&&a.conversationId&&a.fromName&&a.body){let s={id:a.messageId?a.messageId.stringValue:`msg-${Date.now()}`,conversationId:a.conversationId.stringValue,sender:a.fromName.stringValue,text:a.body.stringValue,timestamp:i.fields.date_added?i.fields.date_added.timestampValue:new Date().toISOString(),fromNumber:a.fromNumber?a.fromNumber.stringValue:null,fromEmail:a.fromEmail?a.fromEmail.stringValue:null,contactId:a.contactId?a.contactId.stringValue:null,source:a.source?a.source.stringValue:null};ye(s)}}}}catch(o){console.error("[CRM Extension] Error parsing inner JSON data:",o)}}catch(t){console.error("[CRM Extension] Error processing Firestore response:",t)}}function Lt(){if(document.getElementById("crm-plus-chat-styles"))return;let e=document.createElement("style");e.id="crm-plus-chat-styles",e.textContent=`
      .crm-plus-chat-button {
        display: flex;
        align-items: center;
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 3px;
        padding: 4px 8px;
        color: #e6e6e6;
        font-size: 12px;
        cursor: pointer;
        transition: background-color 0.2s;
      }
      
      .crm-plus-chat-button:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      
      .crm-plus-chat-icon {
        margin-right: 4px;
        font-size: 14px;
      }
      
      .crm-plus-chat-count {
        background-color: #F44336;
        color: white;
        border-radius: 50%;
        padding: 2px 6px;
        font-size: 10px;
        margin-left: 4px;
        display: none;
      }
      
      /* Chat dropdown styling */
      .crm-plus-chat-dropdown {
        position: absolute;
        top: 32px;
        right: 0;
        background-color: #2F3A4B;
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 4px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.3);
        min-width: 300px;
        max-width: 350px;
        z-index: 1000000;
        display: none;
        flex-direction: column;
        max-height: 400px;
      }
      
      .crm-plus-chat-dropdown.show {
        display: flex;
      }
      
      /* Chat tabs styling */
      .crm-plus-chat-tabs {
        display: flex;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      }
      
      .crm-plus-chat-tab {
        padding: 8px 12px;
        color: #e6e6e6;
        font-size: 13px;
        cursor: pointer;
        position: relative;
        flex-grow: 1;
        text-align: center;
      }
      
      .crm-plus-chat-tab.active {
        background-color: rgba(255, 255, 255, 0.1);
        border-bottom: 2px solid #2196F3;
      }
      
      .crm-plus-chat-tab:hover {
        background-color: rgba(255, 255, 255, 0.05);
      }
      
      .crm-plus-chat-tab-badge {
        position: absolute;
        top: 3px;
        right: 3px;
        background-color: #F44336;
        color: white;
        border-radius: 50%;
        padding: 1px 5px;
        font-size: 9px;
        display: none;
      }
      
      /* Messages container */
      .crm-plus-chat-messages {
        overflow-y: auto;
        flex-grow: 1;
        max-height: 330px;
      }
      
      /* Conversations container */
      .crm-plus-chat-conversations {
        overflow-y: auto;
        flex-grow: 1;
        max-height: 330px;
      }
      
      /* Message styling */
      .crm-plus-chat-message {
        padding: 10px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        cursor: pointer;
      }
      
      .crm-plus-chat-message:hover {
        background-color: rgba(255, 255, 255, 0.05);
      }
      
      .crm-plus-chat-user {
        font-weight: bold;
        color: #e6e6e6;
        font-size: 13px;
        margin-bottom: 3px;
      }
      
      .crm-plus-chat-text {
        color: #ccc;
        font-size: 12px;
        margin-bottom: 3px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      
      .crm-plus-chat-time {
        color: #999;
        font-size: 10px;
        text-align: right;
      }
      
      /* Conversation styling */
      .crm-plus-chat-conversation {
        padding: 8px 10px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        cursor: pointer;
        display: flex;
        justify-content: space-between;
      }
      
      .crm-plus-chat-conversation:hover {
        background-color: rgba(255, 255, 255, 0.05);
      }
      
      .crm-plus-chat-conversation.active {
        background-color: rgba(255, 255, 255, 0.1);
      }
      
      .crm-plus-chat-conversation-info {
        flex-grow: 1;
        overflow: hidden;
      }
      
      .crm-plus-chat-conversation-name {
        font-weight: bold;
        color: #e6e6e6;
        font-size: 13px;
        margin-bottom: 3px;
      }
      
      .crm-plus-chat-conversation-preview {
        color: #ccc;
        font-size: 12px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      
      .crm-plus-chat-conversation-meta {
        display: flex;
        flex-direction: column;
        align-items: flex-end;
        min-width: 50px;
      }
      
      .crm-plus-chat-conversation-time {
        color: #999;
        font-size: 10px;
        margin-bottom: 4px;
      }
      
      .crm-plus-chat-unread-badge {
        background-color: #F44336;
        color: white;
        border-radius: 50%;
        padding: 2px 5px;
        font-size: 10px;
        min-width: 15px;
        text-align: center;
      }
      
      /* Chat header styling */
      .crm-plus-chat-header {
        padding: 10px;
        background-color: rgba(255, 255, 255, 0.1);
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        display: flex;
        align-items: center;
        font-weight: bold;
        color: #e6e6e6;
      }
      
      .crm-plus-chat-header-action {
        color: #e6e6e6;
        font-size: 12px;
        cursor: pointer;
        margin-right: 10px;
      }
      
      .crm-plus-chat-header-action:hover {
        text-decoration: underline;
      }
      
      /* Chat footer styling */
      .crm-plus-chat-footer {
        padding: 8px;
        border-top: 1px solid rgba(255, 255, 255, 0.1);
      }
      
      .crm-plus-chat-input {
        width: 100%;
        padding: 6px 10px;
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 3px;
        background-color: rgba(255, 255, 255, 0.1);
        color: #e6e6e6;
        font-size: 12px;
      }
      
      .crm-plus-chat-input:focus {
        outline: none;
        border-color: rgba(255, 255, 255, 0.3);
      }
      
      /* Toast notification styles */
      #crm-plus-toast-container {
        position: fixed;
        bottom: 20px;
        right: 20px;
        z-index: 100000;
      }
      
      /* Highlight animation for messages */
      @keyframes crm-plus-highlight-fade {
        0% { background-color: rgba(33, 150, 243, 0.3); }
        100% { background-color: transparent; }
      }
      
      .crm-plus-highlight {
        animation: crm-plus-highlight-fade 2s ease-out;
      }
    `,document.head.appendChild(e)}var It=!1,we=null;function qe(){It||(console.log("[CRM Extension] Chat monitoring system initializing"),Lt(),fn(),bn(),It=!0)}function fn(){we&&we.disconnect(),we=new MutationObserver(e=>{let t=!1;for(let n of e){if(n.type==="childList"&&n.addedNodes.length>0){for(let o of n.addedNodes)if(o.nodeType===1){if(o.classList&&(o.classList.contains("single-chat-wrapper")||o.classList.contains("chat-message"))){t=!0;break}if(o.querySelector&&(o.querySelector(".single-chat-wrapper")||o.querySelector(".chat-message"))){t=!0;break}}}if(t)break}t&&Ce()}),Nt(5,1e3).then(e=>{e?(we.observe(e,{childList:!0,subtree:!0}),console.log("[CRM Extension] Chat observer successfully started on container:",e)):console.warn("[CRM Extension] Failed to find chat container after multiple attempts")}),setTimeout(Ce,2e3)}function bn(){Tt(),setInterval(()=>{Ce()},1e4)}async function Pt(){let e=detectChatPlatform(),t=[],n=[];switch(e){case"discord":let o=await fetchDiscordData();t=o.channels,n=o.directMessages;break;case"slack":let r=await fetchSlackData();t=r.channels,n=r.directMessages;break;case"mtncare-internal":let i=await fetchInternalChatData();t=i.channels,n=i.directMessages;break;default:t=scrapeChannelsFromDOM(),n=scrapeDirectMessagesFromDOM()}return{channels:t,directMessages:n}}function $e(e,t=2e3){let n=document.getElementById("crm-plus-toast-container");n||(n=document.createElement("div"),n.id="crm-plus-toast-container",n.style.position="fixed",n.style.bottom="20px",n.style.right="20px",n.style.zIndex="100000",document.body.appendChild(n));let o=document.createElement("div");o.textContent=e,o.style.background="#333",o.style.color="#fff",o.style.padding="10px",o.style.borderRadius="5px",o.style.marginTop="10px",o.style.boxShadow="0 2px 5px rgba(0,0,0,0.2)",o.style.transition="opacity 0.5s, transform 0.5s",o.style.opacity="0",o.style.transform="translateY(20px)",n.appendChild(o),o.offsetWidth,o.style.opacity="1",o.style.transform="translateY(0)",setTimeout(()=>{o.style.opacity="0",o.style.transform="translateY(20px)",setTimeout(()=>{o.parentNode&&o.parentNode.removeChild(o),n.childNodes.length===0&&document.body.removeChild(n)},500)},t)}function Ve(){let e=document.createElement("button");e.className="crm-plus-chat-button",e.id="crm-plus-chat-button";let t=document.createElement("span");t.className="crm-plus-chat-icon",t.innerHTML="\u{1F4AC}",e.appendChild(t);let n=document.createElement("span");n.textContent="Chat",e.appendChild(n);let o=document.createElement("span");o.className="crm-plus-chat-count",o.id="crm-plus-chat-count",o.style.display="none",o.textContent="0",e.appendChild(o);let r=xn();return e.addEventListener("click",()=>{r.classList.contains("show")?r.classList.remove("show"):(r.classList.add("show"),o.textContent="0",o.style.display="none",Bt(r))}),G(i=>{if(!r.classList.contains("show")){let s=(parseInt(o.textContent,10)||0)+i.length;o.textContent=s.toString(),o.style.display="inline",Bt(r)}}),document.addEventListener("click",i=>{!e.contains(i.target)&&!r.contains(i.target)&&r.classList.remove("show")}),e}function xn(){let e=document.createElement("div");e.className="crm-plus-chat-dropdown",e.id="crm-plus-chat-dropdown";let t=document.createElement("div");t.className="crm-plus-chat-tabs";let n=document.createElement("div");n.className="crm-plus-chat-tab active",n.textContent="Recent",n.setAttribute("data-tab","recent");let o=document.createElement("div");o.className="crm-plus-chat-tab",o.textContent="Channels",o.setAttribute("data-tab","channels");let r=document.createElement("div");r.className="crm-plus-chat-tab",r.textContent="DMs",r.setAttribute("data-tab","dms"),t.appendChild(n),t.appendChild(o),t.appendChild(r);let i=document.createElement("div");i.id="crm-plus-chat-recent",i.className="crm-plus-chat-messages";let a=document.createElement("div");a.id="crm-plus-chat-channels",a.className="crm-plus-chat-channels",a.style.display="none";let s=document.createElement("div");s.id="crm-plus-chat-dms",s.className="crm-plus-chat-dms",s.style.display="none",n.addEventListener("click",()=>{c(n,i),ve(e)}),o.addEventListener("click",()=>{c(o,a),Oe(a)}),r.addEventListener("click",()=>{c(r,s),Fe(s)});function c(g,h){t.querySelectorAll(".crm-plus-chat-tab").forEach(b=>{b.classList.remove("active")}),e.querySelectorAll(".crm-plus-chat-messages, .crm-plus-chat-channels, .crm-plus-chat-dms, .crm-plus-chat-conversations").forEach(b=>{b.style.display="none"}),g.classList.add("active"),h.style.display="block"}let l=document.createElement("div");l.className="crm-plus-chat-footer";let d=document.createElement("input");d.type="text",d.className="crm-plus-chat-input",d.placeholder="Type a message...",d.addEventListener("keydown",g=>{if(g.key==="Enter"){let h=d.value.trim();if(h){let b=null,k=e.querySelector(".crm-plus-chat-tab.active");if(k){let S=k.getAttribute("data-tab");if(S==="channels"){let C=a.querySelector(".crm-plus-chat-channel.active");C&&(b=C.getAttribute("data-id"))}else if(S==="dms"){let C=s.querySelector(".crm-plus-chat-dm.active");C&&(b=C.getAttribute("data-id"))}else{let C=i.querySelector(".crm-plus-chat-conversation.active");C&&(b=C.getAttribute("data-conversation-id"))}}Cn(h,b),d.value=""}}}),l.appendChild(d);let m=document.createElement("button");return m.className="crm-plus-refresh-button",m.innerHTML="\u{1F504}",m.title="Refresh chat data",m.addEventListener("click",()=>{Dt(e)}),e.appendChild(t),e.appendChild(i),e.appendChild(a),e.appendChild(s),e.appendChild(l),e.appendChild(m),Dt(e),e}function Dt(e){e.querySelectorAll(".crm-plus-chat-messages, .crm-plus-chat-channels, .crm-plus-chat-dms").forEach(n=>{n.innerHTML='<div class="crm-plus-chat-loading">Loading...</div>'}),Pt().then(()=>{let n=e.querySelector(".crm-plus-chat-tab.active");if(n){let o=n.getAttribute("data-tab");o==="recent"?ve(e):o==="channels"?Oe(e.querySelector("#crm-plus-chat-channels")):o==="dms"&&Fe(e.querySelector("#crm-plus-chat-dms"))}}).catch(n=>{console.error("[CRM Extension] Error refreshing chat data:",n),$e("Error refreshing chat data")})}function Bt(e){if(!e)return;let t=e.querySelector(".crm-plus-chat-tab.active");if(t){let n=t.getAttribute("data-tab");n==="recent"?ve(e):n==="channels"?Oe(e.querySelector("#crm-plus-chat-channels")):n==="dms"&&Fe(e.querySelector("#crm-plus-chat-dms"))}else ve(e);yn(e)}function ve(e){let t=e.querySelector("#crm-plus-chat-recent");if(!t)return;let n=Pe(10);if(t.innerHTML="",n.length===0){let o=document.createElement("div");o.className="crm-plus-chat-message",o.textContent="No recent messages",o.style.color="#aaa",o.style.fontStyle="italic",o.style.textAlign="center",t.appendChild(o);return}for(let o of n){let r=document.createElement("div");r.className="crm-plus-chat-message";let i=document.createElement("div");i.className="crm-plus-chat-user",i.textContent=o.sender,r.appendChild(i);let a=document.createElement("div");a.className="crm-plus-chat-text",a.textContent=o.text,r.appendChild(a);let s=document.createElement("div");s.className="crm-plus-chat-time";try{let c=new Date(o.timestamp);isNaN(c.getTime())?s.textContent=o.timestamp:s.textContent=c.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}catch{s.textContent=o.timestamp}r.appendChild(s),r.addEventListener("click",()=>{o.element&&($t(o),e.classList.remove("show"))}),t.appendChild(r)}}function Oe(e){let t=Be();if(e.innerHTML="",t.length===0){let n=document.createElement("div");n.className="crm-plus-chat-empty",n.textContent="No channels found",e.appendChild(n);return}t.forEach(n=>{let o=document.createElement("div");o.className="crm-plus-chat-channel",o.setAttribute("data-id",n.id);let r=document.createElement("div");r.className="crm-plus-channel-icon",r.textContent="#";let i=document.createElement("div");if(i.className="crm-plus-channel-name",i.textContent=n.name,o.appendChild(r),o.appendChild(i),n.unreadCount&&n.unreadCount>0){let a=document.createElement("div");a.className="crm-plus-unread-badge",a.textContent=n.unreadCount>9?"9+":n.unreadCount.toString(),o.appendChild(a)}o.addEventListener("click",()=>{e.querySelectorAll(".crm-plus-chat-channel.active").forEach(a=>{a.classList.remove("active")}),o.classList.add("active"),qt(n.id,"channel",e.closest(".crm-plus-chat-dropdown"))}),e.appendChild(o)})}function Fe(e){let t=ze();if(e.innerHTML="",t.length===0){let n=document.createElement("div");n.className="crm-plus-chat-empty",n.textContent="No direct messages found",e.appendChild(n);return}t.forEach(n=>{let o=document.createElement("div");o.className="crm-plus-chat-dm",o.setAttribute("data-id",n.id);let r;n.avatarSrc?(r=document.createElement("img"),r.className="crm-plus-avatar",r.src=n.avatarSrc,r.alt=n.name):(r=document.createElement("div"),r.className="crm-plus-avatar-placeholder",r.style.backgroundColor=n.avatarColor||vn(n.name),r.textContent=n.initials||wn(n.name));let i=document.createElement("div");if(i.className="crm-plus-dm-name",i.textContent=n.name,o.appendChild(r),o.appendChild(i),n.unreadCount&&n.unreadCount>0){let a=document.createElement("div");a.className="crm-plus-unread-badge",a.textContent=n.unreadCount>9?"9+":n.unreadCount.toString(),o.appendChild(a)}o.addEventListener("click",()=>{e.querySelectorAll(".crm-plus-chat-dm.active").forEach(a=>{a.classList.remove("active")}),o.classList.add("active"),qt(n.id,"dm",e.closest(".crm-plus-chat-dropdown"))}),e.appendChild(o)})}function qt(e,t,n){let o=n.querySelector("#crm-plus-conversation-view");o||(o=document.createElement("div"),o.id="crm-plus-conversation-view",o.className="crm-plus-chat-conversations",n.appendChild(o)),n.querySelectorAll(".crm-plus-chat-messages, .crm-plus-chat-channels, .crm-plus-chat-dms").forEach(l=>{l.style.display="none"}),o.style.display="block";let r=St(e,t);if(!r){o.innerHTML='<div class="crm-plus-chat-empty">Conversation not found</div>';return}o.innerHTML="";let i=document.createElement("div");i.className="crm-plus-chat-header";let a=document.createElement("div");a.className="crm-plus-chat-header-action",a.textContent="\u2190 Back",a.addEventListener("click",()=>{o.style.display="none",t==="channel"?n.querySelector("#crm-plus-chat-channels").style.display="block":t==="dm"?n.querySelector("#crm-plus-chat-dms").style.display="block":n.querySelector("#crm-plus-chat-recent").style.display="block"});let s=document.createElement("div");s.textContent=r.name||(t==="channel"?`#${e}`:"Direct Message"),i.appendChild(a),i.appendChild(s),o.appendChild(i);let c=document.createElement("div");if(c.className="crm-plus-chat-messages-container",!r.messages||r.messages.length===0){let l=document.createElement("div");l.className="crm-plus-chat-empty",l.textContent="No messages yet",c.appendChild(l)}else r.messages.forEach(l=>{let d=document.createElement("div");d.className="crm-plus-chat-message";let m=document.createElement("div");m.className="crm-plus-chat-user",m.textContent=l.sender||r.name,d.appendChild(m);let g=document.createElement("div");g.className="crm-plus-chat-text",g.textContent=l.text,d.appendChild(g);let h=document.createElement("div");h.className="crm-plus-chat-time";try{let b=new Date(l.timestamp);isNaN(b.getTime())?h.textContent=l.timestamp:h.textContent=b.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}catch{h.textContent=l.timestamp}d.appendChild(h),c.appendChild(d)});o.appendChild(c),setTimeout(()=>{c.scrollTop=c.scrollHeight},10)}function yn(e){if(!e)return;let t=0;De().forEach(c=>{t+=c.unreadCount||0});let n=0;Be().forEach(c=>{n+=c.unreadCount||0});let o=0;ze().forEach(c=>{o+=c.unreadCount||0});let i=document.getElementById("crm-plus-chat-button")?.querySelector(".crm-plus-chat-count");if(i){let c=t+n+o;c>0?(i.textContent=c>9?"9+":c.toString(),i.style.display="inline"):i.style.display="none"}let a=e.querySelector('.crm-plus-chat-tab[data-tab="channels"]');zt(a,n);let s=e.querySelector('.crm-plus-chat-tab[data-tab="dms"]');zt(s,o)}function zt(e,t){if(!e)return;let n=e.querySelector(".crm-plus-chat-tab-badge");t>0?(n||(n=document.createElement("span"),n.className="crm-plus-chat-tab-badge",e.appendChild(n)),n.textContent=t>9?"9+":t.toString(),n.style.display="inline"):n&&(n.style.display="none")}function Cn(e,t=null){if(!e)return!1;try{let n=['textarea[placeholder*="message"], input[placeholder*="message"]','textarea[placeholder*="chat"], input[placeholder*="chat"]','textarea[placeholder*="type"], input[placeholder*="type"]',".chat-input",'[contenteditable="true"]'],o=null;if(t){let a=Array.from(document.querySelectorAll("a, div, button")).filter(s=>s.dataset&&s.dataset.conversationId===t||s.getAttribute("data-conversation-id")===t||s.textContent.includes(t));a.length>0&&(a[0].click(),setTimeout(()=>{for(let s of n){let c=document.querySelector(s);if(c)return c.focus(),c.tagName==="INPUT"||c.tagName==="TEXTAREA"?(c.value=e,c.dispatchEvent(new Event("input",{bubbles:!0}))):c.getAttribute("contenteditable")==="true"&&(c.textContent=e,c.dispatchEvent(new InputEvent("input",{bubbles:!0}))),c.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",code:"Enter",keyCode:13,which:13,bubbles:!0})),!0}},500))}for(let a of n){let s=document.querySelector(a);if(s){o=s;break}}if(!o)return console.error("[CRM Extension] Chat input not found"),$e("Chat input not found. Try clicking on a conversation first."),!1;o.focus(),o.tagName==="INPUT"||o.tagName==="TEXTAREA"?(o.value=e,o.dispatchEvent(new Event("input",{bubbles:!0}))):o.getAttribute("contenteditable")==="true"&&(o.textContent=e,o.dispatchEvent(new InputEvent("input",{bubbles:!0})));let r=['button[type="submit"]',"button.send",'button[class*="send"]','button svg[class*="send"]',"button.chat-send",'button[aria-label*="send"]','button[title*="send"]'],i=null;for(let a of r){let s=document.querySelector(a);if(s){i=s;break}}return i?i.click():o.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",code:"Enter",keyCode:13,which:13,bubbles:!0})),!0}catch(n){return console.error("[CRM Extension] Error sending chat message:",n),$e(`Error sending message: ${n.message}`),!1}}function wn(e){if(!e)return"";let t=e.split(/\s+/);return t.length===1?e.charAt(0).toUpperCase():(t[0].charAt(0)+t[t.length-1].charAt(0)).toUpperCase()}function vn(e){if(!e)return"#7289DA";let t=0;for(let o=0;o<e.length;o++)t=e.charCodeAt(o)+((t<<5)-t);let n="#";for(let o=0;o<3;o++){let r=(t>>o*8&255)%128+128;n+=r.toString(16).padStart(2,"0")}return n}function $t(e){Mt(e)}function X(e,t,n={}){let o=document.createElement("div");o.className="group";let r=document.createElement("span");r.className="label",r.textContent=`${t}:`,o.appendChild(r);let i=document.createElement("span");if(i.id=`${e}-display`,i.className="clickable-value",n.initialValue&&i.setAttribute("data-value",n.initialValue),n.icon){let c=document.createElement("span");c.className="btn-icon",c.innerHTML=n.icon,i.appendChild(c)}let a=document.createElement("span");a.textContent=n.initialValue||"",a.id=`${e}-text`,i.appendChild(a);let s=async()=>{let c=i.getAttribute("data-value")||a.textContent.trim();c&&c!==""?await H(c)?u(`Copied ${t}: ${c}`):u(`Failed to copy ${t.toLowerCase()}`):u(`No ${t.toLowerCase()} available to copy`)};return i.addEventListener("click",()=>{n.onClick?n.onClick(i):s()}),i.title=`Click to copy ${t.toLowerCase()} to clipboard`,o.appendChild(i),o}function Vt(){let e=document.createElement("div");return e.className="group",e.id="crm-actions-group",e}function Ot(){let e=document.createElement("div");e.className="dropdown",e.id="crm-tags-dropdown";let t=document.createElement("button");t.className="dropdown-btn",t.textContent="Tags",t.addEventListener("click",p=>{p.stopPropagation(),document.querySelectorAll(".dropdown.show").forEach(Xe=>{Xe!==e&&Xe.classList.remove("show")}),e.classList.toggle("show")});let n=document.createElement("div");if(n.className="dropdown-content",n.style.padding="10px",!document.getElementById("tags-dropdown-styles")){let p=document.createElement("style");p.id="tags-dropdown-styles",p.textContent=`
      .nested-dropdown {
        margin-bottom: 8px;
        width: 100%;
        position: relative;
      }
      .nested-dropdown-btn {
        width: 100%;
        text-align: left;
        padding: 8px 12px;
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 3px;
        cursor: pointer;
        font-weight: bold;
        font-size: 13px;
        color: #e6e6e6;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .nested-dropdown-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      .nested-dropdown-btn:after {
        content: "\u25BC";
        font-size: 8px;
        color: #e6e6e6;
      }
      .nested-dropdown-content {
        display: none;
        padding: 5px 0 5px 10px;
        margin-top: 3px !important;
      }
      .nested-dropdown.open .nested-dropdown-content {
        display: block;
      }
      
      /* Button-style tag options */
      .tag-btn {
        display: block;
        width: 100%;
        padding: 8px 12px;
        margin-bottom: 8px;
        background-color: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 4px;
        text-align: left;
        font-size: 13px;
        color: #e6e6e6;
        cursor: pointer;
        transition: all 0.2s ease;
        font-weight: normal;
      }
      .tag-btn:hover {
        background-color: rgba(255, 255, 255, 0.15);
        border-color: rgba(255, 255, 255, 0.2);
      }
      .tag-btn:active {
        background-color: rgba(255, 255, 255, 0.2);
      }
    `,document.head.appendChild(p)}let o=document.createElement("button");o.className="tag-btn",o.textContent="Opt-in",o.addEventListener("click",()=>{Ft("opt-in"),e.classList.remove("show")}),n.appendChild(o);let r=document.createElement("button");r.className="tag-btn",r.textContent="Refill-Sema-Inj",r.addEventListener("click",()=>{x("refill-sema-inj"),e.classList.remove("show")}),n.appendChild(r);let i=document.createElement("button");i.className="tag-btn",i.textContent="Refill-Tirz-Inj",i.addEventListener("click",()=>{x("refill-tirz-inj"),e.classList.remove("show")}),n.appendChild(i);let a=document.createElement("div");a.className="nested-dropdown";let s=document.createElement("button");s.className="nested-dropdown-btn",s.textContent="Vial-Semaglutide";let c=document.createElement("div");c.className="nested-dropdown-content",s.addEventListener("click",p=>{p.stopPropagation(),a.classList.toggle("open")});let l=document.createElement("button");l.className="tag-btn",l.textContent="Vial-Sema-B12",l.addEventListener("click",p=>{p.stopPropagation(),y(),x("vial-sema-b12")}),c.appendChild(l);let d=document.createElement("button");d.className="tag-btn",d.textContent="Vial-Sema-B6",d.addEventListener("click",p=>{p.stopPropagation(),y(),x("vial-sema-b6")}),c.appendChild(d);let m=document.createElement("button");m.className="tag-btn",m.textContent="Vial-Sema-Lipo",m.addEventListener("click",p=>{p.stopPropagation(),y(),x("vial-sema-lipo")}),c.appendChild(m);let g=document.createElement("button");g.className="tag-btn",g.textContent="Vial-Sema-NAD+",g.addEventListener("click",p=>{p.stopPropagation(),y(),x("vial-sema-nad+")}),c.appendChild(g),a.appendChild(s),a.appendChild(c),n.appendChild(a);let h=document.createElement("div");h.className="nested-dropdown";let b=document.createElement("button");b.className="nested-dropdown-btn",b.textContent="Vial-Tirzepatide";let k=document.createElement("div");k.className="nested-dropdown-content",b.addEventListener("click",p=>{p.stopPropagation(),h.classList.toggle("open")});let S=document.createElement("button");S.className="tag-btn",S.textContent="Vial-Tirz-Cyano",S.addEventListener("click",p=>{p.stopPropagation(),y(),x("vial-tirz-cyano")}),k.appendChild(S);let C=document.createElement("button");C.className="tag-btn",C.textContent="Vial-Tirz-NAD+",C.addEventListener("click",p=>{p.stopPropagation(),y(),x("vial-tirz-nad+")}),k.appendChild(C);let f=document.createElement("button");f.className="tag-btn",f.textContent="Vial-Tirz-Pyr",f.addEventListener("click",p=>{p.stopPropagation(),y(),x("vial-tirz-pyridoxine")}),k.appendChild(f),h.appendChild(b),h.appendChild(k),n.appendChild(h);let v=document.createElement("div");v.className="nested-dropdown";let q=document.createElement("button");q.className="nested-dropdown-btn",q.textContent="NP-Semaglutide";let N=document.createElement("div");N.className="nested-dropdown-content",q.addEventListener("click",p=>{p.stopPropagation(),v.classList.toggle("open")});let O=document.createElement("button");O.className="tag-btn",O.textContent="NP-Sema 0.125",O.addEventListener("click",p=>{p.stopPropagation(),y(),x("np-sema-0.125ml-inj")}),N.appendChild(O);let E=document.createElement("button");E.className="tag-btn",E.textContent="NP-Sema 0.25",E.addEventListener("click",p=>{p.stopPropagation(),y(),x("np-sema-0.25ml-inj")}),N.appendChild(E);let T=document.createElement("button");T.className="tag-btn",T.textContent="NP-Sema 0.5",T.addEventListener("click",p=>{p.stopPropagation(),y(),x("np-sema-0.5ml-inj")}),N.appendChild(T);let D=document.createElement("button");D.className="tag-btn",D.textContent="NP-Sema 0.75",D.addEventListener("click",p=>{p.stopPropagation(),y(),x("np-sema-0.75ml-inj")}),N.appendChild(D);let K=document.createElement("button");K.className="tag-btn",K.textContent="NP-Sema 1.0",K.addEventListener("click",p=>{p.stopPropagation(),y(),x("np-sema-1.0ml-inj")}),N.appendChild(K);let Z=document.createElement("button");Z.className="tag-btn",Z.textContent="NP-Sema 1.25",Z.addEventListener("click",p=>{p.stopPropagation(),y(),x("np-sema-1.25ml-inj")}),N.appendChild(Z);let Q=document.createElement("button");Q.className="tag-btn",Q.textContent="NP-Sema 1.5",Q.addEventListener("click",p=>{p.stopPropagation(),y(),x("np-sema-1.5ml-inj")}),N.appendChild(Q);let ee=document.createElement("button");ee.className="tag-btn",ee.textContent="NP-Sema 2.0",ee.addEventListener("click",p=>{p.stopPropagation(),y(),x("np-sema-2.0ml-inj")}),N.appendChild(ee),v.appendChild(q),v.appendChild(N),n.appendChild(v);let F=document.createElement("div");F.className="nested-dropdown";let te=document.createElement("button");te.className="nested-dropdown-btn",te.textContent="NP-Tirzepatide";let B=document.createElement("div");B.className="nested-dropdown-content",te.addEventListener("click",p=>{p.stopPropagation(),F.classList.toggle("open")});let ne=document.createElement("button");ne.className="tag-btn",ne.textContent="NP-Tirz 0.25",ne.addEventListener("click",p=>{p.stopPropagation(),y(),x("np-tirz-0.25ml-inj")}),B.appendChild(ne);let oe=document.createElement("button");oe.className="tag-btn",oe.textContent="NP-Tirz 0.5",oe.addEventListener("click",p=>{p.stopPropagation(),y(),x("np-tirz-0.5ml-inj")}),B.appendChild(oe);let re=document.createElement("button");re.className="tag-btn",re.textContent="NP-Tirz 0.75",re.addEventListener("click",p=>{p.stopPropagation(),y(),x("np-tirz-0.75ml-inj")}),B.appendChild(re);let ie=document.createElement("button");ie.className="tag-btn",ie.textContent="NP-Tirz 1.0",ie.addEventListener("click",p=>{p.stopPropagation(),y(),x("np-tirz-1.0ml-inj")}),B.appendChild(ie);let ae=document.createElement("button");ae.className="tag-btn",ae.textContent="NP-Tirz 1.25",ae.addEventListener("click",p=>{p.stopPropagation(),y(),x("np-tirz-1.25ml-inj")}),B.appendChild(ae);let se=document.createElement("button");return se.className="tag-btn",se.textContent="NP-Tirz 1.5",se.addEventListener("click",p=>{p.stopPropagation(),y(),x("np-tirz-1.5ml-inj")}),B.appendChild(se),F.appendChild(te),F.appendChild(B),n.appendChild(F),e.appendChild(t),e.appendChild(n),e}function y(){document.querySelectorAll(".dropdown.show").forEach(e=>e.classList.remove("show")),document.querySelectorAll(".nested-dropdown.open").forEach(e=>e.classList.remove("open"))}async function x(e){try{let[t,n]=await Promise.all([Ae(),Te()]);console.log("[CRM Extension] Cleanup completed:"),console.log(`- Tags: ${t.removed}/${t.total} removed`),console.log(`- Automations: ${n.removed}/${n.total} removed`),Ft(e)}catch(t){console.error("[CRM Extension] Error during cleanup:",t),u("Error during cleanup. Please try again.")}}function Ft(e){let t=En();t?(t.focus(),setTimeout(()=>{t.value=e,t.dispatchEvent(new Event("input",{bubbles:!0})),setTimeout(()=>{let n=document.querySelectorAll(".v-list-item, .dropdown-item, .select-option, li"),o=!1;for(let r of n)if(r.textContent.toLowerCase().includes(e)){r.click(),o=!0,u(`Selected tag: ${e}`);break}if(!o){let r=document.querySelectorAll("*");for(let i of r)if(i.textContent.trim().toLowerCase()===e){i.click(),o=!0,u(`Selected tag: ${e}`);break}o||t.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",code:"Enter",keyCode:13,which:13,bubbles:!0}))}},300)},300)):u("Tags field not found")}function En(){let e=document.querySelector('input[placeholder="Add Tags"]');if(e)return e;let t=Array.from(document.querySelectorAll("input[placeholder]")).filter(i=>i.placeholder.toLowerCase().includes("tag"));if(t.length>0)return t[0];let n=document.querySelectorAll(".tag-input, .tags-input, .tag-container");for(let i of n){let a=i.querySelector("input");if(a)return a}if(e=document.querySelector('input[placeholder="smartList.bulkTags.addTags"]'),e)return e;let o=document.querySelectorAll(".hl-text-input");if(o.length>0)return o[0];console.error("[CRM Extension] Could not find tag input field with any strategy");let r=document.querySelectorAll("input");return console.log("[CRM Extension] All inputs on page:",r),null}var L={"Sema/B12 Refill - Step 2":"Refill - Semaglutide/B12 Injection Refill Order - (Step 2)","Sema/B12 Vial - Step 2":"Semaglutide/B12 Vial Order - (Step 2)","Sema/B6 Vial - Step 2":"Semaglutide/B6 Vial Order - (Step 2)","Sema/Lipo Vial - Step 2":"Semaglutide/Lipo Vial Order - (Step 2)","Sema/NAD+ Vial - Step 2":"Semaglutide/NAD+ Vial Order - (Step 2)","Tirz/B6 Refill - Step 2":"Syringe - Tirzepatide/Pyridoxine Injection Order - (Step 2)","Tirz/B12 Vial - Step 2":"Tirzepatide/Cyano Vial Order - (Step 2)","Tirz/NAD+ Vial - Step 2":"Tirzepatide/NAD+ Vial Order - (Step 2)","Tirz/B6 Vial - Step 2":"Tirzepatide/Pyridoxine Vial Order - (Step 2)"};function _t(){let e=document.createElement("div");e.className="dropdown",e.id="crm-automation-dropdown";let t=document.createElement("button");t.className="dropdown-btn",t.textContent="Automation",t.addEventListener("click",f=>{f.stopPropagation(),document.querySelectorAll(".dropdown.show").forEach(v=>{v!==e&&v.classList.remove("show")}),e.classList.toggle("show")});let n=document.createElement("div");if(n.className="dropdown-content",n.style.padding="10px",!document.getElementById("automation-dropdown-styles")){let f=document.createElement("style");f.id="automation-dropdown-styles",f.textContent=`
      .nested-dropdown {
        margin-bottom: 8px;
        width: 100%;
        position: relative;
      }
      .nested-dropdown-btn {
        width: 100%;
        text-align: left;
        padding: 8px 12px;
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 3px;
        cursor: pointer;
        font-weight: bold;
        font-size: 13px;
        color: #e6e6e6;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .nested-dropdown-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      .nested-dropdown-btn:after {
        content: "\u25BC";
        font-size: 8px;
        color: #e6e6e6;
      }
      .nested-dropdown-content {
        display: none;
        padding: 5px 0 5px 10px;
        margin-top: 3px !important;
      }
      .nested-dropdown.open .nested-dropdown-content {
        display: block;
      }
      
      /* Button-style options */
      .automation-btn {
        display: block;
        width: 100%;
        padding: 8px 12px;
        margin-bottom: 8px;
        background-color: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 4px;
        text-align: left;
        font-size: 13px;
        color: #e6e6e6;
        cursor: pointer;
        transition: all 0.2s ease;
        font-weight: normal;
      }
      .automation-btn:hover {
        background-color: rgba(255, 255, 255, 0.15);
        border-color: rgba(255, 255, 255, 0.2);
      }
      .automation-btn:active {
        background-color: rgba(255, 255, 255, 0.2);
      }
    `,document.head.appendChild(f)}let o=document.createElement("div");o.className="nested-dropdown";let r=document.createElement("button");r.className="nested-dropdown-btn",r.textContent="Semaglutide (Step 2)";let i=document.createElement("div");i.className="nested-dropdown-content",r.addEventListener("click",f=>{f.stopPropagation(),o.classList.toggle("open")});let a=document.createElement("button");a.className="automation-btn",a.textContent="Sema/B12 Refill - Step 2",a.addEventListener("click",f=>{f.stopPropagation(),I(),setTimeout(()=>{P(L["Sema/B12 Refill - Step 2"])},300)}),i.appendChild(a);let s=document.createElement("button");s.className="automation-btn",s.textContent="Sema/B12 Vial - Step 2",s.addEventListener("click",f=>{f.stopPropagation(),I(),setTimeout(()=>{P(L["Sema/B12 Vial - Step 2"])},300)}),i.appendChild(s);let c=document.createElement("button");c.className="automation-btn",c.textContent="Sema/B6 Vial - Step 2",c.addEventListener("click",f=>{f.stopPropagation(),I(),setTimeout(()=>{P(L["Sema/B6 Vial - Step 2"])},300)}),i.appendChild(c);let l=document.createElement("button");l.className="automation-btn",l.textContent="Sema/Lipo Vial - Step 2",l.addEventListener("click",f=>{f.stopPropagation(),I(),setTimeout(()=>{P(L["Sema/Lipo Vial - Step 2"])},300)}),i.appendChild(l);let d=document.createElement("button");d.className="automation-btn",d.textContent="Sema/NAD+ Vial - Step 2",d.addEventListener("click",f=>{f.stopPropagation(),I(),setTimeout(()=>{P(L["Sema/NAD+ Vial - Step 2"])},300)}),i.appendChild(d),o.appendChild(r),o.appendChild(i),n.appendChild(o);let m=document.createElement("div");m.className="nested-dropdown";let g=document.createElement("button");g.className="nested-dropdown-btn",g.textContent="Tirzepatide (Step 2)";let h=document.createElement("div");h.className="nested-dropdown-content",g.addEventListener("click",f=>{f.stopPropagation(),m.classList.toggle("open")});let b=document.createElement("button");b.className="automation-btn",b.textContent="Tirz/B6 Refill - Step 2",b.addEventListener("click",f=>{f.stopPropagation(),I(),setTimeout(()=>{P(L["Tirz/B6 Refill - Step 2"])},300)}),h.appendChild(b);let k=document.createElement("button");k.className="automation-btn",k.textContent="Tirz/B12 Vial - Step 2",k.addEventListener("click",f=>{f.stopPropagation(),I(),setTimeout(()=>{P(L["Tirz/B12 Vial - Step 2"])},300)}),h.appendChild(k);let S=document.createElement("button");S.className="automation-btn",S.textContent="Tirz/NAD+ Vial - Step 2",S.addEventListener("click",f=>{f.stopPropagation(),I(),setTimeout(()=>{P(L["Tirz/NAD+ Vial - Step 2"])},300)}),h.appendChild(S);let C=document.createElement("button");return C.className="automation-btn",C.textContent="Tirz/B6 Vial - Step 2",C.addEventListener("click",f=>{f.stopPropagation(),I(),setTimeout(()=>{P(L["Tirz/B6 Vial - Step 2"])},300)}),h.appendChild(C),m.appendChild(g),m.appendChild(h),n.appendChild(m),e.appendChild(t),e.appendChild(n),e}function I(){document.querySelectorAll(".dropdown.show").forEach(e=>e.classList.remove("show")),document.querySelectorAll(".nested-dropdown.open").forEach(e=>e.classList.remove("open"))}function P(e){try{console.log(`[CRM Extension] Starting workflow for "${e}"`),u(`Starting workflow for "${e}"`);let t=Array.from(document.querySelectorAll("button.btn.btn-light2.btn-xs")).find(n=>n.textContent.trim().includes("Add"));if(!t){console.error("[CRM Extension] Add Automation button not found"),u("Add Automation button not found");return}console.log("[CRM Extension] Found Add button, clicking it"),t.click(),setTimeout(()=>{let n=document.querySelector('input[placeholder="Type to search"]');if(!n){console.error("[CRM Extension] Search input not found"),u("Search input not found");return}console.log("[CRM Extension] Found search input, entering 'step 2'"),n.focus(),n.value="step 2",n.dispatchEvent(new Event("input",{bubbles:!0})),setTimeout(()=>{let o=[".v-list",".dropdown-menu",".v-select-list",".vs__dropdown-menu",'[role="listbox"]',"ul",".v-menu__content"],r=null;for(let l of o){let d=document.querySelector(l);if(d&&d.querySelector("li, .v-list-item, .dropdown-item")&&d.scrollHeight>d.clientHeight){r=d,console.log(`[CRM Extension] Found scrollable dropdown container: ${l}`);break}}if(!r){let l=document.querySelector('.modal, dialog, [role="dialog"]');if(l){let d=Array.from(l.querySelectorAll("*")).filter(m=>m.scrollHeight>m.clientHeight&&m.clientHeight>50);d.length>0&&(r=d[0],console.log("[CRM Extension] Found scrollable element via fallback method"))}}if(!r){console.error("[CRM Extension] Could not find scrollable container"),u("Could not find dropdown container");return}console.log("[CRM Extension] Starting scroll wheel simulation"),console.log(`[CRM Extension] Container dimensions: ${r.scrollHeight}x${r.clientHeight}`);let i=0,a=20,s=!1;function c(){if(s||i>=a){s||(console.error("[CRM Extension] Max scroll attempts reached without finding match"),u("Option not found after scrolling"));return}i++,console.log(`[CRM Extension] Scroll attempt ${i}/${a}`);let l=new WheelEvent("wheel",{deltaY:100,bubbles:!0});r.dispatchEvent(l),r.scrollTop+=100,console.log(`[CRM Extension] Scrolled to position: ${r.scrollTop}/${r.scrollHeight}`),setTimeout(()=>{let d=r.querySelectorAll('li, .v-list-item, .dropdown-item, [role="option"]');console.log(`[CRM Extension] Found ${d.length} options after scrolling`);for(let m of d){if(!m.textContent)continue;let g=m.textContent.trim();if(g===e&&!g.includes("Provider Paid")&&!g.includes("New Patient")){console.log(`[CRM Extension] Found exact matching option: "${g}"`);try{m.scrollIntoView({block:"center"}),setTimeout(()=>{m.click(),s=!0,setTimeout(()=>{let h=Array.from(document.querySelectorAll("button")).find(b=>b.textContent.trim()==="Add");h?(console.log("[CRM Extension] Clicking Add button in dialog"),h.click(),u(`Added "${e}" workflow`)):(console.error("[CRM Extension] Add button in dialog not found"),u("Add button in dialog not found"))},1e3)},300)}catch(h){console.error("[CRM Extension] Error clicking option:",h)}break}}if(!s){if(r.scrollHeight-r.scrollTop<=r.clientHeight+20){console.log("[CRM Extension] Reached bottom of dropdown without finding match"),u(`Reached end without finding "${e}"`);return}setTimeout(c,500)}},500)}c()},1500)},1e3)}catch(t){console.error("[CRM Extension] Error in workflow:",t),u(`Error in workflow: ${t.message}`)}}function Ht(){let e=document.createElement("div");return e.className="group",e.id="crm-dropdowns-group",e.appendChild(_t()),e.appendChild(Ot()),document.addEventListener("click",t=>{document.querySelectorAll(".dropdown").forEach(o=>{o.contains(t.target)||(o.classList.remove("show"),o.querySelectorAll(".nested-dropdown").forEach(i=>{i.classList.remove("open")}))})}),kn(),e}function kn(){if(document.getElementById("custom-dropdown-styles"))return;let e=document.createElement("style");e.id="custom-dropdown-styles",e.textContent=`
    /* Improved dropdown positioning */
    .dropdown {
      position: relative !important;
      margin-right: 8px !important; /* Ensure space between dropdowns, reduced for tighter layout */
    }
    
    .dropdown:last-child {
      margin-right: 0 !important; /* Remove margin from the last dropdown */
    }
    
    .dropdown-content {
      position: absolute !important;
      background-color: #2F3A4B; /* Match toolbar background color */
      min-width: 220px !important; /* Increased width */
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.3);
      z-index: 999;
      border-radius: 4px;
      margin-top: 5px !important; /* Add space between button and dropdown */
      left: 0;
      top: 100% !important; /* Position below the button */
      display: none;
      border: 1px solid rgba(255, 255, 255, 0.1); /* Subtle border */
    }
    
    /* Ensure right-aligned dropdowns don't overflow */
    #crm-tags-dropdown .dropdown-content {
      right: 0;
      left: auto; /* Override left positioning for Tags dropdown */
    }
    
    .dropdown.show .dropdown-content {
      display: block;
    }
    
    /* Improved nested dropdown positioning */
    .nested-dropdown-content {
      margin-top: 3px !important;
      background-color: #2F3A4B; /* Match toolbar background color */
      border-radius: 4px;
      padding: 5px !important;
    }
    
    /* Style dropdown items */
    .dropdown-item {
      color: #e6e6e6; /* White text for visibility */
      padding: 10px 14px !important; /* Increased padding */
      text-decoration: none;
      display: block;
      font-size: 14px;
      cursor: pointer;
      border-radius: 3px;
      font-weight: normal;
    }
    
    .dropdown-item:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
    
    /* Fix for Vial-Sema and Vial-Tirz nested dropdowns */
    .nested-dropdown-btn {
      text-align: left !important;
      padding: 8px 12px !important;
      background-color: rgba(255, 255, 255, 0.1) !important;
      border: 1px solid rgba(255, 255, 255, 0.15) !important;
      color: #e6e6e6 !important;
      font-weight: bold !important;
    }
    
    .nested-dropdown-btn:hover {
      background-color: rgba(255, 255, 255, 0.2) !important;
    }
    
    /* Force visibility for Tags dropdown */
    #crm-tags-dropdown {
      display: flex !important;
    }
    
    #crm-tags-dropdown .dropdown-content {
      min-width: 220px !important;
    }
  `,document.head.appendChild(e)}function Ut(){let e=document.createElement("div");e.className="group",e.id="crm-settings-group",e.style.position="relative";let t=document.createElement("button");t.className="btn",t.id="crm-settings-btn";let n=document.createElement("span");n.className="btn-icon",n.innerHTML="\u2699\uFE0F",t.appendChild(n);let o=document.createElement("span");o.textContent="Settings",t.appendChild(o);let r=Nn();if(t.addEventListener("click",i=>{i.stopPropagation(),r.classList.toggle("show")}),document.addEventListener("click",i=>{i.target!==t&&!t.contains(i.target)&&i.target!==r&&!r.contains(i.target)&&r.classList.remove("show")}),!document.getElementById("settings-dropdown-styles")){let i=document.createElement("style");i.id="settings-dropdown-styles",i.textContent=`
      #mcp-crm-settings-dropdown {
        display: none;
        position: absolute;
        top: calc(100% + 5px); /* Position below the button with 5px gap */
        right: 0;
        z-index: 1000;
        min-width: 230px;
        background-color: #2F3A4B;
        border-radius: 4px;
        border: 1px solid rgba(255, 255, 255, 0.1);
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
        overflow: hidden;
      }
      
      #mcp-crm-settings-dropdown.show {
        display: block;
      }
      
      .settings-header {
        padding: 10px;
        background-color: rgba(255, 255, 255, 0.1);
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        font-weight: bold;
        color: #e6e6e6;
      }
      
      .settings-body {
        padding: 10px;
        color: #e6e6e6;
      }
      
      .setting-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
        font-size: 13px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        padding-bottom: 10px;
      }
      
      .setting-item:last-child {
        margin-bottom: 0;
        border-bottom: none;
        padding-bottom: 0;
      }
      
      .setting-label {
        color: #e6e6e6;
        font-weight: normal;
      }
      
      /* Toggle switch styles */
      .switch {
        position: relative;
        display: inline-block;
        width: 40px;
        height: 20px;
      }
      
      .switch input {
        opacity: 0;
        width: 0;
        height: 0;
      }
      
      .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #555;
        transition: .4s;
        border-radius: 34px;
      }
      
      .slider:before {
        position: absolute;
        content: "";
        height: 16px;
        width: 16px;
        left: 2px;
        bottom: 2px;
        background-color: white;
        transition: .4s;
        border-radius: 50%;
      }
      
      input:checked + .slider {
        background-color: #2196F3;
      }
      
      input:focus + .slider {
        box-shadow: 0 0 1px #2196F3;
      }
      
      input:checked + .slider:before {
        transform: translateX(20px);
      }
      
      /* Version info styles */
      .version-info {
        border-top: 1px solid rgba(255, 255, 255, 0.1);
        margin-top: 10px;
        padding-top: 10px;
        font-size: 12px;
        color: #e6e6e6;
      }
      
      .version-info p {
        margin: 5px 0;
        color: #e6e6e6;
      }
      
      .version-number {
        font-weight: 600;
        color: #e6e6e6;
      }
      
      .check-updates-btn {
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 3px;
        padding: 4px 8px;
        margin-top: 5px;
        font-size: 11px;
        cursor: pointer;
        transition: background-color 0.2s;
        width: 100%;
        text-align: center;
        color: #e6e6e6;
      }
      
      .check-updates-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      
      .check-updates-btn:disabled {
        opacity: 0.6;
        cursor: not-allowed;
      }
      
      #crm-update-status {
        margin: 5px 0 0 0;
        padding: 3px 6px;
        font-size: 11px;
        border-radius: 3px;
        background-color: rgba(255, 255, 255, 0.05);
        text-align: center;
        transition: all 0.3s ease;
        color: #e6e6e6;
      }
      
      #last-update-check {
        font-size: 11px;
        margin: 5px 0;
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        color: #e6e6e6;
      }
      
      .check-status {
        font-size: 10px;
        margin-left: 5px;
        padding: 1px 4px;
        border-radius: 3px;
        font-weight: normal;
      }
      
      .loading-text {
        font-style: italic;
        color: #aaa;
      }
      
      /* Section styles */
      .setting-section {
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      }
      
      .setting-section-title {
        font-size: 12px;
        font-weight: bold;
        color: #e6e6e6;
        margin-bottom: 10px;
      }
    `,document.head.appendChild(i)}return e.appendChild(t),e.appendChild(r),e}function Sn(e){try{(typeof browser<"u"?browser:chrome).runtime.sendMessage({action:"getLastUpdateCheck"}).then(n=>{if(n&&n.success&&n.lastUpdateCheck){let o=n.lastUpdateCheck,r="",i="";o.success?o.status==="update_available"?(r="Update available",i="#4CAF50"):o.status==="no_update"?(r="No updates needed",i="#2196F3"):o.status==="throttled"?(r="Check throttled",i="#FF9800"):(r="Completed",i="#2196F3"):(r="Failed",i="#F44336"),e.innerHTML=`Last Check: <span class="version-number">${o.formattedTime}</span> <span class="check-status" style="color:${i};font-size:10px;margin-left:5px;">${r}</span>`}else e.innerHTML='Last Check: <span class="version-number">No checks recorded</span>'}).catch(n=>{console.error("[CRM Extension] Error fetching last update check:",n),e.innerHTML='Last Check: <span class="version-number">Unknown</span>'})}catch(t){console.error("[CRM Extension] Error in fetchLastUpdateCheckInfo:",t),e.innerHTML='Last Check: <span class="version-number">Error</span>'}}function Nn(){let e=document.createElement("div");e.id="mcp-crm-settings-dropdown";let t=document.createElement("div");t.className="settings-header",t.textContent="CRM+ Settings",e.appendChild(t);let n=document.createElement("div");if(n.className="settings-body",e.appendChild(n),!document.getElementById("collapsible-settings-styles")){let s=document.createElement("style");s.id="collapsible-settings-styles",s.textContent=`
      .setting-section {
        margin-bottom: 8px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        padding-bottom: 0; /* No bottom padding when collapsed */
      }
      
      .setting-section-title {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 13px;
        font-weight: bold;
        color: #e6e6e6;
        padding: 8px 0;
        cursor: pointer;
        user-select: none;
      }
      
      .setting-section-title:after {
        content: "\u25BC";
        font-size: 8px;
        color: #e6e6e6;
        transition: transform 0.2s ease;
      }
      
      .setting-section.collapsed .setting-section-title:after {
        transform: rotate(-90deg);
      }
      
      .setting-section-content {
        max-height: 500px;
        overflow: hidden;
        transition: max-height 0.3s ease, opacity 0.2s ease, margin-bottom 0.3s ease;
        opacity: 1;
        margin-bottom: 10px;
      }
      
      .setting-section.collapsed .setting-section-content {
        max-height: 0;
        opacity: 0;
        margin-bottom: 0;
      }
    `,document.head.appendChild(s)}let o=_e("General Settings");o.content.appendChild($("Show Header Bar","crmplus_headerBarVisible",s=>{let c=document.getElementById("mcp-crm-header");c&&(c.style.display=s?"flex":"none",document.body.style.paddingTop=s?"32px":"0"),u(`Header bar: ${s?"Visible":"Hidden"}`)},!0)),o.content.appendChild($("Show Provider-Paid Alerts","crmplus_showProviderPaidAlerts",s=>{u(`Provider-Paid alerts: ${s?"Enabled":"Disabled"}`)},!0)),n.appendChild(o.section);let r=_e("External Links");r.content.appendChild($("Show ShipStation Link","crmplus_showShipStation",s=>{let c=document.querySelector(".shipstation-link");c&&(c.style.display=s?"flex":"none"),u(`ShipStation link: ${s?"Visible":"Hidden"}`)},!0)),r.content.appendChild($("Show Stripe Link","crmplus_showStripe",s=>{let c=document.querySelector(".stripe-link");c&&(c.style.display=s?"flex":"none"),u(`Stripe link: ${s?"Visible":"Hidden"}`)},!0)),r.content.appendChild($("Show Webmail Link","crmplus_showWebmail",s=>{let c=document.querySelector(".webmail-link");c&&(c.style.display=s?"flex":"none"),u(`Webmail link: ${s?"Visible":"Hidden"}`)},!0)),n.appendChild(r.section);let i=_e("Features");i.content.appendChild($("Auto-copy phone number on page load","crmplus_autoCopyPhone",s=>{u(`Auto-copy phone: ${s?"Enabled":"Disabled"}`)},!1)),i.content.appendChild($("CRM Automation","crmplus_automationEnabled",s=>{[document.getElementById("crm-automation-dropdown"),document.getElementById("crm-tags-dropdown")].forEach(l=>{l?(l.style.display=s?"flex":"none",console.log(`[CRM Extension] Changed visibility for ${l.id}: ${s?"visible":"hidden"}`)):console.error("[CRM Extension] Could not find automation element to toggle")}),u(`CRM Automation: ${s?"Enabled":"Disabled"}`)},!0)),n.appendChild(i.section);let a=Mn();return n.appendChild(a),e}function _e(e,t=!1){let n=document.createElement("div");n.className="setting-section"+(t?" collapsed":"");let o=document.createElement("div");o.className="setting-section-title",o.textContent=e,o.addEventListener("click",()=>{n.classList.toggle("collapsed")}),n.appendChild(o);let r=document.createElement("div");return r.className="setting-section-content",n.appendChild(r),{section:n,content:r}}function Mn(){let e=document.createElement("div");e.className="version-info";let t="Loading...",n="Loading...";try{let c=(typeof browser<"u"?browser:chrome).runtime.getManifest();if(c&&c.version&&(t=c.version,t.includes("."))){let l=t.split(".");if(l.length===3&&l[0].length===4){let d=l[0],m=l[1],g=l[2];n=`${m}/${g}/${d}`}}}catch(s){console.error("[CRM Extension] Error fetching version:",s),t="Unknown",n="Unknown"}let o=document.createElement("p");o.innerHTML=`Version: <span class="version-number">${t}</span>`,e.appendChild(o);let r=document.createElement("p");r.innerHTML=`Last Updated: <span class="version-number">${n}</span>`,e.appendChild(r);let i=document.createElement("p");i.id="last-update-check",i.innerHTML='Last Check: <span class="loading-text">Loading...</span>',e.appendChild(i),Sn(i);let a=document.createElement("button");return a.className="check-updates-btn",a.textContent="Check for Updates",a.addEventListener("click",()=>{let s=typeof browser<"u"?browser:chrome;a.disabled=!0,a.textContent="Checking...",u("Checking for updates...");let c=document.getElementById("crm-update-status");c||(c=document.createElement("p"),c.id="crm-update-status",c.style.fontSize="11px",c.style.marginTop="5px",c.style.color="#e6e6e6",c.textContent="",e.appendChild(c)),s.runtime.sendMessage({action:"checkForUpdates"}).then(l=>{if(l&&l.success){u("Update check completed"),l.updateStatus==="update_available"?(c.textContent=`Update available (${l.updateVersion})`,c.style.color="#4CAF50"):l.updateStatus==="no_update"?(c.textContent="You have the latest version",c.style.color="#2196F3"):l.updateStatus==="throttled"?(c.textContent="Update check throttled, try again later",c.style.color="#FF9800"):l.updateStatus==="error"?(c.textContent="Error checking for updates",c.style.color="#F44336"):(c.textContent="Update check initiated",c.style.color="#e6e6e6");let d=document.getElementById("last-update-check");if(d&&l.lastCheck){let m=l.lastCheck,g="",h="";m.success?m.status==="update_available"?(g="Update available",h="#4CAF50"):m.status==="no_update"?(g="No updates needed",h="#2196F3"):m.status==="throttled"?(g="Check throttled",h="#FF9800"):(g="Completed",h="#2196F3"):(g="Failed",h="#F44336"),d.innerHTML=`Last Check: <span class="version-number">${m.formattedTime}</span> <span class="check-status" style="color:${h};font-size:10px;margin-left:5px;">${g}</span>`}}else u("Error checking for updates"),c.textContent="Update check failed",c.style.color="#F44336";a.disabled=!1,a.textContent="Check for Updates"}).catch(l=>{console.error("[CRM Extension] Error sending update check message:",l),u("Error checking for updates"),c.textContent="Connection failed",c.style.color="#F44336",a.disabled=!1,a.textContent="Check for Updates"})}),e.appendChild(a),e}function $(e,t,n,o=!1){let r=document.createElement("div");r.className="setting-item";let i=document.createElement("div");i.className="setting-label",i.textContent=e,r.appendChild(i);let a=document.createElement("label");a.className="switch";let s=document.createElement("input");s.type="checkbox";let c=localStorage.getItem(t),l=c!==null?c==="true":o;c===null&&localStorage.setItem(t,o.toString()),s.checked=l,s.addEventListener("change",()=>{let m=s.checked;localStorage.setItem(t,m.toString()),n&&typeof n=="function"&&n(m)});let d=document.createElement("span");return d.className="slider",a.appendChild(s),a.appendChild(d),r.appendChild(a),r}function jt(){if(document.getElementById("mcp-crm-header-styles"))return;let e=document.createElement("style");e.id="mcp-crm-header-styles",e.textContent=`
    #mcp-crm-header {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 32px;
      background-color: #2F3A4B;
      display: flex;
      align-items: center;
      padding: 0 15px;
      font-family: 'Segoe UI', 'Roboto', sans-serif;
      font-size: 12px;
      z-index: 999999;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    }
    
    #mcp-crm-header .group {
      display: flex;
      align-items: center;
      margin-right: 15px;
      border-right: 1px solid rgba(255, 255, 255, 0.1);
      padding-right: 15px;
    }
    
    #mcp-crm-header .group:last-child {
      border-right: none;
      margin-right: 0; /* Remove margin from the last group (Settings) */
    }
    
    /* Special styling for dropdowns group to match other elements' spacing */
    #crm-dropdowns-group {
      margin-right: 15px; /* Same spacing as other elements */
      padding-right: 15px; /* Same padding as other elements */
    }
    
    /* Ensure settings is positioned at the far right */
    #crm-settings-btn {
      margin-right: 0;
    }
    
    #mcp-crm-header .spacer {
      flex-grow: 1;
    }
    
    #mcp-crm-header .label {
      color: #8a9cad;
      margin-right: 6px;
      font-weight: 500;
    }
    
    #mcp-crm-header .value {
      color: #e6e6e6;
      font-weight: 600;
    }
    
    #mcp-crm-header .clickable-value {
      color: #e6e6e6;
      font-weight: 600;
      cursor: pointer;
      background-color: rgba(255, 255, 255, 0.05);
      padding: 2px 8px;
      border-radius: 3px;
      transition: background-color 0.2s;
      display: inline-flex;
      align-items: center;
    }
    
    #mcp-crm-header .clickable-value:hover {
      background-color: rgba(255, 255, 255, 0.15);
    }
    
    #mcp-crm-header .btn-icon {
      margin-right: 4px;
      font-size: 10px;
    }
    
    /* Logo link styling */
    #mcp-crm-header .logo-link {
      display: flex;
      align-items: center;
      text-decoration: none;
      transition: all 0.2s ease;
    }
    
    #mcp-crm-header .logo-link:hover {
      opacity: 0.85;
    }
    
    #mcp-crm-header .logo-icon {
      width: 16px;
      height: 16px;
      margin-right: 6px;
    }
    
    #mcp-crm-header .logo {
      font-weight: bold;
      color: white;
      font-size: 14px;
    }
    
    #mcp-crm-header .external-link {
      text-decoration: none;
      color: #e6e6e6;
      display: flex;
      align-items: center;
      transition: all 0.2s ease;
      margin-right: 10px;
    }
    
    #mcp-crm-header .external-link:hover {
      background: rgba(255, 255, 255, 0.2);
      transform: translateY(-1px);
    }
    
    #mcp-crm-header .ext-link-icon {
      font-size: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    /* Styling for text links with icons */
    #mcp-crm-header .text-link {
      text-decoration: none;
      margin-right: 4px; /* Reduced margin between buttons */
      font-size: 12px;
      padding: 3px 6px; /* Reduced horizontal padding to make buttons skinnier */
      border-radius: 3px;
      color: #e6e6e6;
      display: flex;
      align-items: center;
      justify-content: center; /* Center content horizontally */
      white-space: nowrap; /* Prevent text wrapping */
      min-width: 68px; /* Set minimum width to keep consistency */
    }
    
    #mcp-crm-header .text-link:hover {
      background-color: rgba(255, 255, 255, 0.15);
    }
    
    #mcp-crm-header .text-link .link-icon {
      margin-right: 4px; /* Slightly reduced margin for tighter look */
      width: 16px;
      height: 16px;
      vertical-align: middle;
      flex-shrink: 0; /* Prevent icon from shrinking */
    }
    
    /* Add a specific class for each button to fine-tune widths if needed */
    #mcp-crm-header .shipstation-link {
      min-width: 92px;
    }
    
    #mcp-crm-header .stripe-link {
      min-width: 65px;
    }
    
    #mcp-crm-header .webmail-link {
      min-width: 78px;
    }
    
    #mcp-crm-header .btn {
      color: #e6e6e6;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 3px;
      padding: 4px 8px;
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      margin-right: 8px;
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
    }
    
    #mcp-crm-header .btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    #mcp-crm-header .btn:active {
      background-color: rgba(255, 255, 255, 0.3);
    }
    
    #mcp-crm-header .btn:last-child {
      margin-right: 0;
    }
    
    /* Dropdown styling */
    .dropdown {
      position: relative;
      display: inline-block;
      margin-right: 8px;
    }
    
    .dropdown-btn {
      color: #e6e6e6;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 3px;
      padding: 4px 8px;
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
      justify-content: space-between;
      min-width: 100px;
    }
    
    .dropdown-btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .dropdown-btn:after {
      content: "\u25BC";
      font-size: 8px;
      margin-left: 5px;
    }
    
    .dropdown-content {
      display: none;
      position: absolute;
      background-color: #2F3A4B;
      min-width: 180px;
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.3);
      z-index: 1000000;
      border-radius: 4px;
      border: 1px solid rgba(255, 255, 255, 0.1);
      margin-top: 2px;
      left: 0;
    }
    
    .dropdown.show .dropdown-content {
      display: block;
    }
    
    .dropdown-item {
      color: #e6e6e6;
      padding: 8px 12px;
      text-decoration: none;
      display: block;
      font-size: 12px;
      cursor: pointer;
      font-weight: normal;
    }
    
    .dropdown-item:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
    
    /* Nested Dropdown styling */
    .nested-dropdown {
      margin-bottom: 5px;
      width: 100%;
    }
    
    .nested-dropdown-btn {
      width: 100%;
      text-align: left;
      padding: 6px 10px;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 3px;
      cursor: pointer;
      font-weight: bold;
      font-size: 12px;
      color: #e6e6e6;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .nested-dropdown-btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .nested-dropdown-btn:after {
      content: "\u25BC";
      font-size: 8px;
      color: #e6e6e6;
    }
    
    .nested-dropdown-content {
      display: none;
      padding: 5px 0 5px 10px;
      background-color: #2F3A4B;
    }
    
    .nested-dropdown.open .nested-dropdown-content {
      display: block;
    }
    
    .nested-dropdown-item {
      display: block;
      padding: 5px 10px;
      color: #e6e6e6;
      text-decoration: none;
      font-size: 12px;
      cursor: pointer;
      border-radius: 3px;
      font-weight: normal;
    }
    
    .nested-dropdown-item:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
    
    /* Settings dropdown styling */
    #mcp-crm-settings-dropdown {
      position: absolute;
      top: 32px;
      right: 15px;
      background-color: #2F3A4B;
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 4px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.3);
      min-width: 200px;
      z-index: 1000000;
      display: none;
      color: #e6e6e6;
    }
    
    #mcp-crm-settings-dropdown.show {
      display: block;
    }
    
    #mcp-crm-settings-dropdown .settings-header {
      background-color: rgba(255, 255, 255, 0.1);
      color: #e6e6e6;
      padding: 8px 12px;
      font-weight: bold;
      border-top-left-radius: 3px;
      border-top-right-radius: 3px;
    }
    
    #mcp-crm-settings-dropdown .settings-body {
      padding: 10px;
    }
    
    #mcp-crm-settings-dropdown .setting-item {
      display: flex;
      align-items: center;
      margin-bottom: 8px;
      padding-bottom: 8px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    #mcp-crm-settings-dropdown .setting-item:last-child {
      margin-bottom: 0;
      padding-bottom: 0;
      border-bottom: none;
    }
    
    #mcp-crm-settings-dropdown .setting-label {
      flex-grow: 1;
      font-size: 13px;
      color: #e6e6e6;
    }
    
    /* Toggle switch styling */
    .switch {
      position: relative;
      display: inline-block;
      width: 40px;
      height: 20px;
    }
    
    .switch input { 
      opacity: 0;
      width: 0;
      height: 0;
    }
    
    .slider {
      position: absolute;
      cursor: pointer;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: #555;
      transition: .4s;
      border-radius: 34px;
    }
    
    .slider:before {
      position: absolute;
      content: "";
      height: 16px;
      width: 16px;
      left: 2px;
      bottom: 2px;
      background-color: white;
      transition: .4s;
      border-radius: 50%;
    }
    
    input:checked + .slider {
      background-color: #2196F3;
    }
    
    input:checked + .slider:before {
      transform: translateX(20px);
    }
    
    /* Version info section in settings */
    .version-info {
      border-top: 1px solid rgba(255, 255, 255, 0.1);
      margin-top: 10px;
      padding-top: 10px;
      font-size: 12px;
      color: #e6e6e6;
    }
    
    .version-info p {
      margin: 5px 0;
    }
    
    .version-number {
      font-weight: 600;
      color: #e6e6e6;
    }
    
    .check-updates-btn {
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 3px;
      padding: 4px 8px;
      margin-top: 5px;
      font-size: 11px;
      cursor: pointer;
      transition: background-color 0.2s;
      width: 100%;
      text-align: center;
      color: #e6e6e6;
    }
    
    .check-updates-btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .check-updates-btn:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
  `,document.head.appendChild(e)}function Gt(){let e=document.createElement("div");e.className="dropdown",e.id="crm-history-dropdown";let t=document.createElement("button");t.className="dropdown-btn",t.textContent="History",t.addEventListener("click",s=>{s.stopPropagation(),document.querySelectorAll(".dropdown.show").forEach(c=>{c!==e&&c.classList.remove("show")}),e.classList.toggle("show"),e.classList.contains("show")&&Wt(e)});let n=document.createElement("div");if(n.className="dropdown-content",n.id="crm-history-content",n.style.width="300px",n.style.maxHeight="400px",n.style.overflowY="auto",n.style.right="0",n.style.left="auto",!document.getElementById("history-dropdown-styles")){let s=document.createElement("style");s.id="history-dropdown-styles",s.textContent=`
      #crm-history-dropdown .dropdown-content {
        padding: 0;
        right: 0;
        left: auto;
      }
      
      /* For small screens, make sure the dropdown doesn't extend beyond viewport */
      @media screen and (max-width: 768px) {
        #crm-history-dropdown .dropdown-content {
          right: 0;
          left: auto;
          max-width: 100vw;
          width: 280px; /* Slightly smaller on small screens */
        }
      }
      
      .history-header {
        padding: 10px;
        background-color: rgba(255, 255, 255, 0.1);
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      
      .history-title {
        font-weight: bold;
        color: #e6e6e6;
        font-size: 14px;
      }
      
      .history-clear-btn {
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 3px;
        padding: 2px 6px;
        font-size: 11px;
        cursor: pointer;
        color: #e6e6e6;
        transition: background-color 0.2s;
      }
      
      .history-clear-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      
      .history-empty {
        padding: 20px;
        text-align: center;
        color: #aaa;
        font-style: italic;
        font-size: 13px;
      }
      
      .history-item {
        padding: 10px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        cursor: pointer;
        transition: background-color 0.2s;
      }
      
      .history-item:hover {
        background-color: rgba(255, 255, 255, 0.1);
      }
      
      .history-item:last-child {
        border-bottom: none;
      }
      
      .history-item-row {
        display: flex;
        margin-bottom: 3px;
        width: 100%;
      }
      
      .history-item-time {
        color: #aaa;
        font-size: 11px;
        width: 60px;
        flex-shrink: 0;
        margin-right: 5px;
      }
      
      .history-item-name {
        font-weight: bold;
        color: #e6e6e6;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        flex-grow: 1;
      }
      
      .history-item-phone {
        color: #ccc;
        font-size: 12px;
        margin-left: 65px; /* Align with name (time width + margin) */
      }
    `,document.head.appendChild(s)}let o=document.createElement("div");o.className="history-header";let r=document.createElement("div");r.className="history-title",r.textContent="Recent Patients",o.appendChild(r);let i=document.createElement("button");i.className="history-clear-btn",i.textContent="Clear All",i.addEventListener("click",s=>{s.stopPropagation(),Ct(),Wt(e),u("History cleared")}),o.appendChild(i),n.appendChild(o);let a=document.createElement("div");return a.className="history-empty",a.textContent="No patient history yet",n.appendChild(a),e.appendChild(t),e.appendChild(n),e}function Wt(e){let t=e.querySelector("#crm-history-content");if(!t)return;let n=yt(),o=t.querySelector(".history-header");if(t.innerHTML="",o&&t.appendChild(o),n.length===0){let r=document.createElement("div");r.className="history-empty",r.textContent="No patient history yet",t.appendChild(r);return}n.forEach(r=>{let i=document.createElement("div");i.className="history-item",i.addEventListener("click",()=>{window.location.href=r.url,e.classList.remove("show")});let a=document.createElement("div");a.className="history-item-row";let s=document.createElement("div");s.className="history-item-time",s.textContent=wt(r.timestamp);let c=document.createElement("div");if(c.className="history-item-name",c.textContent=r.patientName||"Unknown Patient",a.appendChild(s),a.appendChild(c),i.appendChild(a),r.phoneNumber){let l=document.createElement("div");l.className="history-item-phone",l.textContent=r.phoneNumber,i.appendChild(l)}t.appendChild(i)})}var Rn=!1;function Ue(){try{if(document.getElementById("mcp-crm-header")){console.log("[uiHeaderBar] Toolbar already exists.");return}jt();let e=document.createElement("div");e.id="mcp-crm-header";let t=localStorage.getItem("crmplus_headerBarVisible")!=="false";console.log("[CRM Extension] Header visibility setting:",t),e.style.display=t?"flex":"none";let n=typeof browser<"u"?browser:chrome,o=E=>n.runtime.getURL(E),r=document.createElement("div");r.className="group";let i=document.createElement("a");i.href="https://app.mtncarerx.com/",i.className="logo-link";let a=document.createElement("img");a.src=o("assets/mcp-favicon.ico"),a.alt="",a.className="logo-icon",i.appendChild(a);let s=document.createElement("span");s.className="logo",s.textContent="CRM+",i.appendChild(s),r.appendChild(i);let c=document.createElement("div");c.className="group external-links";let l=He("ShipStation","https://ship15.shipstation.com/onboard","shipstation-link",o("assets/shipstation-favicon.ico"));c.appendChild(l);let d=He("Stripe","https://dashboard.stripe.com/login","stripe-link",o("assets/stripe-favicon.ico"));c.appendChild(d);let m=He("Webmail","https://p3plzcpnl506102.prod.phx3.secureserver.net:2096/cpsess5640910985/webmail/jupiter/index.html?login=1&post_login=89371011642013","webmail-link",o("assets/webmail-favicon.ico"));c.appendChild(m);let g=X("name","Name"),h=X("phone","Phone",{icon:"\u{1F4DE}",initialValue:"",onClick:async E=>{et(E)}}),b=X("dob","DOB"),k=X("srxid","SRx ID"),S=Vt(),C=Ht(),f=document.createElement("div");f.className="spacer";let v=document.createElement("div");v.className="group right-buttons",v.style.borderRight="none",v.style.display="flex",v.style.marginRight="0";let q=Ve();q.style.marginRight="8px";let N=Gt();v.appendChild(q),v.appendChild(N);let O=Ut();e.appendChild(r),e.appendChild(c),e.appendChild(g),e.appendChild(h),e.appendChild(b),e.appendChild(k),e.appendChild(C),e.appendChild(S),e.appendChild(f),e.appendChild(v),e.appendChild(O),document.body.appendChild(e),document.body.style.paddingTop=t?"32px":"0",setTimeout(()=>{try{let E=localStorage.getItem("crmplus_automationEnabled")==="true";[document.getElementById("crm-automation-dropdown"),document.getElementById("crm-tags-dropdown")].forEach(D=>{D&&(D.style.display=E?"flex":"none",console.log(`[CRM Extension] Initial visibility for ${D.id}: ${E?"visible":"hidden"}`))})}catch(E){console.error("[CRM Extension] Error setting initial automation visibility:",E)}},100),R(),nt(),it(),Qe(),ct(),bt(),qe(),G(E=>{if(E.length>0){let T=E[0];u(`New message from ${T.sender}: ${T.text.substring(0,30)}${T.text.length>30?"...":""}`,3e3)}}),window.addEventListener("popstate",function(){console.log("[CRM Extension] Navigation detected, clearing phone display"),R()}),An()||R(),Rn=!0,console.log("[CRM Extension] Header successfully initialized")}catch(e){console.error("[CRM Extension] Critical error creating toolbar:",e);try{let t=document.getElementById("mcp-crm-header");t&&(t.style.display="flex")}catch(t){console.error("[CRM Extension] Failed to recover toolbar:",t)}}}function He(e,t,n="",o=""){let r=document.createElement("a");r.href=t,r.target="_blank",r.className=`text-link btn ${n}`,r.rel="noopener noreferrer";let i=document.createElement("div");if(i.style.display="flex",i.style.alignItems="center",i.style.justifyContent="center",i.style.width="100%",o){let s=document.createElement("img");s.src=o,s.alt="",s.className="link-icon",s.style.width="16px",s.style.height="16px",s.style.marginRight="4px",i.appendChild(s)}let a=document.createElement("span");return a.textContent=e,i.appendChild(a),r.appendChild(i),r}function An(){let e=window.location.href;return[/\/patient\/\d+/i,/\/contact\/\d+/i,/\/profile\/\d+/i,/[?&]patient_id=\d+/i,/[?&]contact_id=\d+/i].some(o=>o.test(e))?!0:['input[name="contact.phone"]','input[name="contact.first_name"]','input[name="contact.last_name"]','input[name="contact.date_of_birth"]',".patient-info",".contact-details",".patient-header",".patient-profile"].some(o=>document.querySelector(o)!==null)}function je(e){try{let t=document.getElementById("mcp-crm-header");if(t){console.log(`[CRM Extension] Setting header visibility to: ${e}`),t.style.display=e?"flex":"none";let n=document.body.classList.contains("has-alert");return e?(document.body.style.paddingTop=n?"72px":"32px",document.body.classList.remove("no-header")):(document.body.style.paddingTop=n?"40px":"0",document.body.classList.add("no-header")),localStorage.setItem("crmplus_headerBarVisible",e.toString()),!0}else if(e)return console.log("[CRM Extension] Header not found but should be visible, creating it"),Ue(),!0;return!1}catch(t){return console.error("[CRM Extension] Error toggling header visibility:",t),!1}}function Xt(){if(!(localStorage.getItem("crmplus_autoCopyPhone")==="true")){console.log("[CRM Extension] Auto-copy phone is disabled");return}let t=()=>{let o=le();if(o){let r=Re(o);r&&H(r).then(i=>{if(i)return u("Phone number auto-copied: "+r),!0})}return!1};if(t())return;let n=new MutationObserver((o,r)=>{t()&&r.disconnect()});n.observe(document.body,{childList:!0,subtree:!0,attributes:!0,characterData:!0}),setTimeout(()=>{n.disconnect(),t()},5e3)}var Yt=!1,Y=new Set,Ee="",Ge=!1,ke=null,We=null;function Kt(){Yt||(Tn(),Ln(),Yt=!0,console.log("[CRM Extension] Alert system initialized"))}function Tn(){if(document.getElementById("crm-alert-styles"))return;let e=document.createElement("style");e.id="crm-alert-styles",e.textContent=`
    .crm-alert-banner {
      position: fixed;
      top: 32px; /* Positioned right below the header bar */
      left: 0;
      right: 0;
      width: 100%;
      padding: 4px 15px; /* Reduced vertical padding for smaller height */
      font-size: 13px;
      font-weight: 500;
      z-index: 999990;
      display: flex;
      align-items: center;
      justify-content: center; /* Center contents horizontally */
      transition: all 0.3s ease;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
      transform: translateY(-100%);
      opacity: 0;
      height: 25px; /* Fixed height at 3/4 of original (approx) */
    }
    
    .crm-alert-banner.show {
      transform: translateY(0);
      opacity: 1;
    }
    
    .crm-alert-banner .alert-icon {
      margin-right: 8px;
      font-size: 16px;
    }
    
    .crm-alert-banner .alert-message {
      text-align: center; /* Center the text */
      margin: 0 auto; /* Center with auto margins */
      flex-grow: 0; /* Don't grow to fill space */
    }
    
    /* Provider Paid specific alert styling */
    .crm-alert-banner.provider-paid {
      background-color: #FFAB40; /* Orange */
      color: #5F4200;
      border-bottom: 1px solid #FF9100;
    }
    
    /* Adjust body padding to accommodate the alert banner */
    body.has-alert {
      padding-top: 72px !important; /* 32px (header) + approx alert height */
    }
    
    /* When header is hidden but alert is visible */
    body.no-header.has-alert {
      padding-top: 25px !important; /* Just the alert height */
    }
    
    /* Multiple alerts stacking */
    .crm-alert-banner.second-alert {
      top: 57px;
    }
    
    .crm-alert-banner.third-alert {
      top: 82px;
    }
    
    /* Countdown timer styling */
    .countdown-timer {
      margin-left: 5px;
      font-size: 11px;
      opacity: 0.75;
      background-color: rgba(0, 0, 0, 0.1);
      padding: 1px 4px;
      border-radius: 3px;
      min-width: 30px;
      text-align: center;
    }
  `,document.head.appendChild(e)}function Jt(){let e=window.location.href,t=[/\/patient\/(\d+)/i,/\/contact\/(\d+)/i,/\/profile\/(\d+)/i,/[?&]patient_id=(\d+)/i,/[?&]contact_id=(\d+)/i];for(let n of t){let o=e.match(n);if(o&&o[1])return o[1]}return""}function Ln(){Ee=Jt(),Se(),ke&&ke.disconnect(),ke=new MutationObserver(e=>{for(let t of e)t.type==="childList"&&Se(),t.type==="attributes"&&(t.target.classList.contains("tag")||t.target.classList.contains("tag-label")||t.target.classList.contains("provider-paid"))&&Se()}),ke.observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["class","data-tag"]}),We&&clearInterval(We),We=setInterval(()=>{let e=Jt();e!==Ee&&(console.log("[CRM Extension] Navigation detected, patient changed from",Ee,"to",e),Ee=e,Ge=!1,Ne("provider-paid"),setTimeout(Se,1e3))},1e3)}function Se(){if(!(localStorage.getItem("crmplus_showProviderPaidAlerts")!=="false")){Ne("provider-paid");return}In()?Ge||Pn():Ne("provider-paid")}function In(){let e=document.querySelectorAll(".tag, .tag-label, .pill, .badge");for(let r of e)if(r.textContent.toLowerCase().includes("provider-paid"))return r;let t=document.querySelectorAll(".provider-paid");if(t.length>0)return t[0];let n=document.querySelectorAll('[data-tag="provider-paid"], [data-tag-name="provider-paid"]');if(n.length>0)return n[0];let o=document.querySelectorAll(".tags-container, .tag-list, .tags");for(let r of o)if(r.textContent.toLowerCase().includes("provider-paid"))return r;return null}function Pn(){if(Y.has("provider-paid"))return;Ge=!0;let e=document.createElement("div");e.className="crm-alert-banner provider-paid",e.id="provider-paid-alert",e.setAttribute("data-alert-type","provider-paid");let t=document.createElement("span");t.className="alert-icon",t.innerHTML="\u26A0\uFE0F",e.appendChild(t);let n=document.createElement("span");n.className="alert-message",n.textContent="This patient has Provider Paid status. Special billing rules apply.";let o=document.createElement("span");o.className="countdown-timer",o.textContent="30",n.appendChild(o),e.appendChild(n),document.body.appendChild(e),Dn(e),setTimeout(()=>{e.classList.add("show"),document.body.classList.add("has-alert")},10),Y.add("provider-paid");let r=document.getElementById("mcp-crm-header");r&&r.style.display==="none"?document.body.classList.add("no-header"):document.body.classList.remove("no-header"),console.log("[CRM Extension] Provider Paid alert shown");let i=15,a=setInterval(()=>{i--,o&&(o.textContent=i),i<=0&&(clearInterval(a),Ne("provider-paid"))},1e3)}function Dn(e){let t=Y.size;t===1?e.classList.add("second-alert"):t===2&&e.classList.add("third-alert")}function Ne(e){let t=document.querySelector(`.crm-alert-banner[data-alert-type="${e}"]`);t&&(t.classList.remove("show"),Y.delete(e),setTimeout(()=>{t.parentNode&&t.parentNode.removeChild(t),Y.size===0&&document.body.classList.remove("has-alert"),Bn()},300))}function Bn(){document.querySelectorAll(".crm-alert-banner").forEach((t,n)=>{t.classList.remove("second-alert","third-alert"),n===1?t.classList.add("second-alert"):n===2&&t.classList.add("third-alert")})}console.log("[CRM Extension] Content script injected.");var J=typeof browser<"u"?browser:chrome;J.runtime.sendMessage({action:"loadSettings"}).then(e=>{e&&e.success&&(console.log("[CRM Extension] Settings loaded from browser storage on startup:",e.settings),document.getElementById("mcp-crm-header")||V())}).catch(e=>{console.error("[CRM Extension] Error requesting settings on startup:",e)});localStorage.getItem("crmplus_headerBarVisible")===null?(console.log("[CRM Extension] No local toolbar visibility setting, requesting from browser storage"),J.runtime.sendMessage({action:"loadSettings"}).then(e=>{e&&e.success?(console.log("[CRM Extension] Settings loaded from browser storage:",e.settings),V()):(console.error("[CRM Extension] Failed to load settings, using defaults"),localStorage.setItem("crmplus_headerBarVisible","true"),V())}).catch(e=>{console.error("[CRM Extension] Error requesting settings:",e),localStorage.setItem("crmplus_headerBarVisible","true"),V()})):(console.log("[CRM Extension] Using existing localStorage settings"),V());function V(){let e=localStorage.getItem("crmplus_headerBarVisible")!=="false";console.log("[CRM Extension] Header visibility setting on init:",e);try{console.log("[CRM Extension] Creating fixed header..."),Ue(),je(e)}catch(t){console.error("[CRM Extension] Error creating fixed header:",t)}try{Ye(t=>{console.log(`[CRM Extension] Intercepted console message: ${t}`)})}catch(t){console.error("[CRM Extension] Error initializing console monitor:",t)}try{Xt()}catch(t){console.error("[CRM Extension] Error initializing auto phone copy:",t)}try{Kt()}catch(t){console.error("[CRM Extension] Error initializing alert system:",t)}try{lt()}catch(t){console.error("[CRM Extension] Error initializing tag removal system:",t)}try{mt()}catch(t){console.error("[CRM Extension] Error initializing automation removal system:",t)}R()}J.runtime.onMessage.addListener((e,t,n)=>{if(console.log("[CRM Extension] Received message:",e),e.action==="toggleHeaderVisibility"){console.log("[CRM Extension] Toggling header visibility to:",e.isVisible);try{let o=je(e.isVisible);localStorage.setItem("crmplus_headerBarVisible",e.isVisible.toString()),J.runtime.sendMessage({action:"syncSettings"}).catch(r=>console.error("[CRM Extension] Error syncing settings:",r)),n({success:o})}catch(o){console.error("[CRM Extension] Error toggling header visibility:",o),n({success:!1,error:o.message})}return!0}return!1});document.addEventListener("DOMContentLoaded",()=>{console.log("[CRM Extension] DOM fully loaded, checking visibility setting"),document.getElementById("mcp-crm-header")||J.runtime.sendMessage({action:"loadSettings"}).then(e=>{e&&e.success&&V()}).catch(()=>{localStorage.setItem("crmplus_headerBarVisible","true"),V()})});})();
