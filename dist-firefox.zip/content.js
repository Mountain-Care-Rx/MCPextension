(()=>{function ze(e){if(window.__crmConsoleMonitor)return;window.__crmConsoleMonitor=!0;let t=console.log,o=console.error,n=console.warn;console.log=function(...i){t.apply(console,i),!(typeof i[0]=="string"&&i[0].includes("[CRM Extension]"))&&Ce(i,"log",e)},console.error=function(...i){o.apply(console,i),!(typeof i[0]=="string"&&i[0].includes("[CRM Extension]"))&&Ce(i,"error",e)},console.warn=function(...i){n.apply(console,i),!(typeof i[0]=="string"&&i[0].includes("[CRM Extension]"))&&Ce(i,"warn",e)}}function Ce(e,t,o){let n=e.join(" ");["error","failed","unauthorized","critical"].some(r=>n.toLowerCase().includes(r))&&o(n)}var Le=window.location.href,F="";function ce(){if(!Ie())return"";let e=document.querySelector('input[name="contact.phone"]');if(e&&e.value.trim()!=="")return e.value.trim();let t=document.querySelector(".phone-number .number");if(t&&t.textContent.trim()!=="")return t.textContent.trim();let o=['input[placeholder="Phone"]','input[placeholder="Phone Number"]',".patient-info .phone",".contact-info .phone","span.phone",'label[for*="phone"]',".phone-display",'div[data-field="phone"]','span[data-field="phone_number"]'];for(let n of o){let i=document.querySelector(n);if(i)if(i.tagName==="INPUT"){let r=i.value.trim();if(r)return r}else if(i.tagName==="LABEL"){let r=i.getAttribute("for");if(r){let s=document.getElementById(r);if(s&&s.value.trim())return s.value.trim()}let a=i.parentElement?.querySelector("input");if(a&&a.value.trim())return a.value.trim()}else{let r=i.textContent.trim();if(r)return r}}return""}function Ie(){let e=window.location.href;return[/\/patient\/\d+/i,/\/contact\/\d+/i,/\/profile\/\d+/i,/[?&]patient_id=\d+/i,/[?&]contact_id=\d+/i].some(n=>n.test(e))?!0:['input[name="contact.phone"]','input[name="contact.first_name"]','input[name="contact.last_name"]','input[name="contact.date_of_birth"]',".patient-info",".contact-details",".patient-header",".patient-profile"].some(n=>document.querySelector(n)!==null)}function Be(e){try{let t=e?xt(e):"";if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("phone",t);else{let o=document.getElementById("phone-text");if(o){o.textContent=t;let n=document.getElementById("phone-display");n&&(e?n.setAttribute("data-value",e):n.removeAttribute("data-value"))}}}catch(t){console.error("[CRM Extension] Error updating phone display:",t)}}function D(){F="",Be("");try{let e=document.getElementById("phone-display");e&&e.removeAttribute("data-value")}catch(e){console.error("[CRM Extension] Error clearing phone display:",e)}}function xt(e){if(!e)return"";let t=e.replace(/\D/g,"");if(t.length===0)return"";if(t.length===10)return`(${t.substring(0,3)}) ${t.substring(3,6)}-${t.substring(6)}`;if(t.length===11&&t.startsWith("1"))return`(${t.substring(1,4)}) ${t.substring(4,7)}-${t.substring(7)}`;if(t.length>4){let o="";for(let n=0;n<t.length;n+=3)if(n+4>=t.length&&t.length%3!==0){o+=" "+t.substring(n);break}else o+=" "+t.substring(n,n+3);return o.trim()}return t.replace(/(\d{3})/g,"$1 ").trim()}function se(){try{if(!Ie())return F&&D(),!1;let e=ce();return e?(e!==F&&(F=e,Be(e)),!0):(F&&D(),!1)}catch(e){return console.error("[CRM Extension] Error detecting phone number:",e),!1}}function Pe(){D(),se();let e=setInterval(()=>{let t=window.location.href;t!==Le&&(console.log("[CRM Extension] URL changed, resetting phone detection"),Le=t,D()),se()},200);try{let t=new MutationObserver(n=>{se()}),o=document.body;t.observe(o,{childList:!0,subtree:!0,characterData:!0,attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] Phone number mutation observer active")}catch(t){console.error("[CRM Extension] Error setting up phone mutation observer:",t)}}function De(e){let t=ce();if(!t){p("No phone number found");return}let o=we(t);if(!o){p("Invalid phone number format");return}e.setAttribute("data-value",t),O(o).then(n=>{p(n?"Copied: "+o:"Failed to copy phone number")})}function we(e){if(!e)return"";let t=e.replace(/\D/g,"");return t.length<7?"":"+1"+t}async function O(e){if(navigator.clipboard&&navigator.clipboard.writeText)try{return await navigator.clipboard.writeText(e),!0}catch(t){console.warn("Clipboard API failed, trying fallback method:",t)}try{let t=document.createElement("textarea");t.value=e,t.style.position="fixed",t.style.top="0",t.style.left="0",t.style.opacity="0",t.style.pointerEvents="none",document.body.appendChild(t),t.focus(),t.select();let o=document.execCommand("copy");return document.body.removeChild(t),o}catch(t){return console.error("All clipboard methods failed:",t),!1}}function p(e,t=2e3){let o=document.getElementById("crm-plus-toast-container");o||(o=document.createElement("div"),o.id="crm-plus-toast-container",o.style.position="fixed",o.style.bottom="20px",o.style.right="20px",o.style.zIndex="100000",document.body.appendChild(o));let n=document.createElement("div");n.textContent=e,n.style.background="#333",n.style.color="#fff",n.style.padding="10px",n.style.borderRadius="5px",n.style.marginTop="10px",n.style.boxShadow="0 2px 5px rgba(0,0,0,0.2)",n.style.transition="opacity 0.5s, transform 0.5s",n.style.opacity="0",n.style.transform="translateY(20px)",o.appendChild(n),n.offsetWidth,n.style.opacity="1",n.style.transform="translateY(0)",setTimeout(()=>{n.style.opacity="0",n.style.transform="translateY(20px)",setTimeout(()=>{n.parentNode&&n.parentNode.removeChild(n),o.childNodes.length===0&&document.body.removeChild(o)},500)},t)}var $e=window.location.href;function U(e){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("name",e);else{let t=document.getElementById("name-text");if(t){t.textContent=e;let o=document.getElementById("name-display");o&&o.setAttribute("data-value",e)}}}catch(t){console.error("[CRM Extension] Error updating name display:",t)}}function de(){try{let e=document.querySelector('input[name="contact.first_name"]'),t=document.querySelector('input[name="contact.last_name"]');if(e&&e.value&&t&&t.value){let i=`${e.value} ${t.value}`;return U(i),!0}let o=document.querySelectorAll(".patient-name, .contact-name, h1.name, .customer-name");for(let i of o)if(i&&i.textContent&&i.textContent.trim()!==""){let r=i.textContent.trim();return U(r),!0}let n=["span.name",".profile-name","h2.name",".contact-header .name",'div[data-field="name"]',".patient-info .name"];for(let i of n){let r=document.querySelector(i);if(r&&r.textContent&&r.textContent.trim()!==""){let a=r.textContent.trim();return U(a),!0}}return!1}catch(e){return console.error("[CRM Extension] Error detecting name:",e),!1}}function Ve(){de();let e=setInterval(()=>{let t=window.location.href;t!==$e&&(console.log("[CRM Extension] URL changed, resetting name detection"),$e=t,U(""),de());let o=document.getElementById("name-text");o&&(o.textContent==="Loading..."||!o.textContent)&&de()},1e3);try{let t=new MutationObserver(n=>{n.some(r=>r.addedNodes.length>5||r.removedNodes.length>5)&&(console.log("[CRM Extension] Significant DOM changes detected, rechecking name"),U(""),de())}),o=document.querySelector("main")||document.body;t.observe(o,{childList:!0,subtree:!0})}catch(t){console.error("[CRM Extension] Error setting up navigation observer for name:",t)}}var qe=window.location.href;function me(e){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("dob",e);else{let t=document.getElementById("dob-text");if(t){t.textContent=e;let o=document.getElementById("dob-display");o&&o.setAttribute("data-value",e)}}}catch(t){console.error("[CRM Extension] Error updating DOB display:",t)}}function _e(e){if(!e)return"";if(e.match(/^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2}(st|nd|rd|th)?\s+\d{4}$/))try{let t=e.match(/(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+(\d{1,2})(st|nd|rd|th)?\s+(\d{4})/);if(t){let o=t[1],n=t[2],i=t[4];return`${(["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"].indexOf(o)+1).toString().padStart(2,"0")}/${n.toString().padStart(2,"0")}/${i}`}}catch(t){console.error("[CRM Extension] Error parsing date:",t)}try{let t=new Date(e);if(!isNaN(t.getTime()))return`${(t.getMonth()+1).toString().padStart(2,"0")}/${t.getDate().toString().padStart(2,"0")}/${t.getFullYear()}`}catch(t){console.error("[CRM Extension] Error parsing date as Date object:",t)}return e}function pe(){try{let e=document.querySelector('input[name="contact.date_of_birth"]');if(e&&e.value){let o=_e(e.value);return me(o),!0}let t=[".dob",".patient-dob",".contact-dob",'span[data-field="date_of_birth"]','div[data-field="dob"]',".patient-info .dob",".contact-info .dob"];for(let o of t){let n=document.querySelector(o);if(n&&n.textContent&&n.textContent.trim()!==""){let i=_e(n.textContent.trim());return me(i),!0}}return!1}catch(e){return console.error("[CRM Extension] Error detecting DOB:",e),!1}}function He(){pe();let e=setInterval(()=>{let t=window.location.href;t!==qe&&(console.log("[CRM Extension] URL changed, resetting DOB detection"),qe=t,me(""),pe());let o=document.getElementById("dob-text");o&&(o.textContent==="Loading..."||!o.textContent)&&pe()},1e3);try{let t=new MutationObserver(n=>{n.some(r=>r.addedNodes.length>5||r.removedNodes.length>5)&&(console.log("[CRM Extension] Significant DOM changes detected, rechecking DOB"),me(""),pe())}),o=document.querySelector("main")||document.body;t.observe(o,{childList:!0,subtree:!0})}catch(t){console.error("[CRM Extension] Error setting up navigation observer for DOB:",t)}}var Fe=window.location.href,ue="";function Oe(e){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("srxid",e);else{let t=document.getElementById("srxid-text");if(t){t.textContent=e;let o=document.getElementById("srxid-display");o&&o.setAttribute("data-value",e)}}}catch(t){console.error("[CRM Extension] Error updating SRx ID display:",t)}}function j(){try{let e=document.querySelector('input[name="contact.srx_id"]');if(e&&e.value){let t="^"+e.value.trim();if(t&&/^\d+$/.test(t))return t!==ue&&(console.log("[CRM Extension] Found SRx ID from contact.srx_id input:",t),ue=t,Oe(t)),!0}return!!ue}catch(e){return console.error("[CRM Extension] Error detecting SRx ID:",e),!1}}function Ue(){j();let e=setInterval(()=>{let t=window.location.href;t!==Fe&&(console.log("[CRM Extension] URL changed, resetting SRx ID detection"),Fe=t,ue="",Oe(""),j()),j()},500);try{new MutationObserver(o=>{let n=!1;for(let i of o){if(i.target.tagName==="INPUT"&&i.target.name==="contact.srx_id"||i.target.querySelector&&i.target.querySelector('input[name="contact.srx_id"]')){n=!0;break}if(i.addedNodes.length>0){for(let r of i.addedNodes)if(r.nodeType===1&&r.querySelector&&(r.tagName==="INPUT"&&r.name==="contact.srx_id"||r.querySelector('input[name="contact.srx_id"]'))){n=!0;break}}}n&&j()}).observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] SRx ID mutation observer active")}catch(t){console.error("[CRM Extension] Error setting up observer for SRx ID:",t)}setTimeout(()=>{try{let t=document.querySelector('input[name="contact.srx_id"]');t&&(new MutationObserver(n=>{j()}).observe(t,{attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] Direct input observer attached to contact.srx_id"))}catch(t){console.error("[CRM Extension] Error setting up direct input observer:",t)}},1e3)}var ge=["np-tirz-1.5ml-inj","refill-sema-inj","refill-tirz-inj","vial-sema-b12","vial-sema-b6","vial-sema-lipo","vial-sema-nad+","vial-tirz-cyano","vial-tirz-nad+","vial-tirz-pyridoxine","np-sema-0.125ml-inj","np-sema-0.25ml-inj","np-sema-0.5ml-inj","np-sema-0.75ml-inj","np-sema-1.0ml-inj","np-sema-1.25ml-inj","np-sema-1.5ml-inj","np-sema-2.0ml-inj","np-tirz-0.25ml-inj","np-tirz-0.5ml-inj","np-tirz-0.75ml-inj","np-tirz-1.0ml-inj","np-tirz-1.25ml-inj","api-tirz-b6-0.25ml-syringe","api-tirz-b6-0.5ml-syringe","api-tirz-b6-0.75ml-syringe","api-tirz-b6-1.0ml-syringe","api-tirz-b6-1.25ml-syringe","api-tirz-b6-1.5ml-syringe","api-tirz-b6-2.5ml-vial","api-tirz-b6-5.0ml-vial","api-tirz-b6-7.5ml-vial","api-tirz-b6-10.0ml-vial","api-tirz-b12-2.5ml-vial","api-tirz-b12-5.0ml-vial","api-tirz-b12-7.5ml-vial","api-tirz-b12-10.0ml-vial","api-tirz-nad+-2.5ml-vial","api-tirz-nad+-5.0ml-vial","api-tirz-nad+-7.5ml-vial","api-tirz-nad+-10.0ml-vial","api-sema-b6-2.5ml-vial","api-sema-b6-5.0ml-vial","api-sema-b6-7.5ml-vial","api-sema-b6-10.0ml-vial","api-sema-b12-0.125ml-syringe","api-sema-b12-0.25ml-syringe","api-sema-b12-0.5ml-syringe","api-sema-b12-0.75ml-syringe","api-sema-b12-1.0ml-syringe","api-sema-b12-1.25ml-syringe","api-sema-b12-1.5ml-syringe","api-sema-b12-1.75ml-syringe","api-sema-b12-2.0ml-syringe","api-sema-b12-2.5ml-vial","api-sema-b12-5.0ml-vial","api-sema-b12-7.5ml-vial","api-sema-b12-10.0ml-vial","api-sema-nad+-2.5ml-vial","api-sema-nad+-5.0ml-vial","api-sema-nad+-7.5ml-vial","api-sema-nad+-10.0ml-vial","api-sema-lipo-2.5ml-vial","api-sema-lipo-5.0ml-vial","api-sema-lipo-7.5ml-vial","api-sema-lipo-10.0ml-vial"],R=[];function je(){console.log("[CRM Extension] Tag removal system initialized")}function vt(){R=[];try{let e=document.querySelectorAll(".tag, .tag-label, .pill, .badge");for(let i of e){let r=i.textContent.trim().toLowerCase();ge.some(a=>r.includes(a))&&R.push({element:i,text:r})}let t=document.querySelectorAll("[data-tag]");for(let i of t){let r=i.getAttribute("data-tag").toLowerCase();ge.some(a=>r.includes(a))&&R.push({element:i,text:r})}let o=document.querySelectorAll(".tags-container, .tag-list, .tags");for(let i of o){let r=i.querySelectorAll("*");for(let a of r)if(a.nodeType===1){let s=a.textContent.trim().toLowerCase();ge.some(l=>s.includes(l))&&(R.some(l=>l.element===a)||R.push({element:a,text:s}))}}let n=document.querySelectorAll("*[class]");for(let i of n){let r=String(i.className).toLowerCase();r&&typeof r=="string"&&ge.some(a=>r.includes(a))&&(R.some(a=>a.element===i)||R.push({element:i,text:i.textContent.trim().toLowerCase()}))}return console.log(`[CRM Extension] Found ${R.length} removable tags`),R}catch(e){return console.error("[CRM Extension] Error detecting tags:",e),[]}}function Ct(e){try{let t=e.querySelector('.close, .remove, .delete, .tag-remove, [aria-label="Remove"], .x-button');if(t)return console.log("[CRM Extension] Found close button in tag, clicking it"),t.click(),!0;let o=e.parentElement;if(o){let r=o.querySelector('.close, .remove, .delete, .tag-remove, [aria-label="Remove"], .x-button');if(r)return console.log("[CRM Extension] Found close button as sibling, clicking it"),r.click(),!0}let n=[...Array.from(e.querySelectorAll("*")),...Array.from(o?o.children:[])];for(let r of n){let a=r.textContent.trim();if(a==="\xD7"||a==="x"||a==="\u2715"||a==="\u2716"||a==="X")return console.log("[CRM Extension] Found X button by text content, clicking it"),r.click(),!0;if(r.className&&(r.className.includes("close")||r.className.includes("delete")||r.className.includes("remove")||r.className.includes("x-button")))return console.log("[CRM Extension] Found X button by class name, clicking it"),r.click(),!0;if(r.classList&&(r.classList.contains("fa-times")||r.classList.contains("fa-close")||r.classList.contains("icon-close")||r.classList.contains("icon-remove")))return console.log("[CRM Extension] Found X button by icon class, clicking it"),r.click(),!0}if(e.tagName==="BUTTON"||e.tagName==="A"||e.getAttribute("role")==="button"||window.getComputedStyle(e).cursor==="pointer")return console.log("[CRM Extension] Tag appears to be clickable, clicking it"),e.click(),!0;let i=o;for(let r=0;r<3&&i;r++){let a=i.querySelectorAll("button, span, i, div");for(let s of a){let l=s.textContent.trim();if(l==="\xD7"||l==="x"||l==="\u2715"||l==="\u2716"||l==="X"||s.classList.contains("fa-times")||s.classList.contains("fa-close")||s.classList.contains("close")||s.classList.contains("remove"))return console.log("[CRM Extension] Found X button in parent container, clicking it"),s.click(),!0}i=i.parentElement}return console.log("[CRM Extension] No method found to remove tag:",e),!1}catch(t){return console.error("[CRM Extension] Error removing tag:",t),!1}}function W(){return new Promise((e,t)=>{try{let i=function(r){if(r>=R.length){console.log(`[CRM Extension] Removed ${o}/${n} tags`),e({success:!0,message:`Removed ${o} of ${n} tags`,removed:o,total:n});return}let a=R[r];console.log(`[CRM Extension] Removing tag: ${a.text}`),Ct(a.element)&&o++,setTimeout(()=>{i(r+1)},300)};vt();let o=0,n=R.length;if(n===0){console.log("[CRM Extension] No removable tags found"),e({success:!0,message:"No tags to remove",removed:0,total:0});return}console.log(`[CRM Extension] Attempting to remove ${n} tags`),i(0)}catch(o){console.error("[CRM Extension] Error in removeAllTags:",o),t(o)}})}var wt=["API - New Patient - Semaglutide Combo","API - New Patient - Tirzepatide Combo","API - Refill - Semaglutide Combo - (Step 1 Verify First Name)","API - Refill - Tirzepatide Combo - (Step 1 Verify First Name)"],fe=[];function N(e){try{if(e&&typeof e.getBoundingClientRect=="function")return e.getBoundingClientRect()}catch{}return{top:0,bottom:0,left:0,right:0,width:0,height:0}}function Qe(){console.log("[CRM Extension] Automation removal system initialized")}function Et(){fe=[];try{let e=Ge("Active");return e?(fe=(e.workflows.length?e.workflows:St(e.label)).filter(o=>{if(!o)return!1;let n=(o.textContent||"").trim();return n.includes("Workflow")&&wt.some(i=>n.includes(i))}),console.log(`[CRM Extension] Found ${fe.length} automation(s) in Active section.`),fe):(console.log("[CRM Extension] Active section not found."),[])}catch(e){return console.error("[CRM Extension] Error detecting automations:",e),[]}}function St(e){let t=N(e).bottom,o=null,n=Ge("Past");return n&&n.label&&(o=N(n.label).top),Array.from(document.querySelectorAll('div[id^="workflow_"], div[data-workflow-id]')).filter(r=>{let a=N(r);return!(a.top<t||o&&a.top>=o)})}function Ge(e){try{let o=Array.from(document.querySelectorAll("div.py-2")).find(r=>(r.textContent||"").trim()===e);if(o)return{label:o,workflows:e==="Active"?kt(o):At(o)};let n=e==="Active"?'[data-automation="Active"], #automation-active':'[data-automation="Past"], #automation-past',i=document.querySelector(n);return i?{label:i,workflows:[]}:null}catch(t){return console.error(`[CRM Extension] Error finding section for "${e}":`,t),null}}function kt(e){let t=N(e).bottom,n=Array.from(document.querySelectorAll("div.py-2")).find(a=>(a.textContent||"").trim()==="Past"),i=n?N(n).top:null;return Array.from(document.querySelectorAll('div[id^="workflow_"], div[data-workflow-id]')).filter(a=>{let s=N(a);return s.top>t&&(!i||s.top<i)})}function At(e){let t=N(e).bottom;return Array.from(document.querySelectorAll('div[id^="workflow_"], div[data-workflow-id]')).filter(n=>N(n).top>t)}function Rt(e){if(!e)return console.error("[CRM Extension] removeAutomation called with undefined element."),!1;try{let t=N(e),o=t.width>0&&t.height>0,n=t.top>=0&&t.left>=0&&t.bottom<=(window.innerHeight||document.documentElement.clientHeight);return!o||!n?(e.scrollIntoView({behavior:"smooth",block:"center"}),new Promise(i=>{setTimeout(()=>i(We(e)),500)})):We(e)}catch(t){return console.error("[CRM Extension] Error removing automation:",t),!1}}function We(e){if(!e)return!1;try{let t=e.querySelectorAll("i.icon-close, i.icon.icon-close");if(t.length)return t[0].click(),!0}catch(t){console.error("[CRM Extension] Error in Strategy 1:",t)}try{let t=e.querySelectorAll("a");for(let o of t){let n=(o.textContent||"").trim();if(n==="\xD7"||n.toLowerCase()==="x")return o.click(),!0}}catch(t){console.error("[CRM Extension] Error in Strategy 2:",t)}try{let t=e.querySelectorAll('button, .btn, [role="button"]');for(let o of t)if((o.textContent||"").toLowerCase().includes("manage"))return o.click(),setTimeout(()=>{document.querySelectorAll(".dropdown-menu .dropdown-item, .menu-item").forEach(r=>{let a=(r.textContent||"").toLowerCase();(a.includes("remove")||a.includes("delete"))&&r.click()})},300),!0}catch(t){console.error("[CRM Extension] Error in Strategy 3:",t)}if(e.id&&e.id.startsWith("workflow_")){let t=e.id;try{let o=`#${t} i.icon-close, #${t} i.icon.icon-close`,n=document.querySelector(o);if(n)return n.click(),!0;o=`#${t} .remove, #${t} .close`;let i=document.querySelector(o);if(i)return i.click(),!0}catch(o){console.error("[CRM Extension] Error in Strategy 4:",o)}}try{let t=e.querySelectorAll("span");for(let o of t){let n=(o.textContent||"").trim();if(n==="\xD7"||n.toLowerCase()==="x")return o.click(),!0}}catch(t){console.error("[CRM Extension] Error in Strategy 5:",t)}try{let t=e.nextElementSibling,o=0;for(;t&&o<3;){if(t.classList&&(t.classList.contains("close")||t.classList.contains("remove"))||t.textContent&&(t.textContent.trim()==="\xD7"||t.textContent.trim().toLowerCase()==="x"))return t.click(),!0;let n=t.querySelector("i.icon-close, i.icon.icon-close");if(n)return n.click(),!0;t=t.nextElementSibling,o++}}catch(t){console.error("[CRM Extension] Error in Strategy 6:",t)}try{let t=N(e),o=t.right-10,n=t.top+t.height/2,i=document.elementsFromPoint(o,n);for(let a of i)if(a!==e)return a.click(),!0;let r=new MouseEvent("click",{view:window,bubbles:!0,cancelable:!0,clientX:o,clientY:n});return(i[0]||document.elementFromPoint(o,n))?.dispatchEvent(r),!0}catch(t){console.error("[CRM Extension] Error in Strategy 7:",t)}return console.error("[CRM Extension] No method found to remove automation:",e),!1}function Ye(){return new Promise(e=>{setTimeout(()=>{if(document.querySelectorAll('.modal, [role="dialog"], .dialog').length){let o=document.querySelectorAll('.modal .btn-primary, .modal .btn-danger, .modal .confirm-btn, [role="dialog"] .btn-primary, .modal button, [role="dialog"] button');for(let i of o){let r=(i.textContent||"").trim().toLowerCase();if(["delete","remove","yes","confirm","ok","continue"].includes(r)){i.click(),e(!0);return}}let n=document.querySelectorAll('.modal button, [role="dialog"] button, .dialog button');if(n.length){n[n.length-1].click(),e(!0);return}}e(!1)},500)})}function Y(){return new Promise((e,t)=>{try{let r=function(a){if(a>=i){e({success:!0,message:`Removed ${n} of ${i} automations`,removed:n,total:i});return}let s=o[a],l=Rt(s.element);l instanceof Promise?l.then(c=>{c&&n++,Ye().then(()=>setTimeout(()=>r(a+1),1e3))}):(l&&n++,Ye().then(()=>setTimeout(()=>r(a+1),1e3)))},o=Et();if(!o.length){console.log("[CRM Extension] No automations to remove."),e({success:!0,message:"No automations to remove",removed:0,total:0});return}let n=0,i=o.length;r(0)}catch(o){console.error("[CRM Extension] Error in removeAllAutomations:",o),t(o)}})}var w=[];var he="crmplus_history";function Ze(){et(),Nt(),Mt(),window.addEventListener("storage",Tt),console.log("[CRM Extension] History tracking initialized")}function et(){try{let e=localStorage.getItem(he);if(e){w=JSON.parse(e);let t=Date.now();w=w.filter(o=>t-o.timestamp<144e5),Ee()}}catch(e){console.error("[CRM Extension] Error loading history:",e),w=[]}}function Ee(){try{localStorage.setItem(he,JSON.stringify(w))}catch(e){console.error("[CRM Extension] Error saving history:",e)}}function Tt(e){if(e.key===he)try{e.newValue?(w=JSON.parse(e.newValue),console.log("[CRM Extension] History updated from another tab")):(w=[],console.log("[CRM Extension] History cleared from another tab"))}catch(t){console.error("[CRM Extension] Error processing cross-tab history update:",t)}}function Nt(){let e=window.location.href;setInterval(()=>{let n=window.location.href;n!==e&&(e=n,Q(n))},500),Q(window.location.href);let t=history.pushState;history.pushState=function(){t.apply(this,arguments),Q(window.location.href)};let o=history.replaceState;history.replaceState=function(){o.apply(this,arguments),Q(window.location.href)},window.addEventListener("popstate",()=>{Q(window.location.href)})}function Q(e){if(!e)return;let t=e.match(/\/detail\/([^/]+)/);if(t&&t[1]){let o=t[1];setTimeout(()=>{let n=Xe(),i=Je();n&&n!=="Unknown Patient"?Ke(o,n,i,e):(console.log("[CRM Extension] Patient name not found yet, retrying in 3 seconds..."),setTimeout(()=>{let r=Xe(),a=Je();r&&r!=="Unknown Patient"?Ke(o,r,a,e):console.log("[CRM Extension] Could not retrieve patient info after retry, not adding to history")},3e3))},5e3)}}function Xe(){let e=document.getElementById("name-text");if(e&&e.textContent&&e.textContent.trim()!=="")return e.textContent.trim();let t=document.querySelector('input[name="contact.first_name"]'),o=document.querySelector('input[name="contact.last_name"]');if(t&&t.value&&o&&o.value)return`${t.value} ${o.value}`.trim();let n=[".patient-name",".contact-name","h1.name",".customer-name","span.name",".profile-name","h2.name",".contact-header .name",'div[data-field="name"]',".patient-info .name"];for(let i of n){let r=document.querySelector(i);if(r&&r.textContent&&r.textContent.trim()!=="")return r.textContent.trim()}return"Unknown Patient"}function Je(){let e=document.getElementById("phone-text");if(e&&e.textContent&&e.textContent.trim()!=="")return e.textContent.trim();let t=document.querySelector('input[name="contact.phone"]');if(t&&t.value.trim()!=="")return t.value.trim();let o=[".phone-number .number",'input[placeholder="Phone"]','input[placeholder="Phone Number"]',".patient-info .phone",".contact-info .phone","span.phone",'div[data-field="phone"]','span[data-field="phone_number"]'];for(let n of o){let i=document.querySelector(n);if(i)if(i.tagName==="INPUT"){let r=i.value.trim();if(r)return r}else{let r=i.textContent.trim();if(r)return r}}return""}function Ke(e,t,o,n){let r=Date.now(),a=w.findIndex(s=>s.patientId===e);if(a!==-1){let s=w[a];s.timestamp=r,s.patientName=t,s.phoneNumber=o,w.splice(a,1),w.unshift(s)}else w.unshift({patientId:e,patientName:t,phoneNumber:o,url:n,timestamp:r}),w.length>20&&w.pop();Ee()}function Mt(){setInterval(()=>{let e=Date.now(),t=0;w=w.filter(o=>{let n=e-o.timestamp<144e5;return n||t++,n}),t>0&&(console.log(`[CRM Extension] Removed ${t} expired history entries`),Ee())},5*60*1e3)}function tt(){et();let e=Date.now();return w=w.filter(t=>e-t.timestamp<144e5),[...w]}function ot(){w=[],localStorage.removeItem(he),console.log("[CRM Extension] History cleared")}function nt(e){return new Date(e).toLocaleString("en-US",{hour:"numeric",minute:"2-digit",hour12:!0})}function G(e,t,o={}){let n=document.createElement("div");n.className="group";let i=document.createElement("span");i.className="label",i.textContent=`${t}:`,n.appendChild(i);let r=document.createElement("span");if(r.id=`${e}-display`,r.className="clickable-value",o.initialValue&&r.setAttribute("data-value",o.initialValue),o.icon){let l=document.createElement("span");l.className="btn-icon",l.innerHTML=o.icon,r.appendChild(l)}let a=document.createElement("span");a.textContent=o.initialValue||"",a.id=`${e}-text`,r.appendChild(a);let s=async()=>{let l=r.getAttribute("data-value")||a.textContent.trim();l&&l!==""?await O(l)?p(`Copied ${t}: ${l}`):p(`Failed to copy ${t.toLowerCase()}`):p(`No ${t.toLowerCase()} available to copy`)};return r.addEventListener("click",()=>{o.onClick?o.onClick(r):s()}),r.title=`Click to copy ${t.toLowerCase()} to clipboard`,n.appendChild(r),n}function it(){let e=document.createElement("div");return e.className="group",e.id="crm-actions-group",e}function rt(){let e=document.createElement("div");e.className="dropdown",e.id="crm-tags-dropdown";let t=document.createElement("button");t.className="dropdown-btn",t.textContent="Tags",t.addEventListener("click",d=>{d.stopPropagation(),document.querySelectorAll(".dropdown.show").forEach(Me=>{Me!==e&&Me.classList.remove("show")}),e.classList.toggle("show")});let o=document.createElement("div");if(o.className="dropdown-content",o.style.padding="10px",!document.getElementById("tags-dropdown-styles")){let d=document.createElement("style");d.id="tags-dropdown-styles",d.textContent=`
      .nested-dropdown {
        margin-bottom: 8px;
        width: 100%;
        position: relative;
      }
      .nested-dropdown-btn {
        width: 100%;
        text-align: left;
        padding: 8px 12px;
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 3px;
        cursor: pointer;
        font-weight: bold;
        font-size: 13px;
        color: #e6e6e6;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .nested-dropdown-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      .nested-dropdown-btn:after {
        content: "\u25BC";
        font-size: 8px;
        color: #e6e6e6;
      }
      .nested-dropdown-content {
        display: none;
        padding: 5px 0 5px 10px;
        margin-top: 3px !important;
      }
      .nested-dropdown.open .nested-dropdown-content {
        display: block;
      }
      
      /* Button-style tag options */
      .tag-btn {
        display: block;
        width: 100%;
        padding: 8px 12px;
        margin-bottom: 8px;
        background-color: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 4px;
        text-align: left;
        font-size: 13px;
        color: #e6e6e6;
        cursor: pointer;
        transition: all 0.2s ease;
        font-weight: normal;
      }
      .tag-btn:hover {
        background-color: rgba(255, 255, 255, 0.15);
        border-color: rgba(255, 255, 255, 0.2);
      }
      .tag-btn:active {
        background-color: rgba(255, 255, 255, 0.2);
      }
    `,document.head.appendChild(d)}let n=document.createElement("button");n.className="tag-btn",n.textContent="Opt-in",n.addEventListener("click",()=>{at("opt-in"),e.classList.remove("show")}),o.appendChild(n);let i=document.createElement("button");i.className="tag-btn",i.textContent="Refill-Sema-Inj",i.addEventListener("click",()=>{x("refill-sema-inj"),e.classList.remove("show")}),o.appendChild(i);let r=document.createElement("button");r.className="tag-btn",r.textContent="Refill-Tirz-Inj",r.addEventListener("click",()=>{x("refill-tirz-inj"),e.classList.remove("show")}),o.appendChild(r);let a=document.createElement("div");a.className="nested-dropdown";let s=document.createElement("button");s.className="nested-dropdown-btn",s.textContent="Vial-Semaglutide";let l=document.createElement("div");l.className="nested-dropdown-content",s.addEventListener("click",d=>{d.stopPropagation(),a.classList.toggle("open")});let c=document.createElement("button");c.className="tag-btn",c.textContent="Vial-Sema-B12",c.addEventListener("click",d=>{d.stopPropagation(),C(),x("vial-sema-b12")}),l.appendChild(c);let g=document.createElement("button");g.className="tag-btn",g.textContent="Vial-Sema-B6",g.addEventListener("click",d=>{d.stopPropagation(),C(),x("vial-sema-b6")}),l.appendChild(g);let u=document.createElement("button");u.className="tag-btn",u.textContent="Vial-Sema-Lipo",u.addEventListener("click",d=>{d.stopPropagation(),C(),x("vial-sema-lipo")}),l.appendChild(u);let h=document.createElement("button");h.className="tag-btn",h.textContent="Vial-Sema-NAD+",h.addEventListener("click",d=>{d.stopPropagation(),C(),x("vial-sema-nad+")}),l.appendChild(h),a.appendChild(s),a.appendChild(l),o.appendChild(a);let f=document.createElement("div");f.className="nested-dropdown";let E=document.createElement("button");E.className="nested-dropdown-btn",E.textContent="Vial-Tirzepatide";let S=document.createElement("div");S.className="nested-dropdown-content",E.addEventListener("click",d=>{d.stopPropagation(),f.classList.toggle("open")});let b=document.createElement("button");b.className="tag-btn",b.textContent="Vial-Tirz-Cyano",b.addEventListener("click",d=>{d.stopPropagation(),C(),x("vial-tirz-cyano")}),S.appendChild(b);let v=document.createElement("button");v.className="tag-btn",v.textContent="Vial-Tirz-NAD+",v.addEventListener("click",d=>{d.stopPropagation(),C(),x("vial-tirz-nad+")}),S.appendChild(v);let m=document.createElement("button");m.className="tag-btn",m.textContent="Vial-Tirz-Pyr",m.addEventListener("click",d=>{d.stopPropagation(),C(),x("vial-tirz-pyridoxine")}),S.appendChild(m),f.appendChild(E),f.appendChild(S),o.appendChild(f);let y=document.createElement("div");y.className="nested-dropdown";let I=document.createElement("button");I.className="nested-dropdown-btn",I.textContent="NP-Semaglutide";let A=document.createElement("div");A.className="nested-dropdown-content",I.addEventListener("click",d=>{d.stopPropagation(),y.classList.toggle("open")});let q=document.createElement("button");q.className="tag-btn",q.textContent="NP-Sema 0.125",q.addEventListener("click",d=>{d.stopPropagation(),C(),x("np-sema-0.125ml-inj")}),A.appendChild(q);let T=document.createElement("button");T.className="tag-btn",T.textContent="NP-Sema 0.25",T.addEventListener("click",d=>{d.stopPropagation(),C(),x("np-sema-0.25ml-inj")}),A.appendChild(T);let k=document.createElement("button");k.className="tag-btn",k.textContent="NP-Sema 0.5",k.addEventListener("click",d=>{d.stopPropagation(),C(),x("np-sema-0.5ml-inj")}),A.appendChild(k);let _=document.createElement("button");_.className="tag-btn",_.textContent="NP-Sema 0.75",_.addEventListener("click",d=>{d.stopPropagation(),C(),x("np-sema-0.75ml-inj")}),A.appendChild(_);let B=document.createElement("button");B.className="tag-btn",B.textContent="NP-Sema 1.0",B.addEventListener("click",d=>{d.stopPropagation(),C(),x("np-sema-1.0ml-inj")}),A.appendChild(B);let K=document.createElement("button");K.className="tag-btn",K.textContent="NP-Sema 1.25",K.addEventListener("click",d=>{d.stopPropagation(),C(),x("np-sema-1.25ml-inj")}),A.appendChild(K);let Z=document.createElement("button");Z.className="tag-btn",Z.textContent="NP-Sema 1.5",Z.addEventListener("click",d=>{d.stopPropagation(),C(),x("np-sema-1.5ml-inj")}),A.appendChild(Z);let ee=document.createElement("button");ee.className="tag-btn",ee.textContent="NP-Sema 2.0",ee.addEventListener("click",d=>{d.stopPropagation(),C(),x("np-sema-2.0ml-inj")}),A.appendChild(ee),y.appendChild(I),y.appendChild(A),o.appendChild(y);let H=document.createElement("div");H.className="nested-dropdown";let te=document.createElement("button");te.className="nested-dropdown-btn",te.textContent="NP-Tirzepatide";let P=document.createElement("div");P.className="nested-dropdown-content",te.addEventListener("click",d=>{d.stopPropagation(),H.classList.toggle("open")});let oe=document.createElement("button");oe.className="tag-btn",oe.textContent="NP-Tirz 0.25",oe.addEventListener("click",d=>{d.stopPropagation(),C(),x("np-tirz-0.25ml-inj")}),P.appendChild(oe);let ne=document.createElement("button");ne.className="tag-btn",ne.textContent="NP-Tirz 0.5",ne.addEventListener("click",d=>{d.stopPropagation(),C(),x("np-tirz-0.5ml-inj")}),P.appendChild(ne);let ie=document.createElement("button");ie.className="tag-btn",ie.textContent="NP-Tirz 0.75",ie.addEventListener("click",d=>{d.stopPropagation(),C(),x("np-tirz-0.75ml-inj")}),P.appendChild(ie);let re=document.createElement("button");re.className="tag-btn",re.textContent="NP-Tirz 1.0",re.addEventListener("click",d=>{d.stopPropagation(),C(),x("np-tirz-1.0ml-inj")}),P.appendChild(re);let ae=document.createElement("button");ae.className="tag-btn",ae.textContent="NP-Tirz 1.25",ae.addEventListener("click",d=>{d.stopPropagation(),C(),x("np-tirz-1.25ml-inj")}),P.appendChild(ae);let le=document.createElement("button");return le.className="tag-btn",le.textContent="NP-Tirz 1.5",le.addEventListener("click",d=>{d.stopPropagation(),C(),x("np-tirz-1.5ml-inj")}),P.appendChild(le),H.appendChild(te),H.appendChild(P),o.appendChild(H),e.appendChild(t),e.appendChild(o),e}function C(){document.querySelectorAll(".dropdown.show").forEach(e=>e.classList.remove("show")),document.querySelectorAll(".nested-dropdown.open").forEach(e=>e.classList.remove("open"))}async function x(e){try{let[t,o]=await Promise.all([W(),Y()]);console.log("[CRM Extension] Cleanup completed:"),console.log(`- Tags: ${t.removed}/${t.total} removed`),console.log(`- Automations: ${o.removed}/${o.total} removed`),at(e)}catch(t){console.error("[CRM Extension] Error during cleanup:",t),p("Error during cleanup. Please try again.")}}function at(e){let t=zt();t?(t.focus(),setTimeout(()=>{t.value=e,t.dispatchEvent(new Event("input",{bubbles:!0})),setTimeout(()=>{let o=document.querySelectorAll(".v-list-item, .dropdown-item, .select-option, li"),n=!1;for(let i of o)if(i.textContent.toLowerCase().includes(e)){i.click(),n=!0,p(`Selected tag: ${e}`);break}if(!n){let i=document.querySelectorAll("*");for(let r of i)if(r.textContent.trim().toLowerCase()===e){r.click(),n=!0,p(`Selected tag: ${e}`);break}n||t.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",code:"Enter",keyCode:13,which:13,bubbles:!0}))}},300)},300)):p("Tags field not found")}function zt(){let e=document.querySelector('input[placeholder="Add Tags"]');if(e)return e;let t=Array.from(document.querySelectorAll("input[placeholder]")).filter(r=>r.placeholder.toLowerCase().includes("tag"));if(t.length>0)return t[0];let o=document.querySelectorAll(".tag-input, .tags-input, .tag-container");for(let r of o){let a=r.querySelector("input");if(a)return a}if(e=document.querySelector('input[placeholder="smartList.bulkTags.addTags"]'),e)return e;let n=document.querySelectorAll(".hl-text-input");if(n.length>0)return n[0];console.error("[CRM Extension] Could not find tag input field with any strategy");let i=document.querySelectorAll("input");return console.log("[CRM Extension] All inputs on page:",i),null}var M={"Sema/B12 Refill - Step 2":"Refill - Semaglutide/B12 Injection Refill Order - (Step 2)","Sema/B12 Vial - Step 2":"Semaglutide/B12 Vial Order - (Step 2)","Sema/B6 Vial - Step 2":"Semaglutide/B6 Vial Order - (Step 2)","Sema/Lipo Vial - Step 2":"Semaglutide/Lipo Vial Order - (Step 2)","Sema/NAD+ Vial - Step 2":"Semaglutide/NAD+ Vial Order - (Step 2)","Tirz/B6 Refill - Step 2":"Syringe - Tirzepatide/Pyridoxine Injection Order - (Step 2)","Tirz/B12 Vial - Step 2":"Tirzepatide/Cyano Vial Order - (Step 2)","Tirz/NAD+ Vial - Step 2":"Tirzepatide/NAD+ Vial Order - (Step 2)","Tirz/B6 Vial - Step 2":"Tirzepatide/Pyridoxine Vial Order - (Step 2)"};function lt(){let e=document.createElement("div");e.className="dropdown",e.id="crm-automation-dropdown";let t=document.createElement("button");t.className="dropdown-btn",t.textContent="Automation",t.addEventListener("click",m=>{m.stopPropagation(),document.querySelectorAll(".dropdown.show").forEach(y=>{y!==e&&y.classList.remove("show")}),e.classList.toggle("show")});let o=document.createElement("div");if(o.className="dropdown-content",o.style.padding="10px",!document.getElementById("automation-dropdown-styles")){let m=document.createElement("style");m.id="automation-dropdown-styles",m.textContent=`
      .nested-dropdown {
        margin-bottom: 8px;
        width: 100%;
        position: relative;
      }
      .nested-dropdown-btn {
        width: 100%;
        text-align: left;
        padding: 8px 12px;
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 3px;
        cursor: pointer;
        font-weight: bold;
        font-size: 13px;
        color: #e6e6e6;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .nested-dropdown-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      .nested-dropdown-btn:after {
        content: "\u25BC";
        font-size: 8px;
        color: #e6e6e6;
      }
      .nested-dropdown-content {
        display: none;
        padding: 5px 0 5px 10px;
        margin-top: 3px !important;
      }
      .nested-dropdown.open .nested-dropdown-content {
        display: block;
      }

      /* Button-style options */
      .automation-btn {
        display: block;
        width: 100%;
        padding: 8px 12px;
        margin-bottom: 8px;
        background-color: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 4px;
        text-align: left;
        font-size: 13px;
        color: #e6e6e6;
        cursor: pointer;
        transition: all 0.2s ease;
        font-weight: normal;
      }
      .automation-btn:hover {
        background-color: rgba(255, 255, 255, 0.15);
        border-color: rgba(255, 255, 255, 0.2);
      }
      .automation-btn:active {
        background-color: rgba(255, 255, 255, 0.2);
      }
    `,document.head.appendChild(m)}let n=document.createElement("div");n.className="nested-dropdown";let i=document.createElement("button");i.className="nested-dropdown-btn",i.textContent="Semaglutide (Step 2)";let r=document.createElement("div");r.className="nested-dropdown-content",i.addEventListener("click",m=>{m.stopPropagation(),n.classList.toggle("open")});let a=document.createElement("button");a.className="automation-btn",a.textContent="Sema/B12 Refill - Step 2",a.addEventListener("click",m=>{m.stopPropagation(),z(),setTimeout(()=>{L(M["Sema/B12 Refill - Step 2"])},300)}),r.appendChild(a);let s=document.createElement("button");s.className="automation-btn",s.textContent="Sema/B12 Vial - Step 2",s.addEventListener("click",m=>{m.stopPropagation(),z(),setTimeout(()=>{L(M["Sema/B12 Vial - Step 2"])},300)}),r.appendChild(s);let l=document.createElement("button");l.className="automation-btn",l.textContent="Sema/B6 Vial - Step 2",l.addEventListener("click",m=>{m.stopPropagation(),z(),setTimeout(()=>{L(M["Sema/B6 Vial - Step 2"])},300)}),r.appendChild(l);let c=document.createElement("button");c.className="automation-btn",c.textContent="Sema/Lipo Vial - Step 2",c.addEventListener("click",m=>{m.stopPropagation(),z(),setTimeout(()=>{L(M["Sema/Lipo Vial - Step 2"])},300)}),r.appendChild(c);let g=document.createElement("button");g.className="automation-btn",g.textContent="Sema/NAD+ Vial - Step 2",g.addEventListener("click",m=>{m.stopPropagation(),z(),setTimeout(()=>{L(M["Sema/NAD+ Vial - Step 2"])},300)}),r.appendChild(g),n.appendChild(i),n.appendChild(r),o.appendChild(n);let u=document.createElement("div");u.className="nested-dropdown";let h=document.createElement("button");h.className="nested-dropdown-btn",h.textContent="Tirzepatide (Step 2)";let f=document.createElement("div");f.className="nested-dropdown-content",h.addEventListener("click",m=>{m.stopPropagation(),u.classList.toggle("open")});let E=document.createElement("button");E.className="automation-btn",E.textContent="Tirz/B6 Refill - Step 2",E.addEventListener("click",m=>{m.stopPropagation(),z(),setTimeout(()=>{L(M["Tirz/B6 Refill - Step 2"])},300)}),f.appendChild(E);let S=document.createElement("button");S.className="automation-btn",S.textContent="Tirz/B12 Vial - Step 2",S.addEventListener("click",m=>{m.stopPropagation(),z(),setTimeout(()=>{L(M["Tirz/B12 Vial - Step 2"])},300)}),f.appendChild(S);let b=document.createElement("button");b.className="automation-btn",b.textContent="Tirz/NAD+ Vial - Step 2",b.addEventListener("click",m=>{m.stopPropagation(),z(),setTimeout(()=>{L(M["Tirz/NAD+ Vial - Step 2"])},300)}),f.appendChild(b);let v=document.createElement("button");return v.className="automation-btn",v.textContent="Tirz/B6 Vial - Step 2",v.addEventListener("click",m=>{m.stopPropagation(),z(),setTimeout(()=>{L(M["Tirz/B6 Vial - Step 2"])},300)}),f.appendChild(v),u.appendChild(h),u.appendChild(f),o.appendChild(u),e.appendChild(t),e.appendChild(o),e}function z(){document.querySelectorAll(".dropdown.show").forEach(e=>e.classList.remove("show")),document.querySelectorAll(".nested-dropdown.open").forEach(e=>e.classList.remove("open"))}function L(e){try{console.log(`[CRM Extension] Starting workflow for "${e}"`),p(`Starting workflow for "${e}"`);let t=Array.from(document.querySelectorAll("button.btn.btn-light2.btn-xs")).find(o=>o.textContent.trim().includes("Add"));if(!t){console.error("[CRM Extension] Add Automation button not found"),p("Add Automation button not found");return}console.log("[CRM Extension] Found Add button, clicking it"),t.click(),setTimeout(()=>{let o=document.querySelector('input[placeholder="Type to search"]');if(!o){console.error("[CRM Extension] Search input not found"),p("Search input not found");return}console.log("[CRM Extension] Found search input, entering 'step 2'"),o.focus(),o.value="step 2",o.dispatchEvent(new Event("input",{bubbles:!0})),setTimeout(()=>{let n=[".v-list",".dropdown-menu",".v-select-list",".vs__dropdown-menu",'[role="listbox"]',"ul",".v-menu__content"],i=null;for(let c of n){let g=document.querySelector(c);for(let u=0;u<=10;u++)if(g&&g.querySelector("li, .v-list-item, .dropdown-item")&&g.scrollHeight>g.clientHeight){i=g,console.log(`[CRM Extension] Found scrollable dropdown container: ${c}`);break}}if(!i){let c=document.querySelector('.modal, dialog, [role="dialog"]');if(c){let g=Array.from(c.querySelectorAll("*")).filter(u=>u.scrollHeight>u.clientHeight&&u.clientHeight>50);g.length>0&&(i=g[0],console.log("[CRM Extension] Found scrollable element via fallback method"))}}if(!i){console.error("[CRM Extension] Could not find scrollable container"),p("Could not find dropdown container");return}console.log("[CRM Extension] Starting scroll wheel simulation"),console.log(`[CRM Extension] Container dimensions: ${i.scrollHeight}x${i.clientHeight}`);let r=0,a=20,s=!1;function l(){if(s||r>=a){s||(console.error("[CRM Extension] Max scroll attempts reached without finding match"),p("Option not found after scrolling"));return}r++,console.log(`[CRM Extension] Scroll attempt ${r}/${a}`);let c=new WheelEvent("wheel",{deltaY:100,bubbles:!0});i.dispatchEvent(c),i.scrollTop+=100,console.log(`[CRM Extension] Scrolled to position: ${i.scrollTop}/${i.scrollHeight}`),setTimeout(()=>{let g=i.querySelectorAll('li, .v-list-item, .dropdown-item, [role="option"]');console.log(`[CRM Extension] Found ${g.length} options after scrolling`);for(let u of g){if(!u.textContent)continue;let h=u.textContent.trim();if(h===e&&!h.includes("Provider Paid")&&!h.includes("New Patient")){console.log(`[CRM Extension] Found exact matching option: "${h}"`);try{u.scrollIntoView({block:"center"}),setTimeout(()=>{u.click(),s=!0,setTimeout(()=>{let f=Array.from(document.querySelectorAll("button")).find(E=>E.textContent.trim()==="Add");f?(console.log("[CRM Extension] Clicking Add button in dialog"),f.click(),p(`Added "${e}" workflow`)):(console.error("[CRM Extension] Add button in dialog not found"),p("Add button in dialog not found"))},1e3)},300)}catch(f){console.error("[CRM Extension] Error clicking option:",f)}break}}if(!s){if(i.scrollHeight-i.scrollTop<=i.clientHeight+20){console.log("[CRM Extension] Reached bottom of dropdown without finding match"),p(`Reached end without finding "${e}"`);return}setTimeout(l,500)}},500)}l()},1500)},1e3)}catch(t){console.error("[CRM Extension] Error in workflow:",t),p(`Error in workflow: ${t.message}`)}}var Lt=null,It=null,Bt=null,Pt=null;function ct(){let e=document.createElement("div");e.id="crm-api-bar",e.style.display="flex",e.style.flexDirection="row",e.style.alignItems="center",e.style.gap="8px",e.style.background="#23272e",e.style.borderRadius="4px",e.style.padding="4px 8px",e.style.margin="0 0 4px 0",e.style.minWidth="0",e.style.boxShadow="0px 4px 8px 0px rgba(0,0,0,0.10)",e.style.border="1px solid rgba(255,255,255,0.06)";let t=document.createElement("label");t.textContent="Medication:",t.style.marginRight="2px",t.style.fontSize="12px",t.style.color="#e6e6e6";let o=document.createElement("select");o.style.marginRight="4px",o.style.background="#23272e",o.style.color="#a0e0ff",o.style.border="1px solid #444",o.style.borderRadius="2px",o.style.padding="2px 6px",o.style.fontWeight="bold",o.style.fontSize="12px",o.style.height="24px",o.innerHTML=`
    <option value="">Select</option>
    <option value="Tirzepatide">Tirzepatide</option>
    <option value="Semaglutide">Semaglutide</option>
  `;let n=document.createElement("label");n.textContent="Compound:",n.style.marginRight="2px",n.style.fontSize="12px",n.style.color="#e6e6e6";let i=document.createElement("select");i.style.marginRight="4px",i.style.background="#23272e",i.style.color="#a0e0ff",i.style.border="1px solid #444",i.style.borderRadius="2px",i.style.padding="2px 6px",i.style.fontWeight="bold",i.style.fontSize="12px",i.style.height="24px";let r=document.createElement("label");r.textContent="Dosage (ml):",r.style.marginRight="2px",r.style.fontSize="12px",r.style.color="#e6e6e6";let a=document.createElement("select");a.style.marginRight="4px",a.style.background="#23272e",a.style.color="#a0e0ff",a.style.border="1px solid #444",a.style.borderRadius="2px",a.style.padding="2px 6px",a.style.fontWeight="bold",a.style.fontSize="12px",a.style.height="24px";let s=document.createElement("label");s.textContent="Step:",s.style.marginRight="2px",s.style.fontSize="12px",s.style.color="#e6e6e6";let l=document.createElement("select");l.style.marginRight="4px",l.style.background="#23272e",l.style.color="#a0e0ff",l.style.border="1px solid #444",l.style.borderRadius="2px",l.style.padding="2px 6px",l.style.fontWeight="bold",l.style.fontSize="12px",l.style.height="24px",l.innerHTML=`
    <option value="">Select</option>
    <option value="Step 1: Verify first name">Step 1: Verify first name</option>
    <option value="Step 1.5: Verify first name">Step 1.5: Verify first name</option>
    <option value="Step 2: Verify form">Step 2: Verify form</option>
    <option value="Step 4: Sending payment">Step 4: Sending payment</option>
  `;let c=document.createElement("button");c.textContent="Submit",c.style.marginLeft="6px",c.style.padding="2px 12px",c.style.background="#1e90ff",c.style.color="#fff",c.style.border="none",c.style.borderRadius="3px",c.style.fontWeight="bold",c.style.fontSize="12px",c.style.cursor="pointer",c.style.height="24px",c.addEventListener("mouseenter",()=>c.style.background="#0074d9"),c.addEventListener("mouseleave",()=>c.style.background="#1e90ff");function g(){let b=o.value;i.innerHTML=`<option value="">Select</option>
      <option value="NAD+ vial">NAD+ vial</option>
      <option value="Lipo vial">Lipo vial</option>
      <option value="B6 vial">B6 vial</option>
      <option value="B12 vial">B12 vial</option>
      ${b==="Tirzepatide"?'<option value="B6 syringe">B6 syringe</option>':""}
      ${b==="Semaglutide"?'<option value="B12 syringe">B12 syringe</option>':""}
    `,i.value="",u()}function u(){let b=i.value,v=o.value,m=[];b&&b.toLowerCase().includes("syringe")?v==="Tirzepatide"?m=["QTY: 1 - 0.25","QTY: 2 - 0.5","QTY: 3 - 0.75","QTY: 4 - 1.0","QTY: 5 - 1.25","QTY: 6 - 1.5"]:v==="Semaglutide"&&(m=["QTY: 0.5 - 0.125","QTY: 1 - 0.25","QTY: 2 - 0.5","QTY: 3 - 0.75","QTY: 4 - 1.0","QTY: 5 - 1.25","QTY: 6 - 1.5","QTY: 7 - 1.75","QTY: 8 - 2.0"]):b&&b.toLowerCase().includes("vial")&&(m=["2.5","5","7.5","10"]),a.innerHTML='<option value="">Select</option>'+m.map(y=>`<option value="${y} ml">${y} ml</option>`).join(""),a.value=""}o.addEventListener("change",()=>{Lt=o.value,g()}),i.addEventListener("change",()=>{It=i.value,u()}),a.addEventListener("change",()=>{Bt=a.value}),l.addEventListener("change",()=>{Pt=l.value});let h=(b,v,m)=>[b,v,m].map(y=>(y||"").trim()).join("|"),f=(b,v,m)=>[b,v,m].map(y=>(y||"").trim()).join("|"),E={"Tirzepatide|B6 syringe|QTY: 1 - 0.25 ml":"api-tirz-b6-0.25ml-syringe","Tirzepatide|B6 syringe|QTY: 2 - 0.5 ml":"api-tirz-b6-0.5ml-syringe","Tirzepatide|B6 syringe|QTY: 3 - 0.75 ml":"api-tirz-b6-0.75ml-syringe","Tirzepatide|B6 syringe|QTY: 4 - 1.0 ml":"api-tirz-b6-1.0ml-syringe","Tirzepatide|B6 syringe|QTY: 5 - 1.25 ml":"api-tirz-b6-1.25ml-syringe","Tirzepatide|B6 syringe|QTY: 6 - 1.5 ml":"api-tirz-b6-1.5ml-syringe","Semaglutide|B12 syringe|QTY: 0.5 - 0.125 ml":"api-sema-b12-0.125ml-syringe","Semaglutide|B12 syringe|QTY: 1 - 0.25 ml":"api-sema-b12-0.25ml-syringe","Semaglutide|B12 syringe|QTY: 2 - 0.5 ml":"api-sema-b12-0.5ml-syringe","Semaglutide|B12 syringe|QTY: 3 - 0.75 ml":"api-sema-b12-0.75ml-syringe","Semaglutide|B12 syringe|QTY: 4 - 1.0 ml":"api-sema-b12-1.0ml-syringe","Semaglutide|B12 syringe|QTY: 5 - 1.25 ml":"api-sema-b12-1.25ml-syringe","Semaglutide|B12 syringe|QTY: 6 - 1.5 ml":"api-sema-b12-1.5ml-syringe","Semaglutide|B12 syringe|QTY: 7 - 1.75 ml":"api-sema-b12-1.75ml-syringe","Semaglutide|B12 syringe|QTY: 8 - 2.0 ml":"api-sema-b12-2.0ml-syringe","Tirzepatide|NAD+ vial|2.5 ml":"api-tirz-nad+-2.5ml-vial","Tirzepatide|NAD+ vial|5 ml":"api-tirz-nad+-5.0ml-vial","Tirzepatide|NAD+ vial|7.5 ml":"api-tirz-nad+-7.5ml-vial","Tirzepatide|NAD+ vial|10 ml":"api-tirz-nad+-10.0ml-vial","Tirzepatide|B6 vial|2.5 ml":"api-tirz-b6-2.5ml-vial","Tirzepatide|B6 vial|5 ml":"api-tirz-b6-5.0ml-vial","Tirzepatide|B6 vial|7.5 ml":"api-tirz-b6-7.5ml-vial","Tirzepatide|B6 vial|10 ml":"api-tirz-b6-10.0ml-vial","Tirzepatide|B12 vial|2.5 ml":"api-tirz-b12-2.5ml-vial","Tirzepatide|B12 vial|5 ml":"api-tirz-b12-5.0ml-vial","Tirzepatide|B12 vial|7.5 ml":"api-tirz-b12-7.5ml-vial","Tirzepatide|B12 vial|10 ml":"api-tirz-b12-10.0ml-vial","Semaglutide|NAD+ vial|2.5 ml":"api-sema-nad+-2.5ml-vial","Semaglutide|NAD+ vial|5 ml":"api-sema-nad+-5.0ml-vial","Semaglutide|NAD+ vial|7.5 ml":"api-sema-nad+-7.5ml-vial","Semaglutide|NAD+ vial|10 ml":"api-sema-nad+-10.0ml-vial","Semaglutide|B6 vial|2.5 ml":"api-sema-b6-2.5ml-vial","Semaglutide|B6 vial|5 ml":"api-sema-b6-5.0ml-vial","Semaglutide|B6 vial|7.5 ml":"api-sema-b6-7.5ml-vial","Semaglutide|B6 vial|10 ml":"api-sema-b6-10.0ml-vial","Semaglutide|B12 vial|2.5 ml":"api-sema-b12-2.5ml-vial","Semaglutide|B12 vial|5 ml":"api-sema-b12-5.0ml-vial","Semaglutide|B12 vial|7.5 ml":"api-sema-b12-7.5ml-vial","Semaglutide|B12 vial|10 ml":"api-sema-b12-10.0ml-vial","Semaglutide|Lipo vial|2.5 ml":"api-sema-lipo-2.5ml-vial","Semaglutide|Lipo vial|5 ml":"api-sema-lipo-5.0ml-vial","Semaglutide|Lipo vial|7.5 ml":"api-sema-lipo-7.5ml-vial","Semaglutide|Lipo vial|10 ml":"api-sema-lipo-10.0ml-vial"},S={"Tirzepatide|B6 syringe|Step 1: Verify first name":"api-refill-patient-tirz","Tirzepatide|NAD+ vial|Step 1: Verify first name":"api-refill-patient-tirz","Tirzepatide|Lipo vial|Step 1: Verify first name":"api-refill-patient-tirz","Tirzepatide|B6 vial|Step 1: Verify first name":"api-refill-patient-tirz","Tirzepatide|B12 vial|Step 1: Verify first name":"api-refill-patient-tirz","Tirzepatide|B6 syringe|Step 1.5: Verify first name":"api-refill-patient-tirz-name","Tirzepatide|NAD+ vial|Step 1.5: Verify first name":"api-refill-patient-tirz-name","Tirzepatide|Lipo vial|Step 1.5: Verify first name":"api-refill-patient-tirz-name","Tirzepatide|B6 vial|Step 1.5: Verify first name":"api-refill-patient-tirz-name","Tirzepatide|B12 vial|Step 1.5: Verify first name":"api-refill-patient-tirz-name","Tirzepatide|B6 syringe|Step 2: Verify form":"api-refill-patient-tirz-form","Tirzepatide|NAD+ vial|Step 2: Verify form":"api-refill-patient-tirz-form","Tirzepatide|Lipo vial|Step 2: Verify form":"api-refill-patient-tirz-form","Tirzepatide|B6 vial|Step 2: Verify form":"api-refill-patient-tirz-form","Tirzepatide|B12 vial|Step 2: Verify form":"api-refill-patient-tirz-form","Tirzepatide|B6 syringe|Step 3: Waiting on payment":"API - Refill - Tirzepatide Combo - (Step 3 Waiting on Payment)","Tirzepatide|NAD+ vial|Step 3: Waiting on payment":"API - Refill - Tirzepatide Combo - (Step 3 Waiting on Payment)","Tirzepatide|Lipo vial|Step 3: Waiting on payment":"API - Refill - Tirzepatide Combo - (Step 3 Waiting on Payment)","Tirzepatide|B6 vial|Step 3: Waiting on payment":"API - Refill - Tirzepatide Combo - (Step 3 Waiting on Payment)","Tirzepatide|B12 vial|Step 3: Waiting on payment":"API - Refill - Tirzepatide Combo - (Step 3 Waiting on Payment)","Tirzepatide|B6 syringe|Step 4: Sending payment":"api-tirz-refill-invoice","Tirzepatide|NAD+ vial|Step 4: Sending payment":"api-tirz-refill-invoice","Tirzepatide|Lipo vial|Step 4: Sending payment":"api-tirz-refill-invoice","Tirzepatide|B6 vial|Step 4: Sending payment":"api-tirz-refill-invoice","Tirzepatide|B12 vial|Step 4: Sending payment":"api-tirz-refill-invoice","Semaglutide|B12 syringe|Step 1: Verify first name":"api-refill-patient-sema","Semaglutide|NAD+ vial|Step 1: Verify first name":"api-refill-patient-sema","Semaglutide|Lipo vial|Step 1: Verify first name":"api-refill-patient-sema","Semaglutide|B6 vial|Step 1: Verify first name":"api-refill-patient-sema","Semaglutide|B12 vial|Step 1: Verify first name":"api-refill-patient-sema","Semaglutide|B12 syringe|Step 1.5: Verify first name":"api-refill-patient-sema-name","Semaglutide|NAD+ vial|Step 1.5: Verify first name":"api-refill-patient-sema-name","Semaglutide|Lipo vial|Step 1.5: Verify first name":"api-refill-patient-sema-name","Semaglutide|B6 vial|Step 1.5: Verify first name":"api-refill-patient-sema-name","Semaglutide|B12 vial|Step 1.5: Verify first name":"api-refill-patient-sema-name","Semaglutide|B12 syringe|Step 2: Verify form":"api-refill-patient-sema-form","Semaglutide|NAD+ vial|Step 2: Verify form":"api-refill-patient-sema-form","Semaglutide|Lipo vial|Step 2: Verify form":"api-refill-patient-sema-form","Semaglutide|B6 vial|Step 2: Verify form":"api-refill-patient-sema-form","Semaglutide|B12 vial|Step 2: Verify form":"api-refill-patient-sema-form","Semaglutide|B12 syringe|Step 3: Waiting on payment":"API - Refill - Semaglutide Combo - (Step 3 Waiting on Payment)","Semaglutide|NAD+ vial|Step 3: Waiting on payment":"API - Refill - Semaglutide Combo - (Step 3 Waiting on Payment)","Semaglutide|Lipo vial|Step 3: Waiting on payment":"API - Refill - Semaglutide Combo - (Step 3 Waiting on Payment)","Semaglutide|B6 vial|Step 3: Waiting on payment":"API - Refill - Semaglutide Combo - (Step 3 Waiting on Payment)","Semaglutide|B12 vial|Step 3: Waiting on payment":"API - Refill - Semaglutide Combo - (Step 3 Waiting on Payment)","Semaglutide|B12 syringe|Step 4: Sending payment":"api-sema-refill-invoice","Semaglutide|NAD+ vial|Step 4: Sending payment":"api-sema-refill-invoice","Semaglutide|Lipo vial|Step 4: Sending payment":"api-sema-refill-invoice","Semaglutide|B6 vial|Step 4: Sending payment":"api-sema-refill-invoice","Semaglutide|B12 vial|Step 4: Sending payment":"api-sema-refill-invoice"};return c.addEventListener("click",()=>{if(!o.value||!i.value||!a.value||!l.value){p("Please select all required options before proceeding.");return}let b=h(o.value,i.value,l.value),v=f(o.value,i.value,a.value),m=S[b],y=E[v];if(!m){p("No automation found for this selection."),console.error("No automation found for key:",b);return}if(!y){p("No dosage found for this selection."),console.error("No dosage found for key:",v);return}Dt(m,y)}),e.appendChild(t),e.appendChild(o),e.appendChild(n),e.appendChild(i),e.appendChild(r),e.appendChild(a),e.appendChild(s),e.appendChild(l),e.appendChild(c),g(),e}async function Dt(e,t){try{let[o,n]=await Promise.all([W(),Y()]);console.log("[CRM Extension] Cleanup completed:"),console.log(`- Tags: ${o.removed}/${o.total} removed`),console.log(`- Automations: ${n.removed}/${n.total} removed`),await st(t),await st(e)}catch(o){console.error("[CRM Extension] Error during cleanup:",o),p("Error during cleanup. Please try again.")}}function $t(){let e=document.querySelector('input[placeholder="Add Tags"]');if(e)return e;let t=Array.from(document.querySelectorAll("input[placeholder]")).filter(r=>r.placeholder.toLowerCase().includes("tag"));if(t.length>0)return t[0];let o=document.querySelectorAll(".tag-input, .tags-input, .tag-container");for(let r of o){let a=r.querySelector("input");if(a)return a}if(e=document.querySelector('input[placeholder="smartList.bulkTags.addTags"]'),e)return e;let n=document.querySelectorAll(".hl-text-input");if(n.length>0)return n[0];console.error("[CRM Extension] Could not find tag input field with any strategy");let i=document.querySelectorAll("input");return console.log("[CRM Extension] All inputs on page:",i),null}function st(e){return new Promise(t=>{let o=$t();o?(o.focus(),setTimeout(()=>{o.value=e,o.dispatchEvent(new Event("input",{bubbles:!0})),setTimeout(()=>{let n=document.querySelectorAll(".v-list-item, .dropdown-item, .select-option, li"),i=!1;for(let r of n)if(r.textContent.toLowerCase().includes(e)){r.click(),i=!0,p(`Selected tag: ${e}`);break}if(!i){let r=document.querySelectorAll("*");for(let a of r)if(a.textContent.trim().toLowerCase()===e){a.click(),i=!0,p(`Selected tag: ${e}`);break}i||o.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",code:"Enter",keyCode:13,which:13,bubbles:!0}))}setTimeout(t,400)},300)},300)):(p("Tags field not found"),t())})}function dt(){let e=document.createElement("div");return e.className="group",e.id="crm-dropdowns-group",e.appendChild(lt()),e.appendChild(rt()),e.appendChild(ct()),document.addEventListener("click",t=>{document.querySelectorAll(".dropdown").forEach(n=>{n.contains(t.target)||(n.classList.remove("show"),n.querySelectorAll(".nested-dropdown").forEach(r=>{r.classList.remove("open")}))})}),Vt(),e}function Vt(){if(document.getElementById("custom-dropdown-styles"))return;let e=document.createElement("style");e.id="custom-dropdown-styles",e.textContent=`
    /* Improved dropdown positioning */
    .dropdown {
      position: relative !important;
      margin-right: 8px !important; /* Ensure space between dropdowns, reduced for tighter layout */
    }

    .dropdown:last-child {
      margin-right: 0 !important; /* Remove margin from the last dropdown */
    }

    .dropdown-content {
      position: absolute !important;
      background-color: #2F3A4B; /* Match toolbar background color */
      min-width: 220px !important; /* Increased width */
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.3);
      z-index: 999;
      border-radius: 4px;
      margin-top: 5px !important; /* Add space between button and dropdown */
      left: 0;
      top: 100% !important; /* Position below the button */
      display: none;
      border: 1px solid rgba(255, 255, 255, 0.1); /* Subtle border */
    }

    /* Ensure right-aligned dropdowns don't overflow */
    #crm-tags-dropdown .dropdown-content {
      right: 0;
      left: auto; /* Override left positioning for Tags dropdown */
    }

    .dropdown.show .dropdown-content {
      display: block;
    }

    /* Improved nested dropdown positioning */
    .nested-dropdown-content {
      margin-top: 3px !important;
      background-color: #2F3A4B; /* Match toolbar background color */
      border-radius: 4px;
      padding: 5px !important;
    }

    /* Style dropdown items */
    .dropdown-item {
      color: #e6e6e6; /* White text for visibility */
      padding: 10px 14px !important; /* Increased padding */
      text-decoration: none;
      display: block;
      font-size: 14px;
      cursor: pointer;
      border-radius: 3px;
      font-weight: normal;
    }

    .dropdown-item:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }

    /* Fix for Vial-Sema and Vial-Tirz nested dropdowns */
    .nested-dropdown-btn {
      text-align: left !important;
      padding: 8px 12px !important;
      background-color: rgba(255, 255, 255, 0.1) !important;
      border: 1px solid rgba(255, 255, 255, 0.15) !important;
      color: #e6e6e6 !important;
      font-weight: bold !important;
    }

    .nested-dropdown-btn:hover {
      background-color: rgba(255, 255, 255, 0.2) !important;
    }

    /* Force visibility for Tags dropdown */
    #crm-tags-dropdown {
      display: flex !important;
    }

    #crm-tags-dropdown .dropdown-content {
      min-width: 220px !important;
    }
  `,document.head.appendChild(e)}function pt(){let e=document.createElement("div");e.className="group",e.id="crm-settings-group",e.style.position="relative";let t=document.createElement("button");t.className="btn",t.id="crm-settings-btn";let o=document.createElement("span");o.className="btn-icon",o.innerHTML="\u2699\uFE0F",t.appendChild(o);let n=document.createElement("span");n.textContent="Settings",t.appendChild(n);let i=_t();if(t.addEventListener("click",r=>{r.stopPropagation(),i.classList.toggle("show")}),document.addEventListener("click",r=>{r.target!==t&&!t.contains(r.target)&&r.target!==i&&!i.contains(r.target)&&i.classList.remove("show")}),!document.getElementById("settings-dropdown-styles")){let r=document.createElement("style");r.id="settings-dropdown-styles",r.textContent=`
      #mcp-crm-settings-dropdown {
        display: none;
        position: absolute;
        top: calc(100% + 5px); /* Position below the button with 5px gap */
        right: 0;
        z-index: 1000;
        min-width: 230px;
        background-color: #2F3A4B;
        border-radius: 4px;
        border: 1px solid rgba(255, 255, 255, 0.1);
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
        overflow: hidden;
      }
      
      #mcp-crm-settings-dropdown.show {
        display: block;
      }
      
      .settings-header {
        padding: 10px;
        background-color: rgba(255, 255, 255, 0.1);
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        font-weight: bold;
        color: #e6e6e6;
      }
      
      .settings-body {
        padding: 10px;
        color: #e6e6e6;
      }
      
      .setting-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
        font-size: 13px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        padding-bottom: 10px;
      }
      
      .setting-item:last-child {
        margin-bottom: 0;
        border-bottom: none;
        padding-bottom: 0;
      }
      
      .setting-label {
        color: #e6e6e6;
        font-weight: normal;
      }
      
      /* Toggle switch styles */
      .switch {
        position: relative;
        display: inline-block;
        width: 40px;
        height: 20px;
      }
      
      .switch input {
        opacity: 0;
        width: 0;
        height: 0;
      }
      
      .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #555;
        transition: .4s;
        border-radius: 34px;
      }
      
      .slider:before {
        position: absolute;
        content: "";
        height: 16px;
        width: 16px;
        left: 2px;
        bottom: 2px;
        background-color: white;
        transition: .4s;
        border-radius: 50%;
      }
      
      input:checked + .slider {
        background-color: #2196F3;
      }
      
      input:focus + .slider {
        box-shadow: 0 0 1px #2196F3;
      }
      
      input:checked + .slider:before {
        transform: translateX(20px);
      }
      
      /* Version info styles */
      .version-info {
        border-top: 1px solid rgba(255, 255, 255, 0.1);
        margin-top: 10px;
        padding-top: 10px;
        font-size: 12px;
        color: #e6e6e6;
      }
      
      .version-info p {
        margin: 5px 0;
        color: #e6e6e6;
      }
      
      .version-number {
        font-weight: 600;
        color: #e6e6e6;
      }
      
      .check-updates-btn {
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 3px;
        padding: 4px 8px;
        margin-top: 5px;
        font-size: 11px;
        cursor: pointer;
        transition: background-color 0.2s;
        width: 100%;
        text-align: center;
        color: #e6e6e6;
      }
      
      .check-updates-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      
      .check-updates-btn:disabled {
        opacity: 0.6;
        cursor: not-allowed;
      }
      
      #crm-update-status {
        margin: 5px 0 0 0;
        padding: 3px 6px;
        font-size: 11px;
        border-radius: 3px;
        background-color: rgba(255, 255, 255, 0.05);
        text-align: center;
        transition: all 0.3s ease;
        color: #e6e6e6;
      }
      
      #last-update-check {
        font-size: 11px;
        margin: 5px 0;
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        color: #e6e6e6;
      }
      
      .check-status {
        font-size: 10px;
        margin-left: 5px;
        padding: 1px 4px;
        border-radius: 3px;
        font-weight: normal;
      }
      
      .loading-text {
        font-style: italic;
        color: #aaa;
      }
      
      /* Section styles */
      .setting-section {
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      }
      
      .setting-section-title {
        font-size: 12px;
        font-weight: bold;
        color: #e6e6e6;
        margin-bottom: 10px;
      }
    `,document.head.appendChild(r)}return e.appendChild(t),e.appendChild(i),e}function qt(e){try{(typeof browser<"u"?browser:chrome).runtime.sendMessage({action:"getLastUpdateCheck"}).then(o=>{if(o&&o.success&&o.lastUpdateCheck){let n=o.lastUpdateCheck,i="",r="";n.success?n.status==="update_available"?(i="Update available",r="#4CAF50"):n.status==="no_update"?(i="No updates needed",r="#2196F3"):n.status==="throttled"?(i="Check throttled",r="#FF9800"):(i="Completed",r="#2196F3"):(i="Failed",r="#F44336"),e.innerHTML=`Last Check: <span class="version-number">${n.formattedTime}</span> <span class="check-status" style="color:${r};font-size:10px;margin-left:5px;">${i}</span>`}else e.innerHTML='Last Check: <span class="version-number">No checks recorded</span>'}).catch(o=>{console.error("[CRM Extension] Error fetching last update check:",o),e.innerHTML='Last Check: <span class="version-number">Unknown</span>'})}catch(t){console.error("[CRM Extension] Error in fetchLastUpdateCheckInfo:",t),e.innerHTML='Last Check: <span class="version-number">Error</span>'}}function _t(){let e=document.createElement("div");e.id="mcp-crm-settings-dropdown";let t=document.createElement("div");t.className="settings-header",t.textContent="CRM+ Settings",e.appendChild(t);let o=document.createElement("div");if(o.className="settings-body",e.appendChild(o),!document.getElementById("collapsible-settings-styles")){let s=document.createElement("style");s.id="collapsible-settings-styles",s.textContent=`
      .setting-section {
        margin-bottom: 8px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        padding-bottom: 0; /* No bottom padding when collapsed */
      }
      
      .setting-section-title {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 13px;
        font-weight: bold;
        color: #e6e6e6;
        padding: 8px 0;
        cursor: pointer;
        user-select: none;
      }
      
      .setting-section-title:after {
        content: "\u25BC";
        font-size: 8px;
        color: #e6e6e6;
        transition: transform 0.2s ease;
      }
      
      .setting-section.collapsed .setting-section-title:after {
        transform: rotate(-90deg);
      }
      
      .setting-section-content {
        max-height: 500px;
        overflow: hidden;
        transition: max-height 0.3s ease, opacity 0.2s ease, margin-bottom 0.3s ease;
        opacity: 1;
        margin-bottom: 10px;
      }
      
      .setting-section.collapsed .setting-section-content {
        max-height: 0;
        opacity: 0;
        margin-bottom: 0;
      }
    `,document.head.appendChild(s)}let n=Se("General Settings");n.content.appendChild($("Show Header Bar","crmplus_headerBarVisible",s=>{let l=document.getElementById("mcp-crm-header");l&&(l.style.display=s?"flex":"none",document.body.style.paddingTop=s?"32px":"0"),p(`Header bar: ${s?"Visible":"Hidden"}`)},!0)),n.content.appendChild($("Show Provider-Paid Alerts","crmplus_showProviderPaidAlerts",s=>{p(`Provider-Paid alerts: ${s?"Enabled":"Disabled"}`)},!0)),o.appendChild(n.section);let i=Se("External Links");i.content.appendChild($("Show ShipStation Link","crmplus_showShipStation",s=>{let l=document.querySelector(".shipstation-link");l&&(l.style.display=s?"flex":"none"),p(`ShipStation link: ${s?"Visible":"Hidden"}`)},!0)),i.content.appendChild($("Show Stripe Link","crmplus_showStripe",s=>{let l=document.querySelector(".stripe-link");l&&(l.style.display=s?"flex":"none"),p(`Stripe link: ${s?"Visible":"Hidden"}`)},!0)),i.content.appendChild($("Show Webmail Link","crmplus_showWebmail",s=>{let l=document.querySelector(".webmail-link");l&&(l.style.display=s?"flex":"none"),p(`Webmail link: ${s?"Visible":"Hidden"}`)},!0)),o.appendChild(i.section);let r=Se("Features");r.content.appendChild($("Auto-copy phone number on page load","crmplus_autoCopyPhone",s=>{p(`Auto-copy phone: ${s?"Enabled":"Disabled"}`)},!1)),r.content.appendChild($("CRM Automation","crmplus_automationEnabled",s=>{[document.getElementById("crm-automation-dropdown"),document.getElementById("crm-tags-dropdown")].forEach(c=>{c?(c.style.display=s?"flex":"none",console.log(`[CRM Extension] Changed visibility for ${c.id}: ${s?"visible":"hidden"}`)):console.error("[CRM Extension] Could not find automation element to toggle")}),p(`CRM Automation: ${s?"Enabled":"Disabled"}`)},!0)),o.appendChild(r.section);let a=Ht();return o.appendChild(a),e}function Se(e,t=!1){let o=document.createElement("div");o.className="setting-section"+(t?" collapsed":"");let n=document.createElement("div");n.className="setting-section-title",n.textContent=e,n.addEventListener("click",()=>{o.classList.toggle("collapsed")}),o.appendChild(n);let i=document.createElement("div");return i.className="setting-section-content",o.appendChild(i),{section:o,content:i}}function Ht(){let e=document.createElement("div");e.className="version-info";let t="Loading...",o="Loading...";try{let l=(typeof browser<"u"?browser:chrome).runtime.getManifest();if(l&&l.version&&(t=l.version,t.includes("."))){let c=t.split(".");if(c.length===3&&c[0].length===4){let g=c[0],u=c[1],h=c[2];o=`${u}/${h}/${g}`}}}catch(s){console.error("[CRM Extension] Error fetching version:",s),t="Unknown",o="Unknown"}let n=document.createElement("p");n.innerHTML=`Version: <span class="version-number">${t}</span>`,e.appendChild(n);let i=document.createElement("p");i.innerHTML=`Last Updated: <span class="version-number">${o}</span>`,e.appendChild(i);let r=document.createElement("p");r.id="last-update-check",r.innerHTML='Last Check: <span class="loading-text">Loading...</span>',e.appendChild(r),qt(r);let a=document.createElement("button");return a.className="check-updates-btn",a.textContent="Check for Updates",a.addEventListener("click",()=>{let s=typeof browser<"u"?browser:chrome;a.disabled=!0,a.textContent="Checking...",p("Checking for updates...");let l=document.getElementById("crm-update-status");l||(l=document.createElement("p"),l.id="crm-update-status",l.style.fontSize="11px",l.style.marginTop="5px",l.style.color="#e6e6e6",l.textContent="",e.appendChild(l)),s.runtime.sendMessage({action:"checkForUpdates"}).then(c=>{if(c&&c.success){p("Update check completed"),c.updateStatus==="update_available"?(l.textContent=`Update available (${c.updateVersion})`,l.style.color="#4CAF50"):c.updateStatus==="no_update"?(l.textContent="You have the latest version",l.style.color="#2196F3"):c.updateStatus==="throttled"?(l.textContent="Update check throttled, try again later",l.style.color="#FF9800"):c.updateStatus==="error"?(l.textContent="Error checking for updates",l.style.color="#F44336"):(l.textContent="Update check initiated",l.style.color="#e6e6e6");let g=document.getElementById("last-update-check");if(g&&c.lastCheck){let u=c.lastCheck,h="",f="";u.success?u.status==="update_available"?(h="Update available",f="#4CAF50"):u.status==="no_update"?(h="No updates needed",f="#2196F3"):u.status==="throttled"?(h="Check throttled",f="#FF9800"):(h="Completed",f="#2196F3"):(h="Failed",f="#F44336"),g.innerHTML=`Last Check: <span class="version-number">${u.formattedTime}</span> <span class="check-status" style="color:${f};font-size:10px;margin-left:5px;">${h}</span>`}}else p("Error checking for updates"),l.textContent="Update check failed",l.style.color="#F44336";a.disabled=!1,a.textContent="Check for Updates"}).catch(c=>{console.error("[CRM Extension] Error sending update check message:",c),p("Error checking for updates"),l.textContent="Connection failed",l.style.color="#F44336",a.disabled=!1,a.textContent="Check for Updates"})}),e.appendChild(a),e}function $(e,t,o,n=!1){let i=document.createElement("div");i.className="setting-item";let r=document.createElement("div");r.className="setting-label",r.textContent=e,i.appendChild(r);let a=document.createElement("label");a.className="switch";let s=document.createElement("input");s.type="checkbox";let l=localStorage.getItem(t),c=l!==null?l==="true":n;l===null&&localStorage.setItem(t,n.toString()),s.checked=c,s.addEventListener("change",()=>{let u=s.checked;localStorage.setItem(t,u.toString()),o&&typeof o=="function"&&o(u)});let g=document.createElement("span");return g.className="slider",a.appendChild(s),a.appendChild(g),i.appendChild(a),i}function mt(){if(document.getElementById("mcp-crm-header-styles"))return;let e=document.createElement("style");e.id="mcp-crm-header-styles",e.textContent=`
    #mcp-crm-header {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 32px;
      background-color: #2F3A4B;
      display: flex;
      align-items: center;
      padding: 0 15px;
      font-family: 'Segoe UI', 'Roboto', sans-serif;
      font-size: 12px;
      z-index: 999999;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    }
    
    #mcp-crm-header .group {
      display: flex;
      align-items: center;
      margin-right: 15px;
      border-right: 1px solid rgba(255, 255, 255, 0.1);
      padding-right: 15px;
    }
    
    #mcp-crm-header .group:last-child {
      border-right: none;
      margin-right: 0; /* Remove margin from the last group (Settings) */
    }
    
    /* Special styling for dropdowns group to match other elements' spacing */
    #crm-dropdowns-group {
      margin-right: 15px; /* Same spacing as other elements */
      padding-right: 15px; /* Same padding as other elements */
    }
    
    /* Ensure settings is positioned at the far right */
    #crm-settings-btn {
      margin-right: 0;
    }
    
    #mcp-crm-header .spacer {
      flex-grow: 1;
    }
    
    #mcp-crm-header .label {
      color: #8a9cad;
      margin-right: 6px;
      font-weight: 500;
    }
    
    #mcp-crm-header .value {
      color: #e6e6e6;
      font-weight: 600;
    }
    
    #mcp-crm-header .clickable-value {
      color: #e6e6e6;
      font-weight: 600;
      cursor: pointer;
      background-color: rgba(255, 255, 255, 0.05);
      padding: 2px 8px;
      border-radius: 3px;
      transition: background-color 0.2s;
      display: inline-flex;
      align-items: center;
    }
    
    #mcp-crm-header .clickable-value:hover {
      background-color: rgba(255, 255, 255, 0.15);
    }
    
    #mcp-crm-header .btn-icon {
      margin-right: 4px;
      font-size: 10px;
    }
    
    /* Logo link styling */
    #mcp-crm-header .logo-link {
      display: flex;
      align-items: center;
      text-decoration: none;
      transition: all 0.2s ease;
    }
    
    #mcp-crm-header .logo-link:hover {
      opacity: 0.85;
    }
    
    #mcp-crm-header .logo-icon {
      width: 16px;
      height: 16px;
      margin-right: 6px;
    }
    
    #mcp-crm-header .logo {
      font-weight: bold;
      color: white;
      font-size: 14px;
    }
    
    #mcp-crm-header .external-link {
      text-decoration: none;
      color: #e6e6e6;
      display: flex;
      align-items: center;
      transition: all 0.2s ease;
      margin-right: 10px;
    }
    
    #mcp-crm-header .external-link:hover {
      background: rgba(255, 255, 255, 0.2);
      transform: translateY(-1px);
    }
    
    #mcp-crm-header .ext-link-icon {
      font-size: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    /* Styling for text links with icons */
    #mcp-crm-header .text-link {
      text-decoration: none;
      margin-right: 4px; /* Reduced margin between buttons */
      font-size: 12px;
      padding: 3px 6px; /* Reduced horizontal padding to make buttons skinnier */
      border-radius: 3px;
      color: #e6e6e6;
      display: flex;
      align-items: center;
      justify-content: center; /* Center content horizontally */
      white-space: nowrap; /* Prevent text wrapping */
      min-width: 68px; /* Set minimum width to keep consistency */
    }
    
    #mcp-crm-header .text-link:hover {
      background-color: rgba(255, 255, 255, 0.15);
    }
    
    #mcp-crm-header .text-link .link-icon {
      margin-right: 4px; /* Slightly reduced margin for tighter look */
      width: 16px;
      height: 16px;
      vertical-align: middle;
      flex-shrink: 0; /* Prevent icon from shrinking */
    }
    
    /* Add a specific class for each button to fine-tune widths if needed */
    #mcp-crm-header .shipstation-link {
      min-width: 92px;
    }
    
    #mcp-crm-header .stripe-link {
      min-width: 65px;
    }
    
    #mcp-crm-header .webmail-link {
      min-width: 78px;
    }
    
    #mcp-crm-header .btn {
      color: #e6e6e6;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 3px;
      padding: 4px 8px;
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      margin-right: 8px;
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
    }
    
    #mcp-crm-header .btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    #mcp-crm-header .btn:active {
      background-color: rgba(255, 255, 255, 0.3);
    }
    
    #mcp-crm-header .btn:last-child {
      margin-right: 0;
    }
    
    /* Dropdown styling */
    .dropdown {
      position: relative;
      display: inline-block;
      margin-right: 8px;
    }
    
    .dropdown-btn {
      color: #e6e6e6;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 3px;
      padding: 4px 8px;
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
      justify-content: space-between;
      min-width: 100px;
    }
    
    .dropdown-btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .dropdown-btn:after {
      content: "\u25BC";
      font-size: 8px;
      margin-left: 5px;
    }
    
    .dropdown-content {
      display: none;
      position: absolute;
      background-color: #2F3A4B;
      min-width: 180px;
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.3);
      z-index: 1000000;
      border-radius: 4px;
      border: 1px solid rgba(255, 255, 255, 0.1);
      margin-top: 2px;
      left: 0;
    }
    
    .dropdown.show .dropdown-content {
      display: block;
    }
    
    .dropdown-item {
      color: #e6e6e6;
      padding: 8px 12px;
      text-decoration: none;
      display: block;
      font-size: 12px;
      cursor: pointer;
      font-weight: normal;
    }
    
    .dropdown-item:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
    
    /* Nested Dropdown styling */
    .nested-dropdown {
      margin-bottom: 5px;
      width: 100%;
    }
    
    .nested-dropdown-btn {
      width: 100%;
      text-align: left;
      padding: 6px 10px;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 3px;
      cursor: pointer;
      font-weight: bold;
      font-size: 12px;
      color: #e6e6e6;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .nested-dropdown-btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .nested-dropdown-btn:after {
      content: "\u25BC";
      font-size: 8px;
      color: #e6e6e6;
    }
    
    .nested-dropdown-content {
      display: none;
      padding: 5px 0 5px 10px;
      background-color: #2F3A4B;
    }
    
    .nested-dropdown.open .nested-dropdown-content {
      display: block;
    }
    
    .nested-dropdown-item {
      display: block;
      padding: 5px 10px;
      color: #e6e6e6;
      text-decoration: none;
      font-size: 12px;
      cursor: pointer;
      border-radius: 3px;
      font-weight: normal;
    }
    
    .nested-dropdown-item:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
    
    /* Settings dropdown styling */
    #mcp-crm-settings-dropdown {
      position: absolute;
      top: 32px;
      right: 15px;
      background-color: #2F3A4B;
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 4px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.3);
      min-width: 200px;
      z-index: 1000000;
      display: none;
      color: #e6e6e6;
    }
    
    #mcp-crm-settings-dropdown.show {
      display: block;
    }
    
    #mcp-crm-settings-dropdown .settings-header {
      background-color: rgba(255, 255, 255, 0.1);
      color: #e6e6e6;
      padding: 8px 12px;
      font-weight: bold;
      border-top-left-radius: 3px;
      border-top-right-radius: 3px;
    }
    
    #mcp-crm-settings-dropdown .settings-body {
      padding: 10px;
    }
    
    #mcp-crm-settings-dropdown .setting-item {
      display: flex;
      align-items: center;
      margin-bottom: 8px;
      padding-bottom: 8px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    #mcp-crm-settings-dropdown .setting-item:last-child {
      margin-bottom: 0;
      padding-bottom: 0;
      border-bottom: none;
    }
    
    #mcp-crm-settings-dropdown .setting-label {
      flex-grow: 1;
      font-size: 13px;
      color: #e6e6e6;
    }
    
    /* Toggle switch styling */
    .switch {
      position: relative;
      display: inline-block;
      width: 40px;
      height: 20px;
    }
    
    .switch input { 
      opacity: 0;
      width: 0;
      height: 0;
    }
    
    .slider {
      position: absolute;
      cursor: pointer;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: #555;
      transition: .4s;
      border-radius: 34px;
    }
    
    .slider:before {
      position: absolute;
      content: "";
      height: 16px;
      width: 16px;
      left: 2px;
      bottom: 2px;
      background-color: white;
      transition: .4s;
      border-radius: 50%;
    }
    
    input:checked + .slider {
      background-color: #2196F3;
    }
    
    input:checked + .slider:before {
      transform: translateX(20px);
    }
    
    /* Version info section in settings */
    .version-info {
      border-top: 1px solid rgba(255, 255, 255, 0.1);
      margin-top: 10px;
      padding-top: 10px;
      font-size: 12px;
      color: #e6e6e6;
    }
    
    .version-info p {
      margin: 5px 0;
    }
    
    .version-number {
      font-weight: 600;
      color: #e6e6e6;
    }
    
    .check-updates-btn {
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 3px;
      padding: 4px 8px;
      margin-top: 5px;
      font-size: 11px;
      cursor: pointer;
      transition: background-color 0.2s;
      width: 100%;
      text-align: center;
      color: #e6e6e6;
    }
    
    .check-updates-btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .check-updates-btn:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
  `,document.head.appendChild(e)}function gt(){let e=document.createElement("div");e.className="dropdown",e.id="crm-history-dropdown";let t=document.createElement("button");t.className="dropdown-btn",t.textContent="History",t.addEventListener("click",s=>{s.stopPropagation(),document.querySelectorAll(".dropdown.show").forEach(l=>{l!==e&&l.classList.remove("show")}),e.classList.toggle("show"),e.classList.contains("show")&&ut(e)});let o=document.createElement("div");if(o.className="dropdown-content",o.id="crm-history-content",o.style.width="300px",o.style.maxHeight="400px",o.style.overflowY="auto",o.style.right="0",o.style.left="auto",!document.getElementById("history-dropdown-styles")){let s=document.createElement("style");s.id="history-dropdown-styles",s.textContent=`
      #crm-history-dropdown .dropdown-content {
        padding: 0;
        right: 0;
        left: auto;
      }
      
      /* For small screens, make sure the dropdown doesn't extend beyond viewport */
      @media screen and (max-width: 768px) {
        #crm-history-dropdown .dropdown-content {
          right: 0;
          left: auto;
          max-width: 100vw;
          width: 280px; /* Slightly smaller on small screens */
        }
      }
      
      .history-header {
        padding: 10px;
        background-color: rgba(255, 255, 255, 0.1);
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      
      .history-title {
        font-weight: bold;
        color: #e6e6e6;
        font-size: 14px;
      }
      
      .history-clear-btn {
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 3px;
        padding: 2px 6px;
        font-size: 11px;
        cursor: pointer;
        color: #e6e6e6;
        transition: background-color 0.2s;
      }
      
      .history-clear-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      
      .history-empty {
        padding: 20px;
        text-align: center;
        color: #aaa;
        font-style: italic;
        font-size: 13px;
      }
      
      .history-item {
        padding: 10px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        cursor: pointer;
        transition: background-color 0.2s;
      }
      
      .history-item:hover {
        background-color: rgba(255, 255, 255, 0.1);
      }
      
      .history-item:last-child {
        border-bottom: none;
      }
      
      .history-item-row {
        display: flex;
        margin-bottom: 3px;
        width: 100%;
      }
      
      .history-item-time {
        color: #aaa;
        font-size: 11px;
        width: 60px;
        flex-shrink: 0;
        margin-right: 5px;
      }
      
      .history-item-name {
        font-weight: bold;
        color: #e6e6e6;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        flex-grow: 1;
      }
      
      .history-item-phone {
        color: #ccc;
        font-size: 12px;
        margin-left: 65px; /* Align with name (time width + margin) */
      }
    `,document.head.appendChild(s)}let n=document.createElement("div");n.className="history-header";let i=document.createElement("div");i.className="history-title",i.textContent="Recent Patients",n.appendChild(i);let r=document.createElement("button");r.className="history-clear-btn",r.textContent="Clear All",r.addEventListener("click",s=>{s.stopPropagation(),ot(),ut(e),p("History cleared")}),n.appendChild(r),o.appendChild(n);let a=document.createElement("div");return a.className="history-empty",a.textContent="No patient history yet",o.appendChild(a),e.appendChild(t),e.appendChild(o),e}function ut(e){let t=e.querySelector("#crm-history-content");if(!t)return;let o=tt(),n=t.querySelector(".history-header");if(t.innerHTML="",n&&t.appendChild(n),o.length===0){let i=document.createElement("div");i.className="history-empty",i.textContent="No patient history yet",t.appendChild(i);return}o.forEach(i=>{let r=document.createElement("div");r.className="history-item",r.addEventListener("click",()=>{window.location.href=i.url,e.classList.remove("show")});let a=document.createElement("div");a.className="history-item-row";let s=document.createElement("div");s.className="history-item-time",s.textContent=nt(i.timestamp);let l=document.createElement("div");if(l.className="history-item-name",l.textContent=i.patientName||"Unknown Patient",a.appendChild(s),a.appendChild(l),r.appendChild(a),i.phoneNumber){let c=document.createElement("div");c.className="history-item-phone",c.textContent=i.phoneNumber,r.appendChild(c)}t.appendChild(r)})}var Ft=!1;function Ae(){try{if(document.getElementById("mcp-crm-header")){console.log("[uiHeaderBar] Toolbar already exists.");return}mt();let e=document.createElement("div");e.id="mcp-crm-header";let t=localStorage.getItem("crmplus_headerBarVisible")!=="false";console.log("[CRM Extension] Header visibility setting:",t),e.style.display=t?"flex":"none";let o=typeof browser<"u"?browser:chrome,n=k=>o.runtime.getURL(k),i=document.createElement("div");i.className="group";let r=document.createElement("a");r.href="https://app.mtncarerx.com/",r.className="logo-link";let a=document.createElement("img");a.src=n("assets/mcp-favicon.ico"),a.alt="",a.className="logo-icon",r.appendChild(a);let s=document.createElement("span");s.className="logo",s.textContent="CRM+",r.appendChild(s),i.appendChild(r);let l=document.createElement("div");l.className="group external-links";let c=ke("ShipStation","https://ship15.shipstation.com/onboard","shipstation-link",n("assets/shipstation-favicon.ico"));l.appendChild(c);let g=ke("Stripe","https://dashboard.stripe.com/login","stripe-link",n("assets/stripe-favicon.ico"));l.appendChild(g);let u=ke("Webmail","https://p3plzcpnl506102.prod.phx3.secureserver.net:2096/cpsess5640910985/webmail/jupiter/index.html?login=1&post_login=89371011642013","webmail-link",n("assets/webmail-favicon.ico"));l.appendChild(u);let h=G("name","Name"),f=G("phone","Phone",{icon:"\u{1F4DE}",initialValue:"",onClick:async k=>{De(k)}}),E=G("dob","DOB"),S=G("srxid","SRx ID"),b=it(),v=dt(),m=document.createElement("div");m.className="spacer";let y=document.createElement("div");y.className="group right-buttons",y.style.borderRight="none",y.style.display="flex",y.style.marginRight="0";let I=document.createElement("div");I.style.display="flex",I.style.alignItems="center",I.style.justifyContent="center";let A=gt();y.appendChild(A);let q=pt();e.appendChild(i),e.appendChild(l),e.appendChild(h),e.appendChild(f),e.appendChild(E),e.appendChild(S),e.appendChild(v),e.appendChild(b),e.appendChild(m),e.appendChild(y),e.appendChild(q),document.body.insertBefore(e,document.body.firstChild),e.style.position="fixed",e.style.top="0",e.style.left="0",e.style.right="0",e.style.zIndex="9999",e.style.width="100%",e.style.boxSizing="border-box",e.style.height="32px";let T=document.getElementById("crm-header-padding-style");T||(T=document.createElement("style"),T.id="crm-header-padding-style",document.head.appendChild(T)),T.textContent="body { padding-top: 32px !important; }",setTimeout(()=>{try{let k=localStorage.getItem("crmplus_automationEnabled")==="true";[document.getElementById("crm-automation-dropdown"),document.getElementById("crm-tags-dropdown")].forEach(B=>{B&&(B.style.display=k?"flex":"none",console.log(`[CRM Extension] Initial visibility for ${B.id}: ${k?"visible":"hidden"}`))})}catch(k){console.error("[CRM Extension] Error setting initial automation visibility:",k)}},100),D(),Ve(),He(),Pe(),Ue(),Ze(),Ft=!0,console.log("[CRM Extension] Header successfully initialized")}catch(e){console.error("[CRM Extension] Critical error creating toolbar:",e);try{let t=document.getElementById("mcp-crm-header");t&&(t.style.display="flex")}catch(t){console.error("[CRM Extension] Failed to recover toolbar:",t)}}}function ke(e,t,o="",n=""){let i=document.createElement("a");i.href=t,i.target="_blank",i.className=`text-link btn ${o}`,i.rel="noopener noreferrer";let r=document.createElement("div");if(r.style.display="flex",r.style.alignItems="center",r.style.justifyContent="center",r.style.width="100%",n){let s=document.createElement("img");s.src=n,s.alt="",s.className="link-icon",s.style.width="16px",s.style.height="16px",s.style.marginRight="4px",r.appendChild(s)}let a=document.createElement("span");return a.textContent=e,r.appendChild(a),i.appendChild(r),i}function Re(e){try{let t=document.getElementById("mcp-crm-header");if(t){console.log(`[CRM Extension] Setting header visibility to: ${e}`),t.style.display=e?"flex":"none";let o=document.body.classList.contains("has-alert");return e?(document.querySelector("#app > div:nth-child(1) > div.flex.v2-collapse.sidebar-v2-location.pmd-app.sO76CG3rwxaaryItNHrX.flex.v2-collapse.sidebar-v2-location > div > header").style.paddingTop=o?"72px":"32px",document.querySelector("#app > div:nth-child(1) > div.flex.v2-collapse.sidebar-v2-location.pmd-app.sO76CG3rwxaaryItNHrX.flex.v2-collapse.sidebar-v2-location > section > section > div").style.paddingTop=o?"72px":"32px",document.querySelector("#app > div:nth-child(1) > div.flex.v2-open.sidebar-v2-location.sO76CG3rwxaaryItNHrX.flex.v2-open.sidebar-v2-location > div > header").style.paddingTop=o?"72px":"32px",document.body.classList.remove("no-header")):(document.querySelector("#app > div:nth-child(1)").style.paddingTop=o?"40px":"0px",document.querySelector("h1_header").style.paddingTop=o?"40px":"0px",document.body.classList.add("no-header")),localStorage.setItem("crmplus_headerBarVisible",e.toString()),!0}else if(e)return console.log("[CRM Extension] Header not found but should be visible, creating it"),Ae(),!0;return!1}catch(t){return console.error("[CRM Extension] Error toggling header visibility:",t),!1}}function ft(){if(!(localStorage.getItem("crmplus_autoCopyPhone")==="true")){console.log("[CRM Extension] Auto-copy phone is disabled");return}let t=()=>{let n=ce();if(n){let i=we(n);i&&O(i).then(r=>{if(r)return p("Phone number auto-copied: "+i),!0})}return!1};if(t())return;let o=new MutationObserver((n,i)=>{t()&&i.disconnect()});o.observe(document.body,{childList:!0,subtree:!0,attributes:!0,characterData:!0}),setTimeout(()=>{o.disconnect(),t()},5e3)}var ht=!1,X=new Set,be="",Ne=!1,ye=null,Te=null;function yt(){ht||(Ot(),Ut(),ht=!0,console.log("[CRM Extension] Alert system initialized"))}function Ot(){if(document.getElementById("crm-alert-styles"))return;let e=document.createElement("style");e.id="crm-alert-styles",e.textContent=`
    .crm-alert-banner {
      position: fixed;
      top: 32px; /* Positioned right below the header bar */
      left: 0;
      right: 0;
      width: 100%;
      padding: 4px 15px; /* Reduced vertical padding for smaller height */
      font-size: 13px;
      font-weight: 500;
      z-index: 999990;
      display: flex;
      align-items: center;
      justify-content: center; /* Center contents horizontally */
      transition: all 0.3s ease;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
      transform: translateY(-100%);
      opacity: 0;
      height: 25px; /* Fixed height at 3/4 of original (approx) */
    }
    
    .crm-alert-banner.show {
      transform: translateY(0);
      opacity: 1;
    }
    
    .crm-alert-banner .alert-icon {
      margin-right: 8px;
      font-size: 16px;
    }
    
    .crm-alert-banner .alert-message {
      text-align: center; /* Center the text */
      margin: 0 auto; /* Center with auto margins */
      flex-grow: 0; /* Don't grow to fill space */
    }
    
    /* Provider Paid specific alert styling */
    .crm-alert-banner.provider-paid {
      background-color: #FFAB40; /* Orange */
      color: #5F4200;
      border-bottom: 1px solid #FF9100;
    }
    
    /* Adjust body padding to accommodate the alert banner */
    body.has-alert {
      padding-top: 72px !important; /* 32px (header) + approx alert height */
    }
    
    /* When header is hidden but alert is visible */
    body.no-header.has-alert {
      padding-top: 25px !important; /* Just the alert height */
    }
    
    /* Multiple alerts stacking */
    .crm-alert-banner.second-alert {
      top: 57px;
    }
    
    .crm-alert-banner.third-alert {
      top: 82px;
    }
    
    /* Countdown timer styling */
    .countdown-timer {
      margin-left: 5px;
      font-size: 11px;
      opacity: 0.75;
      background-color: rgba(0, 0, 0, 0.1);
      padding: 1px 4px;
      border-radius: 3px;
      min-width: 30px;
      text-align: center;
    }
  `,document.head.appendChild(e)}function bt(){let e=window.location.href,t=[/\/patient\/(\d+)/i,/\/contact\/(\d+)/i,/\/profile\/(\d+)/i,/[?&]patient_id=(\d+)/i,/[?&]contact_id=(\d+)/i];for(let o of t){let n=e.match(o);if(n&&n[1])return n[1]}return""}function Ut(){be=bt(),xe(),ye&&ye.disconnect(),ye=new MutationObserver(e=>{for(let t of e)t.type==="childList"&&xe(),t.type==="attributes"&&(t.target.classList.contains("tag")||t.target.classList.contains("tag-label")||t.target.classList.contains("provider-paid"))&&xe()}),ye.observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["class","data-tag"]}),Te&&clearInterval(Te),Te=setInterval(()=>{let e=bt();e!==be&&(console.log("[CRM Extension] Navigation detected, patient changed from",be,"to",e),be=e,Ne=!1,ve("provider-paid"),setTimeout(xe,1e3))},1e3)}function xe(){if(!(localStorage.getItem("crmplus_showProviderPaidAlerts")!=="false")){ve("provider-paid");return}jt()?Ne||Wt():ve("provider-paid")}function jt(){let e=document.querySelectorAll(".tag, .tag-label, .pill, .badge");for(let i of e)if(i.textContent.toLowerCase().includes("provider-paid"))return i;let t=document.querySelectorAll(".provider-paid");if(t.length>0)return t[0];let o=document.querySelectorAll('[data-tag="provider-paid"], [data-tag-name="provider-paid"]');if(o.length>0)return o[0];let n=document.querySelectorAll(".tags-container, .tag-list, .tags");for(let i of n)if(i.textContent.toLowerCase().includes("provider-paid"))return i;return null}function Wt(){if(X.has("provider-paid"))return;Ne=!0;let e=document.createElement("div");e.className="crm-alert-banner provider-paid",e.id="provider-paid-alert",e.setAttribute("data-alert-type","provider-paid");let t=document.createElement("span");t.className="alert-icon",t.innerHTML="\u26A0\uFE0F",e.appendChild(t);let o=document.createElement("span");o.className="alert-message",o.textContent="This patient has Provider Paid status. Special billing rules apply.";let n=document.createElement("span");n.className="countdown-timer",n.textContent="30",o.appendChild(n),e.appendChild(o),document.body.appendChild(e),Yt(e),setTimeout(()=>{e.classList.add("show"),document.body.classList.add("has-alert")},10),X.add("provider-paid");let i=document.getElementById("mcp-crm-header");i&&i.style.display==="none"?document.body.classList.add("no-header"):document.body.classList.remove("no-header"),console.log("[CRM Extension] Provider Paid alert shown");let r=15,a=setInterval(()=>{r--,n&&(n.textContent=r),r<=0&&(clearInterval(a),ve("provider-paid"))},1e3)}function Yt(e){let t=X.size;t===1?e.classList.add("second-alert"):t===2&&e.classList.add("third-alert")}function ve(e){let t=document.querySelector(`.crm-alert-banner[data-alert-type="${e}"]`);t&&(t.classList.remove("show"),X.delete(e),setTimeout(()=>{t.parentNode&&t.parentNode.removeChild(t),X.size===0&&document.body.classList.remove("has-alert"),Qt()},300))}function Qt(){document.querySelectorAll(".crm-alert-banner").forEach((t,o)=>{t.classList.remove("second-alert","third-alert"),o===1?t.classList.add("second-alert"):o===2&&t.classList.add("third-alert")})}console.log("[CRM Extension] Content script injected.");var J=typeof browser<"u"?browser:chrome;J.runtime.sendMessage({action:"loadSettings"}).then(e=>{e&&e.success&&(console.log("[CRM Extension] Settings loaded from browser storage on startup:",e.settings),document.getElementById("mcp-crm-header")||V())}).catch(e=>{console.error("[CRM Extension] Error requesting settings on startup:",e)});localStorage.getItem("crmplus_headerBarVisible")===null?(console.log("[CRM Extension] No local toolbar visibility setting, requesting from browser storage"),J.runtime.sendMessage({action:"loadSettings"}).then(e=>{e&&e.success?(console.log("[CRM Extension] Settings loaded from browser storage:",e.settings),V()):(console.error("[CRM Extension] Failed to load settings, using defaults"),localStorage.setItem("crmplus_headerBarVisible","true"),V())}).catch(e=>{console.error("[CRM Extension] Error requesting settings:",e),localStorage.setItem("crmplus_headerBarVisible","true"),V()})):(console.log("[CRM Extension] Using existing localStorage settings"),V());function V(){let e=localStorage.getItem("crmplus_headerBarVisible")!=="false";console.log("[CRM Extension] Header visibility setting on init:",e);try{console.log("[CRM Extension] Creating fixed header..."),Ae(),Re(e)}catch(t){console.error("[CRM Extension] Error creating fixed header:",t)}try{ze(t=>{console.log(`[CRM Extension] Intercepted console message: ${t}`)})}catch(t){console.error("[CRM Extension] Error initializing console monitor:",t)}try{ft()}catch(t){console.error("[CRM Extension] Error initializing auto phone copy:",t)}try{yt()}catch(t){console.error("[CRM Extension] Error initializing alert system:",t)}try{je()}catch(t){console.error("[CRM Extension] Error initializing tag removal system:",t)}try{Qe()}catch(t){console.error("[CRM Extension] Error initializing automation removal system:",t)}D()}J.runtime.onMessage.addListener((e,t,o)=>{if(console.log("[CRM Extension] Received message:",e),e.action==="toggleHeaderVisibility"){console.log("[CRM Extension] Toggling header visibility to:",e.isVisible);try{let n=Re(e.isVisible);localStorage.setItem("crmplus_headerBarVisible",e.isVisible.toString()),J.runtime.sendMessage({action:"syncSettings"}).catch(i=>console.error("[CRM Extension] Error syncing settings:",i)),o({success:n})}catch(n){console.error("[CRM Extension] Error toggling header visibility:",n),o({success:!1,error:n.message})}return!0}return!1});document.addEventListener("DOMContentLoaded",()=>{console.log("[CRM Extension] DOM fully loaded, checking visibility setting"),document.getElementById("mcp-crm-header")||J.runtime.sendMessage({action:"loadSettings"}).then(e=>{e&&e.success&&V()}).catch(()=>{localStorage.setItem("crmplus_headerBarVisible","true"),V()})});})();
