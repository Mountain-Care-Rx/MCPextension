(()=>{function Ae(t){if(window.__crmConsoleMonitor)return;window.__crmConsoleMonitor=!0;let e=console.log,o=console.error,n=console.warn;console.log=function(...r){e.apply(console,r),!(typeof r[0]=="string"&&r[0].includes("[CRM Extension]"))&&he(r,"log",t)},console.error=function(...r){o.apply(console,r),!(typeof r[0]=="string"&&r[0].includes("[CRM Extension]"))&&he(r,"error",t)},console.warn=function(...r){n.apply(console,r),!(typeof r[0]=="string"&&r[0].includes("[CRM Extension]"))&&he(r,"warn",t)}}function he(t,e,o){let n=t.join(" ");["error","failed","unauthorized","critical"].some(i=>n.toLowerCase().includes(i))&&o(n)}var Me=window.location.href,$="";function ie(){if(!Re())return"";let t=document.querySelector('input[name="contact.phone"]');if(t&&t.value.trim()!=="")return t.value.trim();let e=document.querySelector(".phone-number .number");if(e&&e.textContent.trim()!=="")return e.textContent.trim();let o=['input[placeholder="Phone"]','input[placeholder="Phone Number"]',".patient-info .phone",".contact-info .phone","span.phone",'label[for*="phone"]',".phone-display",'div[data-field="phone"]','span[data-field="phone_number"]'];for(let n of o){let r=document.querySelector(n);if(r)if(r.tagName==="INPUT"){let i=r.value.trim();if(i)return i}else if(r.tagName==="LABEL"){let i=r.getAttribute("for");if(i){let l=document.getElementById(i);if(l&&l.value.trim())return l.value.trim()}let a=r.parentElement?.querySelector("input");if(a&&a.value.trim())return a.value.trim()}else{let i=r.textContent.trim();if(i)return i}}return""}function Re(){let t=window.location.href;return[/\/patient\/\d+/i,/\/contact\/\d+/i,/\/profile\/\d+/i,/[?&]patient_id=\d+/i,/[?&]contact_id=\d+/i].some(n=>n.test(t))?!0:['input[name="contact.phone"]','input[name="contact.first_name"]','input[name="contact.last_name"]','input[name="contact.date_of_birth"]',".patient-info",".contact-details",".patient-header",".patient-profile"].some(n=>document.querySelector(n)!==null)}function Le(t){try{let e=t?nt(t):"";if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("phone",e);else{let o=document.getElementById("phone-text");if(o){o.textContent=e;let n=document.getElementById("phone-display");n&&(t?n.setAttribute("data-value",t):n.removeAttribute("data-value"))}}}catch(e){console.error("[CRM Extension] Error updating phone display:",e)}}function A(){$="",Le("");try{let t=document.getElementById("phone-display");t&&t.removeAttribute("data-value")}catch(t){console.error("[CRM Extension] Error clearing phone display:",t)}}function nt(t){if(!t)return"";let e=t.replace(/\D/g,"");if(e.length===0)return"";if(e.length===10)return`(${e.substring(0,3)}) ${e.substring(3,6)}-${e.substring(6)}`;if(e.length===11&&e.startsWith("1"))return`(${e.substring(1,4)}) ${e.substring(4,7)}-${e.substring(7)}`;if(e.length>4){let o="";for(let n=0;n<e.length;n+=3)if(n+4>=e.length&&e.length%3!==0){o+=" "+e.substring(n);break}else o+=" "+e.substring(n,n+3);return o.trim()}return e.replace(/(\d{3})/g,"$1 ").trim()}function re(){try{if(!Re())return $&&A(),!1;let t=ie();return t?(t!==$&&($=t,Le(t)),!0):($&&A(),!1)}catch(t){return console.error("[CRM Extension] Error detecting phone number:",t),!1}}function Te(){A(),re();let t=setInterval(()=>{let e=window.location.href;e!==Me&&(console.log("[CRM Extension] URL changed, resetting phone detection"),Me=e,A()),re()},200);try{let e=new MutationObserver(n=>{re()}),o=document.body;e.observe(o,{childList:!0,subtree:!0,characterData:!0,attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] Phone number mutation observer active")}catch(e){console.error("[CRM Extension] Error setting up phone mutation observer:",e)}}function Ie(t){let e=ie();if(!e){p("No phone number found");return}let o=be(e);if(!o){p("Invalid phone number format");return}t.setAttribute("data-value",e),V(o).then(n=>{p(n?"Copied: "+o:"Failed to copy phone number")})}function be(t){if(!t)return"";let e=t.replace(/\D/g,"");return e.length<7?"":"+1"+e}async function V(t){if(navigator.clipboard&&navigator.clipboard.writeText)try{return await navigator.clipboard.writeText(t),!0}catch(e){console.warn("Clipboard API failed, trying fallback method:",e)}try{let e=document.createElement("textarea");e.value=t,e.style.position="fixed",e.style.top="0",e.style.left="0",e.style.opacity="0",e.style.pointerEvents="none",document.body.appendChild(e),e.focus(),e.select();let o=document.execCommand("copy");return document.body.removeChild(e),o}catch(e){return console.error("All clipboard methods failed:",e),!1}}function p(t,e=2e3){let o=document.getElementById("crm-plus-toast-container");o||(o=document.createElement("div"),o.id="crm-plus-toast-container",o.style.position="fixed",o.style.bottom="20px",o.style.right="20px",o.style.zIndex="100000",document.body.appendChild(o));let n=document.createElement("div");n.textContent=t,n.style.background="#333",n.style.color="#fff",n.style.padding="10px",n.style.borderRadius="5px",n.style.marginTop="10px",n.style.boxShadow="0 2px 5px rgba(0,0,0,0.2)",n.style.transition="opacity 0.5s, transform 0.5s",n.style.opacity="0",n.style.transform="translateY(20px)",o.appendChild(n),n.offsetWidth,n.style.opacity="1",n.style.transform="translateY(0)",setTimeout(()=>{n.style.opacity="0",n.style.transform="translateY(20px)",setTimeout(()=>{n.parentNode&&n.parentNode.removeChild(n),o.childNodes.length===0&&document.body.removeChild(o)},500)},e)}var Pe=window.location.href;function q(t){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("name",t);else{let e=document.getElementById("name-text");if(e){e.textContent=t;let o=document.getElementById("name-display");o&&o.setAttribute("data-value",t)}}}catch(e){console.error("[CRM Extension] Error updating name display:",e)}}function ae(){try{let t=document.querySelector('input[name="contact.first_name"]'),e=document.querySelector('input[name="contact.last_name"]');if(t&&t.value&&e&&e.value){let r=`${t.value} ${e.value}`;return q(r),!0}let o=document.querySelectorAll(".patient-name, .contact-name, h1.name, .customer-name");for(let r of o)if(r&&r.textContent&&r.textContent.trim()!==""){let i=r.textContent.trim();return q(i),!0}let n=["span.name",".profile-name","h2.name",".contact-header .name",'div[data-field="name"]',".patient-info .name"];for(let r of n){let i=document.querySelector(r);if(i&&i.textContent&&i.textContent.trim()!==""){let a=i.textContent.trim();return q(a),!0}}return!1}catch(t){return console.error("[CRM Extension] Error detecting name:",t),!1}}function ze(){ae();let t=setInterval(()=>{let e=window.location.href;e!==Pe&&(console.log("[CRM Extension] URL changed, resetting name detection"),Pe=e,q(""),ae());let o=document.getElementById("name-text");o&&(o.textContent==="Loading..."||!o.textContent)&&ae()},1e3);try{let e=new MutationObserver(n=>{n.some(i=>i.addedNodes.length>5||i.removedNodes.length>5)&&(console.log("[CRM Extension] Significant DOM changes detected, rechecking name"),q(""),ae())}),o=document.querySelector("main")||document.body;e.observe(o,{childList:!0,subtree:!0})}catch(e){console.error("[CRM Extension] Error setting up navigation observer for name:",e)}}var Be=window.location.href;function le(t){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("dob",t);else{let e=document.getElementById("dob-text");if(e){e.textContent=t;let o=document.getElementById("dob-display");o&&o.setAttribute("data-value",t)}}}catch(e){console.error("[CRM Extension] Error updating DOB display:",e)}}function De(t){if(!t)return"";if(t.match(/^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2}(st|nd|rd|th)?\s+\d{4}$/))try{let e=t.match(/(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+(\d{1,2})(st|nd|rd|th)?\s+(\d{4})/);if(e){let o=e[1],n=e[2],r=e[4];return`${(["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"].indexOf(o)+1).toString().padStart(2,"0")}/${n.toString().padStart(2,"0")}/${r}`}}catch(e){console.error("[CRM Extension] Error parsing date:",e)}try{let e=new Date(t);if(!isNaN(e.getTime()))return`${(e.getMonth()+1).toString().padStart(2,"0")}/${e.getDate().toString().padStart(2,"0")}/${e.getFullYear()}`}catch(e){console.error("[CRM Extension] Error parsing date as Date object:",e)}return t}function se(){try{let t=document.querySelector('input[name="contact.date_of_birth"]');if(t&&t.value){let o=De(t.value);return le(o),!0}let e=[".dob",".patient-dob",".contact-dob",'span[data-field="date_of_birth"]','div[data-field="dob"]',".patient-info .dob",".contact-info .dob"];for(let o of e){let n=document.querySelector(o);if(n&&n.textContent&&n.textContent.trim()!==""){let r=De(n.textContent.trim());return le(r),!0}}return!1}catch(t){return console.error("[CRM Extension] Error detecting DOB:",t),!1}}function $e(){se();let t=setInterval(()=>{let e=window.location.href;e!==Be&&(console.log("[CRM Extension] URL changed, resetting DOB detection"),Be=e,le(""),se());let o=document.getElementById("dob-text");o&&(o.textContent==="Loading..."||!o.textContent)&&se()},1e3);try{let e=new MutationObserver(n=>{n.some(i=>i.addedNodes.length>5||i.removedNodes.length>5)&&(console.log("[CRM Extension] Significant DOM changes detected, rechecking DOB"),le(""),se())}),o=document.querySelector("main")||document.body;e.observe(o,{childList:!0,subtree:!0})}catch(e){console.error("[CRM Extension] Error setting up navigation observer for DOB:",e)}}var Ve=window.location.href,ce="";function qe(t){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("srxid",t);else{let e=document.getElementById("srxid-text");if(e){e.textContent=t;let o=document.getElementById("srxid-display");o&&o.setAttribute("data-value",t)}}}catch(e){console.error("[CRM Extension] Error updating SRx ID display:",e)}}function F(){try{let t=document.querySelector('input[name="contact.srx_id"]');if(t&&t.value){let e=t.value.trim();if(e&&/^\d+$/.test(e))return e!==ce&&(console.log("[CRM Extension] Found SRx ID from contact.srx_id input:",e),ce=e,qe(e)),!0}return!!ce}catch(t){return console.error("[CRM Extension] Error detecting SRx ID:",t),!1}}function Fe(){F();let t=setInterval(()=>{let e=window.location.href;e!==Ve&&(console.log("[CRM Extension] URL changed, resetting SRx ID detection"),Ve=e,ce="",qe(""),F()),F()},500);try{new MutationObserver(o=>{let n=!1;for(let r of o){if(r.target.tagName==="INPUT"&&r.target.name==="contact.srx_id"||r.target.querySelector&&r.target.querySelector('input[name="contact.srx_id"]')){n=!0;break}if(r.addedNodes.length>0){for(let i of r.addedNodes)if(i.nodeType===1&&i.querySelector&&(i.tagName==="INPUT"&&i.name==="contact.srx_id"||i.querySelector('input[name="contact.srx_id"]'))){n=!0;break}}}n&&F()}).observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] SRx ID mutation observer active")}catch(e){console.error("[CRM Extension] Error setting up observer for SRx ID:",e)}setTimeout(()=>{try{let e=document.querySelector('input[name="contact.srx_id"]');e&&(new MutationObserver(n=>{F()}).observe(e,{attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] Direct input observer attached to contact.srx_id"))}catch(e){console.error("[CRM Extension] Error setting up direct input observer:",e)}},1e3)}var de=["np-tirz-1.5ml-inj","refill-sema-inj","refill-tirz-inj","vial-sema-b12","vial-sema-b6","vial-sema-lipo","vial-sema-nad+","vial-tirz-cyano","vial-tirz-nad+","vial-tirz-pyridoxine","np-sema-0.125ml-inj","np-sema-0.25ml-inj","np-sema-0.5ml-inj","np-sema-0.75ml-inj","np-sema-1.0ml-inj","np-sema-1.25ml-inj","np-sema-1.5ml-inj","np-sema-2.0ml-inj","np-tirz-0.25ml-inj","np-tirz-0.5ml-inj","np-tirz-0.75ml-inj","np-tirz-1.0ml-inj","np-tirz-1.25ml-inj"],E=[];function Oe(){console.log("[CRM Extension] Tag removal system initialized")}function rt(){E=[];try{let t=document.querySelectorAll(".tag, .tag-label, .pill, .badge");for(let r of t){let i=r.textContent.trim().toLowerCase();de.some(a=>i.includes(a))&&E.push({element:r,text:i})}let e=document.querySelectorAll("[data-tag]");for(let r of e){let i=r.getAttribute("data-tag").toLowerCase();de.some(a=>i.includes(a))&&E.push({element:r,text:i})}let o=document.querySelectorAll(".tags-container, .tag-list, .tags");for(let r of o){let i=r.querySelectorAll("*");for(let a of i)if(a.nodeType===1){let l=a.textContent.trim().toLowerCase();de.some(s=>l.includes(s))&&(E.some(s=>s.element===a)||E.push({element:a,text:l}))}}let n=document.querySelectorAll("*[class]");for(let r of n){let i=r.className.toLowerCase();i&&typeof i=="string"&&de.some(a=>i.includes(a))&&(E.some(a=>a.element===r)||E.push({element:r,text:r.textContent.trim().toLowerCase()}))}return console.log(`[CRM Extension] Found ${E.length} removable tags`),E}catch(t){return console.error("[CRM Extension] Error detecting tags:",t),[]}}function it(t){try{let e=t.querySelector('.close, .remove, .delete, .tag-remove, [aria-label="Remove"], .x-button');if(e)return console.log("[CRM Extension] Found close button in tag, clicking it"),e.click(),!0;let o=t.parentElement;if(o){let i=o.querySelector('.close, .remove, .delete, .tag-remove, [aria-label="Remove"], .x-button');if(i)return console.log("[CRM Extension] Found close button as sibling, clicking it"),i.click(),!0}let n=[...Array.from(t.querySelectorAll("*")),...Array.from(o?o.children:[])];for(let i of n){let a=i.textContent.trim();if(a==="\xD7"||a==="x"||a==="\u2715"||a==="\u2716"||a==="X")return console.log("[CRM Extension] Found X button by text content, clicking it"),i.click(),!0;if(i.className&&(i.className.includes("close")||i.className.includes("delete")||i.className.includes("remove")||i.className.includes("x-button")))return console.log("[CRM Extension] Found X button by class name, clicking it"),i.click(),!0;if(i.classList&&(i.classList.contains("fa-times")||i.classList.contains("fa-close")||i.classList.contains("icon-close")||i.classList.contains("icon-remove")))return console.log("[CRM Extension] Found X button by icon class, clicking it"),i.click(),!0}if(t.tagName==="BUTTON"||t.tagName==="A"||t.getAttribute("role")==="button"||window.getComputedStyle(t).cursor==="pointer")return console.log("[CRM Extension] Tag appears to be clickable, clicking it"),t.click(),!0;let r=o;for(let i=0;i<3&&r;i++){let a=r.querySelectorAll("button, span, i, div");for(let l of a){let s=l.textContent.trim();if(s==="\xD7"||s==="x"||s==="\u2715"||s==="\u2716"||s==="X"||l.classList.contains("fa-times")||l.classList.contains("fa-close")||l.classList.contains("close")||l.classList.contains("remove"))return console.log("[CRM Extension] Found X button in parent container, clicking it"),l.click(),!0}r=r.parentElement}return console.log("[CRM Extension] No method found to remove tag:",t),!1}catch(e){return console.error("[CRM Extension] Error removing tag:",e),!1}}function xe(){return new Promise((t,e)=>{try{let r=function(i){if(i>=E.length){console.log(`[CRM Extension] Removed ${o}/${n} tags`),t({success:!0,message:`Removed ${o} of ${n} tags`,removed:o,total:n});return}let a=E[i];console.log(`[CRM Extension] Removing tag: ${a.text}`),it(a.element)&&o++,setTimeout(()=>{r(i+1)},300)};rt();let o=0,n=E.length;if(n===0){console.log("[CRM Extension] No removable tags found"),t({success:!0,message:"No tags to remove",removed:0,total:0});return}console.log(`[CRM Extension] Attempting to remove ${n} tags`),r(0)}catch(o){console.error("[CRM Extension] Error in removeAllTags:",o),e(o)}})}var at=["Workflow - New Patient - Semaglutide 0.125ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 0.25ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 0.5ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 0.75ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 1.0ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 1.25ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 1.5ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 2.0ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 0.25ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 0.5ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 0.75ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 1.0ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 1.25ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 1.5ml Onboarding - (Step 1)","Workflow - Refill - Semaglutide/B12 Injection Refill Order - (Step 1)","Workflow - Semaglutide/B12 Vial Order - (Step 1)","Workflow - Semaglutide/B6 Vial Order - (Step 1)","Workflow - Semaglutide/Lipo Vial Order - (Step 1)","Workflow - Semaglutide/NAD+ Vial Order - (Step 1)","Workflow - Syringe - Tirzepatide/Pyridoxine Injection Order - (Step 1)","Workflow - Tirzepatide/Cyano Vial Order - (Step 1)","Workflow - Tirzepatide/NAD+ Vial Order - (Step 1)","Workflow - Tirzepatide/Pyridoxine Vial Order - (Step 1)"],pe=[];function M(t){try{if(t&&typeof t.getBoundingClientRect=="function")return t.getBoundingClientRect()}catch{}return{top:0,bottom:0,left:0,right:0,width:0,height:0}}function Ue(){console.log("[CRM Extension] Automation removal system initialized")}function st(){pe=[];try{let t=We("Active");return t?(pe=(t.workflows.length?t.workflows:lt(t.label)).filter(o=>{if(!o)return!1;let n=(o.textContent||"").trim();return n.includes("Workflow")&&at.some(r=>n.includes(r))}),console.log(`[CRM Extension] Found ${pe.length} automation(s) in Active section.`),pe):(console.log("[CRM Extension] Active section not found."),[])}catch(t){return console.error("[CRM Extension] Error detecting automations:",t),[]}}function lt(t){let e=M(t).bottom,o=null,n=We("Past");return n&&n.label&&(o=M(n.label).top),Array.from(document.querySelectorAll('div[id^="workflow_"], div[data-workflow-id]')).filter(i=>{let a=M(i);return!(a.top<e||o&&a.top>=o)})}function We(t){try{let o=Array.from(document.querySelectorAll("div.py-2")).find(i=>(i.textContent||"").trim()===t);if(o)return{label:o,workflows:t==="Active"?ct(o):dt(o)};let n=t==="Active"?'[data-automation="Active"], #automation-active':'[data-automation="Past"], #automation-past',r=document.querySelector(n);return r?{label:r,workflows:[]}:null}catch(e){return console.error(`[CRM Extension] Error finding section for "${t}":`,e),null}}function ct(t){let e=M(t).bottom,n=Array.from(document.querySelectorAll("div.py-2")).find(a=>(a.textContent||"").trim()==="Past"),r=n?M(n).top:null;return Array.from(document.querySelectorAll('div[id^="workflow_"], div[data-workflow-id]')).filter(a=>{let l=M(a);return l.top>e&&(!r||l.top<r)})}function dt(t){let e=M(t).bottom;return Array.from(document.querySelectorAll('div[id^="workflow_"], div[data-workflow-id]')).filter(n=>M(n).top>e)}function pt(t){if(!t)return console.error("[CRM Extension] removeAutomation called with undefined element."),!1;try{let e=M(t),o=e.width>0&&e.height>0,n=e.top>=0&&e.left>=0&&e.bottom<=(window.innerHeight||document.documentElement.clientHeight);return!o||!n?(t.scrollIntoView({behavior:"smooth",block:"center"}),new Promise(r=>{setTimeout(()=>r(_e(t)),500)})):_e(t)}catch(e){return console.error("[CRM Extension] Error removing automation:",e),!1}}function _e(t){if(!t)return!1;try{let e=t.querySelectorAll("i.icon-close, i.icon.icon-close");if(e.length)return e[0].click(),!0}catch(e){console.error("[CRM Extension] Error in Strategy 1:",e)}try{let e=t.querySelectorAll("a");for(let o of e){let n=(o.textContent||"").trim();if(n==="\xD7"||n.toLowerCase()==="x")return o.click(),!0}}catch(e){console.error("[CRM Extension] Error in Strategy 2:",e)}try{let e=t.querySelectorAll('button, .btn, [role="button"]');for(let o of e)if((o.textContent||"").toLowerCase().includes("manage"))return o.click(),setTimeout(()=>{document.querySelectorAll(".dropdown-menu .dropdown-item, .menu-item").forEach(i=>{let a=(i.textContent||"").toLowerCase();(a.includes("remove")||a.includes("delete"))&&i.click()})},300),!0}catch(e){console.error("[CRM Extension] Error in Strategy 3:",e)}if(t.id&&t.id.startsWith("workflow_")){let e=t.id;try{let o=`#${e} i.icon-close, #${e} i.icon.icon-close`,n=document.querySelector(o);if(n)return n.click(),!0;o=`#${e} .remove, #${e} .close`;let r=document.querySelector(o);if(r)return r.click(),!0}catch(o){console.error("[CRM Extension] Error in Strategy 4:",o)}}try{let e=t.querySelectorAll("span");for(let o of e){let n=(o.textContent||"").trim();if(n==="\xD7"||n.toLowerCase()==="x")return o.click(),!0}}catch(e){console.error("[CRM Extension] Error in Strategy 5:",e)}try{let e=t.nextElementSibling,o=0;for(;e&&o<3;){if(e.classList&&(e.classList.contains("close")||e.classList.contains("remove"))||e.textContent&&(e.textContent.trim()==="\xD7"||e.textContent.trim().toLowerCase()==="x"))return e.click(),!0;let n=e.querySelector("i.icon-close, i.icon.icon-close");if(n)return n.click(),!0;e=e.nextElementSibling,o++}}catch(e){console.error("[CRM Extension] Error in Strategy 6:",e)}try{let e=M(t),o=e.right-10,n=e.top+e.height/2,r=document.elementsFromPoint(o,n);for(let a of r)if(a!==t)return a.click(),!0;let i=new MouseEvent("click",{view:window,bubbles:!0,cancelable:!0,clientX:o,clientY:n});return(r[0]||document.elementFromPoint(o,n))?.dispatchEvent(i),!0}catch(e){console.error("[CRM Extension] Error in Strategy 7:",e)}return console.error("[CRM Extension] No method found to remove automation:",t),!1}function je(){return new Promise(t=>{setTimeout(()=>{if(document.querySelectorAll('.modal, [role="dialog"], .dialog').length){let o=document.querySelectorAll('.modal .btn-primary, .modal .btn-danger, .modal .confirm-btn, [role="dialog"] .btn-primary, .modal button, [role="dialog"] button');for(let r of o){let i=(r.textContent||"").trim().toLowerCase();if(["delete","remove","yes","confirm","ok","continue"].includes(i)){r.click(),t(!0);return}}let n=document.querySelectorAll('.modal button, [role="dialog"] button, .dialog button');if(n.length){n[n.length-1].click(),t(!0);return}}t(!1)},500)})}function ye(){return new Promise((t,e)=>{try{let i=function(a){if(a>=r){t({success:!0,message:`Removed ${n} of ${r} automations`,removed:n,total:r});return}let l=o[a],s=pt(l.element);s instanceof Promise?s.then(d=>{d&&n++,je().then(()=>setTimeout(()=>i(a+1),1e3))}):(s&&n++,je().then(()=>setTimeout(()=>i(a+1),1e3)))},o=st();if(!o.length){console.log("[CRM Extension] No automations to remove."),t({success:!0,message:"No automations to remove",removed:0,total:0});return}let n=0,r=o.length;i(0)}catch(o){console.error("[CRM Extension] Error in removeAllAutomations:",o),e(o)}})}function O(t,e,o={}){let n=document.createElement("div");n.className="group";let r=document.createElement("span");r.className="label",r.textContent=`${e}:`,n.appendChild(r);let i=document.createElement("span");if(i.id=`${t}-display`,i.className="clickable-value",o.initialValue&&i.setAttribute("data-value",o.initialValue),o.icon){let s=document.createElement("span");s.className="btn-icon",s.innerHTML=o.icon,i.appendChild(s)}let a=document.createElement("span");a.textContent=o.initialValue||"",a.id=`${t}-text`,i.appendChild(a);let l=async()=>{let s=i.getAttribute("data-value")||a.textContent.trim();s&&s!==""?await V(s)?p(`Copied ${e}: ${s}`):p(`Failed to copy ${e.toLowerCase()}`):p(`No ${e.toLowerCase()} available to copy`)};return i.addEventListener("click",()=>{o.onClick?o.onClick(i):l()}),i.title=`Click to copy ${e.toLowerCase()} to clipboard`,n.appendChild(i),n}function He(){let t=document.createElement("div");return t.className="group",t.id="crm-actions-group",t}function Ge(){let t=document.createElement("div");t.className="dropdown",t.id="crm-tags-dropdown";let e=document.createElement("button");e.className="dropdown-btn",e.textContent="Tags",e.addEventListener("click",c=>{c.stopPropagation(),document.querySelectorAll(".dropdown.show").forEach(Ne=>{Ne!==t&&Ne.classList.remove("show")}),t.classList.toggle("show")});let o=document.createElement("div");if(o.className="dropdown-content",o.style.padding="10px",!document.getElementById("tags-dropdown-styles")){let c=document.createElement("style");c.id="tags-dropdown-styles",c.textContent=`
      .nested-dropdown {
        margin-bottom: 8px;
        width: 100%;
        position: relative;
      }
      .nested-dropdown-btn {
        width: 100%;
        text-align: left;
        padding: 8px 12px;
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 3px;
        cursor: pointer;
        font-weight: bold;
        font-size: 13px;
        color: #e6e6e6;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .nested-dropdown-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      .nested-dropdown-btn:after {
        content: "\u25BC";
        font-size: 8px;
        color: #e6e6e6;
      }
      .nested-dropdown-content {
        display: none;
        padding: 5px 0 5px 10px;
        margin-top: 3px !important;
      }
      .nested-dropdown.open .nested-dropdown-content {
        display: block;
      }
      
      /* Button-style tag options */
      .tag-btn {
        display: block;
        width: 100%;
        padding: 8px 12px;
        margin-bottom: 8px;
        background-color: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 4px;
        text-align: left;
        font-size: 13px;
        color: #e6e6e6;
        cursor: pointer;
        transition: all 0.2s ease;
        font-weight: normal;
      }
      .tag-btn:hover {
        background-color: rgba(255, 255, 255, 0.15);
        border-color: rgba(255, 255, 255, 0.2);
      }
      .tag-btn:active {
        background-color: rgba(255, 255, 255, 0.2);
      }
    `,document.head.appendChild(c)}let n=document.createElement("button");n.className="tag-btn",n.textContent="Opt-in",n.addEventListener("click",()=>{Je("opt-in"),t.classList.remove("show")}),o.appendChild(n);let r=document.createElement("button");r.className="tag-btn",r.textContent="Refill-Sema-Inj",r.addEventListener("click",()=>{b("refill-sema-inj"),t.classList.remove("show")}),o.appendChild(r);let i=document.createElement("button");i.className="tag-btn",i.textContent="Refill-Tirz-Inj",i.addEventListener("click",()=>{b("refill-tirz-inj"),t.classList.remove("show")}),o.appendChild(i);let a=document.createElement("div");a.className="nested-dropdown";let l=document.createElement("button");l.className="nested-dropdown-btn",l.textContent="Vial-Semaglutide";let s=document.createElement("div");s.className="nested-dropdown-content",l.addEventListener("click",c=>{c.stopPropagation(),a.classList.toggle("open")});let d=document.createElement("button");d.className="tag-btn",d.textContent="Vial-Sema-B12",d.addEventListener("click",c=>{c.stopPropagation(),x(),b("vial-sema-b12")}),s.appendChild(d);let g=document.createElement("button");g.className="tag-btn",g.textContent="Vial-Sema-B6",g.addEventListener("click",c=>{c.stopPropagation(),x(),b("vial-sema-b6")}),s.appendChild(g);let u=document.createElement("button");u.className="tag-btn",u.textContent="Vial-Sema-Lipo",u.addEventListener("click",c=>{c.stopPropagation(),x(),b("vial-sema-lipo")}),s.appendChild(u);let h=document.createElement("button");h.className="tag-btn",h.textContent="Vial-Sema-NAD+",h.addEventListener("click",c=>{c.stopPropagation(),x(),b("vial-sema-nad+")}),s.appendChild(h),a.appendChild(l),a.appendChild(s),o.appendChild(a);let f=document.createElement("div");f.className="nested-dropdown";let y=document.createElement("button");y.className="nested-dropdown-btn",y.textContent="Vial-Tirzepatide";let C=document.createElement("div");C.className="nested-dropdown-content",y.addEventListener("click",c=>{c.stopPropagation(),f.classList.toggle("open")});let v=document.createElement("button");v.className="tag-btn",v.textContent="Vial-Tirz-Cyano",v.addEventListener("click",c=>{c.stopPropagation(),x(),b("vial-tirz-cyano")}),C.appendChild(v);let k=document.createElement("button");k.className="tag-btn",k.textContent="Vial-Tirz-NAD+",k.addEventListener("click",c=>{c.stopPropagation(),x(),b("vial-tirz-nad+")}),C.appendChild(k);let m=document.createElement("button");m.className="tag-btn",m.textContent="Vial-Tirz-Pyr",m.addEventListener("click",c=>{c.stopPropagation(),x(),b("vial-tirz-pyridoxine")}),C.appendChild(m),f.appendChild(y),f.appendChild(C),o.appendChild(f);let N=document.createElement("div");N.className="nested-dropdown";let w=document.createElement("button");w.className="nested-dropdown-btn",w.textContent="NP-Semaglutide";let S=document.createElement("div");S.className="nested-dropdown-content",w.addEventListener("click",c=>{c.stopPropagation(),N.classList.toggle("open")});let I=document.createElement("button");I.className="tag-btn",I.textContent="NP-Sema 0.125",I.addEventListener("click",c=>{c.stopPropagation(),x(),b("np-sema-0.125ml-inj")}),S.appendChild(I);let U=document.createElement("button");U.className="tag-btn",U.textContent="NP-Sema 0.25",U.addEventListener("click",c=>{c.stopPropagation(),x(),b("np-sema-0.25ml-inj")}),S.appendChild(U);let W=document.createElement("button");W.className="tag-btn",W.textContent="NP-Sema 0.5",W.addEventListener("click",c=>{c.stopPropagation(),x(),b("np-sema-0.5ml-inj")}),S.appendChild(W);let H=document.createElement("button");H.className="tag-btn",H.textContent="NP-Sema 0.75",H.addEventListener("click",c=>{c.stopPropagation(),x(),b("np-sema-0.75ml-inj")}),S.appendChild(H);let G=document.createElement("button");G.className="tag-btn",G.textContent="NP-Sema 1.0",G.addEventListener("click",c=>{c.stopPropagation(),x(),b("np-sema-1.0ml-inj")}),S.appendChild(G);let J=document.createElement("button");J.className="tag-btn",J.textContent="NP-Sema 1.25",J.addEventListener("click",c=>{c.stopPropagation(),x(),b("np-sema-1.25ml-inj")}),S.appendChild(J);let X=document.createElement("button");X.className="tag-btn",X.textContent="NP-Sema 1.5",X.addEventListener("click",c=>{c.stopPropagation(),x(),b("np-sema-1.5ml-inj")}),S.appendChild(X);let Y=document.createElement("button");Y.className="tag-btn",Y.textContent="NP-Sema 2.0",Y.addEventListener("click",c=>{c.stopPropagation(),x(),b("np-sema-2.0ml-inj")}),S.appendChild(Y),N.appendChild(w),N.appendChild(S),o.appendChild(N);let D=document.createElement("div");D.className="nested-dropdown";let K=document.createElement("button");K.className="nested-dropdown-btn",K.textContent="NP-Tirzepatide";let P=document.createElement("div");P.className="nested-dropdown-content",K.addEventListener("click",c=>{c.stopPropagation(),D.classList.toggle("open")});let Q=document.createElement("button");Q.className="tag-btn",Q.textContent="NP-Tirz 0.25",Q.addEventListener("click",c=>{c.stopPropagation(),x(),b("np-tirz-0.25ml-inj")}),P.appendChild(Q);let Z=document.createElement("button");Z.className="tag-btn",Z.textContent="NP-Tirz 0.5",Z.addEventListener("click",c=>{c.stopPropagation(),x(),b("np-tirz-0.5ml-inj")}),P.appendChild(Z);let ee=document.createElement("button");ee.className="tag-btn",ee.textContent="NP-Tirz 0.75",ee.addEventListener("click",c=>{c.stopPropagation(),x(),b("np-tirz-0.75ml-inj")}),P.appendChild(ee);let te=document.createElement("button");te.className="tag-btn",te.textContent="NP-Tirz 1.0",te.addEventListener("click",c=>{c.stopPropagation(),x(),b("np-tirz-1.0ml-inj")}),P.appendChild(te);let oe=document.createElement("button");oe.className="tag-btn",oe.textContent="NP-Tirz 1.25",oe.addEventListener("click",c=>{c.stopPropagation(),x(),b("np-tirz-1.25ml-inj")}),P.appendChild(oe);let ne=document.createElement("button");return ne.className="tag-btn",ne.textContent="NP-Tirz 1.5",ne.addEventListener("click",c=>{c.stopPropagation(),x(),b("np-tirz-1.5ml-inj")}),P.appendChild(ne),D.appendChild(K),D.appendChild(P),o.appendChild(D),t.appendChild(e),t.appendChild(o),t}function x(){document.querySelectorAll(".dropdown.show").forEach(t=>t.classList.remove("show")),document.querySelectorAll(".nested-dropdown.open").forEach(t=>t.classList.remove("open"))}async function b(t){try{let[e,o]=await Promise.all([xe(),ye()]);console.log("[CRM Extension] Cleanup completed:"),console.log(`- Tags: ${e.removed}/${e.total} removed`),console.log(`- Automations: ${o.removed}/${o.total} removed`),Je(t)}catch(e){console.error("[CRM Extension] Error during cleanup:",e),p("Error during cleanup. Please try again.")}}function Je(t){let e=mt();e?(e.focus(),setTimeout(()=>{e.value=t,e.dispatchEvent(new Event("input",{bubbles:!0})),setTimeout(()=>{let o=document.querySelectorAll(".v-list-item, .dropdown-item, .select-option, li"),n=!1;for(let r of o)if(r.textContent.toLowerCase().includes(t)){r.click(),n=!0,p(`Selected tag: ${t}`);break}if(!n){let r=document.querySelectorAll("*");for(let i of r)if(i.textContent.trim().toLowerCase()===t){i.click(),n=!0,p(`Selected tag: ${t}`);break}n||e.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",code:"Enter",keyCode:13,which:13,bubbles:!0}))}},300)},300)):p("Tags field not found")}function mt(){let t=document.querySelector('input[placeholder="Add Tags"]');if(t)return t;let e=Array.from(document.querySelectorAll("input[placeholder]")).filter(i=>i.placeholder.toLowerCase().includes("tag"));if(e.length>0)return e[0];let o=document.querySelectorAll(".tag-input, .tags-input, .tag-container");for(let i of o){let a=i.querySelector("input");if(a)return a}if(t=document.querySelector('input[placeholder="smartList.bulkTags.addTags"]'),t)return t;let n=document.querySelectorAll(".hl-text-input");if(n.length>0)return n[0];console.error("[CRM Extension] Could not find tag input field with any strategy");let r=document.querySelectorAll("input");return console.log("[CRM Extension] All inputs on page:",r),null}var R={"Sema/B12 Refill - Step 2":"Refill - Semaglutide/B12 Injection Refill Order - (Step 2)","Sema/B12 Vial - Step 2":"Semaglutide/B12 Vial Order - (Step 2)","Sema/B6 Vial - Step 2":"Semaglutide/B6 Vial Order - (Step 2)","Sema/Lipo Vial - Step 2":"Semaglutide/Lipo Vial Order - (Step 2)","Sema/NAD+ Vial - Step 2":"Semaglutide/NAD+ Vial Order - (Step 2)","Tirz/B6 Refill - Step 2":"Syringe - Tirzepatide/Pyridoxine Injection Order - (Step 2)","Tirz/B12 Vial - Step 2":"Tirzepatide/Cyano Vial Order - (Step 2)","Tirz/NAD+ Vial - Step 2":"Tirzepatide/NAD+ Vial Order - (Step 2)","Tirz/B6 Vial - Step 2":"Tirzepatide/Pyridoxine Vial Order - (Step 2)"};function Xe(){let t=document.createElement("div");t.className="dropdown",t.id="crm-automation-dropdown";let e=document.createElement("button");e.className="dropdown-btn",e.textContent="Automation",e.addEventListener("click",m=>{m.stopPropagation(),document.querySelectorAll(".dropdown.show").forEach(N=>{N!==t&&N.classList.remove("show")}),t.classList.toggle("show")});let o=document.createElement("div");if(o.className="dropdown-content",o.style.padding="10px",!document.getElementById("automation-dropdown-styles")){let m=document.createElement("style");m.id="automation-dropdown-styles",m.textContent=`
      .nested-dropdown {
        margin-bottom: 8px;
        width: 100%;
        position: relative;
      }
      .nested-dropdown-btn {
        width: 100%;
        text-align: left;
        padding: 8px 12px;
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 3px;
        cursor: pointer;
        font-weight: bold;
        font-size: 13px;
        color: #e6e6e6;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .nested-dropdown-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      .nested-dropdown-btn:after {
        content: "\u25BC";
        font-size: 8px;
        color: #e6e6e6;
      }
      .nested-dropdown-content {
        display: none;
        padding: 5px 0 5px 10px;
        margin-top: 3px !important;
      }
      .nested-dropdown.open .nested-dropdown-content {
        display: block;
      }
      
      /* Button-style options */
      .automation-btn {
        display: block;
        width: 100%;
        padding: 8px 12px;
        margin-bottom: 8px;
        background-color: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 4px;
        text-align: left;
        font-size: 13px;
        color: #e6e6e6;
        cursor: pointer;
        transition: all 0.2s ease;
        font-weight: normal;
      }
      .automation-btn:hover {
        background-color: rgba(255, 255, 255, 0.15);
        border-color: rgba(255, 255, 255, 0.2);
      }
      .automation-btn:active {
        background-color: rgba(255, 255, 255, 0.2);
      }
    `,document.head.appendChild(m)}let n=document.createElement("div");n.className="nested-dropdown";let r=document.createElement("button");r.className="nested-dropdown-btn",r.textContent="Semaglutide (Step 2)";let i=document.createElement("div");i.className="nested-dropdown-content",r.addEventListener("click",m=>{m.stopPropagation(),n.classList.toggle("open")});let a=document.createElement("button");a.className="automation-btn",a.textContent="Sema/B12 Refill - Step 2",a.addEventListener("click",m=>{m.stopPropagation(),L(),setTimeout(()=>{T(R["Sema/B12 Refill - Step 2"])},300)}),i.appendChild(a);let l=document.createElement("button");l.className="automation-btn",l.textContent="Sema/B12 Vial - Step 2",l.addEventListener("click",m=>{m.stopPropagation(),L(),setTimeout(()=>{T(R["Sema/B12 Vial - Step 2"])},300)}),i.appendChild(l);let s=document.createElement("button");s.className="automation-btn",s.textContent="Sema/B6 Vial - Step 2",s.addEventListener("click",m=>{m.stopPropagation(),L(),setTimeout(()=>{T(R["Sema/B6 Vial - Step 2"])},300)}),i.appendChild(s);let d=document.createElement("button");d.className="automation-btn",d.textContent="Sema/Lipo Vial - Step 2",d.addEventListener("click",m=>{m.stopPropagation(),L(),setTimeout(()=>{T(R["Sema/Lipo Vial - Step 2"])},300)}),i.appendChild(d);let g=document.createElement("button");g.className="automation-btn",g.textContent="Sema/NAD+ Vial - Step 2",g.addEventListener("click",m=>{m.stopPropagation(),L(),setTimeout(()=>{T(R["Sema/NAD+ Vial - Step 2"])},300)}),i.appendChild(g),n.appendChild(r),n.appendChild(i),o.appendChild(n);let u=document.createElement("div");u.className="nested-dropdown";let h=document.createElement("button");h.className="nested-dropdown-btn",h.textContent="Tirzepatide (Step 2)";let f=document.createElement("div");f.className="nested-dropdown-content",h.addEventListener("click",m=>{m.stopPropagation(),u.classList.toggle("open")});let y=document.createElement("button");y.className="automation-btn",y.textContent="Tirz/B6 Refill - Step 2",y.addEventListener("click",m=>{m.stopPropagation(),L(),setTimeout(()=>{T(R["Tirz/B6 Refill - Step 2"])},300)}),f.appendChild(y);let C=document.createElement("button");C.className="automation-btn",C.textContent="Tirz/B12 Vial - Step 2",C.addEventListener("click",m=>{m.stopPropagation(),L(),setTimeout(()=>{T(R["Tirz/B12 Vial - Step 2"])},300)}),f.appendChild(C);let v=document.createElement("button");v.className="automation-btn",v.textContent="Tirz/NAD+ Vial - Step 2",v.addEventListener("click",m=>{m.stopPropagation(),L(),setTimeout(()=>{T(R["Tirz/NAD+ Vial - Step 2"])},300)}),f.appendChild(v);let k=document.createElement("button");return k.className="automation-btn",k.textContent="Tirz/B6 Vial - Step 2",k.addEventListener("click",m=>{m.stopPropagation(),L(),setTimeout(()=>{T(R["Tirz/B6 Vial - Step 2"])},300)}),f.appendChild(k),u.appendChild(h),u.appendChild(f),o.appendChild(u),t.appendChild(e),t.appendChild(o),t}function L(){document.querySelectorAll(".dropdown.show").forEach(t=>t.classList.remove("show")),document.querySelectorAll(".nested-dropdown.open").forEach(t=>t.classList.remove("open"))}function T(t){try{console.log(`[CRM Extension] Starting workflow for "${t}"`),p(`Starting workflow for "${t}"`);let e=Array.from(document.querySelectorAll("button.btn.btn-light2.btn-xs")).find(o=>o.textContent.trim().includes("Add"));if(!e){console.error("[CRM Extension] Add Automation button not found"),p("Add Automation button not found");return}console.log("[CRM Extension] Found Add button, clicking it"),e.click(),setTimeout(()=>{let o=document.querySelector('input[placeholder="Type to search"]');if(!o){console.error("[CRM Extension] Search input not found"),p("Search input not found");return}console.log("[CRM Extension] Found search input, entering 'step 2'"),o.focus(),o.value="step 2",o.dispatchEvent(new Event("input",{bubbles:!0})),setTimeout(()=>{let n=[".v-list",".dropdown-menu",".v-select-list",".vs__dropdown-menu",'[role="listbox"]',"ul",".v-menu__content"],r=null;for(let d of n){let g=document.querySelector(d);if(g&&g.querySelector("li, .v-list-item, .dropdown-item")&&g.scrollHeight>g.clientHeight){r=g,console.log(`[CRM Extension] Found scrollable dropdown container: ${d}`);break}}if(!r){let d=document.querySelector('.modal, dialog, [role="dialog"]');if(d){let g=Array.from(d.querySelectorAll("*")).filter(u=>u.scrollHeight>u.clientHeight&&u.clientHeight>50);g.length>0&&(r=g[0],console.log("[CRM Extension] Found scrollable element via fallback method"))}}if(!r){console.error("[CRM Extension] Could not find scrollable container"),p("Could not find dropdown container");return}console.log("[CRM Extension] Starting scroll wheel simulation"),console.log(`[CRM Extension] Container dimensions: ${r.scrollHeight}x${r.clientHeight}`);let i=0,a=20,l=!1;function s(){if(l||i>=a){l||(console.error("[CRM Extension] Max scroll attempts reached without finding match"),p("Option not found after scrolling"));return}i++,console.log(`[CRM Extension] Scroll attempt ${i}/${a}`);let d=new WheelEvent("wheel",{deltaY:100,bubbles:!0});r.dispatchEvent(d),r.scrollTop+=100,console.log(`[CRM Extension] Scrolled to position: ${r.scrollTop}/${r.scrollHeight}`),setTimeout(()=>{let g=r.querySelectorAll('li, .v-list-item, .dropdown-item, [role="option"]');console.log(`[CRM Extension] Found ${g.length} options after scrolling`);for(let u of g){if(!u.textContent)continue;let h=u.textContent.trim();if(h===t&&!h.includes("Provider Paid")&&!h.includes("New Patient")){console.log(`[CRM Extension] Found exact matching option: "${h}"`);try{u.scrollIntoView({block:"center"}),setTimeout(()=>{u.click(),l=!0,setTimeout(()=>{let f=Array.from(document.querySelectorAll("button")).find(y=>y.textContent.trim()==="Add");f?(console.log("[CRM Extension] Clicking Add button in dialog"),f.click(),p(`Added "${t}" workflow`)):(console.error("[CRM Extension] Add button in dialog not found"),p("Add button in dialog not found"))},1e3)},300)}catch(f){console.error("[CRM Extension] Error clicking option:",f)}break}}if(!l){if(r.scrollHeight-r.scrollTop<=r.clientHeight+20){console.log("[CRM Extension] Reached bottom of dropdown without finding match"),p(`Reached end without finding "${t}"`);return}setTimeout(s,500)}},500)}s()},1500)},1e3)}catch(e){console.error("[CRM Extension] Error in workflow:",e),p(`Error in workflow: ${e.message}`)}}function Ye(){let t=document.createElement("div");return t.className="group",t.id="crm-dropdowns-group",t.appendChild(Xe()),t.appendChild(Ge()),document.addEventListener("click",e=>{document.querySelectorAll(".dropdown").forEach(n=>{n.contains(e.target)||(n.classList.remove("show"),n.querySelectorAll(".nested-dropdown").forEach(i=>{i.classList.remove("open")}))})}),ut(),t}function ut(){if(document.getElementById("custom-dropdown-styles"))return;let t=document.createElement("style");t.id="custom-dropdown-styles",t.textContent=`
    /* Improved dropdown positioning */
    .dropdown {
      position: relative !important;
      margin-right: 8px !important; /* Ensure space between dropdowns, reduced for tighter layout */
    }
    
    .dropdown:last-child {
      margin-right: 0 !important; /* Remove margin from the last dropdown */
    }
    
    .dropdown-content {
      position: absolute !important;
      background-color: #2F3A4B; /* Match toolbar background color */
      min-width: 220px !important; /* Increased width */
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.3);
      z-index: 999;
      border-radius: 4px;
      margin-top: 5px !important; /* Add space between button and dropdown */
      left: 0;
      top: 100% !important; /* Position below the button */
      display: none;
      border: 1px solid rgba(255, 255, 255, 0.1); /* Subtle border */
    }
    
    /* Ensure right-aligned dropdowns don't overflow */
    #crm-tags-dropdown .dropdown-content {
      right: 0;
      left: auto; /* Override left positioning for Tags dropdown */
    }
    
    .dropdown.show .dropdown-content {
      display: block;
    }
    
    /* Improved nested dropdown positioning */
    .nested-dropdown-content {
      margin-top: 3px !important;
      background-color: #2F3A4B; /* Match toolbar background color */
      border-radius: 4px;
      padding: 5px !important;
    }
    
    /* Style dropdown items */
    .dropdown-item {
      color: #e6e6e6; /* White text for visibility */
      padding: 10px 14px !important; /* Increased padding */
      text-decoration: none;
      display: block;
      font-size: 14px;
      cursor: pointer;
      border-radius: 3px;
      font-weight: normal;
    }
    
    .dropdown-item:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
    
    /* Fix for Vial-Sema and Vial-Tirz nested dropdowns */
    .nested-dropdown-btn {
      text-align: left !important;
      padding: 8px 12px !important;
      background-color: rgba(255, 255, 255, 0.1) !important;
      border: 1px solid rgba(255, 255, 255, 0.15) !important;
      color: #e6e6e6 !important;
      font-weight: bold !important;
    }
    
    .nested-dropdown-btn:hover {
      background-color: rgba(255, 255, 255, 0.2) !important;
    }
    
    /* Force visibility for Tags dropdown */
    #crm-tags-dropdown {
      display: flex !important;
    }
    
    #crm-tags-dropdown .dropdown-content {
      min-width: 220px !important;
    }
  `,document.head.appendChild(t)}function Ke(){let t=document.createElement("div");t.className="group",t.id="crm-settings-group",t.style.position="relative";let e=document.createElement("button");e.className="btn",e.id="crm-settings-btn";let o=document.createElement("span");o.className="btn-icon",o.innerHTML="\u2699\uFE0F",e.appendChild(o);let n=document.createElement("span");n.textContent="Settings",e.appendChild(n);let r=ft();if(e.addEventListener("click",i=>{i.stopPropagation(),r.classList.toggle("show")}),document.addEventListener("click",i=>{i.target!==e&&!e.contains(i.target)&&i.target!==r&&!r.contains(i.target)&&r.classList.remove("show")}),!document.getElementById("settings-dropdown-styles")){let i=document.createElement("style");i.id="settings-dropdown-styles",i.textContent=`
      #mcp-crm-settings-dropdown {
        display: none;
        position: absolute;
        top: calc(100% + 5px); /* Position below the button with 5px gap */
        right: 0;
        z-index: 1000;
        min-width: 230px;
        background-color: #2F3A4B;
        border-radius: 4px;
        border: 1px solid rgba(255, 255, 255, 0.1);
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
        overflow: hidden;
      }
      
      #mcp-crm-settings-dropdown.show {
        display: block;
      }
      
      .settings-header {
        padding: 10px;
        background-color: rgba(255, 255, 255, 0.1);
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        font-weight: bold;
        color: #e6e6e6;
      }
      
      .settings-body {
        padding: 10px;
        color: #e6e6e6;
      }
      
      .setting-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
        font-size: 13px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        padding-bottom: 10px;
      }
      
      .setting-item:last-child {
        margin-bottom: 0;
        border-bottom: none;
        padding-bottom: 0;
      }
      
      .setting-label {
        color: #e6e6e6;
        font-weight: normal;
      }
      
      /* Toggle switch styles */
      .switch {
        position: relative;
        display: inline-block;
        width: 40px;
        height: 20px;
      }
      
      .switch input {
        opacity: 0;
        width: 0;
        height: 0;
      }
      
      .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #555;
        transition: .4s;
        border-radius: 34px;
      }
      
      .slider:before {
        position: absolute;
        content: "";
        height: 16px;
        width: 16px;
        left: 2px;
        bottom: 2px;
        background-color: white;
        transition: .4s;
        border-radius: 50%;
      }
      
      input:checked + .slider {
        background-color: #2196F3;
      }
      
      input:focus + .slider {
        box-shadow: 0 0 1px #2196F3;
      }
      
      input:checked + .slider:before {
        transform: translateX(20px);
      }
      
      /* Version info styles */
      .version-info {
        border-top: 1px solid rgba(255, 255, 255, 0.1);
        margin-top: 10px;
        padding-top: 10px;
        font-size: 12px;
        color: #e6e6e6;
      }
      
      .version-info p {
        margin: 5px 0;
        color: #e6e6e6;
      }
      
      .version-number {
        font-weight: 600;
        color: #e6e6e6;
      }
      
      .check-updates-btn {
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 3px;
        padding: 4px 8px;
        margin-top: 5px;
        font-size: 11px;
        cursor: pointer;
        transition: background-color 0.2s;
        width: 100%;
        text-align: center;
        color: #e6e6e6;
      }
      
      .check-updates-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      
      .check-updates-btn:disabled {
        opacity: 0.6;
        cursor: not-allowed;
      }
      
      #crm-update-status {
        margin: 5px 0 0 0;
        padding: 3px 6px;
        font-size: 11px;
        border-radius: 3px;
        background-color: rgba(255, 255, 255, 0.05);
        text-align: center;
        transition: all 0.3s ease;
        color: #e6e6e6;
      }
      
      #last-update-check {
        font-size: 11px;
        margin: 5px 0;
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        color: #e6e6e6;
      }
      
      .check-status {
        font-size: 10px;
        margin-left: 5px;
        padding: 1px 4px;
        border-radius: 3px;
        font-weight: normal;
      }
      
      .loading-text {
        font-style: italic;
        color: #aaa;
      }
      
      /* Section styles */
      .setting-section {
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      }
      
      .setting-section-title {
        font-size: 12px;
        font-weight: bold;
        color: #e6e6e6;
        margin-bottom: 10px;
      }
    `,document.head.appendChild(i)}return t.appendChild(e),t.appendChild(r),t}function gt(t){try{(typeof browser<"u"?browser:chrome).runtime.sendMessage({action:"getLastUpdateCheck"}).then(o=>{if(o&&o.success&&o.lastUpdateCheck){let n=o.lastUpdateCheck,r="",i="";n.success?n.status==="update_available"?(r="Update available",i="#4CAF50"):n.status==="no_update"?(r="No updates needed",i="#2196F3"):n.status==="throttled"?(r="Check throttled",i="#FF9800"):(r="Completed",i="#2196F3"):(r="Failed",i="#F44336"),t.innerHTML=`Last Check: <span class="version-number">${n.formattedTime}</span> <span class="check-status" style="color:${i};font-size:10px;margin-left:5px;">${r}</span>`}else t.innerHTML='Last Check: <span class="version-number">No checks recorded</span>'}).catch(o=>{console.error("[CRM Extension] Error fetching last update check:",o),t.innerHTML='Last Check: <span class="version-number">Unknown</span>'})}catch(e){console.error("[CRM Extension] Error in fetchLastUpdateCheckInfo:",e),t.innerHTML='Last Check: <span class="version-number">Error</span>'}}function ft(){let t=document.createElement("div");t.id="mcp-crm-settings-dropdown";let e=document.createElement("div");e.className="settings-header",e.textContent="CRM+ Settings",t.appendChild(e);let o=document.createElement("div");if(o.className="settings-body",t.appendChild(o),!document.getElementById("collapsible-settings-styles")){let l=document.createElement("style");l.id="collapsible-settings-styles",l.textContent=`
      .setting-section {
        margin-bottom: 8px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        padding-bottom: 0; /* No bottom padding when collapsed */
      }
      
      .setting-section-title {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 13px;
        font-weight: bold;
        color: #e6e6e6;
        padding: 8px 0;
        cursor: pointer;
        user-select: none;
      }
      
      .setting-section-title:after {
        content: "\u25BC";
        font-size: 8px;
        color: #e6e6e6;
        transition: transform 0.2s ease;
      }
      
      .setting-section.collapsed .setting-section-title:after {
        transform: rotate(-90deg);
      }
      
      .setting-section-content {
        max-height: 500px;
        overflow: hidden;
        transition: max-height 0.3s ease, opacity 0.2s ease, margin-bottom 0.3s ease;
        opacity: 1;
        margin-bottom: 10px;
      }
      
      .setting-section.collapsed .setting-section-content {
        max-height: 0;
        opacity: 0;
        margin-bottom: 0;
      }
    `,document.head.appendChild(l)}let n=we("General Settings");n.content.appendChild(z("Show Header Bar","crmplus_headerBarVisible",l=>{let s=document.getElementById("mcp-crm-header");s&&(s.style.display=l?"flex":"none",document.body.style.paddingTop=l?"32px":"0"),p(`Header bar: ${l?"Visible":"Hidden"}`)},!0)),n.content.appendChild(z("Show Provider-Paid Alerts","crmplus_showProviderPaidAlerts",l=>{p(`Provider-Paid alerts: ${l?"Enabled":"Disabled"}`)},!0)),o.appendChild(n.section);let r=we("External Links");r.content.appendChild(z("Show ShipStation Link","crmplus_showShipStation",l=>{let s=document.querySelector(".shipstation-link");s&&(s.style.display=l?"flex":"none"),p(`ShipStation link: ${l?"Visible":"Hidden"}`)},!0)),r.content.appendChild(z("Show Stripe Link","crmplus_showStripe",l=>{let s=document.querySelector(".stripe-link");s&&(s.style.display=l?"flex":"none"),p(`Stripe link: ${l?"Visible":"Hidden"}`)},!0)),r.content.appendChild(z("Show Webmail Link","crmplus_showWebmail",l=>{let s=document.querySelector(".webmail-link");s&&(s.style.display=l?"flex":"none"),p(`Webmail link: ${l?"Visible":"Hidden"}`)},!0)),o.appendChild(r.section);let i=we("Features");i.content.appendChild(z("Auto-copy phone number on page load","crmplus_autoCopyPhone",l=>{p(`Auto-copy phone: ${l?"Enabled":"Disabled"}`)},!1)),i.content.appendChild(z("CRM Automation","crmplus_automationEnabled",l=>{[document.getElementById("crm-automation-dropdown"),document.getElementById("crm-tags-dropdown")].forEach(d=>{d?(d.style.display=l?"flex":"none",console.log(`[CRM Extension] Changed visibility for ${d.id}: ${l?"visible":"hidden"}`)):console.error("[CRM Extension] Could not find automation element to toggle")}),p(`CRM Automation: ${l?"Enabled":"Disabled"}`)},!0)),o.appendChild(i.section);let a=ht();return o.appendChild(a),t}function we(t,e=!1){let o=document.createElement("div");o.className="setting-section"+(e?" collapsed":"");let n=document.createElement("div");n.className="setting-section-title",n.textContent=t,n.addEventListener("click",()=>{o.classList.toggle("collapsed")}),o.appendChild(n);let r=document.createElement("div");return r.className="setting-section-content",o.appendChild(r),{section:o,content:r}}function ht(){let t=document.createElement("div");t.className="version-info";let e="Loading...",o="Loading...";try{let s=(typeof browser<"u"?browser:chrome).runtime.getManifest();if(s&&s.version&&(e=s.version,e.includes("."))){let d=e.split(".");if(d.length===3&&d[0].length===4){let g=d[0],u=d[1],h=d[2];o=`${u}/${h}/${g}`}}}catch(l){console.error("[CRM Extension] Error fetching version:",l),e="Unknown",o="Unknown"}let n=document.createElement("p");n.innerHTML=`Version: <span class="version-number">${e}</span>`,t.appendChild(n);let r=document.createElement("p");r.innerHTML=`Last Updated: <span class="version-number">${o}</span>`,t.appendChild(r);let i=document.createElement("p");i.id="last-update-check",i.innerHTML='Last Check: <span class="loading-text">Loading...</span>',t.appendChild(i),gt(i);let a=document.createElement("button");return a.className="check-updates-btn",a.textContent="Check for Updates",a.addEventListener("click",()=>{let l=typeof browser<"u"?browser:chrome;a.disabled=!0,a.textContent="Checking...",p("Checking for updates...");let s=document.getElementById("crm-update-status");s||(s=document.createElement("p"),s.id="crm-update-status",s.style.fontSize="11px",s.style.marginTop="5px",s.style.color="#e6e6e6",s.textContent="",t.appendChild(s)),l.runtime.sendMessage({action:"checkForUpdates"}).then(d=>{if(d&&d.success){p("Update check completed"),d.updateStatus==="update_available"?(s.textContent=`Update available (${d.updateVersion})`,s.style.color="#4CAF50"):d.updateStatus==="no_update"?(s.textContent="You have the latest version",s.style.color="#2196F3"):d.updateStatus==="throttled"?(s.textContent="Update check throttled, try again later",s.style.color="#FF9800"):d.updateStatus==="error"?(s.textContent="Error checking for updates",s.style.color="#F44336"):(s.textContent="Update check initiated",s.style.color="#e6e6e6");let g=document.getElementById("last-update-check");if(g&&d.lastCheck){let u=d.lastCheck,h="",f="";u.success?u.status==="update_available"?(h="Update available",f="#4CAF50"):u.status==="no_update"?(h="No updates needed",f="#2196F3"):u.status==="throttled"?(h="Check throttled",f="#FF9800"):(h="Completed",f="#2196F3"):(h="Failed",f="#F44336"),g.innerHTML=`Last Check: <span class="version-number">${u.formattedTime}</span> <span class="check-status" style="color:${f};font-size:10px;margin-left:5px;">${h}</span>`}}else p("Error checking for updates"),s.textContent="Update check failed",s.style.color="#F44336";a.disabled=!1,a.textContent="Check for Updates"}).catch(d=>{console.error("[CRM Extension] Error sending update check message:",d),p("Error checking for updates"),s.textContent="Connection failed",s.style.color="#F44336",a.disabled=!1,a.textContent="Check for Updates"})}),t.appendChild(a),t}function z(t,e,o,n=!1){let r=document.createElement("div");r.className="setting-item";let i=document.createElement("div");i.className="setting-label",i.textContent=t,r.appendChild(i);let a=document.createElement("label");a.className="switch";let l=document.createElement("input");l.type="checkbox";let s=localStorage.getItem(e),d=s!==null?s==="true":n;s===null&&localStorage.setItem(e,n.toString()),l.checked=d,l.addEventListener("change",()=>{let u=l.checked;localStorage.setItem(e,u.toString()),o&&typeof o=="function"&&o(u)});let g=document.createElement("span");return g.className="slider",a.appendChild(l),a.appendChild(g),r.appendChild(a),r}function Qe(){if(document.getElementById("mcp-crm-header-styles"))return;let t=document.createElement("style");t.id="mcp-crm-header-styles",t.textContent=`
    #mcp-crm-header {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 32px;
      background-color: #2F3A4B;
      display: flex;
      align-items: center;
      padding: 0 15px;
      font-family: 'Segoe UI', 'Roboto', sans-serif;
      font-size: 12px;
      z-index: 999999;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    }
    
    #mcp-crm-header .group {
      display: flex;
      align-items: center;
      margin-right: 15px;
      border-right: 1px solid rgba(255, 255, 255, 0.1);
      padding-right: 15px;
    }
    
    #mcp-crm-header .group:last-child {
      border-right: none;
      margin-right: 0; /* Remove margin from the last group (Settings) */
    }
    
    /* Special styling for dropdowns group to match other elements' spacing */
    #crm-dropdowns-group {
      margin-right: 15px; /* Same spacing as other elements */
      padding-right: 15px; /* Same padding as other elements */
    }
    
    /* Ensure settings is positioned at the far right */
    #crm-settings-btn {
      margin-right: 0;
    }
    
    #mcp-crm-header .spacer {
      flex-grow: 1;
    }
    
    #mcp-crm-header .label {
      color: #8a9cad;
      margin-right: 6px;
      font-weight: 500;
    }
    
    #mcp-crm-header .value {
      color: #e6e6e6;
      font-weight: 600;
    }
    
    #mcp-crm-header .clickable-value {
      color: #e6e6e6;
      font-weight: 600;
      cursor: pointer;
      background-color: rgba(255, 255, 255, 0.05);
      padding: 2px 8px;
      border-radius: 3px;
      transition: background-color 0.2s;
      display: inline-flex;
      align-items: center;
    }
    
    #mcp-crm-header .clickable-value:hover {
      background-color: rgba(255, 255, 255, 0.15);
    }
    
    #mcp-crm-header .btn-icon {
      margin-right: 4px;
      font-size: 10px;
    }
    
    /* Logo link styling */
    #mcp-crm-header .logo-link {
      display: flex;
      align-items: center;
      text-decoration: none;
      transition: all 0.2s ease;
    }
    
    #mcp-crm-header .logo-link:hover {
      opacity: 0.85;
    }
    
    #mcp-crm-header .logo-icon {
      width: 16px;
      height: 16px;
      margin-right: 6px;
    }
    
    #mcp-crm-header .logo {
      font-weight: bold;
      color: white;
      font-size: 14px;
    }
    
    #mcp-crm-header .external-link {
      text-decoration: none;
      color: #e6e6e6;
      display: flex;
      align-items: center;
      transition: all 0.2s ease;
      margin-right: 10px;
    }
    
    #mcp-crm-header .external-link:hover {
      background: rgba(255, 255, 255, 0.2);
      transform: translateY(-1px);
    }
    
    #mcp-crm-header .ext-link-icon {
      font-size: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    /* Styling for text links with icons */
    #mcp-crm-header .text-link {
      text-decoration: none;
      margin-right: 4px; /* Reduced margin between buttons */
      font-size: 12px;
      padding: 3px 6px; /* Reduced horizontal padding to make buttons skinnier */
      border-radius: 3px;
      color: #e6e6e6;
      display: flex;
      align-items: center;
      justify-content: center; /* Center content horizontally */
      white-space: nowrap; /* Prevent text wrapping */
      min-width: 68px; /* Set minimum width to keep consistency */
    }
    
    #mcp-crm-header .text-link:hover {
      background-color: rgba(255, 255, 255, 0.15);
    }
    
    #mcp-crm-header .text-link .link-icon {
      margin-right: 4px; /* Slightly reduced margin for tighter look */
      width: 16px;
      height: 16px;
      vertical-align: middle;
      flex-shrink: 0; /* Prevent icon from shrinking */
    }
    
    /* Add a specific class for each button to fine-tune widths if needed */
    #mcp-crm-header .shipstation-link {
      min-width: 92px;
    }
    
    #mcp-crm-header .stripe-link {
      min-width: 65px;
    }
    
    #mcp-crm-header .webmail-link {
      min-width: 78px;
    }
    
    #mcp-crm-header .btn {
      color: #e6e6e6;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 3px;
      padding: 4px 8px;
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      margin-right: 8px;
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
    }
    
    #mcp-crm-header .btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    #mcp-crm-header .btn:active {
      background-color: rgba(255, 255, 255, 0.3);
    }
    
    #mcp-crm-header .btn:last-child {
      margin-right: 0;
    }
    
    /* Dropdown styling */
    .dropdown {
      position: relative;
      display: inline-block;
      margin-right: 8px;
    }
    
    .dropdown-btn {
      color: #e6e6e6;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 3px;
      padding: 4px 8px;
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
      justify-content: space-between;
      min-width: 100px;
    }
    
    .dropdown-btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .dropdown-btn:after {
      content: "\u25BC";
      font-size: 8px;
      margin-left: 5px;
    }
    
    .dropdown-content {
      display: none;
      position: absolute;
      background-color: #2F3A4B;
      min-width: 180px;
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.3);
      z-index: 1000000;
      border-radius: 4px;
      border: 1px solid rgba(255, 255, 255, 0.1);
      margin-top: 2px;
      left: 0;
    }
    
    .dropdown.show .dropdown-content {
      display: block;
    }
    
    .dropdown-item {
      color: #e6e6e6;
      padding: 8px 12px;
      text-decoration: none;
      display: block;
      font-size: 12px;
      cursor: pointer;
      font-weight: normal;
    }
    
    .dropdown-item:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
    
    /* Nested Dropdown styling */
    .nested-dropdown {
      margin-bottom: 5px;
      width: 100%;
    }
    
    .nested-dropdown-btn {
      width: 100%;
      text-align: left;
      padding: 6px 10px;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 3px;
      cursor: pointer;
      font-weight: bold;
      font-size: 12px;
      color: #e6e6e6;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .nested-dropdown-btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .nested-dropdown-btn:after {
      content: "\u25BC";
      font-size: 8px;
      color: #e6e6e6;
    }
    
    .nested-dropdown-content {
      display: none;
      padding: 5px 0 5px 10px;
      background-color: #2F3A4B;
    }
    
    .nested-dropdown.open .nested-dropdown-content {
      display: block;
    }
    
    .nested-dropdown-item {
      display: block;
      padding: 5px 10px;
      color: #e6e6e6;
      text-decoration: none;
      font-size: 12px;
      cursor: pointer;
      border-radius: 3px;
      font-weight: normal;
    }
    
    .nested-dropdown-item:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
    
    /* Settings dropdown styling */
    #mcp-crm-settings-dropdown {
      position: absolute;
      top: 32px;
      right: 15px;
      background-color: #2F3A4B;
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 4px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.3);
      min-width: 200px;
      z-index: 1000000;
      display: none;
      color: #e6e6e6;
    }
    
    #mcp-crm-settings-dropdown.show {
      display: block;
    }
    
    #mcp-crm-settings-dropdown .settings-header {
      background-color: rgba(255, 255, 255, 0.1);
      color: #e6e6e6;
      padding: 8px 12px;
      font-weight: bold;
      border-top-left-radius: 3px;
      border-top-right-radius: 3px;
    }
    
    #mcp-crm-settings-dropdown .settings-body {
      padding: 10px;
    }
    
    #mcp-crm-settings-dropdown .setting-item {
      display: flex;
      align-items: center;
      margin-bottom: 8px;
      padding-bottom: 8px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    #mcp-crm-settings-dropdown .setting-item:last-child {
      margin-bottom: 0;
      padding-bottom: 0;
      border-bottom: none;
    }
    
    #mcp-crm-settings-dropdown .setting-label {
      flex-grow: 1;
      font-size: 13px;
      color: #e6e6e6;
    }
    
    /* Toggle switch styling */
    .switch {
      position: relative;
      display: inline-block;
      width: 40px;
      height: 20px;
    }
    
    .switch input { 
      opacity: 0;
      width: 0;
      height: 0;
    }
    
    .slider {
      position: absolute;
      cursor: pointer;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: #555;
      transition: .4s;
      border-radius: 34px;
    }
    
    .slider:before {
      position: absolute;
      content: "";
      height: 16px;
      width: 16px;
      left: 2px;
      bottom: 2px;
      background-color: white;
      transition: .4s;
      border-radius: 50%;
    }
    
    input:checked + .slider {
      background-color: #2196F3;
    }
    
    input:checked + .slider:before {
      transform: translateX(20px);
    }
    
    /* Version info section in settings */
    .version-info {
      border-top: 1px solid rgba(255, 255, 255, 0.1);
      margin-top: 10px;
      padding-top: 10px;
      font-size: 12px;
      color: #e6e6e6;
    }
    
    .version-info p {
      margin: 5px 0;
    }
    
    .version-number {
      font-weight: 600;
      color: #e6e6e6;
    }
    
    .check-updates-btn {
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 3px;
      padding: 4px 8px;
      margin-top: 5px;
      font-size: 11px;
      cursor: pointer;
      transition: background-color 0.2s;
      width: 100%;
      text-align: center;
      color: #e6e6e6;
    }
    
    .check-updates-btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .check-updates-btn:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
  `,document.head.appendChild(t)}var bt=!1;function Ee(){try{if(document.getElementById("mcp-crm-header")){console.log("[uiHeaderBar] Toolbar already exists.");return}Qe();let t=document.createElement("div");t.id="mcp-crm-header";let e=localStorage.getItem("crmplus_headerBarVisible")!=="false";console.log("[CRM Extension] Header visibility setting:",e),t.style.display=e?"flex":"none";let o=typeof browser<"u"?browser:chrome,n=w=>o.runtime.getURL(w),r=document.createElement("div");r.className="group";let i=document.createElement("a");i.href="https://app.mtncarerx.com/",i.className="logo-link";let a=document.createElement("img");a.src=n("assets/mcp-favicon.ico"),a.alt="",a.className="logo-icon",i.appendChild(a);let l=document.createElement("span");l.className="logo",l.textContent="CRM+",i.appendChild(l),r.appendChild(i);let s=document.createElement("div");s.className="group external-links";let d=Ce("ShipStation","https://ship15.shipstation.com/onboard","shipstation-link",n("assets/shipstation-favicon.ico"));s.appendChild(d);let g=Ce("Stripe","https://dashboard.stripe.com/login","stripe-link",n("assets/stripe-favicon.ico"));s.appendChild(g);let u=Ce("Webmail","https://p3plzcpnl506102.prod.phx3.secureserver.net:2096/cpsess5640910985/webmail/jupiter/index.html?login=1&post_login=89371011642013","webmail-link",n("assets/webmail-favicon.ico"));s.appendChild(u);let h=O("name","Name"),f=O("phone","Phone",{icon:"\u{1F4DE}",initialValue:"",onClick:async w=>{Ie(w)}}),y=O("dob","DOB"),C=O("srxid","SRx ID"),v=He(),k=Ye(),m=document.createElement("div");m.className="spacer";let N=Ke();t.appendChild(r),t.appendChild(s),t.appendChild(h),t.appendChild(f),t.appendChild(y),t.appendChild(C),t.appendChild(k),t.appendChild(v),t.appendChild(m),t.appendChild(N),document.body.appendChild(t),document.body.style.paddingTop=e?"32px":"0",setTimeout(()=>{try{let w=localStorage.getItem("crmplus_automationEnabled")==="true";[document.getElementById("crm-automation-dropdown"),document.getElementById("crm-tags-dropdown")].forEach(I=>{I&&(I.style.display=w?"flex":"none",console.log(`[CRM Extension] Initial visibility for ${I.id}: ${w?"visible":"hidden"}`))})}catch(w){console.error("[CRM Extension] Error setting initial automation visibility:",w)}},100),A(),ze(),$e(),Te(),Fe(),window.addEventListener("popstate",function(){console.log("[CRM Extension] Navigation detected, clearing phone display"),A()}),xt()||A(),bt=!0,console.log("[CRM Extension] Header successfully initialized")}catch(t){console.error("[CRM Extension] Critical error creating toolbar:",t);try{let e=document.getElementById("mcp-crm-header");e&&(e.style.display="flex")}catch(e){console.error("[CRM Extension] Failed to recover toolbar:",e)}}}function Ce(t,e,o="",n=""){let r=document.createElement("a");r.href=e,r.target="_blank",r.className=`text-link btn ${o}`,r.rel="noopener noreferrer";let i=document.createElement("div");if(i.style.display="flex",i.style.alignItems="center",i.style.justifyContent="center",i.style.width="100%",n){let l=document.createElement("img");l.src=n,l.alt="",l.className="link-icon",l.style.width="16px",l.style.height="16px",l.style.marginRight="4px",i.appendChild(l)}let a=document.createElement("span");return a.textContent=t,i.appendChild(a),r.appendChild(i),r}function xt(){let t=window.location.href;return[/\/patient\/\d+/i,/\/contact\/\d+/i,/\/profile\/\d+/i,/[?&]patient_id=\d+/i,/[?&]contact_id=\d+/i].some(n=>n.test(t))?!0:['input[name="contact.phone"]','input[name="contact.first_name"]','input[name="contact.last_name"]','input[name="contact.date_of_birth"]',".patient-info",".contact-details",".patient-header",".patient-profile"].some(n=>document.querySelector(n)!==null)}function ve(t){try{let e=document.getElementById("mcp-crm-header");if(e){console.log(`[CRM Extension] Setting header visibility to: ${t}`),e.style.display=t?"flex":"none";let o=document.body.classList.contains("has-alert");return t?(document.body.style.paddingTop=o?"72px":"32px",document.body.classList.remove("no-header")):(document.body.style.paddingTop=o?"40px":"0",document.body.classList.add("no-header")),localStorage.setItem("crmplus_headerBarVisible",t.toString()),!0}else if(t)return console.log("[CRM Extension] Header not found but should be visible, creating it"),Ee(),!0;return!1}catch(e){return console.error("[CRM Extension] Error toggling header visibility:",e),!1}}function Ze(){if(!(localStorage.getItem("crmplus_autoCopyPhone")==="true")){console.log("[CRM Extension] Auto-copy phone is disabled");return}let e=()=>{let n=ie();if(n){let r=be(n);r&&V(r).then(i=>{if(i)return p("Phone number auto-copied: "+r),!0})}return!1};if(e())return;let o=new MutationObserver((n,r)=>{e()&&r.disconnect()});o.observe(document.body,{childList:!0,subtree:!0,attributes:!0,characterData:!0}),setTimeout(()=>{o.disconnect(),e()},5e3)}var et=!1,_=new Set,me="",Se=!1,ue=null,ke=null;function ot(){et||(yt(),wt(),et=!0,console.log("[CRM Extension] Alert system initialized"))}function yt(){if(document.getElementById("crm-alert-styles"))return;let t=document.createElement("style");t.id="crm-alert-styles",t.textContent=`
    .crm-alert-banner {
      position: fixed;
      top: 32px; /* Positioned right below the header bar */
      left: 0;
      right: 0;
      width: 100%;
      padding: 4px 15px; /* Reduced vertical padding for smaller height */
      font-size: 13px;
      font-weight: 500;
      z-index: 999990;
      display: flex;
      align-items: center;
      justify-content: center; /* Center contents horizontally */
      transition: all 0.3s ease;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
      transform: translateY(-100%);
      opacity: 0;
      height: 25px; /* Fixed height at 3/4 of original (approx) */
    }
    
    .crm-alert-banner.show {
      transform: translateY(0);
      opacity: 1;
    }
    
    .crm-alert-banner .alert-icon {
      margin-right: 8px;
      font-size: 16px;
    }
    
    .crm-alert-banner .alert-message {
      text-align: center; /* Center the text */
      margin: 0 auto; /* Center with auto margins */
      flex-grow: 0; /* Don't grow to fill space */
    }
    
    /* Provider Paid specific alert styling */
    .crm-alert-banner.provider-paid {
      background-color: #FFAB40; /* Orange */
      color: #5F4200;
      border-bottom: 1px solid #FF9100;
    }
    
    /* Adjust body padding to accommodate the alert banner */
    body.has-alert {
      padding-top: 72px !important; /* 32px (header) + approx alert height */
    }
    
    /* When header is hidden but alert is visible */
    body.no-header.has-alert {
      padding-top: 25px !important; /* Just the alert height */
    }
    
    /* Multiple alerts stacking */
    .crm-alert-banner.second-alert {
      top: 57px;
    }
    
    .crm-alert-banner.third-alert {
      top: 82px;
    }
    
    /* Countdown timer styling */
    .countdown-timer {
      margin-left: 5px;
      font-size: 11px;
      opacity: 0.75;
      background-color: rgba(0, 0, 0, 0.1);
      padding: 1px 4px;
      border-radius: 3px;
      min-width: 30px;
      text-align: center;
    }
  `,document.head.appendChild(t)}function tt(){let t=window.location.href,e=[/\/patient\/(\d+)/i,/\/contact\/(\d+)/i,/\/profile\/(\d+)/i,/[?&]patient_id=(\d+)/i,/[?&]contact_id=(\d+)/i];for(let o of e){let n=t.match(o);if(n&&n[1])return n[1]}return""}function wt(){me=tt(),ge(),ue&&ue.disconnect(),ue=new MutationObserver(t=>{for(let e of t)e.type==="childList"&&ge(),e.type==="attributes"&&(e.target.classList.contains("tag")||e.target.classList.contains("tag-label")||e.target.classList.contains("provider-paid"))&&ge()}),ue.observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["class","data-tag"]}),ke&&clearInterval(ke),ke=setInterval(()=>{let t=tt();t!==me&&(console.log("[CRM Extension] Navigation detected, patient changed from",me,"to",t),me=t,Se=!1,fe("provider-paid"),setTimeout(ge,1e3))},1e3)}function ge(){if(!(localStorage.getItem("crmplus_showProviderPaidAlerts")!=="false")){fe("provider-paid");return}Ct()?Se||Et():fe("provider-paid")}function Ct(){let t=document.querySelectorAll(".tag, .tag-label, .pill, .badge");for(let r of t)if(r.textContent.toLowerCase().includes("provider-paid"))return r;let e=document.querySelectorAll(".provider-paid");if(e.length>0)return e[0];let o=document.querySelectorAll('[data-tag="provider-paid"], [data-tag-name="provider-paid"]');if(o.length>0)return o[0];let n=document.querySelectorAll(".tags-container, .tag-list, .tags");for(let r of n)if(r.textContent.toLowerCase().includes("provider-paid"))return r;return null}function Et(){if(_.has("provider-paid"))return;Se=!0;let t=document.createElement("div");t.className="crm-alert-banner provider-paid",t.id="provider-paid-alert",t.setAttribute("data-alert-type","provider-paid");let e=document.createElement("span");e.className="alert-icon",e.innerHTML="\u26A0\uFE0F",t.appendChild(e);let o=document.createElement("span");o.className="alert-message",o.textContent="This patient has Provider Paid status. Special billing rules apply.";let n=document.createElement("span");n.className="countdown-timer",n.textContent="30",o.appendChild(n),t.appendChild(o),document.body.appendChild(t),vt(t),setTimeout(()=>{t.classList.add("show"),document.body.classList.add("has-alert")},10),_.add("provider-paid");let r=document.getElementById("mcp-crm-header");r&&r.style.display==="none"?document.body.classList.add("no-header"):document.body.classList.remove("no-header"),console.log("[CRM Extension] Provider Paid alert shown");let i=15,a=setInterval(()=>{i--,n&&(n.textContent=i),i<=0&&(clearInterval(a),fe("provider-paid"))},1e3)}function vt(t){let e=_.size;e===1?t.classList.add("second-alert"):e===2&&t.classList.add("third-alert")}function fe(t){let e=document.querySelector(`.crm-alert-banner[data-alert-type="${t}"]`);e&&(e.classList.remove("show"),_.delete(t),setTimeout(()=>{e.parentNode&&e.parentNode.removeChild(e),_.size===0&&document.body.classList.remove("has-alert"),kt()},300))}function kt(){document.querySelectorAll(".crm-alert-banner").forEach((e,o)=>{e.classList.remove("second-alert","third-alert"),o===1?e.classList.add("second-alert"):o===2&&e.classList.add("third-alert")})}console.log("[CRM Extension] Content script injected.");var j=typeof browser<"u"?browser:chrome;j.runtime.sendMessage({action:"loadSettings"}).then(t=>{t&&t.success&&(console.log("[CRM Extension] Settings loaded from browser storage on startup:",t.settings),document.getElementById("mcp-crm-header")||B())}).catch(t=>{console.error("[CRM Extension] Error requesting settings on startup:",t)});localStorage.getItem("crmplus_headerBarVisible")===null?(console.log("[CRM Extension] No local toolbar visibility setting, requesting from browser storage"),j.runtime.sendMessage({action:"loadSettings"}).then(t=>{t&&t.success?(console.log("[CRM Extension] Settings loaded from browser storage:",t.settings),B()):(console.error("[CRM Extension] Failed to load settings, using defaults"),localStorage.setItem("crmplus_headerBarVisible","true"),B())}).catch(t=>{console.error("[CRM Extension] Error requesting settings:",t),localStorage.setItem("crmplus_headerBarVisible","true"),B()})):(console.log("[CRM Extension] Using existing localStorage settings"),B());function B(){let t=localStorage.getItem("crmplus_headerBarVisible")!=="false";console.log("[CRM Extension] Header visibility setting on init:",t);try{console.log("[CRM Extension] Creating fixed header..."),Ee(),ve(t)}catch(e){console.error("[CRM Extension] Error creating fixed header:",e)}try{Ae(e=>{console.log(`[CRM Extension] Intercepted console message: ${e}`)})}catch(e){console.error("[CRM Extension] Error initializing console monitor:",e)}try{Ze()}catch(e){console.error("[CRM Extension] Error initializing auto phone copy:",e)}try{ot()}catch(e){console.error("[CRM Extension] Error initializing alert system:",e)}try{Oe()}catch(e){console.error("[CRM Extension] Error initializing tag removal system:",e)}try{Ue()}catch(e){console.error("[CRM Extension] Error initializing automation removal system:",e)}A()}j.runtime.onMessage.addListener((t,e,o)=>{if(console.log("[CRM Extension] Received message:",t),t.action==="toggleHeaderVisibility"){console.log("[CRM Extension] Toggling header visibility to:",t.isVisible);try{let n=ve(t.isVisible);localStorage.setItem("crmplus_headerBarVisible",t.isVisible.toString()),j.runtime.sendMessage({action:"syncSettings"}).catch(r=>console.error("[CRM Extension] Error syncing settings:",r)),o({success:n})}catch(n){console.error("[CRM Extension] Error toggling header visibility:",n),o({success:!1,error:n.message})}return!0}return!1});document.addEventListener("DOMContentLoaded",()=>{console.log("[CRM Extension] DOM fully loaded, checking visibility setting"),document.getElementById("mcp-crm-header")||j.runtime.sendMessage({action:"loadSettings"}).then(t=>{t&&t.success&&B()}).catch(()=>{localStorage.setItem("crmplus_headerBarVisible","true"),B()})});})();
