// modules/ui/components/settingsGroup.js - Updated with improved dropdown positioning

import { showToast } from '../../phoneUtils.js';

/**
 * Creates the settings group with settings button and dropdown menu
 * 
 * @returns {HTMLElement} The settings group element
 */
export function createSettingsGroup() {
  const settingsGroup = document.createElement("div");
  settingsGroup.className = "group";
  settingsGroup.style.position = "relative"; // Make sure position is relative for dropdown positioning
  
  // Create "Settings" button
  const btnSettings = document.createElement("button");
  btnSettings.className = "btn";
  btnSettings.id = "crm-settings-btn";
  
  // Add settings icon
  const settingsIcon = document.createElement("span");
  settingsIcon.className = "btn-icon";
  settingsIcon.innerHTML = "⚙️";
  btnSettings.appendChild(settingsIcon);
  
  // Add button text
  const settingsText = document.createElement("span");
  settingsText.textContent = "Settings";
  btnSettings.appendChild(settingsText);
  
  // Create settings dropdown
  const settingsDropdown = createSettingsDropdown();
  
  // Toggle settings dropdown when settings button is clicked
  btnSettings.addEventListener("click", (e) => {
    e.stopPropagation();
    settingsDropdown.classList.toggle("show");
  });
  
  // Close settings dropdown when clicking elsewhere
  document.addEventListener("click", (e) => {
    if (e.target !== btnSettings && !btnSettings.contains(e.target) && 
        e.target !== settingsDropdown && !settingsDropdown.contains(e.target)) {
      settingsDropdown.classList.remove("show");
    }
  });
  
  // Add custom styles for settings dropdown
  if (!document.getElementById('settings-dropdown-styles')) {
    const style = document.createElement('style');
    style.id = 'settings-dropdown-styles';
    style.textContent = `
      #mcp-crm-settings-dropdown {
        display: none;
        position: absolute;
        top: calc(100% + 5px); /* Position below the button with 5px gap */
        right: 0;
        z-index: 1000;
        min-width: 230px;
        background-color: #fff;
        border-radius: 4px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
        overflow: hidden;
      }
      
      #mcp-crm-settings-dropdown.show {
        display: block;
      }
      
      .settings-header {
        padding: 10px;
        background-color: #f5f5f5;
        border-bottom: 1px solid #ddd;
        font-weight: bold;
        color: #333;
      }
      
      .settings-body {
        padding: 10px;
      }
      
      .setting-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
        font-size: 13px;
      }
      
      .setting-item:last-child {
        margin-bottom: 0;
      }
      
      /* Toggle switch styles */
      .switch {
        position: relative;
        display: inline-block;
        width: 40px;
        height: 20px;
      }
      
      .switch input {
        opacity: 0;
        width: 0;
        height: 0;
      }
      
      .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        transition: .4s;
        border-radius: 34px;
      }
      
      .slider:before {
        position: absolute;
        content: "";
        height: 16px;
        width: 16px;
        left: 2px;
        bottom: 2px;
        background-color: white;
        transition: .4s;
        border-radius: 50%;
      }
      
      input:checked + .slider {
        background-color: #2196F3;
      }
      
      input:focus + .slider {
        box-shadow: 0 0 1px #2196F3;
      }
      
      input:checked + .slider:before {
        transform: translateX(20px);
      }
    `;
    document.head.appendChild(style);
  }
  
  settingsGroup.appendChild(btnSettings);
  settingsGroup.appendChild(settingsDropdown);
  
  return settingsGroup;
}

/**
 * Creates the settings dropdown menu
 * 
 * @returns {HTMLElement} The settings dropdown element
 */
function createSettingsDropdown() {
  const settingsDropdown = document.createElement("div");
  settingsDropdown.id = "mcp-crm-settings-dropdown";
  
  // Create settings header
  const settingsHeader = document.createElement("div");
  settingsHeader.className = "settings-header";
  settingsHeader.textContent = "CRM+ Settings";
  settingsDropdown.appendChild(settingsHeader);
  
  // Create settings body
  const settingsBody = document.createElement("div");
  settingsBody.className = "settings-body";
  settingsDropdown.appendChild(settingsBody);
  
  // Add auto-copy setting
  settingsBody.appendChild(createSettingItem(
    "Auto-copy phone number on page load",
    "crmplus_autoCopyPhone",
    (enabled) => {
      showToast(`Auto-copy phone: ${enabled ? "Enabled" : "Disabled"}`);
    }
  ));
  
  // Add automation options setting
  settingsBody.appendChild(createSettingItem(
    "CRM Automation",
    "crmplus_automationEnabled",
    (enabled) => {
      // Update visibility of automation elements
      const automationElements = [
        document.getElementById("crm-automation-dropdown"),  // Automation dropdown
        document.getElementById("crm-tags-dropdown"),        // Tags dropdown
      ];
      
      // Set visibility for each automation element
      automationElements.forEach(element => {
        if (element) {
          // Fixed logic: enabled = visible, disabled = hidden
          element.style.display = enabled ? "flex" : "none";
          console.log(`[CRM Extension] Changed visibility for ${element.id}: ${enabled ? "visible" : "hidden"}`);
        } else {
          console.error(`[CRM Extension] Could not find automation element to toggle`);
        }
      });
      
      showToast(`CRM Automation: ${enabled ? "Enabled" : "Disabled"}`);
    }
  ));
  
  return settingsDropdown;
}

/**
 * Creates a setting item with toggle switch
 * 
 * @param {string} label - Setting label text
 * @param {string} storageKey - LocalStorage key for the setting
 * @param {Function} changeCallback - Function to call when setting changes
 * @returns {HTMLElement} The setting item element
 */
function createSettingItem(label, storageKey, changeCallback) {
  const settingItem = document.createElement("div");
  settingItem.className = "setting-item";
  
  // Create label element
  const labelElement = document.createElement("div");
  labelElement.className = "setting-label";
  labelElement.textContent = label;
  settingItem.appendChild(labelElement);
  
  // Create toggle switch
  const toggleSwitch = document.createElement("label");
  toggleSwitch.className = "switch";
  
  // Create toggle input
  const toggleInput = document.createElement("input");
  toggleInput.type = "checkbox";
  
  // Get the saved setting value (default to false/off)
  // Use only localStorage, avoid browser.storage API
  const isEnabled = localStorage.getItem(storageKey) === "true";
  toggleInput.checked = isEnabled;
  
  // When toggle changes, save setting and invoke callback
  toggleInput.addEventListener("change", () => {
    const newState = toggleInput.checked;
    // Save only to localStorage
    localStorage.setItem(storageKey, newState);
    
    if (changeCallback && typeof changeCallback === 'function') {
      changeCallback(newState);
    }
  });
  
  // Create slider element
  const slider = document.createElement("span");
  slider.className = "slider";
  
  // Assemble toggle switch
  toggleSwitch.appendChild(toggleInput);
  toggleSwitch.appendChild(slider);
  settingItem.appendChild(toggleSwitch);
  
  return settingItem;
}