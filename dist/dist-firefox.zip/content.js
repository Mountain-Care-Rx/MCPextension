(()=>{function Ie(e){if(window.__crmConsoleMonitor)return;window.__crmConsoleMonitor=!0;let t=console.log,o=console.error,i=console.warn;console.log=function(...n){t.apply(console,n),!(typeof n[0]=="string"&&n[0].includes("[CRM Extension]"))&&ye(n,"log",e)},console.error=function(...n){o.apply(console,n),!(typeof n[0]=="string"&&n[0].includes("[CRM Extension]"))&&ye(n,"error",e)},console.warn=function(...n){i.apply(console,n),!(typeof n[0]=="string"&&n[0].includes("[CRM Extension]"))&&ye(n,"warn",e)}}function ye(e,t,o){let i=e.join(" ");["error","failed","unauthorized","critical"].some(r=>i.toLowerCase().includes(r))&&o(i)}var Pe=window.location.href,U="";function le(){if(!Le())return"";let e=document.querySelector('input[name="contact.phone"]');if(e&&e.value.trim()!=="")return e.value.trim();let t=document.querySelector(".phone-number .number");if(t&&t.textContent.trim()!=="")return t.textContent.trim();let o=['input[placeholder="Phone"]','input[placeholder="Phone Number"]',".patient-info .phone",".contact-info .phone","span.phone",'label[for*="phone"]',".phone-display",'div[data-field="phone"]','span[data-field="phone_number"]'];for(let i of o){let n=document.querySelector(i);if(n)if(n.tagName==="INPUT"){let r=n.value.trim();if(r)return r}else if(n.tagName==="LABEL"){let r=n.getAttribute("for");if(r){let s=document.getElementById(r);if(s&&s.value.trim())return s.value.trim()}let a=n.parentElement?.querySelector("input");if(a&&a.value.trim())return a.value.trim()}else{let r=n.textContent.trim();if(r)return r}}return""}function Le(){let e=window.location.href;return[/\/patient\/\d+/i,/\/contact\/\d+/i,/\/profile\/\d+/i,/[?&]patient_id=\d+/i,/[?&]contact_id=\d+/i].some(i=>i.test(e))?!0:['input[name="contact.phone"]','input[name="contact.first_name"]','input[name="contact.last_name"]','input[name="contact.date_of_birth"]',".patient-info",".contact-details",".patient-header",".patient-profile"].some(i=>document.querySelector(i)!==null)}function ze(e){try{let t=e?xt(e):"";if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("phone",t);else{let o=document.getElementById("phone-text");if(o){o.textContent=t;let i=document.getElementById("phone-display");i&&(e?i.setAttribute("data-value",e):i.removeAttribute("data-value"))}}}catch(t){console.error("[CRM Extension] Error updating phone display:",t)}}function I(){U="",ze("");try{let e=document.getElementById("phone-display");e&&e.removeAttribute("data-value")}catch(e){console.error("[CRM Extension] Error clearing phone display:",e)}}function xt(e){if(!e)return"";let t=e.replace(/\D/g,"");if(t.length===0)return"";if(t.length===10)return`(${t.substring(0,3)}) ${t.substring(3,6)}-${t.substring(6)}`;if(t.length===11&&t.startsWith("1"))return`(${t.substring(1,4)}) ${t.substring(4,7)}-${t.substring(7)}`;if(t.length>4){let o="";for(let i=0;i<t.length;i+=3)if(i+4>=t.length&&t.length%3!==0){o+=" "+t.substring(i);break}else o+=" "+t.substring(i,i+3);return o.trim()}return t.replace(/(\d{3})/g,"$1 ").trim()}function ae(){try{if(!Le())return U&&I(),!1;let e=le();return e?(e!==U&&(U=e,ze(e)),!0):(U&&I(),!1)}catch(e){return console.error("[CRM Extension] Error detecting phone number:",e),!1}}function Be(){I(),ae();let e=setInterval(()=>{let t=window.location.href;t!==Pe&&(console.log("[CRM Extension] URL changed, resetting phone detection"),Pe=t,I()),ae()},200);try{let t=new MutationObserver(i=>{ae()}),o=document.body;t.observe(o,{childList:!0,subtree:!0,characterData:!0,attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] Phone number mutation observer active")}catch(t){console.error("[CRM Extension] Error setting up phone mutation observer:",t)}}function De(e){let t=le();if(!t){u("No phone number found");return}let o=Ce(t);if(!o){u("Invalid phone number format");return}e.setAttribute("data-value",t),j(o).then(i=>{u(i?"Copied: "+o:"Failed to copy phone number")})}function Ce(e){if(!e)return"";let t=e.replace(/\D/g,"");return t.length<7?"":"+1"+t}async function j(e){if(navigator.clipboard&&navigator.clipboard.writeText)try{return await navigator.clipboard.writeText(e),!0}catch(t){console.warn("Clipboard API failed, trying fallback method:",t)}try{let t=document.createElement("textarea");t.value=e,t.style.position="fixed",t.style.top="0",t.style.left="0",t.style.opacity="0",t.style.pointerEvents="none",document.body.appendChild(t),t.focus(),t.select();let o=document.execCommand("copy");return document.body.removeChild(t),o}catch(t){return console.error("All clipboard methods failed:",t),!1}}function u(e,t=2e3){let o=document.getElementById("crm-plus-toast-container");o||(o=document.createElement("div"),o.id="crm-plus-toast-container",o.style.position="fixed",o.style.bottom="20px",o.style.right="20px",o.style.zIndex="100000",document.body.appendChild(o));let i=document.createElement("div");i.textContent=e,i.style.background="#333",i.style.color="#fff",i.style.padding="10px",i.style.borderRadius="5px",i.style.marginTop="10px",i.style.boxShadow="0 2px 5px rgba(0,0,0,0.2)",i.style.transition="opacity 0.5s, transform 0.5s",i.style.opacity="0",i.style.transform="translateY(20px)",o.appendChild(i),i.offsetWidth,i.style.opacity="1",i.style.transform="translateY(0)",setTimeout(()=>{i.style.opacity="0",i.style.transform="translateY(20px)",setTimeout(()=>{i.parentNode&&i.parentNode.removeChild(i),o.childNodes.length===0&&document.body.removeChild(o)},500)},t)}var Ve=window.location.href;function G(e){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("name",e);else{let t=document.getElementById("name-text");if(t){t.textContent=e;let o=document.getElementById("name-display");o&&o.setAttribute("data-value",e)}}}catch(t){console.error("[CRM Extension] Error updating name display:",t)}}function se(){try{let e=document.querySelector('input[name="contact.first_name"]'),t=document.querySelector('input[name="contact.last_name"]');if(e&&e.value&&t&&t.value){let n=`${e.value} ${t.value}`;return G(n),!0}let o=document.querySelectorAll(".patient-name, .contact-name, h1.name, .customer-name");for(let n of o)if(n&&n.textContent&&n.textContent.trim()!==""){let r=n.textContent.trim();return G(r),!0}let i=["span.name",".profile-name","h2.name",".contact-header .name",'div[data-field="name"]',".patient-info .name"];for(let n of i){let r=document.querySelector(n);if(r&&r.textContent&&r.textContent.trim()!==""){let a=r.textContent.trim();return G(a),!0}}return!1}catch(e){return console.error("[CRM Extension] Error detecting name:",e),!1}}function $e(){se();let e=setInterval(()=>{let t=window.location.href;t!==Ve&&(console.log("[CRM Extension] URL changed, resetting name detection"),Ve=t,G(""),se());let o=document.getElementById("name-text");o&&(o.textContent==="Loading..."||!o.textContent)&&se()},1e3);try{let t=new MutationObserver(i=>{i.some(r=>r.addedNodes.length>5||r.removedNodes.length>5)&&(console.log("[CRM Extension] Significant DOM changes detected, rechecking name"),G(""),se())}),o=document.querySelector("main")||document.body;t.observe(o,{childList:!0,subtree:!0})}catch(t){console.error("[CRM Extension] Error setting up navigation observer for name:",t)}}var qe=window.location.href;function de(e){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("dob",e);else{let t=document.getElementById("dob-text");if(t){t.textContent=e;let o=document.getElementById("dob-display");o&&o.setAttribute("data-value",e)}}}catch(t){console.error("[CRM Extension] Error updating DOB display:",t)}}function Fe(e){if(!e)return"";if(e.match(/^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2}(st|nd|rd|th)?\s+\d{4}$/))try{let t=e.match(/(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+(\d{1,2})(st|nd|rd|th)?\s+(\d{4})/);if(t){let o=t[1],i=t[2],n=t[4];return`${(["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"].indexOf(o)+1).toString().padStart(2,"0")}/${i.toString().padStart(2,"0")}/${n}`}}catch(t){console.error("[CRM Extension] Error parsing date:",t)}try{let t=new Date(e);if(!isNaN(t.getTime()))return`${(t.getMonth()+1).toString().padStart(2,"0")}/${t.getDate().toString().padStart(2,"0")}/${t.getFullYear()}`}catch(t){console.error("[CRM Extension] Error parsing date as Date object:",t)}return e}function ce(){try{let e=document.querySelector('input[name="contact.date_of_birth"]');if(e&&e.value){let o=Fe(e.value);return de(o),!0}let t=[".dob",".patient-dob",".contact-dob",'span[data-field="date_of_birth"]','div[data-field="dob"]',".patient-info .dob",".contact-info .dob"];for(let o of t){let i=document.querySelector(o);if(i&&i.textContent&&i.textContent.trim()!==""){let n=Fe(i.textContent.trim());return de(n),!0}}return!1}catch(e){return console.error("[CRM Extension] Error detecting DOB:",e),!1}}function Oe(){ce();let e=setInterval(()=>{let t=window.location.href;t!==qe&&(console.log("[CRM Extension] URL changed, resetting DOB detection"),qe=t,de(""),ce());let o=document.getElementById("dob-text");o&&(o.textContent==="Loading..."||!o.textContent)&&ce()},1e3);try{let t=new MutationObserver(i=>{i.some(r=>r.addedNodes.length>5||r.removedNodes.length>5)&&(console.log("[CRM Extension] Significant DOM changes detected, rechecking DOB"),de(""),ce())}),o=document.querySelector("main")||document.body;t.observe(o,{childList:!0,subtree:!0})}catch(t){console.error("[CRM Extension] Error setting up navigation observer for DOB:",t)}}var _e=window.location.href,pe="";function He(e){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("srxid",e);else{let t=document.getElementById("srxid-text");if(t){t.textContent=e;let o=document.getElementById("srxid-display");o&&o.setAttribute("data-value",e)}}}catch(t){console.error("[CRM Extension] Error updating SRx ID display:",t)}}function Y(){try{let e=document.querySelector('input[name="contact.srx_id"]');if(e&&e.value){let t="^"+e.value.trim();if(t&&/^\d+$/.test(t))return t!==pe&&(console.log("[CRM Extension] Found SRx ID from contact.srx_id input:",t),pe=t,He(t)),!0}return!!pe}catch(e){return console.error("[CRM Extension] Error detecting SRx ID:",e),!1}}function We(){Y();let e=setInterval(()=>{let t=window.location.href;t!==_e&&(console.log("[CRM Extension] URL changed, resetting SRx ID detection"),_e=t,pe="",He(""),Y()),Y()},500);try{new MutationObserver(o=>{let i=!1;for(let n of o){if(n.target.tagName==="INPUT"&&n.target.name==="contact.srx_id"||n.target.querySelector&&n.target.querySelector('input[name="contact.srx_id"]')){i=!0;break}if(n.addedNodes.length>0){for(let r of n.addedNodes)if(r.nodeType===1&&r.querySelector&&(r.tagName==="INPUT"&&r.name==="contact.srx_id"||r.querySelector('input[name="contact.srx_id"]'))){i=!0;break}}}i&&Y()}).observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] SRx ID mutation observer active")}catch(t){console.error("[CRM Extension] Error setting up observer for SRx ID:",t)}setTimeout(()=>{try{let t=document.querySelector('input[name="contact.srx_id"]');t&&(new MutationObserver(i=>{Y()}).observe(t,{attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] Direct input observer attached to contact.srx_id"))}catch(t){console.error("[CRM Extension] Error setting up direct input observer:",t)}},1e3)}var me=["np-tirz-1.5ml-inj","refill-sema-inj","refill-tirz-inj","vial-sema-b12","vial-sema-b6","vial-sema-lipo","vial-sema-nad+","vial-tirz-cyano","vial-tirz-nad+","vial-tirz-pyridoxine","np-sema-0.125ml-inj","np-sema-0.25ml-inj","np-sema-0.5ml-inj","np-sema-0.75ml-inj","np-sema-1.0ml-inj","np-sema-1.25ml-inj","np-sema-1.5ml-inj","np-sema-2.0ml-inj","np-tirz-0.25ml-inj","np-tirz-0.5ml-inj","np-tirz-0.75ml-inj","np-tirz-1.0ml-inj","np-tirz-1.25ml-inj"],A=[];function Ue(){console.log("[CRM Extension] Tag removal system initialized")}function yt(){A=[];try{let e=document.querySelectorAll(".tag, .tag-label, .pill, .badge");for(let n of e){let r=n.textContent.trim().toLowerCase();me.some(a=>r.includes(a))&&A.push({element:n,text:r})}let t=document.querySelectorAll("[data-tag]");for(let n of t){let r=n.getAttribute("data-tag").toLowerCase();me.some(a=>r.includes(a))&&A.push({element:n,text:r})}let o=document.querySelectorAll(".tags-container, .tag-list, .tags");for(let n of o){let r=n.querySelectorAll("*");for(let a of r)if(a.nodeType===1){let s=a.textContent.trim().toLowerCase();me.some(l=>s.includes(l))&&(A.some(l=>l.element===a)||A.push({element:a,text:s}))}}let i=document.querySelectorAll("*[class]");for(let n of i){let r=n.className.toLowerCase();r&&typeof r=="string"&&me.some(a=>r.includes(a))&&(A.some(a=>a.element===n)||A.push({element:n,text:n.textContent.trim().toLowerCase()}))}return console.log(`[CRM Extension] Found ${A.length} removable tags`),A}catch(e){return console.error("[CRM Extension] Error detecting tags:",e),[]}}function Ct(e){try{let t=e.querySelector('.close, .remove, .delete, .tag-remove, [aria-label="Remove"], .x-button');if(t)return console.log("[CRM Extension] Found close button in tag, clicking it"),t.click(),!0;let o=e.parentElement;if(o){let r=o.querySelector('.close, .remove, .delete, .tag-remove, [aria-label="Remove"], .x-button');if(r)return console.log("[CRM Extension] Found close button as sibling, clicking it"),r.click(),!0}let i=[...Array.from(e.querySelectorAll("*")),...Array.from(o?o.children:[])];for(let r of i){let a=r.textContent.trim();if(a==="\xD7"||a==="x"||a==="\u2715"||a==="\u2716"||a==="X")return console.log("[CRM Extension] Found X button by text content, clicking it"),r.click(),!0;if(r.className&&(r.className.includes("close")||r.className.includes("delete")||r.className.includes("remove")||r.className.includes("x-button")))return console.log("[CRM Extension] Found X button by class name, clicking it"),r.click(),!0;if(r.classList&&(r.classList.contains("fa-times")||r.classList.contains("fa-close")||r.classList.contains("icon-close")||r.classList.contains("icon-remove")))return console.log("[CRM Extension] Found X button by icon class, clicking it"),r.click(),!0}if(e.tagName==="BUTTON"||e.tagName==="A"||e.getAttribute("role")==="button"||window.getComputedStyle(e).cursor==="pointer")return console.log("[CRM Extension] Tag appears to be clickable, clicking it"),e.click(),!0;let n=o;for(let r=0;r<3&&n;r++){let a=n.querySelectorAll("button, span, i, div");for(let s of a){let l=s.textContent.trim();if(l==="\xD7"||l==="x"||l==="\u2715"||l==="\u2716"||l==="X"||s.classList.contains("fa-times")||s.classList.contains("fa-close")||s.classList.contains("close")||s.classList.contains("remove"))return console.log("[CRM Extension] Found X button in parent container, clicking it"),s.click(),!0}n=n.parentElement}return console.log("[CRM Extension] No method found to remove tag:",e),!1}catch(t){return console.error("[CRM Extension] Error removing tag:",t),!1}}function we(){return new Promise((e,t)=>{try{let n=function(r){if(r>=A.length){console.log(`[CRM Extension] Removed ${o}/${i} tags`),e({success:!0,message:`Removed ${o} of ${i} tags`,removed:o,total:i});return}let a=A[r];console.log(`[CRM Extension] Removing tag: ${a.text}`),Ct(a.element)&&o++,setTimeout(()=>{n(r+1)},300)};yt();let o=0,i=A.length;if(i===0){console.log("[CRM Extension] No removable tags found"),e({success:!0,message:"No tags to remove",removed:0,total:0});return}console.log(`[CRM Extension] Attempting to remove ${i} tags`),n(0)}catch(o){console.error("[CRM Extension] Error in removeAllTags:",o),t(o)}})}var wt=["Workflow - New Patient - Semaglutide 0.125ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 0.25ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 0.5ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 0.75ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 1.0ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 1.25ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 1.5ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 2.0ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 0.25ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 0.5ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 0.75ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 1.0ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 1.25ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 1.5ml Onboarding - (Step 1)","Workflow - Refill - Semaglutide/B12 Injection Refill Order - (Step 1)","Workflow - Semaglutide/B12 Vial Order - (Step 1)","Workflow - Semaglutide/B6 Vial Order - (Step 1)","Workflow - Semaglutide/Lipo Vial Order - (Step 1)","Workflow - Semaglutide/NAD+ Vial Order - (Step 1)","Workflow - Syringe - Tirzepatide/Pyridoxine Injection Order - (Step 1)","Workflow - Tirzepatide/Cyano Vial Order - (Step 1)","Workflow - Tirzepatide/NAD+ Vial Order - (Step 1)","Workflow - Tirzepatide/Pyridoxine Vial Order - (Step 1)"],ue=[];function P(e){try{if(e&&typeof e.getBoundingClientRect=="function")return e.getBoundingClientRect()}catch{}return{top:0,bottom:0,left:0,right:0,width:0,height:0}}function Ye(){console.log("[CRM Extension] Automation removal system initialized")}function vt(){ue=[];try{let e=Je("Active");return e?(ue=(e.workflows.length?e.workflows:Et(e.label)).filter(o=>{if(!o)return!1;let i=(o.textContent||"").trim();return i.includes("Workflow")&&wt.some(n=>i.includes(n))}),console.log(`[CRM Extension] Found ${ue.length} automation(s) in Active section.`),ue):(console.log("[CRM Extension] Active section not found."),[])}catch(e){return console.error("[CRM Extension] Error detecting automations:",e),[]}}function Et(e){let t=P(e).bottom,o=null,i=Je("Past");return i&&i.label&&(o=P(i.label).top),Array.from(document.querySelectorAll('div[id^="workflow_"], div[data-workflow-id]')).filter(r=>{let a=P(r);return!(a.top<t||o&&a.top>=o)})}function Je(e){try{let o=Array.from(document.querySelectorAll("div.py-2")).find(r=>(r.textContent||"").trim()===e);if(o)return{label:o,workflows:e==="Active"?St(o):kt(o)};let i=e==="Active"?'[data-automation="Active"], #automation-active':'[data-automation="Past"], #automation-past',n=document.querySelector(i);return n?{label:n,workflows:[]}:null}catch(t){return console.error(`[CRM Extension] Error finding section for "${e}":`,t),null}}function St(e){let t=P(e).bottom,i=Array.from(document.querySelectorAll("div.py-2")).find(a=>(a.textContent||"").trim()==="Past"),n=i?P(i).top:null;return Array.from(document.querySelectorAll('div[id^="workflow_"], div[data-workflow-id]')).filter(a=>{let s=P(a);return s.top>t&&(!n||s.top<n)})}function kt(e){let t=P(e).bottom;return Array.from(document.querySelectorAll('div[id^="workflow_"], div[data-workflow-id]')).filter(i=>P(i).top>t)}function Rt(e){if(!e)return console.error("[CRM Extension] removeAutomation called with undefined element."),!1;try{let t=P(e),o=t.width>0&&t.height>0,i=t.top>=0&&t.left>=0&&t.bottom<=(window.innerHeight||document.documentElement.clientHeight);return!o||!i?(e.scrollIntoView({behavior:"smooth",block:"center"}),new Promise(n=>{setTimeout(()=>n(je(e)),500)})):je(e)}catch(t){return console.error("[CRM Extension] Error removing automation:",t),!1}}function je(e){if(!e)return!1;try{let t=e.querySelectorAll("i.icon-close, i.icon.icon-close");if(t.length)return t[0].click(),!0}catch(t){console.error("[CRM Extension] Error in Strategy 1:",t)}try{let t=e.querySelectorAll("a");for(let o of t){let i=(o.textContent||"").trim();if(i==="\xD7"||i.toLowerCase()==="x")return o.click(),!0}}catch(t){console.error("[CRM Extension] Error in Strategy 2:",t)}try{let t=e.querySelectorAll('button, .btn, [role="button"]');for(let o of t)if((o.textContent||"").toLowerCase().includes("manage"))return o.click(),setTimeout(()=>{document.querySelectorAll(".dropdown-menu .dropdown-item, .menu-item").forEach(r=>{let a=(r.textContent||"").toLowerCase();(a.includes("remove")||a.includes("delete"))&&r.click()})},300),!0}catch(t){console.error("[CRM Extension] Error in Strategy 3:",t)}if(e.id&&e.id.startsWith("workflow_")){let t=e.id;try{let o=`#${t} i.icon-close, #${t} i.icon.icon-close`,i=document.querySelector(o);if(i)return i.click(),!0;o=`#${t} .remove, #${t} .close`;let n=document.querySelector(o);if(n)return n.click(),!0}catch(o){console.error("[CRM Extension] Error in Strategy 4:",o)}}try{let t=e.querySelectorAll("span");for(let o of t){let i=(o.textContent||"").trim();if(i==="\xD7"||i.toLowerCase()==="x")return o.click(),!0}}catch(t){console.error("[CRM Extension] Error in Strategy 5:",t)}try{let t=e.nextElementSibling,o=0;for(;t&&o<3;){if(t.classList&&(t.classList.contains("close")||t.classList.contains("remove"))||t.textContent&&(t.textContent.trim()==="\xD7"||t.textContent.trim().toLowerCase()==="x"))return t.click(),!0;let i=t.querySelector("i.icon-close, i.icon.icon-close");if(i)return i.click(),!0;t=t.nextElementSibling,o++}}catch(t){console.error("[CRM Extension] Error in Strategy 6:",t)}try{let t=P(e),o=t.right-10,i=t.top+t.height/2,n=document.elementsFromPoint(o,i);for(let a of n)if(a!==e)return a.click(),!0;let r=new MouseEvent("click",{view:window,bubbles:!0,cancelable:!0,clientX:o,clientY:i});return(n[0]||document.elementFromPoint(o,i))?.dispatchEvent(r),!0}catch(t){console.error("[CRM Extension] Error in Strategy 7:",t)}return console.error("[CRM Extension] No method found to remove automation:",e),!1}function Ge(){return new Promise(e=>{setTimeout(()=>{if(document.querySelectorAll('.modal, [role="dialog"], .dialog').length){let o=document.querySelectorAll('.modal .btn-primary, .modal .btn-danger, .modal .confirm-btn, [role="dialog"] .btn-primary, .modal button, [role="dialog"] button');for(let n of o){let r=(n.textContent||"").trim().toLowerCase();if(["delete","remove","yes","confirm","ok","continue"].includes(r)){n.click(),e(!0);return}}let i=document.querySelectorAll('.modal button, [role="dialog"] button, .dialog button');if(i.length){i[i.length-1].click(),e(!0);return}}e(!1)},500)})}function ve(){return new Promise((e,t)=>{try{let r=function(a){if(a>=n){e({success:!0,message:`Removed ${i} of ${n} automations`,removed:i,total:n});return}let s=o[a],l=Rt(s.element);l instanceof Promise?l.then(c=>{c&&i++,Ge().then(()=>setTimeout(()=>r(a+1),1e3))}):(l&&i++,Ge().then(()=>setTimeout(()=>r(a+1),1e3)))},o=vt();if(!o.length){console.log("[CRM Extension] No automations to remove."),e({success:!0,message:"No automations to remove",removed:0,total:0});return}let i=0,n=o.length;r(0)}catch(o){console.error("[CRM Extension] Error in removeAllAutomations:",o),t(o)}})}var v=[];var ge="crmplus_history";function Qe(){et(),At(),Mt(),window.addEventListener("storage",Nt),console.log("[CRM Extension] History tracking initialized")}function et(){try{let e=localStorage.getItem(ge);if(e){v=JSON.parse(e);let t=Date.now();v=v.filter(o=>t-o.timestamp<144e5),Ee()}}catch(e){console.error("[CRM Extension] Error loading history:",e),v=[]}}function Ee(){try{localStorage.setItem(ge,JSON.stringify(v))}catch(e){console.error("[CRM Extension] Error saving history:",e)}}function Nt(e){if(e.key===ge)try{e.newValue?(v=JSON.parse(e.newValue),console.log("[CRM Extension] History updated from another tab")):(v=[],console.log("[CRM Extension] History cleared from another tab"))}catch(t){console.error("[CRM Extension] Error processing cross-tab history update:",t)}}function At(){let e=window.location.href;setInterval(()=>{let i=window.location.href;i!==e&&(e=i,J(i))},500),J(window.location.href);let t=history.pushState;history.pushState=function(){t.apply(this,arguments),J(window.location.href)};let o=history.replaceState;history.replaceState=function(){o.apply(this,arguments),J(window.location.href)},window.addEventListener("popstate",()=>{J(window.location.href)})}function J(e){if(!e)return;let t=e.match(/\/detail\/([^/]+)/);if(t&&t[1]){let o=t[1];setTimeout(()=>{let i=Xe(),n=Ke();i&&i!=="Unknown Patient"?Ze(o,i,n,e):(console.log("[CRM Extension] Patient name not found yet, retrying in 3 seconds..."),setTimeout(()=>{let r=Xe(),a=Ke();r&&r!=="Unknown Patient"?Ze(o,r,a,e):console.log("[CRM Extension] Could not retrieve patient info after retry, not adding to history")},3e3))},5e3)}}function Xe(){let e=document.getElementById("name-text");if(e&&e.textContent&&e.textContent.trim()!=="")return e.textContent.trim();let t=document.querySelector('input[name="contact.first_name"]'),o=document.querySelector('input[name="contact.last_name"]');if(t&&t.value&&o&&o.value)return`${t.value} ${o.value}`.trim();let i=[".patient-name",".contact-name","h1.name",".customer-name","span.name",".profile-name","h2.name",".contact-header .name",'div[data-field="name"]',".patient-info .name"];for(let n of i){let r=document.querySelector(n);if(r&&r.textContent&&r.textContent.trim()!=="")return r.textContent.trim()}return"Unknown Patient"}function Ke(){let e=document.getElementById("phone-text");if(e&&e.textContent&&e.textContent.trim()!=="")return e.textContent.trim();let t=document.querySelector('input[name="contact.phone"]');if(t&&t.value.trim()!=="")return t.value.trim();let o=[".phone-number .number",'input[placeholder="Phone"]','input[placeholder="Phone Number"]',".patient-info .phone",".contact-info .phone","span.phone",'div[data-field="phone"]','span[data-field="phone_number"]'];for(let i of o){let n=document.querySelector(i);if(n)if(n.tagName==="INPUT"){let r=n.value.trim();if(r)return r}else{let r=n.textContent.trim();if(r)return r}}return""}function Ze(e,t,o,i){let r=Date.now(),a=v.findIndex(s=>s.patientId===e);if(a!==-1){let s=v[a];s.timestamp=r,s.patientName=t,s.phoneNumber=o,v.splice(a,1),v.unshift(s)}else v.unshift({patientId:e,patientName:t,phoneNumber:o,url:i,timestamp:r}),v.length>20&&v.pop();Ee()}function Mt(){setInterval(()=>{let e=Date.now(),t=0;v=v.filter(o=>{let i=e-o.timestamp<144e5;return i||t++,i}),t>0&&(console.log(`[CRM Extension] Removed ${t} expired history entries`),Ee())},5*60*1e3)}function tt(){et();let e=Date.now();return v=v.filter(t=>e-t.timestamp<144e5),[...v]}function ot(){v=[],localStorage.removeItem(ge),console.log("[CRM Extension] History cleared")}function nt(e){return new Date(e).toLocaleString("en-US",{hour:"numeric",minute:"2-digit",hour12:!0})}function X(e,t,o={}){let i=document.createElement("div");i.className="group";let n=document.createElement("span");n.className="label",n.textContent=`${t}:`,i.appendChild(n);let r=document.createElement("span");if(r.id=`${e}-display`,r.className="clickable-value",o.initialValue&&r.setAttribute("data-value",o.initialValue),o.icon){let l=document.createElement("span");l.className="btn-icon",l.innerHTML=o.icon,r.appendChild(l)}let a=document.createElement("span");a.textContent=o.initialValue||"",a.id=`${e}-text`,r.appendChild(a);let s=async()=>{let l=r.getAttribute("data-value")||a.textContent.trim();l&&l!==""?await j(l)?u(`Copied ${t}: ${l}`):u(`Failed to copy ${t.toLowerCase()}`):u(`No ${t.toLowerCase()} available to copy`)};return r.addEventListener("click",()=>{o.onClick?o.onClick(r):s()}),r.title=`Click to copy ${t.toLowerCase()} to clipboard`,i.appendChild(r),i}function it(){let e=document.createElement("div");return e.className="group",e.id="crm-actions-group",e}function rt(){let e=document.createElement("div");e.className="dropdown",e.id="crm-tags-dropdown";let t=document.createElement("button");t.className="dropdown-btn",t.textContent="Tags",t.addEventListener("click",m=>{m.stopPropagation(),document.querySelectorAll(".dropdown.show").forEach(Te=>{Te!==e&&Te.classList.remove("show")}),e.classList.toggle("show")});let o=document.createElement("div");if(o.className="dropdown-content",o.style.padding="10px",!document.getElementById("tags-dropdown-styles")){let m=document.createElement("style");m.id="tags-dropdown-styles",m.textContent=`
      .nested-dropdown {
        margin-bottom: 8px;
        width: 100%;
        position: relative;
      }
      .nested-dropdown-btn {
        width: 100%;
        text-align: left;
        padding: 8px 12px;
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 3px;
        cursor: pointer;
        font-weight: bold;
        font-size: 13px;
        color: #e6e6e6;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .nested-dropdown-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      .nested-dropdown-btn:after {
        content: "\u25BC";
        font-size: 8px;
        color: #e6e6e6;
      }
      .nested-dropdown-content {
        display: none;
        padding: 5px 0 5px 10px;
        margin-top: 3px !important;
      }
      .nested-dropdown.open .nested-dropdown-content {
        display: block;
      }
      
      /* Button-style tag options */
      .tag-btn {
        display: block;
        width: 100%;
        padding: 8px 12px;
        margin-bottom: 8px;
        background-color: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 4px;
        text-align: left;
        font-size: 13px;
        color: #e6e6e6;
        cursor: pointer;
        transition: all 0.2s ease;
        font-weight: normal;
      }
      .tag-btn:hover {
        background-color: rgba(255, 255, 255, 0.15);
        border-color: rgba(255, 255, 255, 0.2);
      }
      .tag-btn:active {
        background-color: rgba(255, 255, 255, 0.2);
      }
    `,document.head.appendChild(m)}let i=document.createElement("button");i.className="tag-btn",i.textContent="Opt-in",i.addEventListener("click",()=>{at("opt-in"),e.classList.remove("show")}),o.appendChild(i);let n=document.createElement("button");n.className="tag-btn",n.textContent="Refill-Sema-Inj",n.addEventListener("click",()=>{x("refill-sema-inj"),e.classList.remove("show")}),o.appendChild(n);let r=document.createElement("button");r.className="tag-btn",r.textContent="Refill-Tirz-Inj",r.addEventListener("click",()=>{x("refill-tirz-inj"),e.classList.remove("show")}),o.appendChild(r);let a=document.createElement("div");a.className="nested-dropdown";let s=document.createElement("button");s.className="nested-dropdown-btn",s.textContent="Vial-Semaglutide";let l=document.createElement("div");l.className="nested-dropdown-content",s.addEventListener("click",m=>{m.stopPropagation(),a.classList.toggle("open")});let c=document.createElement("button");c.className="tag-btn",c.textContent="Vial-Sema-B12",c.addEventListener("click",m=>{m.stopPropagation(),C(),x("vial-sema-b12")}),l.appendChild(c);let d=document.createElement("button");d.className="tag-btn",d.textContent="Vial-Sema-B6",d.addEventListener("click",m=>{m.stopPropagation(),C(),x("vial-sema-b6")}),l.appendChild(d);let p=document.createElement("button");p.className="tag-btn",p.textContent="Vial-Sema-Lipo",p.addEventListener("click",m=>{m.stopPropagation(),C(),x("vial-sema-lipo")}),l.appendChild(p);let h=document.createElement("button");h.className="tag-btn",h.textContent="Vial-Sema-NAD+",h.addEventListener("click",m=>{m.stopPropagation(),C(),x("vial-sema-nad+")}),l.appendChild(h),a.appendChild(s),a.appendChild(l),o.appendChild(a);let g=document.createElement("div");g.className="nested-dropdown";let S=document.createElement("button");S.className="nested-dropdown-btn",S.textContent="Vial-Tirzepatide";let k=document.createElement("div");k.className="nested-dropdown-content",S.addEventListener("click",m=>{m.stopPropagation(),g.classList.toggle("open")});let R=document.createElement("button");R.className="tag-btn",R.textContent="Vial-Tirz-Cyano",R.addEventListener("click",m=>{m.stopPropagation(),C(),x("vial-tirz-cyano")}),k.appendChild(R);let N=document.createElement("button");N.className="tag-btn",N.textContent="Vial-Tirz-NAD+",N.addEventListener("click",m=>{m.stopPropagation(),C(),x("vial-tirz-nad+")}),k.appendChild(N);let f=document.createElement("button");f.className="tag-btn",f.textContent="Vial-Tirz-Pyr",f.addEventListener("click",m=>{m.stopPropagation(),C(),x("vial-tirz-pyridoxine")}),k.appendChild(f),g.appendChild(S),g.appendChild(k),o.appendChild(g);let b=document.createElement("div");b.className="nested-dropdown";let E=document.createElement("button");E.className="nested-dropdown-btn",E.textContent="NP-Semaglutide";let y=document.createElement("div");y.className="nested-dropdown-content",E.addEventListener("click",m=>{m.stopPropagation(),b.classList.toggle("open")});let L=document.createElement("button");L.className="tag-btn",L.textContent="NP-Sema 0.125",L.addEventListener("click",m=>{m.stopPropagation(),C(),x("np-sema-0.125ml-inj")}),y.appendChild(L);let F=document.createElement("button");F.className="tag-btn",F.textContent="NP-Sema 0.25",F.addEventListener("click",m=>{m.stopPropagation(),C(),x("np-sema-0.25ml-inj")}),y.appendChild(F);let $=document.createElement("button");$.className="tag-btn",$.textContent="NP-Sema 0.5",$.addEventListener("click",m=>{m.stopPropagation(),C(),x("np-sema-0.5ml-inj")}),y.appendChild($);let H=document.createElement("button");H.className="tag-btn",H.textContent="NP-Sema 0.75",H.addEventListener("click",m=>{m.stopPropagation(),C(),x("np-sema-0.75ml-inj")}),y.appendChild(H);let W=document.createElement("button");W.className="tag-btn",W.textContent="NP-Sema 1.0",W.addEventListener("click",m=>{m.stopPropagation(),C(),x("np-sema-1.0ml-inj")}),y.appendChild(W);let T=document.createElement("button");T.className="tag-btn",T.textContent="NP-Sema 1.25",T.addEventListener("click",m=>{m.stopPropagation(),C(),x("np-sema-1.25ml-inj")}),y.appendChild(T);let w=document.createElement("button");w.className="tag-btn",w.textContent="NP-Sema 1.5",w.addEventListener("click",m=>{m.stopPropagation(),C(),x("np-sema-1.5ml-inj")}),y.appendChild(w);let M=document.createElement("button");M.className="tag-btn",M.textContent="NP-Sema 2.0",M.addEventListener("click",m=>{m.stopPropagation(),C(),x("np-sema-2.0ml-inj")}),y.appendChild(M),b.appendChild(E),b.appendChild(y),o.appendChild(b);let z=document.createElement("div");z.className="nested-dropdown";let Q=document.createElement("button");Q.className="nested-dropdown-btn",Q.textContent="NP-Tirzepatide";let q=document.createElement("div");q.className="nested-dropdown-content",Q.addEventListener("click",m=>{m.stopPropagation(),z.classList.toggle("open")});let ee=document.createElement("button");ee.className="tag-btn",ee.textContent="NP-Tirz 0.25",ee.addEventListener("click",m=>{m.stopPropagation(),C(),x("np-tirz-0.25ml-inj")}),q.appendChild(ee);let te=document.createElement("button");te.className="tag-btn",te.textContent="NP-Tirz 0.5",te.addEventListener("click",m=>{m.stopPropagation(),C(),x("np-tirz-0.5ml-inj")}),q.appendChild(te);let oe=document.createElement("button");oe.className="tag-btn",oe.textContent="NP-Tirz 0.75",oe.addEventListener("click",m=>{m.stopPropagation(),C(),x("np-tirz-0.75ml-inj")}),q.appendChild(oe);let ne=document.createElement("button");ne.className="tag-btn",ne.textContent="NP-Tirz 1.0",ne.addEventListener("click",m=>{m.stopPropagation(),C(),x("np-tirz-1.0ml-inj")}),q.appendChild(ne);let ie=document.createElement("button");ie.className="tag-btn",ie.textContent="NP-Tirz 1.25",ie.addEventListener("click",m=>{m.stopPropagation(),C(),x("np-tirz-1.25ml-inj")}),q.appendChild(ie);let re=document.createElement("button");return re.className="tag-btn",re.textContent="NP-Tirz 1.5",re.addEventListener("click",m=>{m.stopPropagation(),C(),x("np-tirz-1.5ml-inj")}),q.appendChild(re),z.appendChild(Q),z.appendChild(q),o.appendChild(z),e.appendChild(t),e.appendChild(o),e}function C(){document.querySelectorAll(".dropdown.show").forEach(e=>e.classList.remove("show")),document.querySelectorAll(".nested-dropdown.open").forEach(e=>e.classList.remove("open"))}async function x(e){try{let[t,o]=await Promise.all([we(),ve()]);console.log("[CRM Extension] Cleanup completed:"),console.log(`- Tags: ${t.removed}/${t.total} removed`),console.log(`- Automations: ${o.removed}/${o.total} removed`),at(e)}catch(t){console.error("[CRM Extension] Error during cleanup:",t),u("Error during cleanup. Please try again.")}}function at(e){let t=Tt();t?(t.focus(),setTimeout(()=>{t.value=e,t.dispatchEvent(new Event("input",{bubbles:!0})),setTimeout(()=>{let o=document.querySelectorAll(".v-list-item, .dropdown-item, .select-option, li"),i=!1;for(let n of o)if(n.textContent.toLowerCase().includes(e)){n.click(),i=!0,u(`Selected tag: ${e}`);break}if(!i){let n=document.querySelectorAll("*");for(let r of n)if(r.textContent.trim().toLowerCase()===e){r.click(),i=!0,u(`Selected tag: ${e}`);break}i||t.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",code:"Enter",keyCode:13,which:13,bubbles:!0}))}},300)},300)):u("Tags field not found")}function Tt(){let e=document.querySelector('input[placeholder="Add Tags"]');if(e)return e;let t=Array.from(document.querySelectorAll("input[placeholder]")).filter(r=>r.placeholder.toLowerCase().includes("tag"));if(t.length>0)return t[0];let o=document.querySelectorAll(".tag-input, .tags-input, .tag-container");for(let r of o){let a=r.querySelector("input");if(a)return a}if(e=document.querySelector('input[placeholder="smartList.bulkTags.addTags"]'),e)return e;let i=document.querySelectorAll(".hl-text-input");if(i.length>0)return i[0];console.error("[CRM Extension] Could not find tag input field with any strategy");let n=document.querySelectorAll("input");return console.log("[CRM Extension] All inputs on page:",n),null}var B={"Sema/B12 Refill - Step 2":"Refill - Semaglutide/B12 Injection Refill Order - (Step 2)","Sema/B12 Vial - Step 2":"Semaglutide/B12 Vial Order - (Step 2)","Sema/B6 Vial - Step 2":"Semaglutide/B6 Vial Order - (Step 2)","Sema/Lipo Vial - Step 2":"Semaglutide/Lipo Vial Order - (Step 2)","Sema/NAD+ Vial - Step 2":"Semaglutide/NAD+ Vial Order - (Step 2)","Tirz/B6 Refill - Step 2":"Syringe - Tirzepatide/Pyridoxine Injection Order - (Step 2)","Tirz/B12 Vial - Step 2":"Tirzepatide/Cyano Vial Order - (Step 2)","Tirz/NAD+ Vial - Step 2":"Tirzepatide/NAD+ Vial Order - (Step 2)","Tirz/B6 Vial - Step 2":"Tirzepatide/Pyridoxine Vial Order - (Step 2)"};function lt(){let e=document.createElement("div");e.className="dropdown",e.id="crm-automation-dropdown";let t=document.createElement("button");t.className="dropdown-btn",t.textContent="Automation",t.addEventListener("click",f=>{f.stopPropagation(),document.querySelectorAll(".dropdown.show").forEach(b=>{b!==e&&b.classList.remove("show")}),e.classList.toggle("show")});let o=document.createElement("div");if(o.className="dropdown-content",o.style.padding="10px",!document.getElementById("automation-dropdown-styles")){let f=document.createElement("style");f.id="automation-dropdown-styles",f.textContent=`
      .nested-dropdown {
        margin-bottom: 8px;
        width: 100%;
        position: relative;
      }
      .nested-dropdown-btn {
        width: 100%;
        text-align: left;
        padding: 8px 12px;
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 3px;
        cursor: pointer;
        font-weight: bold;
        font-size: 13px;
        color: #e6e6e6;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .nested-dropdown-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      .nested-dropdown-btn:after {
        content: "\u25BC";
        font-size: 8px;
        color: #e6e6e6;
      }
      .nested-dropdown-content {
        display: none;
        padding: 5px 0 5px 10px;
        margin-top: 3px !important;
      }
      .nested-dropdown.open .nested-dropdown-content {
        display: block;
      }

      /* Button-style options */
      .automation-btn {
        display: block;
        width: 100%;
        padding: 8px 12px;
        margin-bottom: 8px;
        background-color: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 4px;
        text-align: left;
        font-size: 13px;
        color: #e6e6e6;
        cursor: pointer;
        transition: all 0.2s ease;
        font-weight: normal;
      }
      .automation-btn:hover {
        background-color: rgba(255, 255, 255, 0.15);
        border-color: rgba(255, 255, 255, 0.2);
      }
      .automation-btn:active {
        background-color: rgba(255, 255, 255, 0.2);
      }
    `,document.head.appendChild(f)}let i=document.createElement("div");i.className="nested-dropdown";let n=document.createElement("button");n.className="nested-dropdown-btn",n.textContent="Semaglutide (Step 2)";let r=document.createElement("div");r.className="nested-dropdown-content",n.addEventListener("click",f=>{f.stopPropagation(),i.classList.toggle("open")});let a=document.createElement("button");a.className="automation-btn",a.textContent="Sema/B12 Refill - Step 2",a.addEventListener("click",f=>{f.stopPropagation(),D(),setTimeout(()=>{V(B["Sema/B12 Refill - Step 2"])},300)}),r.appendChild(a);let s=document.createElement("button");s.className="automation-btn",s.textContent="Sema/B12 Vial - Step 2",s.addEventListener("click",f=>{f.stopPropagation(),D(),setTimeout(()=>{V(B["Sema/B12 Vial - Step 2"])},300)}),r.appendChild(s);let l=document.createElement("button");l.className="automation-btn",l.textContent="Sema/B6 Vial - Step 2",l.addEventListener("click",f=>{f.stopPropagation(),D(),setTimeout(()=>{V(B["Sema/B6 Vial - Step 2"])},300)}),r.appendChild(l);let c=document.createElement("button");c.className="automation-btn",c.textContent="Sema/Lipo Vial - Step 2",c.addEventListener("click",f=>{f.stopPropagation(),D(),setTimeout(()=>{V(B["Sema/Lipo Vial - Step 2"])},300)}),r.appendChild(c);let d=document.createElement("button");d.className="automation-btn",d.textContent="Sema/NAD+ Vial - Step 2",d.addEventListener("click",f=>{f.stopPropagation(),D(),setTimeout(()=>{V(B["Sema/NAD+ Vial - Step 2"])},300)}),r.appendChild(d),i.appendChild(n),i.appendChild(r),o.appendChild(i);let p=document.createElement("div");p.className="nested-dropdown";let h=document.createElement("button");h.className="nested-dropdown-btn",h.textContent="Tirzepatide (Step 2)";let g=document.createElement("div");g.className="nested-dropdown-content",h.addEventListener("click",f=>{f.stopPropagation(),p.classList.toggle("open")});let S=document.createElement("button");S.className="automation-btn",S.textContent="Tirz/B6 Refill - Step 2",S.addEventListener("click",f=>{f.stopPropagation(),D(),setTimeout(()=>{V(B["Tirz/B6 Refill - Step 2"])},300)}),g.appendChild(S);let k=document.createElement("button");k.className="automation-btn",k.textContent="Tirz/B12 Vial - Step 2",k.addEventListener("click",f=>{f.stopPropagation(),D(),setTimeout(()=>{V(B["Tirz/B12 Vial - Step 2"])},300)}),g.appendChild(k);let R=document.createElement("button");R.className="automation-btn",R.textContent="Tirz/NAD+ Vial - Step 2",R.addEventListener("click",f=>{f.stopPropagation(),D(),setTimeout(()=>{V(B["Tirz/NAD+ Vial - Step 2"])},300)}),g.appendChild(R);let N=document.createElement("button");return N.className="automation-btn",N.textContent="Tirz/B6 Vial - Step 2",N.addEventListener("click",f=>{f.stopPropagation(),D(),setTimeout(()=>{V(B["Tirz/B6 Vial - Step 2"])},300)}),g.appendChild(N),p.appendChild(h),p.appendChild(g),o.appendChild(p),e.appendChild(t),e.appendChild(o),e}function D(){document.querySelectorAll(".dropdown.show").forEach(e=>e.classList.remove("show")),document.querySelectorAll(".nested-dropdown.open").forEach(e=>e.classList.remove("open"))}function V(e){try{console.log(`[CRM Extension] Starting workflow for "${e}"`),u(`Starting workflow for "${e}"`);let t=Array.from(document.querySelectorAll("button.btn.btn-light2.btn-xs")).find(o=>o.textContent.trim().includes("Add"));if(!t){console.error("[CRM Extension] Add Automation button not found"),u("Add Automation button not found");return}console.log("[CRM Extension] Found Add button, clicking it"),t.click(),setTimeout(()=>{let o=document.querySelector('input[placeholder="Type to search"]');if(!o){console.error("[CRM Extension] Search input not found"),u("Search input not found");return}console.log("[CRM Extension] Found search input, entering 'step 2'"),o.focus(),o.value="step 2",o.dispatchEvent(new Event("input",{bubbles:!0})),setTimeout(()=>{let i=[".v-list",".dropdown-menu",".v-select-list",".vs__dropdown-menu",'[role="listbox"]',"ul",".v-menu__content"],n=null;for(let c of i){let d=document.querySelector(c);for(let p=0;p<=10;p++)if(d&&d.querySelector("li, .v-list-item, .dropdown-item")&&d.scrollHeight>d.clientHeight){n=d,console.log(`[CRM Extension] Found scrollable dropdown container: ${c}`);break}}if(!n){let c=document.querySelector('.modal, dialog, [role="dialog"]');if(c){let d=Array.from(c.querySelectorAll("*")).filter(p=>p.scrollHeight>p.clientHeight&&p.clientHeight>50);d.length>0&&(n=d[0],console.log("[CRM Extension] Found scrollable element via fallback method"))}}if(!n){console.error("[CRM Extension] Could not find scrollable container"),u("Could not find dropdown container");return}console.log("[CRM Extension] Starting scroll wheel simulation"),console.log(`[CRM Extension] Container dimensions: ${n.scrollHeight}x${n.clientHeight}`);let r=0,a=20,s=!1;function l(){if(s||r>=a){s||(console.error("[CRM Extension] Max scroll attempts reached without finding match"),u("Option not found after scrolling"));return}r++,console.log(`[CRM Extension] Scroll attempt ${r}/${a}`);let c=new WheelEvent("wheel",{deltaY:100,bubbles:!0});n.dispatchEvent(c),n.scrollTop+=100,console.log(`[CRM Extension] Scrolled to position: ${n.scrollTop}/${n.scrollHeight}`),setTimeout(()=>{let d=n.querySelectorAll('li, .v-list-item, .dropdown-item, [role="option"]');console.log(`[CRM Extension] Found ${d.length} options after scrolling`);for(let p of d){if(!p.textContent)continue;let h=p.textContent.trim();if(h===e&&!h.includes("Provider Paid")&&!h.includes("New Patient")){console.log(`[CRM Extension] Found exact matching option: "${h}"`);try{p.scrollIntoView({block:"center"}),setTimeout(()=>{p.click(),s=!0,setTimeout(()=>{let g=Array.from(document.querySelectorAll("button")).find(S=>S.textContent.trim()==="Add");g?(console.log("[CRM Extension] Clicking Add button in dialog"),g.click(),u(`Added "${e}" workflow`)):(console.error("[CRM Extension] Add button in dialog not found"),u("Add button in dialog not found"))},1e3)},300)}catch(g){console.error("[CRM Extension] Error clicking option:",g)}break}}if(!s){if(n.scrollHeight-n.scrollTop<=n.clientHeight+20){console.log("[CRM Extension] Reached bottom of dropdown without finding match"),u(`Reached end without finding "${e}"`);return}setTimeout(l,500)}},500)}l()},1500)},1e3)}catch(t){console.error("[CRM Extension] Error in workflow:",t),u(`Error in workflow: ${t.message}`)}}function st(){let e=null,t=null,o=null,i=null,n=document.createElement("div");n.id="crm-api-bar",n.style.display="flex",n.style.flexDirection="row",n.style.alignItems="center",n.style.gap="8px",n.style.background="#23272e",n.style.borderRadius="4px",n.style.padding="4px 8px",n.style.margin="0 0 4px 0",n.style.minWidth="0",n.style.boxShadow="0px 4px 8px 0px rgba(0,0,0,0.10)",n.style.border="1px solid rgba(255,255,255,0.06)";let r=document.createElement("label");r.textContent="Medication:",r.style.marginRight="2px",r.style.fontSize="12px",r.style.color="#e6e6e6";let a=document.createElement("select");a.style.marginRight="4px",a.style.background="#23272e",a.style.color="#a0e0ff",a.style.border="1px solid #444",a.style.borderRadius="2px",a.style.padding="2px 6px",a.style.fontWeight="bold",a.style.fontSize="12px",a.style.height="24px",a.innerHTML=`
    <option value="">Select</option>
    <option value="Tirzepatide">Tirzepatide</option>
    <option value="Semaglutide">Semaglutide</option>
  `;let s=document.createElement("label");s.textContent="Compound:",s.style.marginRight="2px",s.style.fontSize="12px",s.style.color="#e6e6e6";let l=document.createElement("select");l.style.marginRight="4px",l.style.background="#23272e",l.style.color="#a0e0ff",l.style.border="1px solid #444",l.style.borderRadius="2px",l.style.padding="2px 6px",l.style.fontWeight="bold",l.style.fontSize="12px",l.style.height="24px";let c=document.createElement("label");c.textContent="Dosage (ml):",c.style.marginRight="2px",c.style.fontSize="12px",c.style.color="#e6e6e6";let d=document.createElement("select");d.style.marginRight="4px",d.style.background="#23272e",d.style.color="#a0e0ff",d.style.border="1px solid #444",d.style.borderRadius="2px",d.style.padding="2px 6px",d.style.fontWeight="bold",d.style.fontSize="12px",d.style.height="24px";let p=document.createElement("label");p.textContent="Step:",p.style.marginRight="2px",p.style.fontSize="12px",p.style.color="#e6e6e6";let h=document.createElement("select");h.style.marginRight="4px",h.style.background="#23272e",h.style.color="#a0e0ff",h.style.border="1px solid #444",h.style.borderRadius="2px",h.style.padding="2px 6px",h.style.fontWeight="bold",h.style.fontSize="12px",h.style.height="24px",h.innerHTML=`
    <option value="">Select</option>
    <option value="Step 1: Verify first name">Step 1: Verify first name</option>
    <option value="Step 2: Verify form">Step 2: Verify form</option>
    <option value="Step 3: Waiting on payment">Step 3: Waiting on payment</option>
    <option value="Step 4: Sending payment">Step 4: Sending payment</option>
  `;let g=document.createElement("button");g.textContent="Submit",g.style.marginLeft="6px",g.style.padding="2px 12px",g.style.background="#1e90ff",g.style.color="#fff",g.style.border="none",g.style.borderRadius="3px",g.style.fontWeight="bold",g.style.fontSize="12px",g.style.cursor="pointer",g.style.height="24px",g.addEventListener("mouseenter",()=>g.style.background="#0074d9"),g.addEventListener("mouseleave",()=>g.style.background="#1e90ff");function S(){let f=a.value;l.innerHTML=`<option value="">Select</option>
      <option value="NAD+ vial">NAD+ vial</option>
      <option value="Lipo vial">Lipo vial</option>
      <option value="B6 vial">B6 vial</option>
      <option value="B12 vial">B12 vial</option>
      ${f==="Tirzepatide"?'<option value="B6 syringe">B6 syringe</option>':""}
      ${f==="Semaglutide"?'<option value="B12 syringe">B12 syringe</option>':""}
    `,l.value="",k()}function k(){let f=l.value,b=a.value,E=[];f&&f.toLowerCase().includes("syringe")?b==="Tirzepatide"?E=["0.25","0.5","0.75","1.0","1.25","1.5"]:b==="Semaglutide"&&(E=["0.125","0.25","0.5","0.75","1.0","1.25","1.5","1.75","2.0"]):f&&f.toLowerCase().includes("vial")&&(E=["2.5","5","7.5","10"]),d.innerHTML='<option value="">Select</option>'+E.map(y=>`<option value="${y} ml">${y} ml</option>`).join(""),d.value=""}a.addEventListener("change",()=>{e=a.value,S()}),l.addEventListener("change",()=>{t=l.value,k()}),d.addEventListener("change",()=>{o=d.value}),h.addEventListener("change",()=>{i=h.value});let R=(f,b,E)=>[f,b,E].map(y=>(y||"").trim()).join("|"),N={"Tirzepatide|B6 syringe|Step 1: Verify first name":"API - Refill - Tirzepatide Combo - (Step 1 Verify First Name)","Tirzepatide|NAD+ vial|Step 1: Verify first name":"API - Refill - Tirzepatide Combo - (Step 1 Verify First Name)","Tirzepatide|Lipo vial|Step 1: Verify first name":"API - Refill - Tirzepatide Combo - (Step 1 Verify First Name)","Tirzepatide|B6 vial|Step 1: Verify first name":"API - Refill - Tirzepatide Combo - (Step 1 Verify First Name)","Tirzepatide|B12 vial|Step 1: Verify first name":"API - Refill - Tirzepatide Combo - (Step 1 Verify First Name)","Tirzepatide|B6 syringe|Step 2: Verify form":"API - Refill - Tirzepatide Combo - (Step 2 Verify Form)","Tirzepatide|NAD+ vial|Step 2: Verify form":"API - Refill - Tirzepatide Combo - (Step 2 Verify Form)","Tirzepatide|Lipo vial|Step 2: Verify form":"API - Refill - Tirzepatide Combo - (Step 2 Verify Form)","Tirzepatide|B6 vial|Step 2: Verify form":"API - Refill - Tirzepatide Combo - (Step 2 Verify Form)","Tirzepatide|B12 vial|Step 2: Verify form":"API - Refill - Tirzepatide Combo - (Step 2 Verify Form)","Tirzepatide|B6 syringe|Step 3: Waiting on payment":"API - Refill - Tirzepatide Combo - (Step 3 Waiting on Payment)","Tirzepatide|NAD+ vial|Step 3: Waiting on payment":"API - Refill - Tirzepatide Combo - (Step 3 Waiting on Payment)","Tirzepatide|Lipo vial|Step 3: Waiting on payment":"API - Refill - Tirzepatide Combo - (Step 3 Waiting on Payment)","Tirzepatide|B6 vial|Step 3: Waiting on payment":"API - Refill - Tirzepatide Combo - (Step 3 Waiting on Payment)","Tirzepatide|B12 vial|Step 3: Waiting on payment":"API - Refill - Tirzepatide Combo - (Step 3 Waiting on Payment)","Tirzepatide|B6 syringe|Step 4: Sending payment":"API - Refill - Tirzepatide Combo - (Step 4 Sending Payment)","Tirzepatide|NAD+ vial|Step 4: Sending payment":"API - Refill - Tirzepatide Combo - (Step 4 Sending Payment)","Tirzepatide|Lipo vial|Step 4: Sending payment":"API - Refill - Tirzepatide Combo - (Step 4 Sending Payment)","Tirzepatide|B6 vial|Step 4: Sending payment":"API - Refill - Tirzepatide Combo - (Step 4 Sending Payment)","Tirzepatide|B12 vial|Step 4: Sending payment":"API - Refill - Tirzepatide Combo - (Step 4 Sending Payment)","Semaglutide|B12 syringe|Step 1: Verify first name":"API - Refill - Semaglutide Combo - (Step 1 Verify First Name)","Semaglutide|NAD+ vial|Step 1: Verify first name":"API - Refill - Semaglutide Combo - (Step 1 Verify First Name)","Semaglutide|Lipo vial|Step 1: Verify first name":"API - Refill - Semaglutide Combo - (Step 1 Verify First Name)","Semaglutide|B6 vial|Step 1: Verify first name":"API - Refill - Semaglutide Combo - (Step 1 Verify First Name)","Semaglutide|B12 vial|Step 1: Verify first name":"API - Refill - Semaglutide Combo - (Step 1 Verify First Name)","Semaglutide|B12 syringe|Step 2: Verify form":"API - Refill - Semaglutide Combo - (Step 2 Verify Form)","Semaglutide|NAD+ vial|Step 2: Verify form":"API - Refill - Semaglutide Combo - (Step 2 Verify Form)","Semaglutide|Lipo vial|Step 2: Verify form":"API - Refill - Semaglutide Combo - (Step 2 Verify Form)","Semaglutide|B6 vial|Step 2: Verify form":"API - Refill - Semaglutide Combo - (Step 2 Verify Form)","Semaglutide|B12 vial|Step 2: Verify form":"API - Refill - Semaglutide Combo - (Step 2 Verify Form)","Semaglutide|B12 syringe|Step 3: Waiting on payment":"API - Refill - Semaglutide Combo - (Step 3 Waiting on Payment)","Semaglutide|NAD+ vial|Step 3: Waiting on payment":"API - Refill - Semaglutide Combo - (Step 3 Waiting on Payment)","Semaglutide|Lipo vial|Step 3: Waiting on payment":"API - Refill - Semaglutide Combo - (Step 3 Waiting on Payment)","Semaglutide|B6 vial|Step 3: Waiting on payment":"API - Refill - Semaglutide Combo - (Step 3 Waiting on Payment)","Semaglutide|B12 vial|Step 3: Waiting on payment":"API - Refill - Semaglutide Combo - (Step 3 Waiting on Payment)","Semaglutide|B12 syringe|Step 4: Sending payment":"API - Refill - Semaglutide Combo - (Step 4 Sending Payment)","Semaglutide|NAD+ vial|Step 4: Sending payment":"API - Refill - Semaglutide Combo - (Step 4 Sending Payment)","Semaglutide|Lipo vial|Step 4: Sending payment":"API - Refill - Semaglutide Combo - (Step 4 Sending Payment)","Semaglutide|B6 vial|Step 4: Sending payment":"API - Refill - Semaglutide Combo - (Step 4 Sending Payment)","Semaglutide|B12 vial|Step 4: Sending payment":"API - Refill - Semaglutide Combo - (Step 4 Sending Payment)"};return g.addEventListener("click",()=>{if(!a.value||!l.value||!d.value||!h.value){u("Please select all required options before proceeding.");return}let f=R(a.value,l.value,h.value),b=N[f];if(!b){u("No automation found for this selection."),console.error("No automation found for key:",f);return}It(b)}),n.appendChild(r),n.appendChild(a),n.appendChild(s),n.appendChild(l),n.appendChild(c),n.appendChild(d),n.appendChild(p),n.appendChild(h),n.appendChild(g),S(),n}function It(e){try{console.log(`[CRM Extension] Starting workflow for "${e}"`),u(`Starting workflow for "${e}"`);let t=Array.from(document.querySelectorAll("button.btn.btn-light2.btn-xs")).find(o=>o.textContent.trim().includes("Add"));if(!t){console.error("[CRM Extension] Add Automation button not found"),u("Add Automation button not found");return}console.log("[CRM Extension] Found Add button, clicking it"),t.click(),setTimeout(()=>{let o=document.querySelector('input[placeholder="Type to search"]');if(!o){console.error("[CRM Extension] Search input not found"),u("Search input not found");return}console.log("[CRM Extension] Found search input, entering 'step 2'"),o.focus(),o.value="step 2",o.dispatchEvent(new Event("input",{bubbles:!0})),setTimeout(()=>{let i=[".v-list",".dropdown-menu",".v-select-list",".vs__dropdown-menu",'[role="listbox"]',"ul",".v-menu__content"],n=null;for(let c of i){let d=document.querySelector(c);for(let p=0;p<=10;p++)if(d&&d.querySelector("li, .v-list-item, .dropdown-item")&&d.scrollHeight>d.clientHeight){n=d,console.log(`[CRM Extension] Found scrollable dropdown container: ${c}`);break}}if(!n){let c=document.querySelector('.modal, dialog, [role="dialog"]');if(c){let d=Array.from(c.querySelectorAll("*")).filter(p=>p.scrollHeight>p.clientHeight&&p.clientHeight>50);d.length>0&&(n=d[0],console.log("[CRM Extension] Found scrollable element via fallback method"))}}if(!n){console.error("[CRM Extension] Could not find scrollable container"),u("Could not find dropdown container");return}console.log("[CRM Extension] Starting scroll wheel simulation"),console.log(`[CRM Extension] Container dimensions: ${n.scrollHeight}x${n.clientHeight}`);let r=0,a=20,s=!1;function l(){if(s||r>=a){s||(console.error("[CRM Extension] Max scroll attempts reached without finding match"),u("Option not found after scrolling"));return}r++,console.log(`[CRM Extension] Scroll attempt ${r}/${a}`);let c=new WheelEvent("wheel",{deltaY:100,bubbles:!0});n.dispatchEvent(c),n.scrollTop+=100,console.log(`[CRM Extension] Scrolled to position: ${n.scrollTop}/${n.scrollHeight}`),setTimeout(()=>{let d=n.querySelectorAll('li, .v-list-item, .dropdown-item, [role="option"]');console.log(`[CRM Extension] Found ${d.length} options after scrolling`);for(let p of d){if(!p.textContent)continue;let h=p.textContent.trim();if(h===e&&!h.includes("Provider Paid")&&!h.includes("New Patient")){console.log(`[CRM Extension] Found exact matching option: "${h}"`);try{p.scrollIntoView({block:"center"}),setTimeout(()=>{p.click(),s=!0,setTimeout(()=>{let g=Array.from(document.querySelectorAll("button")).find(S=>S.textContent.trim()==="Add");g?(console.log("[CRM Extension] Clicking Add button in dialog"),g.click(),u(`Added "${e}" workflow`)):(console.error("[CRM Extension] Add button in dialog not found"),u("Add button in dialog not found"))},1e3)},300)}catch(g){console.error("[CRM Extension] Error clicking option:",g)}break}}if(!s){if(n.scrollHeight-n.scrollTop<=n.clientHeight+20){console.log("[CRM Extension] Reached bottom of dropdown without finding match"),u(`Reached end without finding "${e}"`);return}setTimeout(l,500)}},500)}l()},1500)},1e3)}catch(t){console.error("[CRM Extension] Error in workflow:",t),u(`Error in workflow: ${t.message}`)}}function ct(){let e=document.createElement("div");return e.className="group",e.id="crm-dropdowns-group",e.appendChild(lt()),e.appendChild(rt()),e.appendChild(st()),document.addEventListener("click",t=>{document.querySelectorAll(".dropdown").forEach(i=>{i.contains(t.target)||(i.classList.remove("show"),i.querySelectorAll(".nested-dropdown").forEach(r=>{r.classList.remove("open")}))})}),Pt(),e}function Pt(){if(document.getElementById("custom-dropdown-styles"))return;let e=document.createElement("style");e.id="custom-dropdown-styles",e.textContent=`
    /* Improved dropdown positioning */
    .dropdown {
      position: relative !important;
      margin-right: 8px !important; /* Ensure space between dropdowns, reduced for tighter layout */
    }

    .dropdown:last-child {
      margin-right: 0 !important; /* Remove margin from the last dropdown */
    }

    .dropdown-content {
      position: absolute !important;
      background-color: #2F3A4B; /* Match toolbar background color */
      min-width: 220px !important; /* Increased width */
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.3);
      z-index: 999;
      border-radius: 4px;
      margin-top: 5px !important; /* Add space between button and dropdown */
      left: 0;
      top: 100% !important; /* Position below the button */
      display: none;
      border: 1px solid rgba(255, 255, 255, 0.1); /* Subtle border */
    }

    /* Ensure right-aligned dropdowns don't overflow */
    #crm-tags-dropdown .dropdown-content {
      right: 0;
      left: auto; /* Override left positioning for Tags dropdown */
    }

    .dropdown.show .dropdown-content {
      display: block;
    }

    /* Improved nested dropdown positioning */
    .nested-dropdown-content {
      margin-top: 3px !important;
      background-color: #2F3A4B; /* Match toolbar background color */
      border-radius: 4px;
      padding: 5px !important;
    }

    /* Style dropdown items */
    .dropdown-item {
      color: #e6e6e6; /* White text for visibility */
      padding: 10px 14px !important; /* Increased padding */
      text-decoration: none;
      display: block;
      font-size: 14px;
      cursor: pointer;
      border-radius: 3px;
      font-weight: normal;
    }

    .dropdown-item:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }

    /* Fix for Vial-Sema and Vial-Tirz nested dropdowns */
    .nested-dropdown-btn {
      text-align: left !important;
      padding: 8px 12px !important;
      background-color: rgba(255, 255, 255, 0.1) !important;
      border: 1px solid rgba(255, 255, 255, 0.15) !important;
      color: #e6e6e6 !important;
      font-weight: bold !important;
    }

    .nested-dropdown-btn:hover {
      background-color: rgba(255, 255, 255, 0.2) !important;
    }

    /* Force visibility for Tags dropdown */
    #crm-tags-dropdown {
      display: flex !important;
    }

    #crm-tags-dropdown .dropdown-content {
      min-width: 220px !important;
    }
  `,document.head.appendChild(e)}function dt(){let e=document.createElement("div");e.className="group",e.id="crm-settings-group",e.style.position="relative";let t=document.createElement("button");t.className="btn",t.id="crm-settings-btn";let o=document.createElement("span");o.className="btn-icon",o.innerHTML="\u2699\uFE0F",t.appendChild(o);let i=document.createElement("span");i.textContent="Settings",t.appendChild(i);let n=zt();if(t.addEventListener("click",r=>{r.stopPropagation(),n.classList.toggle("show")}),document.addEventListener("click",r=>{r.target!==t&&!t.contains(r.target)&&r.target!==n&&!n.contains(r.target)&&n.classList.remove("show")}),!document.getElementById("settings-dropdown-styles")){let r=document.createElement("style");r.id="settings-dropdown-styles",r.textContent=`
      #mcp-crm-settings-dropdown {
        display: none;
        position: absolute;
        top: calc(100% + 5px); /* Position below the button with 5px gap */
        right: 0;
        z-index: 1000;
        min-width: 230px;
        background-color: #2F3A4B;
        border-radius: 4px;
        border: 1px solid rgba(255, 255, 255, 0.1);
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
        overflow: hidden;
      }
      
      #mcp-crm-settings-dropdown.show {
        display: block;
      }
      
      .settings-header {
        padding: 10px;
        background-color: rgba(255, 255, 255, 0.1);
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        font-weight: bold;
        color: #e6e6e6;
      }
      
      .settings-body {
        padding: 10px;
        color: #e6e6e6;
      }
      
      .setting-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
        font-size: 13px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        padding-bottom: 10px;
      }
      
      .setting-item:last-child {
        margin-bottom: 0;
        border-bottom: none;
        padding-bottom: 0;
      }
      
      .setting-label {
        color: #e6e6e6;
        font-weight: normal;
      }
      
      /* Toggle switch styles */
      .switch {
        position: relative;
        display: inline-block;
        width: 40px;
        height: 20px;
      }
      
      .switch input {
        opacity: 0;
        width: 0;
        height: 0;
      }
      
      .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #555;
        transition: .4s;
        border-radius: 34px;
      }
      
      .slider:before {
        position: absolute;
        content: "";
        height: 16px;
        width: 16px;
        left: 2px;
        bottom: 2px;
        background-color: white;
        transition: .4s;
        border-radius: 50%;
      }
      
      input:checked + .slider {
        background-color: #2196F3;
      }
      
      input:focus + .slider {
        box-shadow: 0 0 1px #2196F3;
      }
      
      input:checked + .slider:before {
        transform: translateX(20px);
      }
      
      /* Version info styles */
      .version-info {
        border-top: 1px solid rgba(255, 255, 255, 0.1);
        margin-top: 10px;
        padding-top: 10px;
        font-size: 12px;
        color: #e6e6e6;
      }
      
      .version-info p {
        margin: 5px 0;
        color: #e6e6e6;
      }
      
      .version-number {
        font-weight: 600;
        color: #e6e6e6;
      }
      
      .check-updates-btn {
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 3px;
        padding: 4px 8px;
        margin-top: 5px;
        font-size: 11px;
        cursor: pointer;
        transition: background-color 0.2s;
        width: 100%;
        text-align: center;
        color: #e6e6e6;
      }
      
      .check-updates-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      
      .check-updates-btn:disabled {
        opacity: 0.6;
        cursor: not-allowed;
      }
      
      #crm-update-status {
        margin: 5px 0 0 0;
        padding: 3px 6px;
        font-size: 11px;
        border-radius: 3px;
        background-color: rgba(255, 255, 255, 0.05);
        text-align: center;
        transition: all 0.3s ease;
        color: #e6e6e6;
      }
      
      #last-update-check {
        font-size: 11px;
        margin: 5px 0;
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        color: #e6e6e6;
      }
      
      .check-status {
        font-size: 10px;
        margin-left: 5px;
        padding: 1px 4px;
        border-radius: 3px;
        font-weight: normal;
      }
      
      .loading-text {
        font-style: italic;
        color: #aaa;
      }
      
      /* Section styles */
      .setting-section {
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      }
      
      .setting-section-title {
        font-size: 12px;
        font-weight: bold;
        color: #e6e6e6;
        margin-bottom: 10px;
      }
    `,document.head.appendChild(r)}return e.appendChild(t),e.appendChild(n),e}function Lt(e){try{(typeof browser<"u"?browser:chrome).runtime.sendMessage({action:"getLastUpdateCheck"}).then(o=>{if(o&&o.success&&o.lastUpdateCheck){let i=o.lastUpdateCheck,n="",r="";i.success?i.status==="update_available"?(n="Update available",r="#4CAF50"):i.status==="no_update"?(n="No updates needed",r="#2196F3"):i.status==="throttled"?(n="Check throttled",r="#FF9800"):(n="Completed",r="#2196F3"):(n="Failed",r="#F44336"),e.innerHTML=`Last Check: <span class="version-number">${i.formattedTime}</span> <span class="check-status" style="color:${r};font-size:10px;margin-left:5px;">${n}</span>`}else e.innerHTML='Last Check: <span class="version-number">No checks recorded</span>'}).catch(o=>{console.error("[CRM Extension] Error fetching last update check:",o),e.innerHTML='Last Check: <span class="version-number">Unknown</span>'})}catch(t){console.error("[CRM Extension] Error in fetchLastUpdateCheckInfo:",t),e.innerHTML='Last Check: <span class="version-number">Error</span>'}}function zt(){let e=document.createElement("div");e.id="mcp-crm-settings-dropdown";let t=document.createElement("div");t.className="settings-header",t.textContent="CRM+ Settings",e.appendChild(t);let o=document.createElement("div");if(o.className="settings-body",e.appendChild(o),!document.getElementById("collapsible-settings-styles")){let s=document.createElement("style");s.id="collapsible-settings-styles",s.textContent=`
      .setting-section {
        margin-bottom: 8px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        padding-bottom: 0; /* No bottom padding when collapsed */
      }
      
      .setting-section-title {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 13px;
        font-weight: bold;
        color: #e6e6e6;
        padding: 8px 0;
        cursor: pointer;
        user-select: none;
      }
      
      .setting-section-title:after {
        content: "\u25BC";
        font-size: 8px;
        color: #e6e6e6;
        transition: transform 0.2s ease;
      }
      
      .setting-section.collapsed .setting-section-title:after {
        transform: rotate(-90deg);
      }
      
      .setting-section-content {
        max-height: 500px;
        overflow: hidden;
        transition: max-height 0.3s ease, opacity 0.2s ease, margin-bottom 0.3s ease;
        opacity: 1;
        margin-bottom: 10px;
      }
      
      .setting-section.collapsed .setting-section-content {
        max-height: 0;
        opacity: 0;
        margin-bottom: 0;
      }
    `,document.head.appendChild(s)}let i=Se("General Settings");i.content.appendChild(O("Show Header Bar","crmplus_headerBarVisible",s=>{let l=document.getElementById("mcp-crm-header");l&&(l.style.display=s?"flex":"none",document.body.style.paddingTop=s?"32px":"0"),u(`Header bar: ${s?"Visible":"Hidden"}`)},!0)),i.content.appendChild(O("Show Provider-Paid Alerts","crmplus_showProviderPaidAlerts",s=>{u(`Provider-Paid alerts: ${s?"Enabled":"Disabled"}`)},!0)),o.appendChild(i.section);let n=Se("External Links");n.content.appendChild(O("Show ShipStation Link","crmplus_showShipStation",s=>{let l=document.querySelector(".shipstation-link");l&&(l.style.display=s?"flex":"none"),u(`ShipStation link: ${s?"Visible":"Hidden"}`)},!0)),n.content.appendChild(O("Show Stripe Link","crmplus_showStripe",s=>{let l=document.querySelector(".stripe-link");l&&(l.style.display=s?"flex":"none"),u(`Stripe link: ${s?"Visible":"Hidden"}`)},!0)),n.content.appendChild(O("Show Webmail Link","crmplus_showWebmail",s=>{let l=document.querySelector(".webmail-link");l&&(l.style.display=s?"flex":"none"),u(`Webmail link: ${s?"Visible":"Hidden"}`)},!0)),o.appendChild(n.section);let r=Se("Features");r.content.appendChild(O("Auto-copy phone number on page load","crmplus_autoCopyPhone",s=>{u(`Auto-copy phone: ${s?"Enabled":"Disabled"}`)},!1)),r.content.appendChild(O("CRM Automation","crmplus_automationEnabled",s=>{[document.getElementById("crm-automation-dropdown"),document.getElementById("crm-tags-dropdown")].forEach(c=>{c?(c.style.display=s?"flex":"none",console.log(`[CRM Extension] Changed visibility for ${c.id}: ${s?"visible":"hidden"}`)):console.error("[CRM Extension] Could not find automation element to toggle")}),u(`CRM Automation: ${s?"Enabled":"Disabled"}`)},!0)),o.appendChild(r.section);let a=Bt();return o.appendChild(a),e}function Se(e,t=!1){let o=document.createElement("div");o.className="setting-section"+(t?" collapsed":"");let i=document.createElement("div");i.className="setting-section-title",i.textContent=e,i.addEventListener("click",()=>{o.classList.toggle("collapsed")}),o.appendChild(i);let n=document.createElement("div");return n.className="setting-section-content",o.appendChild(n),{section:o,content:n}}function Bt(){let e=document.createElement("div");e.className="version-info";let t="Loading...",o="Loading...";try{let l=(typeof browser<"u"?browser:chrome).runtime.getManifest();if(l&&l.version&&(t=l.version,t.includes("."))){let c=t.split(".");if(c.length===3&&c[0].length===4){let d=c[0],p=c[1],h=c[2];o=`${p}/${h}/${d}`}}}catch(s){console.error("[CRM Extension] Error fetching version:",s),t="Unknown",o="Unknown"}let i=document.createElement("p");i.innerHTML=`Version: <span class="version-number">${t}</span>`,e.appendChild(i);let n=document.createElement("p");n.innerHTML=`Last Updated: <span class="version-number">${o}</span>`,e.appendChild(n);let r=document.createElement("p");r.id="last-update-check",r.innerHTML='Last Check: <span class="loading-text">Loading...</span>',e.appendChild(r),Lt(r);let a=document.createElement("button");return a.className="check-updates-btn",a.textContent="Check for Updates",a.addEventListener("click",()=>{let s=typeof browser<"u"?browser:chrome;a.disabled=!0,a.textContent="Checking...",u("Checking for updates...");let l=document.getElementById("crm-update-status");l||(l=document.createElement("p"),l.id="crm-update-status",l.style.fontSize="11px",l.style.marginTop="5px",l.style.color="#e6e6e6",l.textContent="",e.appendChild(l)),s.runtime.sendMessage({action:"checkForUpdates"}).then(c=>{if(c&&c.success){u("Update check completed"),c.updateStatus==="update_available"?(l.textContent=`Update available (${c.updateVersion})`,l.style.color="#4CAF50"):c.updateStatus==="no_update"?(l.textContent="You have the latest version",l.style.color="#2196F3"):c.updateStatus==="throttled"?(l.textContent="Update check throttled, try again later",l.style.color="#FF9800"):c.updateStatus==="error"?(l.textContent="Error checking for updates",l.style.color="#F44336"):(l.textContent="Update check initiated",l.style.color="#e6e6e6");let d=document.getElementById("last-update-check");if(d&&c.lastCheck){let p=c.lastCheck,h="",g="";p.success?p.status==="update_available"?(h="Update available",g="#4CAF50"):p.status==="no_update"?(h="No updates needed",g="#2196F3"):p.status==="throttled"?(h="Check throttled",g="#FF9800"):(h="Completed",g="#2196F3"):(h="Failed",g="#F44336"),d.innerHTML=`Last Check: <span class="version-number">${p.formattedTime}</span> <span class="check-status" style="color:${g};font-size:10px;margin-left:5px;">${h}</span>`}}else u("Error checking for updates"),l.textContent="Update check failed",l.style.color="#F44336";a.disabled=!1,a.textContent="Check for Updates"}).catch(c=>{console.error("[CRM Extension] Error sending update check message:",c),u("Error checking for updates"),l.textContent="Connection failed",l.style.color="#F44336",a.disabled=!1,a.textContent="Check for Updates"})}),e.appendChild(a),e}function O(e,t,o,i=!1){let n=document.createElement("div");n.className="setting-item";let r=document.createElement("div");r.className="setting-label",r.textContent=e,n.appendChild(r);let a=document.createElement("label");a.className="switch";let s=document.createElement("input");s.type="checkbox";let l=localStorage.getItem(t),c=l!==null?l==="true":i;l===null&&localStorage.setItem(t,i.toString()),s.checked=c,s.addEventListener("change",()=>{let p=s.checked;localStorage.setItem(t,p.toString()),o&&typeof o=="function"&&o(p)});let d=document.createElement("span");return d.className="slider",a.appendChild(s),a.appendChild(d),n.appendChild(a),n}function pt(){if(document.getElementById("mcp-crm-header-styles"))return;let e=document.createElement("style");e.id="mcp-crm-header-styles",e.textContent=`
    #mcp-crm-header {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 32px;
      background-color: #2F3A4B;
      display: flex;
      align-items: center;
      padding: 0 15px;
      font-family: 'Segoe UI', 'Roboto', sans-serif;
      font-size: 12px;
      z-index: 999999;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    }
    
    #mcp-crm-header .group {
      display: flex;
      align-items: center;
      margin-right: 15px;
      border-right: 1px solid rgba(255, 255, 255, 0.1);
      padding-right: 15px;
    }
    
    #mcp-crm-header .group:last-child {
      border-right: none;
      margin-right: 0; /* Remove margin from the last group (Settings) */
    }
    
    /* Special styling for dropdowns group to match other elements' spacing */
    #crm-dropdowns-group {
      margin-right: 15px; /* Same spacing as other elements */
      padding-right: 15px; /* Same padding as other elements */
    }
    
    /* Ensure settings is positioned at the far right */
    #crm-settings-btn {
      margin-right: 0;
    }
    
    #mcp-crm-header .spacer {
      flex-grow: 1;
    }
    
    #mcp-crm-header .label {
      color: #8a9cad;
      margin-right: 6px;
      font-weight: 500;
    }
    
    #mcp-crm-header .value {
      color: #e6e6e6;
      font-weight: 600;
    }
    
    #mcp-crm-header .clickable-value {
      color: #e6e6e6;
      font-weight: 600;
      cursor: pointer;
      background-color: rgba(255, 255, 255, 0.05);
      padding: 2px 8px;
      border-radius: 3px;
      transition: background-color 0.2s;
      display: inline-flex;
      align-items: center;
    }
    
    #mcp-crm-header .clickable-value:hover {
      background-color: rgba(255, 255, 255, 0.15);
    }
    
    #mcp-crm-header .btn-icon {
      margin-right: 4px;
      font-size: 10px;
    }
    
    /* Logo link styling */
    #mcp-crm-header .logo-link {
      display: flex;
      align-items: center;
      text-decoration: none;
      transition: all 0.2s ease;
    }
    
    #mcp-crm-header .logo-link:hover {
      opacity: 0.85;
    }
    
    #mcp-crm-header .logo-icon {
      width: 16px;
      height: 16px;
      margin-right: 6px;
    }
    
    #mcp-crm-header .logo {
      font-weight: bold;
      color: white;
      font-size: 14px;
    }
    
    #mcp-crm-header .external-link {
      text-decoration: none;
      color: #e6e6e6;
      display: flex;
      align-items: center;
      transition: all 0.2s ease;
      margin-right: 10px;
    }
    
    #mcp-crm-header .external-link:hover {
      background: rgba(255, 255, 255, 0.2);
      transform: translateY(-1px);
    }
    
    #mcp-crm-header .ext-link-icon {
      font-size: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    /* Styling for text links with icons */
    #mcp-crm-header .text-link {
      text-decoration: none;
      margin-right: 4px; /* Reduced margin between buttons */
      font-size: 12px;
      padding: 3px 6px; /* Reduced horizontal padding to make buttons skinnier */
      border-radius: 3px;
      color: #e6e6e6;
      display: flex;
      align-items: center;
      justify-content: center; /* Center content horizontally */
      white-space: nowrap; /* Prevent text wrapping */
      min-width: 68px; /* Set minimum width to keep consistency */
    }
    
    #mcp-crm-header .text-link:hover {
      background-color: rgba(255, 255, 255, 0.15);
    }
    
    #mcp-crm-header .text-link .link-icon {
      margin-right: 4px; /* Slightly reduced margin for tighter look */
      width: 16px;
      height: 16px;
      vertical-align: middle;
      flex-shrink: 0; /* Prevent icon from shrinking */
    }
    
    /* Add a specific class for each button to fine-tune widths if needed */
    #mcp-crm-header .shipstation-link {
      min-width: 92px;
    }
    
    #mcp-crm-header .stripe-link {
      min-width: 65px;
    }
    
    #mcp-crm-header .webmail-link {
      min-width: 78px;
    }
    
    #mcp-crm-header .btn {
      color: #e6e6e6;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 3px;
      padding: 4px 8px;
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      margin-right: 8px;
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
    }
    
    #mcp-crm-header .btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    #mcp-crm-header .btn:active {
      background-color: rgba(255, 255, 255, 0.3);
    }
    
    #mcp-crm-header .btn:last-child {
      margin-right: 0;
    }
    
    /* Dropdown styling */
    .dropdown {
      position: relative;
      display: inline-block;
      margin-right: 8px;
    }
    
    .dropdown-btn {
      color: #e6e6e6;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 3px;
      padding: 4px 8px;
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
      justify-content: space-between;
      min-width: 100px;
    }
    
    .dropdown-btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .dropdown-btn:after {
      content: "\u25BC";
      font-size: 8px;
      margin-left: 5px;
    }
    
    .dropdown-content {
      display: none;
      position: absolute;
      background-color: #2F3A4B;
      min-width: 180px;
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.3);
      z-index: 1000000;
      border-radius: 4px;
      border: 1px solid rgba(255, 255, 255, 0.1);
      margin-top: 2px;
      left: 0;
    }
    
    .dropdown.show .dropdown-content {
      display: block;
    }
    
    .dropdown-item {
      color: #e6e6e6;
      padding: 8px 12px;
      text-decoration: none;
      display: block;
      font-size: 12px;
      cursor: pointer;
      font-weight: normal;
    }
    
    .dropdown-item:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
    
    /* Nested Dropdown styling */
    .nested-dropdown {
      margin-bottom: 5px;
      width: 100%;
    }
    
    .nested-dropdown-btn {
      width: 100%;
      text-align: left;
      padding: 6px 10px;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 3px;
      cursor: pointer;
      font-weight: bold;
      font-size: 12px;
      color: #e6e6e6;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .nested-dropdown-btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .nested-dropdown-btn:after {
      content: "\u25BC";
      font-size: 8px;
      color: #e6e6e6;
    }
    
    .nested-dropdown-content {
      display: none;
      padding: 5px 0 5px 10px;
      background-color: #2F3A4B;
    }
    
    .nested-dropdown.open .nested-dropdown-content {
      display: block;
    }
    
    .nested-dropdown-item {
      display: block;
      padding: 5px 10px;
      color: #e6e6e6;
      text-decoration: none;
      font-size: 12px;
      cursor: pointer;
      border-radius: 3px;
      font-weight: normal;
    }
    
    .nested-dropdown-item:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
    
    /* Settings dropdown styling */
    #mcp-crm-settings-dropdown {
      position: absolute;
      top: 32px;
      right: 15px;
      background-color: #2F3A4B;
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 4px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.3);
      min-width: 200px;
      z-index: 1000000;
      display: none;
      color: #e6e6e6;
    }
    
    #mcp-crm-settings-dropdown.show {
      display: block;
    }
    
    #mcp-crm-settings-dropdown .settings-header {
      background-color: rgba(255, 255, 255, 0.1);
      color: #e6e6e6;
      padding: 8px 12px;
      font-weight: bold;
      border-top-left-radius: 3px;
      border-top-right-radius: 3px;
    }
    
    #mcp-crm-settings-dropdown .settings-body {
      padding: 10px;
    }
    
    #mcp-crm-settings-dropdown .setting-item {
      display: flex;
      align-items: center;
      margin-bottom: 8px;
      padding-bottom: 8px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    #mcp-crm-settings-dropdown .setting-item:last-child {
      margin-bottom: 0;
      padding-bottom: 0;
      border-bottom: none;
    }
    
    #mcp-crm-settings-dropdown .setting-label {
      flex-grow: 1;
      font-size: 13px;
      color: #e6e6e6;
    }
    
    /* Toggle switch styling */
    .switch {
      position: relative;
      display: inline-block;
      width: 40px;
      height: 20px;
    }
    
    .switch input { 
      opacity: 0;
      width: 0;
      height: 0;
    }
    
    .slider {
      position: absolute;
      cursor: pointer;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: #555;
      transition: .4s;
      border-radius: 34px;
    }
    
    .slider:before {
      position: absolute;
      content: "";
      height: 16px;
      width: 16px;
      left: 2px;
      bottom: 2px;
      background-color: white;
      transition: .4s;
      border-radius: 50%;
    }
    
    input:checked + .slider {
      background-color: #2196F3;
    }
    
    input:checked + .slider:before {
      transform: translateX(20px);
    }
    
    /* Version info section in settings */
    .version-info {
      border-top: 1px solid rgba(255, 255, 255, 0.1);
      margin-top: 10px;
      padding-top: 10px;
      font-size: 12px;
      color: #e6e6e6;
    }
    
    .version-info p {
      margin: 5px 0;
    }
    
    .version-number {
      font-weight: 600;
      color: #e6e6e6;
    }
    
    .check-updates-btn {
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 3px;
      padding: 4px 8px;
      margin-top: 5px;
      font-size: 11px;
      cursor: pointer;
      transition: background-color 0.2s;
      width: 100%;
      text-align: center;
      color: #e6e6e6;
    }
    
    .check-updates-btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .check-updates-btn:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
  `,document.head.appendChild(e)}function ut(){let e=document.createElement("div");e.className="dropdown",e.id="crm-history-dropdown";let t=document.createElement("button");t.className="dropdown-btn",t.textContent="History",t.addEventListener("click",s=>{s.stopPropagation(),document.querySelectorAll(".dropdown.show").forEach(l=>{l!==e&&l.classList.remove("show")}),e.classList.toggle("show"),e.classList.contains("show")&&mt(e)});let o=document.createElement("div");if(o.className="dropdown-content",o.id="crm-history-content",o.style.width="300px",o.style.maxHeight="400px",o.style.overflowY="auto",o.style.right="0",o.style.left="auto",!document.getElementById("history-dropdown-styles")){let s=document.createElement("style");s.id="history-dropdown-styles",s.textContent=`
      #crm-history-dropdown .dropdown-content {
        padding: 0;
        right: 0;
        left: auto;
      }
      
      /* For small screens, make sure the dropdown doesn't extend beyond viewport */
      @media screen and (max-width: 768px) {
        #crm-history-dropdown .dropdown-content {
          right: 0;
          left: auto;
          max-width: 100vw;
          width: 280px; /* Slightly smaller on small screens */
        }
      }
      
      .history-header {
        padding: 10px;
        background-color: rgba(255, 255, 255, 0.1);
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      
      .history-title {
        font-weight: bold;
        color: #e6e6e6;
        font-size: 14px;
      }
      
      .history-clear-btn {
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 3px;
        padding: 2px 6px;
        font-size: 11px;
        cursor: pointer;
        color: #e6e6e6;
        transition: background-color 0.2s;
      }
      
      .history-clear-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      
      .history-empty {
        padding: 20px;
        text-align: center;
        color: #aaa;
        font-style: italic;
        font-size: 13px;
      }
      
      .history-item {
        padding: 10px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        cursor: pointer;
        transition: background-color 0.2s;
      }
      
      .history-item:hover {
        background-color: rgba(255, 255, 255, 0.1);
      }
      
      .history-item:last-child {
        border-bottom: none;
      }
      
      .history-item-row {
        display: flex;
        margin-bottom: 3px;
        width: 100%;
      }
      
      .history-item-time {
        color: #aaa;
        font-size: 11px;
        width: 60px;
        flex-shrink: 0;
        margin-right: 5px;
      }
      
      .history-item-name {
        font-weight: bold;
        color: #e6e6e6;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        flex-grow: 1;
      }
      
      .history-item-phone {
        color: #ccc;
        font-size: 12px;
        margin-left: 65px; /* Align with name (time width + margin) */
      }
    `,document.head.appendChild(s)}let i=document.createElement("div");i.className="history-header";let n=document.createElement("div");n.className="history-title",n.textContent="Recent Patients",i.appendChild(n);let r=document.createElement("button");r.className="history-clear-btn",r.textContent="Clear All",r.addEventListener("click",s=>{s.stopPropagation(),ot(),mt(e),u("History cleared")}),i.appendChild(r),o.appendChild(i);let a=document.createElement("div");return a.className="history-empty",a.textContent="No patient history yet",o.appendChild(a),e.appendChild(t),e.appendChild(o),e}function mt(e){let t=e.querySelector("#crm-history-content");if(!t)return;let o=tt(),i=t.querySelector(".history-header");if(t.innerHTML="",i&&t.appendChild(i),o.length===0){let n=document.createElement("div");n.className="history-empty",n.textContent="No patient history yet",t.appendChild(n);return}o.forEach(n=>{let r=document.createElement("div");r.className="history-item",r.addEventListener("click",()=>{window.location.href=n.url,e.classList.remove("show")});let a=document.createElement("div");a.className="history-item-row";let s=document.createElement("div");s.className="history-item-time",s.textContent=nt(n.timestamp);let l=document.createElement("div");if(l.className="history-item-name",l.textContent=n.patientName||"Unknown Patient",a.appendChild(s),a.appendChild(l),r.appendChild(a),n.phoneNumber){let c=document.createElement("div");c.className="history-item-phone",c.textContent=n.phoneNumber,r.appendChild(c)}t.appendChild(r)})}var Dt=!1;function Re(){try{if(document.getElementById("mcp-crm-header")){console.log("[uiHeaderBar] Toolbar already exists.");return}pt();let e=document.createElement("div");e.id="mcp-crm-header";let t=localStorage.getItem("crmplus_headerBarVisible")!=="false";console.log("[CRM Extension] Header visibility setting:",t),e.style.display=t?"flex":"none";let o=typeof browser<"u"?browser:chrome,i=w=>o.runtime.getURL(w),n=document.createElement("div");n.className="group";let r=document.createElement("a");r.href="https://app.mtncarerx.com/",r.className="logo-link";let a=document.createElement("img");a.src=i("assets/mcp-favicon.ico"),a.alt="",a.className="logo-icon",r.appendChild(a);let s=document.createElement("span");s.className="logo",s.textContent="CRM+",r.appendChild(s),n.appendChild(r);let l=document.createElement("div");l.className="group external-links";let c=ke("ShipStation","https://ship15.shipstation.com/onboard","shipstation-link",i("assets/shipstation-favicon.ico"));l.appendChild(c);let d=ke("Stripe","https://dashboard.stripe.com/login","stripe-link",i("assets/stripe-favicon.ico"));l.appendChild(d);let p=ke("Webmail","https://p3plzcpnl506102.prod.phx3.secureserver.net:2096/cpsess5640910985/webmail/jupiter/index.html?login=1&post_login=89371011642013","webmail-link",i("assets/webmail-favicon.ico"));l.appendChild(p);let h=X("name","Name"),g=X("phone","Phone",{icon:"\u{1F4DE}",initialValue:"",onClick:async w=>{De(w)}}),S=X("dob","DOB"),k=X("srxid","SRx ID"),R=it(),N=ct(),f=document.createElement("div");f.className="spacer";let b=document.createElement("div");b.className="group right-buttons",b.style.borderRight="none",b.style.display="flex",b.style.marginRight="0";let E=document.createElement("button");E.className="chat-button btn",E.title="Mountain Care Chat",E.style.marginRight="8px";let y=document.createElement("div");y.style.display="flex",y.style.alignItems="center",y.style.justifyContent="center";let L=document.createElement("span");L.className="icon",L.innerHTML="\u{1F4AC}",L.style.marginRight="4px";let F=document.createElement("span");F.textContent="Chat";let $=document.createElement("span");$.className="badge",Object.assign($.style,{position:"absolute",top:"0",right:"0",backgroundColor:"#f44336",color:"white",fontSize:"12px",fontWeight:"bold",padding:"2px 6px",borderRadius:"50%",display:"none"}),y.appendChild(L),y.appendChild(F),E.appendChild(y),E.appendChild($),E.addEventListener("click",function(){if(console.log("[CRM Extension] Chat button clicked"),typeof window.toggleChatUI=="function")window.toggleChatUI();else{console.error("[CRM Extension] toggleChatUI function not available");let w=document.getElementById("hipaa-chat-container");if(w)w.style.display=w.style.display==="none"?"flex":"none",console.log("[CRM Extension] Toggled chat container visibility as fallback");else{console.error("[CRM Extension] Chat container not found");try{typeof initChat=="function"&&initChat().then(()=>{typeof window.toggleChatUI=="function"&&window.toggleChatUI()})}catch(M){console.error("[CRM Extension] Failed to initialize chat:",M)}}}});let H=ut();b.appendChild(E),b.appendChild(H);let W=dt();e.appendChild(n),e.appendChild(l),e.appendChild(h),e.appendChild(g),e.appendChild(S),e.appendChild(k),e.appendChild(N),e.appendChild(R),e.appendChild(f),e.appendChild(b),e.appendChild(W),document.body.insertBefore(e,document.body.firstChild),e.style.position="fixed",e.style.top="0",e.style.left="0",e.style.right="0",e.style.zIndex="9999",e.style.width="100%",e.style.boxSizing="border-box",e.style.height="32px";let T=document.getElementById("crm-header-padding-style");T||(T=document.createElement("style"),T.id="crm-header-padding-style",document.head.appendChild(T)),T.textContent="body { padding-top: 32px !important; }",setTimeout(()=>{try{let w=localStorage.getItem("crmplus_automationEnabled")==="true";[document.getElementById("crm-automation-dropdown"),document.getElementById("crm-tags-dropdown")].forEach(z=>{z&&(z.style.display=w?"flex":"none",console.log(`[CRM Extension] Initial visibility for ${z.id}: ${w?"visible":"hidden"}`))})}catch(w){console.error("[CRM Extension] Error setting initial automation visibility:",w)}},100),I(),$e(),Oe(),Be(),We(),Qe(),initChat(),initChatMonitoring(),onNewMessages(w=>{if(w.length>0){let M=w[0];u(`New message from ${M.sender}: ${M.text.substring(0,30)}${M.text.length>30?"...":""}`,3e3)}}),window.addEventListener("popstate",function(){console.log("[CRM Extension] Navigation detected, clearing phone display"),I()}),Vt()||I(),Dt=!0,console.log("[CRM Extension] Header successfully initialized")}catch(e){console.error("[CRM Extension] Critical error creating toolbar:",e);try{let t=document.getElementById("mcp-crm-header");t&&(t.style.display="flex")}catch(t){console.error("[CRM Extension] Failed to recover toolbar:",t)}}}function ke(e,t,o="",i=""){let n=document.createElement("a");n.href=t,n.target="_blank",n.className=`text-link btn ${o}`,n.rel="noopener noreferrer";let r=document.createElement("div");if(r.style.display="flex",r.style.alignItems="center",r.style.justifyContent="center",r.style.width="100%",i){let s=document.createElement("img");s.src=i,s.alt="",s.className="link-icon",s.style.width="16px",s.style.height="16px",s.style.marginRight="4px",r.appendChild(s)}let a=document.createElement("span");return a.textContent=e,r.appendChild(a),n.appendChild(r),n}function Vt(){let e=window.location.href;return[/\/patient\/\d+/i,/\/contact\/\d+/i,/\/profile\/\d+/i,/[?&]patient_id=\d+/i,/[?&]contact_id=\d+/i].some(i=>i.test(e))?!0:['input[name="contact.phone"]','input[name="contact.first_name"]','input[name="contact.last_name"]','input[name="contact.date_of_birth"]',".patient-info",".contact-details",".patient-header",".patient-profile"].some(i=>document.querySelector(i)!==null)}function Ne(e){try{let t=document.getElementById("mcp-crm-header");if(t){console.log(`[CRM Extension] Setting header visibility to: ${e}`),t.style.display=e?"flex":"none";let o=document.body.classList.contains("has-alert");return e?(document.body.style.paddingTop=o?"72px":"32px",document.body.classList.remove("no-header")):(document.body.style.paddingTop=o?"40px":"0",document.body.classList.add("no-header")),localStorage.setItem("crmplus_headerBarVisible",e.toString()),!0}else if(e)return console.log("[CRM Extension] Header not found but should be visible, creating it"),Re(),!0;return!1}catch(t){return console.error("[CRM Extension] Error toggling header visibility:",t),!1}}function gt(){if(!(localStorage.getItem("crmplus_autoCopyPhone")==="true")){console.log("[CRM Extension] Auto-copy phone is disabled");return}let t=()=>{let i=le();if(i){let n=Ce(i);n&&j(n).then(r=>{if(r)return u("Phone number auto-copied: "+n),!0})}return!1};if(t())return;let o=new MutationObserver((i,n)=>{t()&&n.disconnect()});o.observe(document.body,{childList:!0,subtree:!0,attributes:!0,characterData:!0}),setTimeout(()=>{o.disconnect(),t()},5e3)}var ft=!1,K=new Set,fe="",Me=!1,he=null,Ae=null;function bt(){ft||($t(),qt(),ft=!0,console.log("[CRM Extension] Alert system initialized"))}function $t(){if(document.getElementById("crm-alert-styles"))return;let e=document.createElement("style");e.id="crm-alert-styles",e.textContent=`
    .crm-alert-banner {
      position: fixed;
      top: 32px; /* Positioned right below the header bar */
      left: 0;
      right: 0;
      width: 100%;
      padding: 4px 15px; /* Reduced vertical padding for smaller height */
      font-size: 13px;
      font-weight: 500;
      z-index: 999990;
      display: flex;
      align-items: center;
      justify-content: center; /* Center contents horizontally */
      transition: all 0.3s ease;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
      transform: translateY(-100%);
      opacity: 0;
      height: 25px; /* Fixed height at 3/4 of original (approx) */
    }
    
    .crm-alert-banner.show {
      transform: translateY(0);
      opacity: 1;
    }
    
    .crm-alert-banner .alert-icon {
      margin-right: 8px;
      font-size: 16px;
    }
    
    .crm-alert-banner .alert-message {
      text-align: center; /* Center the text */
      margin: 0 auto; /* Center with auto margins */
      flex-grow: 0; /* Don't grow to fill space */
    }
    
    /* Provider Paid specific alert styling */
    .crm-alert-banner.provider-paid {
      background-color: #FFAB40; /* Orange */
      color: #5F4200;
      border-bottom: 1px solid #FF9100;
    }
    
    /* Adjust body padding to accommodate the alert banner */
    body.has-alert {
      padding-top: 72px !important; /* 32px (header) + approx alert height */
    }
    
    /* When header is hidden but alert is visible */
    body.no-header.has-alert {
      padding-top: 25px !important; /* Just the alert height */
    }
    
    /* Multiple alerts stacking */
    .crm-alert-banner.second-alert {
      top: 57px;
    }
    
    .crm-alert-banner.third-alert {
      top: 82px;
    }
    
    /* Countdown timer styling */
    .countdown-timer {
      margin-left: 5px;
      font-size: 11px;
      opacity: 0.75;
      background-color: rgba(0, 0, 0, 0.1);
      padding: 1px 4px;
      border-radius: 3px;
      min-width: 30px;
      text-align: center;
    }
  `,document.head.appendChild(e)}function ht(){let e=window.location.href,t=[/\/patient\/(\d+)/i,/\/contact\/(\d+)/i,/\/profile\/(\d+)/i,/[?&]patient_id=(\d+)/i,/[?&]contact_id=(\d+)/i];for(let o of t){let i=e.match(o);if(i&&i[1])return i[1]}return""}function qt(){fe=ht(),be(),he&&he.disconnect(),he=new MutationObserver(e=>{for(let t of e)t.type==="childList"&&be(),t.type==="attributes"&&(t.target.classList.contains("tag")||t.target.classList.contains("tag-label")||t.target.classList.contains("provider-paid"))&&be()}),he.observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["class","data-tag"]}),Ae&&clearInterval(Ae),Ae=setInterval(()=>{let e=ht();e!==fe&&(console.log("[CRM Extension] Navigation detected, patient changed from",fe,"to",e),fe=e,Me=!1,xe("provider-paid"),setTimeout(be,1e3))},1e3)}function be(){if(!(localStorage.getItem("crmplus_showProviderPaidAlerts")!=="false")){xe("provider-paid");return}Ft()?Me||Ot():xe("provider-paid")}function Ft(){let e=document.querySelectorAll(".tag, .tag-label, .pill, .badge");for(let n of e)if(n.textContent.toLowerCase().includes("provider-paid"))return n;let t=document.querySelectorAll(".provider-paid");if(t.length>0)return t[0];let o=document.querySelectorAll('[data-tag="provider-paid"], [data-tag-name="provider-paid"]');if(o.length>0)return o[0];let i=document.querySelectorAll(".tags-container, .tag-list, .tags");for(let n of i)if(n.textContent.toLowerCase().includes("provider-paid"))return n;return null}function Ot(){if(K.has("provider-paid"))return;Me=!0;let e=document.createElement("div");e.className="crm-alert-banner provider-paid",e.id="provider-paid-alert",e.setAttribute("data-alert-type","provider-paid");let t=document.createElement("span");t.className="alert-icon",t.innerHTML="\u26A0\uFE0F",e.appendChild(t);let o=document.createElement("span");o.className="alert-message",o.textContent="This patient has Provider Paid status. Special billing rules apply.";let i=document.createElement("span");i.className="countdown-timer",i.textContent="30",o.appendChild(i),e.appendChild(o),document.body.appendChild(e),_t(e),setTimeout(()=>{e.classList.add("show"),document.body.classList.add("has-alert")},10),K.add("provider-paid");let n=document.getElementById("mcp-crm-header");n&&n.style.display==="none"?document.body.classList.add("no-header"):document.body.classList.remove("no-header"),console.log("[CRM Extension] Provider Paid alert shown");let r=15,a=setInterval(()=>{r--,i&&(i.textContent=r),r<=0&&(clearInterval(a),xe("provider-paid"))},1e3)}function _t(e){let t=K.size;t===1?e.classList.add("second-alert"):t===2&&e.classList.add("third-alert")}function xe(e){let t=document.querySelector(`.crm-alert-banner[data-alert-type="${e}"]`);t&&(t.classList.remove("show"),K.delete(e),setTimeout(()=>{t.parentNode&&t.parentNode.removeChild(t),K.size===0&&document.body.classList.remove("has-alert"),Ht()},300))}function Ht(){document.querySelectorAll(".crm-alert-banner").forEach((t,o)=>{t.classList.remove("second-alert","third-alert"),o===1?t.classList.add("second-alert"):o===2&&t.classList.add("third-alert")})}console.log("[CRM Extension] Content script injected.");var Z=typeof browser<"u"?browser:chrome;Z.runtime.sendMessage({action:"loadSettings"}).then(e=>{e&&e.success&&(console.log("[CRM Extension] Settings loaded from browser storage on startup:",e.settings),document.getElementById("mcp-crm-header")||_())}).catch(e=>{console.error("[CRM Extension] Error requesting settings on startup:",e)});localStorage.getItem("crmplus_headerBarVisible")===null?(console.log("[CRM Extension] No local toolbar visibility setting, requesting from browser storage"),Z.runtime.sendMessage({action:"loadSettings"}).then(e=>{e&&e.success?(console.log("[CRM Extension] Settings loaded from browser storage:",e.settings),_()):(console.error("[CRM Extension] Failed to load settings, using defaults"),localStorage.setItem("crmplus_headerBarVisible","true"),_())}).catch(e=>{console.error("[CRM Extension] Error requesting settings:",e),localStorage.setItem("crmplus_headerBarVisible","true"),_()})):(console.log("[CRM Extension] Using existing localStorage settings"),_());function _(){let e=localStorage.getItem("crmplus_headerBarVisible")!=="false";console.log("[CRM Extension] Header visibility setting on init:",e);try{console.log("[CRM Extension] Creating fixed header..."),Re(),Ne(e)}catch(t){console.error("[CRM Extension] Error creating fixed header:",t)}try{Ie(t=>{console.log(`[CRM Extension] Intercepted console message: ${t}`)})}catch(t){console.error("[CRM Extension] Error initializing console monitor:",t)}try{gt()}catch(t){console.error("[CRM Extension] Error initializing auto phone copy:",t)}try{bt()}catch(t){console.error("[CRM Extension] Error initializing alert system:",t)}try{Ue()}catch(t){console.error("[CRM Extension] Error initializing tag removal system:",t)}try{Ye()}catch(t){console.error("[CRM Extension] Error initializing automation removal system:",t)}I()}Z.runtime.onMessage.addListener((e,t,o)=>{if(console.log("[CRM Extension] Received message:",e),e.action==="toggleHeaderVisibility"){console.log("[CRM Extension] Toggling header visibility to:",e.isVisible);try{let i=Ne(e.isVisible);localStorage.setItem("crmplus_headerBarVisible",e.isVisible.toString()),Z.runtime.sendMessage({action:"syncSettings"}).catch(n=>console.error("[CRM Extension] Error syncing settings:",n)),o({success:i})}catch(i){console.error("[CRM Extension] Error toggling header visibility:",i),o({success:!1,error:i.message})}return!0}return!1});document.addEventListener("DOMContentLoaded",()=>{console.log("[CRM Extension] DOM fully loaded, checking visibility setting"),document.getElementById("mcp-crm-header")||Z.runtime.sendMessage({action:"loadSettings"}).then(e=>{e&&e.success&&_()}).catch(()=>{localStorage.setItem("crmplus_headerBarVisible","true"),_()})});})();
