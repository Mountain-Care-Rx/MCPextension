(()=>{var fr=Object.create;var At=Object.defineProperty;var xr=Object.getOwnPropertyDescriptor;var yr=Object.getOwnPropertyNames;var Cr=Object.getPrototypeOf,br=Object.prototype.hasOwnProperty;var Er=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports),ye=(e,t)=>{for(var n in t)At(e,n,{get:t[n],enumerable:!0})},Lt=(e,t,n,o)=>{if(t&&typeof t=="object"||typeof t=="function")for(let r of yr(t))!br.call(e,r)&&r!==n&&At(e,r,{get:()=>t[r],enumerable:!(o=xr(t,r))||o.enumerable});return e},F=(e,t,n)=>(Lt(e,t,"default"),n&&Lt(n,t,"default")),Vn=(e,t,n)=>(n=e!=null?fr(Cr(e)):{},Lt(t||!e||!e.__esModule?At(n,"default",{value:e,enumerable:!0}):n,e));var Jt=Er(()=>{});function Dn(e){if(window.__crmConsoleMonitor)return;window.__crmConsoleMonitor=!0;let t=console.log,n=console.error,o=console.warn;console.log=function(...r){t.apply(console,r),!(typeof r[0]=="string"&&r[0].includes("[CRM Extension]"))&&It(r,"log",e)},console.error=function(...r){n.apply(console,r),!(typeof r[0]=="string"&&r[0].includes("[CRM Extension]"))&&It(r,"error",e)},console.warn=function(...r){o.apply(console,r),!(typeof r[0]=="string"&&r[0].includes("[CRM Extension]"))&&It(r,"warn",e)}}function It(e,t,n){let o=e.join(" ");["error","failed","unauthorized","critical"].some(s=>o.toLowerCase().includes(s))&&n(o)}var zn=window.location.href,Se="";function qe(){if(!_n())return"";let e=document.querySelector('input[name="contact.phone"]');if(e&&e.value.trim()!=="")return e.value.trim();let t=document.querySelector(".phone-number .number");if(t&&t.textContent.trim()!=="")return t.textContent.trim();let n=['input[placeholder="Phone"]','input[placeholder="Phone Number"]',".patient-info .phone",".contact-info .phone","span.phone",'label[for*="phone"]',".phone-display",'div[data-field="phone"]','span[data-field="phone_number"]'];for(let o of n){let r=document.querySelector(o);if(r)if(r.tagName==="INPUT"){let s=r.value.trim();if(s)return s}else if(r.tagName==="LABEL"){let s=r.getAttribute("for");if(s){let a=document.getElementById(s);if(a&&a.value.trim())return a.value.trim()}let i=r.parentElement?.querySelector("input");if(i&&i.value.trim())return i.value.trim()}else{let s=r.textContent.trim();if(s)return s}}return""}function _n(){let e=window.location.href;return[/\/patient\/\d+/i,/\/contact\/\d+/i,/\/profile\/\d+/i,/[?&]patient_id=\d+/i,/[?&]contact_id=\d+/i].some(o=>o.test(e))?!0:['input[name="contact.phone"]','input[name="contact.first_name"]','input[name="contact.last_name"]','input[name="contact.date_of_birth"]',".patient-info",".contact-details",".patient-header",".patient-profile"].some(o=>document.querySelector(o)!==null)}function Fn(e){try{let t=e?Sr(e):"";if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("phone",t);else{let n=document.getElementById("phone-text");if(n){n.textContent=t;let o=document.getElementById("phone-display");o&&(e?o.setAttribute("data-value",e):o.removeAttribute("data-value"))}}}catch(t){console.error("[CRM Extension] Error updating phone display:",t)}}function X(){Se="",Fn("");try{let e=document.getElementById("phone-display");e&&e.removeAttribute("data-value")}catch(e){console.error("[CRM Extension] Error clearing phone display:",e)}}function Sr(e){if(!e)return"";let t=e.replace(/\D/g,"");if(t.length===0)return"";if(t.length===10)return`(${t.substring(0,3)}) ${t.substring(3,6)}-${t.substring(6)}`;if(t.length===11&&t.startsWith("1"))return`(${t.substring(1,4)}) ${t.substring(4,7)}-${t.substring(7)}`;if(t.length>4){let n="";for(let o=0;o<t.length;o+=3)if(o+4>=t.length&&t.length%3!==0){n+=" "+t.substring(o);break}else n+=" "+t.substring(o,o+3);return n.trim()}return t.replace(/(\d{3})/g,"$1 ").trim()}function We(){try{if(!_n())return Se&&X(),!1;let e=qe();return e?(e!==Se&&(Se=e,Fn(e)),!0):(Se&&X(),!1)}catch(e){return console.error("[CRM Extension] Error detecting phone number:",e),!1}}function On(){X(),We();let e=setInterval(()=>{let t=window.location.href;t!==zn&&(console.log("[CRM Extension] URL changed, resetting phone detection"),zn=t,X()),We()},200);try{let t=new MutationObserver(o=>{We()}),n=document.body;t.observe(n,{childList:!0,subtree:!0,characterData:!0,attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] Phone number mutation observer active")}catch(t){console.error("[CRM Extension] Error setting up phone mutation observer:",t)}}function $n(e){let t=qe();if(!t){y("No phone number found");return}let n=Rt(t);if(!n){y("Invalid phone number format");return}e.setAttribute("data-value",t),we(n).then(o=>{y(o?"Copied: "+n:"Failed to copy phone number")})}function Rt(e){if(!e)return"";let t=e.replace(/\D/g,"");return t.length<7?"":"+1"+t}async function we(e){if(navigator.clipboard&&navigator.clipboard.writeText)try{return await navigator.clipboard.writeText(e),!0}catch(t){console.warn("Clipboard API failed, trying fallback method:",t)}try{let t=document.createElement("textarea");t.value=e,t.style.position="fixed",t.style.top="0",t.style.left="0",t.style.opacity="0",t.style.pointerEvents="none",document.body.appendChild(t),t.focus(),t.select();let n=document.execCommand("copy");return document.body.removeChild(t),n}catch(t){return console.error("All clipboard methods failed:",t),!1}}function y(e,t=2e3){let n=document.getElementById("crm-plus-toast-container");n||(n=document.createElement("div"),n.id="crm-plus-toast-container",n.style.position="fixed",n.style.bottom="20px",n.style.right="20px",n.style.zIndex="100000",document.body.appendChild(n));let o=document.createElement("div");o.textContent=e,o.style.background="#333",o.style.color="#fff",o.style.padding="10px",o.style.borderRadius="5px",o.style.marginTop="10px",o.style.boxShadow="0 2px 5px rgba(0,0,0,0.2)",o.style.transition="opacity 0.5s, transform 0.5s",o.style.opacity="0",o.style.transform="translateY(20px)",n.appendChild(o),o.offsetWidth,o.style.opacity="1",o.style.transform="translateY(0)",setTimeout(()=>{o.style.opacity="0",o.style.transform="translateY(20px)",setTimeout(()=>{o.parentNode&&o.parentNode.removeChild(o),n.childNodes.length===0&&document.body.removeChild(n)},500)},t)}var jn=window.location.href;function ve(e){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("name",e);else{let t=document.getElementById("name-text");if(t){t.textContent=e;let n=document.getElementById("name-display");n&&n.setAttribute("data-value",e)}}}catch(t){console.error("[CRM Extension] Error updating name display:",t)}}function Ge(){try{let e=document.querySelector('input[name="contact.first_name"]'),t=document.querySelector('input[name="contact.last_name"]');if(e&&e.value&&t&&t.value){let r=`${e.value} ${t.value}`;return ve(r),!0}let n=document.querySelectorAll(".patient-name, .contact-name, h1.name, .customer-name");for(let r of n)if(r&&r.textContent&&r.textContent.trim()!==""){let s=r.textContent.trim();return ve(s),!0}let o=["span.name",".profile-name","h2.name",".contact-header .name",'div[data-field="name"]',".patient-info .name"];for(let r of o){let s=document.querySelector(r);if(s&&s.textContent&&s.textContent.trim()!==""){let i=s.textContent.trim();return ve(i),!0}}return!1}catch(e){return console.error("[CRM Extension] Error detecting name:",e),!1}}function Hn(){Ge();let e=setInterval(()=>{let t=window.location.href;t!==jn&&(console.log("[CRM Extension] URL changed, resetting name detection"),jn=t,ve(""),Ge());let n=document.getElementById("name-text");n&&(n.textContent==="Loading..."||!n.textContent)&&Ge()},1e3);try{let t=new MutationObserver(o=>{o.some(s=>s.addedNodes.length>5||s.removedNodes.length>5)&&(console.log("[CRM Extension] Significant DOM changes detected, rechecking name"),ve(""),Ge())}),n=document.querySelector("main")||document.body;t.observe(n,{childList:!0,subtree:!0})}catch(t){console.error("[CRM Extension] Error setting up navigation observer for name:",t)}}var Wn=window.location.href;function Ye(e){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("dob",e);else{let t=document.getElementById("dob-text");if(t){t.textContent=e;let n=document.getElementById("dob-display");n&&n.setAttribute("data-value",e)}}}catch(t){console.error("[CRM Extension] Error updating DOB display:",t)}}function qn(e){if(!e)return"";if(e.match(/^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2}(st|nd|rd|th)?\s+\d{4}$/))try{let t=e.match(/(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+(\d{1,2})(st|nd|rd|th)?\s+(\d{4})/);if(t){let n=t[1],o=t[2],r=t[4];return`${(["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"].indexOf(n)+1).toString().padStart(2,"0")}/${o.toString().padStart(2,"0")}/${r}`}}catch(t){console.error("[CRM Extension] Error parsing date:",t)}try{let t=new Date(e);if(!isNaN(t.getTime()))return`${(t.getMonth()+1).toString().padStart(2,"0")}/${t.getDate().toString().padStart(2,"0")}/${t.getFullYear()}`}catch(t){console.error("[CRM Extension] Error parsing date as Date object:",t)}return e}function Je(){try{let e=document.querySelector('input[name="contact.date_of_birth"]');if(e&&e.value){let n=qn(e.value);return Ye(n),!0}let t=[".dob",".patient-dob",".contact-dob",'span[data-field="date_of_birth"]','div[data-field="dob"]',".patient-info .dob",".contact-info .dob"];for(let n of t){let o=document.querySelector(n);if(o&&o.textContent&&o.textContent.trim()!==""){let r=qn(o.textContent.trim());return Ye(r),!0}}return!1}catch(e){return console.error("[CRM Extension] Error detecting DOB:",e),!1}}function Gn(){Je();let e=setInterval(()=>{let t=window.location.href;t!==Wn&&(console.log("[CRM Extension] URL changed, resetting DOB detection"),Wn=t,Ye(""),Je());let n=document.getElementById("dob-text");n&&(n.textContent==="Loading..."||!n.textContent)&&Je()},1e3);try{let t=new MutationObserver(o=>{o.some(s=>s.addedNodes.length>5||s.removedNodes.length>5)&&(console.log("[CRM Extension] Significant DOM changes detected, rechecking DOB"),Ye(""),Je())}),n=document.querySelector("main")||document.body;t.observe(n,{childList:!0,subtree:!0})}catch(t){console.error("[CRM Extension] Error setting up navigation observer for DOB:",t)}}var Jn=window.location.href,Ke="";function Yn(e){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("srxid",e);else{let t=document.getElementById("srxid-text");if(t){t.textContent=e;let n=document.getElementById("srxid-display");n&&n.setAttribute("data-value",e)}}}catch(t){console.error("[CRM Extension] Error updating SRx ID display:",t)}}function ke(){try{let e=document.querySelector('input[name="contact.srx_id"]');if(e&&e.value){let t=e.value.trim();if(t&&/^\d+$/.test(t))return t!==Ke&&(console.log("[CRM Extension] Found SRx ID from contact.srx_id input:",t),Ke=t,Yn(t)),!0}return!!Ke}catch(e){return console.error("[CRM Extension] Error detecting SRx ID:",e),!1}}function Kn(){ke();let e=setInterval(()=>{let t=window.location.href;t!==Jn&&(console.log("[CRM Extension] URL changed, resetting SRx ID detection"),Jn=t,Ke="",Yn(""),ke()),ke()},500);try{new MutationObserver(n=>{let o=!1;for(let r of n){if(r.target.tagName==="INPUT"&&r.target.name==="contact.srx_id"||r.target.querySelector&&r.target.querySelector('input[name="contact.srx_id"]')){o=!0;break}if(r.addedNodes.length>0){for(let s of r.addedNodes)if(s.nodeType===1&&s.querySelector&&(s.tagName==="INPUT"&&s.name==="contact.srx_id"||s.querySelector('input[name="contact.srx_id"]'))){o=!0;break}}}o&&ke()}).observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] SRx ID mutation observer active")}catch(t){console.error("[CRM Extension] Error setting up observer for SRx ID:",t)}setTimeout(()=>{try{let t=document.querySelector('input[name="contact.srx_id"]');t&&(new MutationObserver(o=>{ke()}).observe(t,{attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] Direct input observer attached to contact.srx_id"))}catch(t){console.error("[CRM Extension] Error setting up direct input observer:",t)}},1e3)}var Ze=["np-tirz-1.5ml-inj","refill-sema-inj","refill-tirz-inj","vial-sema-b12","vial-sema-b6","vial-sema-lipo","vial-sema-nad+","vial-tirz-cyano","vial-tirz-nad+","vial-tirz-pyridoxine","np-sema-0.125ml-inj","np-sema-0.25ml-inj","np-sema-0.5ml-inj","np-sema-0.75ml-inj","np-sema-1.0ml-inj","np-sema-1.25ml-inj","np-sema-1.5ml-inj","np-sema-2.0ml-inj","np-tirz-0.25ml-inj","np-tirz-0.5ml-inj","np-tirz-0.75ml-inj","np-tirz-1.0ml-inj","np-tirz-1.25ml-inj"],J=[];function Zn(){console.log("[CRM Extension] Tag removal system initialized")}function wr(){J=[];try{let e=document.querySelectorAll(".tag, .tag-label, .pill, .badge");for(let r of e){let s=r.textContent.trim().toLowerCase();Ze.some(i=>s.includes(i))&&J.push({element:r,text:s})}let t=document.querySelectorAll("[data-tag]");for(let r of t){let s=r.getAttribute("data-tag").toLowerCase();Ze.some(i=>s.includes(i))&&J.push({element:r,text:s})}let n=document.querySelectorAll(".tags-container, .tag-list, .tags");for(let r of n){let s=r.querySelectorAll("*");for(let i of s)if(i.nodeType===1){let a=i.textContent.trim().toLowerCase();Ze.some(l=>a.includes(l))&&(J.some(l=>l.element===i)||J.push({element:i,text:a}))}}let o=document.querySelectorAll("*[class]");for(let r of o){let s=r.className.toLowerCase();s&&typeof s=="string"&&Ze.some(i=>s.includes(i))&&(J.some(i=>i.element===r)||J.push({element:r,text:r.textContent.trim().toLowerCase()}))}return console.log(`[CRM Extension] Found ${J.length} removable tags`),J}catch(e){return console.error("[CRM Extension] Error detecting tags:",e),[]}}function vr(e){try{let t=e.querySelector('.close, .remove, .delete, .tag-remove, [aria-label="Remove"], .x-button');if(t)return console.log("[CRM Extension] Found close button in tag, clicking it"),t.click(),!0;let n=e.parentElement;if(n){let s=n.querySelector('.close, .remove, .delete, .tag-remove, [aria-label="Remove"], .x-button');if(s)return console.log("[CRM Extension] Found close button as sibling, clicking it"),s.click(),!0}let o=[...Array.from(e.querySelectorAll("*")),...Array.from(n?n.children:[])];for(let s of o){let i=s.textContent.trim();if(i==="\xD7"||i==="x"||i==="\u2715"||i==="\u2716"||i==="X")return console.log("[CRM Extension] Found X button by text content, clicking it"),s.click(),!0;if(s.className&&(s.className.includes("close")||s.className.includes("delete")||s.className.includes("remove")||s.className.includes("x-button")))return console.log("[CRM Extension] Found X button by class name, clicking it"),s.click(),!0;if(s.classList&&(s.classList.contains("fa-times")||s.classList.contains("fa-close")||s.classList.contains("icon-close")||s.classList.contains("icon-remove")))return console.log("[CRM Extension] Found X button by icon class, clicking it"),s.click(),!0}if(e.tagName==="BUTTON"||e.tagName==="A"||e.getAttribute("role")==="button"||window.getComputedStyle(e).cursor==="pointer")return console.log("[CRM Extension] Tag appears to be clickable, clicking it"),e.click(),!0;let r=n;for(let s=0;s<3&&r;s++){let i=r.querySelectorAll("button, span, i, div");for(let a of i){let l=a.textContent.trim();if(l==="\xD7"||l==="x"||l==="\u2715"||l==="\u2716"||l==="X"||a.classList.contains("fa-times")||a.classList.contains("fa-close")||a.classList.contains("close")||a.classList.contains("remove"))return console.log("[CRM Extension] Found X button in parent container, clicking it"),a.click(),!0}r=r.parentElement}return console.log("[CRM Extension] No method found to remove tag:",e),!1}catch(t){return console.error("[CRM Extension] Error removing tag:",t),!1}}function Nt(){return new Promise((e,t)=>{try{let r=function(s){if(s>=J.length){console.log(`[CRM Extension] Removed ${n}/${o} tags`),e({success:!0,message:`Removed ${n} of ${o} tags`,removed:n,total:o});return}let i=J[s];console.log(`[CRM Extension] Removing tag: ${i.text}`),vr(i.element)&&n++,setTimeout(()=>{r(s+1)},300)};wr();let n=0,o=J.length;if(o===0){console.log("[CRM Extension] No removable tags found"),e({success:!0,message:"No tags to remove",removed:0,total:0});return}console.log(`[CRM Extension] Attempting to remove ${o} tags`),r(0)}catch(n){console.error("[CRM Extension] Error in removeAllTags:",n),t(n)}})}var kr=["Workflow - New Patient - Semaglutide 0.125ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 0.25ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 0.5ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 0.75ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 1.0ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 1.25ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 1.5ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 2.0ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 0.25ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 0.5ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 0.75ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 1.0ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 1.25ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 1.5ml Onboarding - (Step 1)","Workflow - Refill - Semaglutide/B12 Injection Refill Order - (Step 1)","Workflow - Semaglutide/B12 Vial Order - (Step 1)","Workflow - Semaglutide/B6 Vial Order - (Step 1)","Workflow - Semaglutide/Lipo Vial Order - (Step 1)","Workflow - Semaglutide/NAD+ Vial Order - (Step 1)","Workflow - Syringe - Tirzepatide/Pyridoxine Injection Order - (Step 1)","Workflow - Tirzepatide/Cyano Vial Order - (Step 1)","Workflow - Tirzepatide/NAD+ Vial Order - (Step 1)","Workflow - Tirzepatide/Pyridoxine Vial Order - (Step 1)"],Qe=[];function ee(e){try{if(e&&typeof e.getBoundingClientRect=="function")return e.getBoundingClientRect()}catch{}return{top:0,bottom:0,left:0,right:0,width:0,height:0}}function eo(){console.log("[CRM Extension] Automation removal system initialized")}function Mr(){Qe=[];try{let e=to("Active");return e?(Qe=(e.workflows.length?e.workflows:Lr(e.label)).filter(n=>{if(!n)return!1;let o=(n.textContent||"").trim();return o.includes("Workflow")&&kr.some(r=>o.includes(r))}),console.log(`[CRM Extension] Found ${Qe.length} automation(s) in Active section.`),Qe):(console.log("[CRM Extension] Active section not found."),[])}catch(e){return console.error("[CRM Extension] Error detecting automations:",e),[]}}function Lr(e){let t=ee(e).bottom,n=null,o=to("Past");return o&&o.label&&(n=ee(o.label).top),Array.from(document.querySelectorAll('div[id^="workflow_"], div[data-workflow-id]')).filter(s=>{let i=ee(s);return!(i.top<t||n&&i.top>=n)})}function to(e){try{let n=Array.from(document.querySelectorAll("div.py-2")).find(s=>(s.textContent||"").trim()===e);if(n)return{label:n,workflows:e==="Active"?Ar(n):Ir(n)};let o=e==="Active"?'[data-automation="Active"], #automation-active':'[data-automation="Past"], #automation-past',r=document.querySelector(o);return r?{label:r,workflows:[]}:null}catch(t){return console.error(`[CRM Extension] Error finding section for "${e}":`,t),null}}function Ar(e){let t=ee(e).bottom,o=Array.from(document.querySelectorAll("div.py-2")).find(i=>(i.textContent||"").trim()==="Past"),r=o?ee(o).top:null;return Array.from(document.querySelectorAll('div[id^="workflow_"], div[data-workflow-id]')).filter(i=>{let a=ee(i);return a.top>t&&(!r||a.top<r)})}function Ir(e){let t=ee(e).bottom;return Array.from(document.querySelectorAll('div[id^="workflow_"], div[data-workflow-id]')).filter(o=>ee(o).top>t)}function Rr(e){if(!e)return console.error("[CRM Extension] removeAutomation called with undefined element."),!1;try{let t=ee(e),n=t.width>0&&t.height>0,o=t.top>=0&&t.left>=0&&t.bottom<=(window.innerHeight||document.documentElement.clientHeight);return!n||!o?(e.scrollIntoView({behavior:"smooth",block:"center"}),new Promise(r=>{setTimeout(()=>r(Qn(e)),500)})):Qn(e)}catch(t){return console.error("[CRM Extension] Error removing automation:",t),!1}}function Qn(e){if(!e)return!1;try{let t=e.querySelectorAll("i.icon-close, i.icon.icon-close");if(t.length)return t[0].click(),!0}catch(t){console.error("[CRM Extension] Error in Strategy 1:",t)}try{let t=e.querySelectorAll("a");for(let n of t){let o=(n.textContent||"").trim();if(o==="\xD7"||o.toLowerCase()==="x")return n.click(),!0}}catch(t){console.error("[CRM Extension] Error in Strategy 2:",t)}try{let t=e.querySelectorAll('button, .btn, [role="button"]');for(let n of t)if((n.textContent||"").toLowerCase().includes("manage"))return n.click(),setTimeout(()=>{document.querySelectorAll(".dropdown-menu .dropdown-item, .menu-item").forEach(s=>{let i=(s.textContent||"").toLowerCase();(i.includes("remove")||i.includes("delete"))&&s.click()})},300),!0}catch(t){console.error("[CRM Extension] Error in Strategy 3:",t)}if(e.id&&e.id.startsWith("workflow_")){let t=e.id;try{let n=`#${t} i.icon-close, #${t} i.icon.icon-close`,o=document.querySelector(n);if(o)return o.click(),!0;n=`#${t} .remove, #${t} .close`;let r=document.querySelector(n);if(r)return r.click(),!0}catch(n){console.error("[CRM Extension] Error in Strategy 4:",n)}}try{let t=e.querySelectorAll("span");for(let n of t){let o=(n.textContent||"").trim();if(o==="\xD7"||o.toLowerCase()==="x")return n.click(),!0}}catch(t){console.error("[CRM Extension] Error in Strategy 5:",t)}try{let t=e.nextElementSibling,n=0;for(;t&&n<3;){if(t.classList&&(t.classList.contains("close")||t.classList.contains("remove"))||t.textContent&&(t.textContent.trim()==="\xD7"||t.textContent.trim().toLowerCase()==="x"))return t.click(),!0;let o=t.querySelector("i.icon-close, i.icon.icon-close");if(o)return o.click(),!0;t=t.nextElementSibling,n++}}catch(t){console.error("[CRM Extension] Error in Strategy 6:",t)}try{let t=ee(e),n=t.right-10,o=t.top+t.height/2,r=document.elementsFromPoint(n,o);for(let i of r)if(i!==e)return i.click(),!0;let s=new MouseEvent("click",{view:window,bubbles:!0,cancelable:!0,clientX:n,clientY:o});return(r[0]||document.elementFromPoint(n,o))?.dispatchEvent(s),!0}catch(t){console.error("[CRM Extension] Error in Strategy 7:",t)}return console.error("[CRM Extension] No method found to remove automation:",e),!1}function Xn(){return new Promise(e=>{setTimeout(()=>{if(document.querySelectorAll('.modal, [role="dialog"], .dialog').length){let n=document.querySelectorAll('.modal .btn-primary, .modal .btn-danger, .modal .confirm-btn, [role="dialog"] .btn-primary, .modal button, [role="dialog"] button');for(let r of n){let s=(r.textContent||"").trim().toLowerCase();if(["delete","remove","yes","confirm","ok","continue"].includes(s)){r.click(),e(!0);return}}let o=document.querySelectorAll('.modal button, [role="dialog"] button, .dialog button');if(o.length){o[o.length-1].click(),e(!0);return}}e(!1)},500)})}function Tt(){return new Promise((e,t)=>{try{let s=function(i){if(i>=r){e({success:!0,message:`Removed ${o} of ${r} automations`,removed:o,total:r});return}let a=n[i],l=Rr(a.element);l instanceof Promise?l.then(c=>{c&&o++,Xn().then(()=>setTimeout(()=>s(i+1),1e3))}):(l&&o++,Xn().then(()=>setTimeout(()=>s(i+1),1e3)))},n=Mr();if(!n.length){console.log("[CRM Extension] No automations to remove."),e({success:!0,message:"No automations to remove",removed:0,total:0});return}let o=0,r=n.length;s(0)}catch(n){console.error("[CRM Extension] Error in removeAllAutomations:",n),t(n)}})}var P=[];var Xe="crmplus_history";function so(){io(),Tr(),Ur(),window.addEventListener("storage",Nr),console.log("[CRM Extension] History tracking initialized")}function io(){try{let e=localStorage.getItem(Xe);if(e){P=JSON.parse(e);let t=Date.now();P=P.filter(n=>t-n.timestamp<144e5),Ut()}}catch(e){console.error("[CRM Extension] Error loading history:",e),P=[]}}function Ut(){try{localStorage.setItem(Xe,JSON.stringify(P))}catch(e){console.error("[CRM Extension] Error saving history:",e)}}function Nr(e){if(e.key===Xe)try{e.newValue?(P=JSON.parse(e.newValue),console.log("[CRM Extension] History updated from another tab")):(P=[],console.log("[CRM Extension] History cleared from another tab"))}catch(t){console.error("[CRM Extension] Error processing cross-tab history update:",t)}}function Tr(){let e=window.location.href;setInterval(()=>{let o=window.location.href;o!==e&&(e=o,Me(o))},500),Me(window.location.href);let t=history.pushState;history.pushState=function(){t.apply(this,arguments),Me(window.location.href)};let n=history.replaceState;history.replaceState=function(){n.apply(this,arguments),Me(window.location.href)},window.addEventListener("popstate",()=>{Me(window.location.href)})}function Me(e){if(!e)return;let t=e.match(/\/detail\/([^/]+)/);if(t&&t[1]){let n=t[1];setTimeout(()=>{let o=no(),r=oo();o&&o!=="Unknown Patient"?ro(n,o,r,e):(console.log("[CRM Extension] Patient name not found yet, retrying in 3 seconds..."),setTimeout(()=>{let s=no(),i=oo();s&&s!=="Unknown Patient"?ro(n,s,i,e):console.log("[CRM Extension] Could not retrieve patient info after retry, not adding to history")},3e3))},5e3)}}function no(){let e=document.getElementById("name-text");if(e&&e.textContent&&e.textContent.trim()!=="")return e.textContent.trim();let t=document.querySelector('input[name="contact.first_name"]'),n=document.querySelector('input[name="contact.last_name"]');if(t&&t.value&&n&&n.value)return`${t.value} ${n.value}`.trim();let o=[".patient-name",".contact-name","h1.name",".customer-name","span.name",".profile-name","h2.name",".contact-header .name",'div[data-field="name"]',".patient-info .name"];for(let r of o){let s=document.querySelector(r);if(s&&s.textContent&&s.textContent.trim()!=="")return s.textContent.trim()}return"Unknown Patient"}function oo(){let e=document.getElementById("phone-text");if(e&&e.textContent&&e.textContent.trim()!=="")return e.textContent.trim();let t=document.querySelector('input[name="contact.phone"]');if(t&&t.value.trim()!=="")return t.value.trim();let n=[".phone-number .number",'input[placeholder="Phone"]','input[placeholder="Phone Number"]',".patient-info .phone",".contact-info .phone","span.phone",'div[data-field="phone"]','span[data-field="phone_number"]'];for(let o of n){let r=document.querySelector(o);if(r)if(r.tagName==="INPUT"){let s=r.value.trim();if(s)return s}else{let s=r.textContent.trim();if(s)return s}}return""}function ro(e,t,n,o){let s=Date.now(),i=P.findIndex(a=>a.patientId===e);if(i!==-1){let a=P[i];a.timestamp=s,a.patientName=t,a.phoneNumber=n,P.splice(i,1),P.unshift(a)}else P.unshift({patientId:e,patientName:t,phoneNumber:n,url:o,timestamp:s}),P.length>20&&P.pop();Ut()}function Ur(){setInterval(()=>{let e=Date.now(),t=0;P=P.filter(n=>{let o=e-n.timestamp<144e5;return o||t++,o}),t>0&&(console.log(`[CRM Extension] Removed ${t} expired history entries`),Ut())},5*60*1e3)}function ao(){io();let e=Date.now();return P=P.filter(t=>e-t.timestamp<144e5),[...P]}function lo(){P=[],localStorage.removeItem(Xe),console.log("[CRM Extension] History cleared")}function co(e){return new Date(e).toLocaleString("en-US",{hour:"numeric",minute:"2-digit",hour12:!0})}var po="crmplus_chat_audit_log";function d(e,t,n={}){try{let o={timestamp:new Date().toISOString(),category:e,action:t,details:n,username:localStorage.getItem("crmplus_chat_username")||"Unknown",browser:Br(),ip:"127.0.0.1"},r=uo();return r.unshift(o),r.length>1e3&&(r.length=1e3),localStorage.setItem(po,JSON.stringify(r)),!0}catch(o){return console.error("[CRM Extension] Error logging audit event:",o),!1}}function uo(){try{let e=localStorage.getItem(po);return e?JSON.parse(e):[]}catch(e){return console.error("[CRM Extension] Error getting audit log:",e),[]}}function Br(){let e=navigator.userAgent,t="Unknown Browser";return e.includes("Firefox")?t="Firefox":e.includes("Edg")?t="Edge":e.includes("Chrome")?t="Chrome":e.includes("Safari")&&(t="Safari"),t}var et="crmplus_chat_",Pt=`${et}messages`,ho=`${et}channels`,go=`${et}users`,fo=`${et}settings`,mo=100,Pr=24*60*60*1e3;function xo(){try{return Bt(),setInterval(Bt,60*60*1e3),d("storage","Storage system initialized"),console.log("[CRM Extension] Storage system initialized"),!0}catch(e){return console.error("[CRM Extension] Error initializing storage:",e),!1}}function Vt(e){try{if(!e||!e.id)return!1;let t=e.channel||"general",n={...e,stored:Date.now()},o=Dt(),r=o[t]||[],s=r.findIndex(i=>i.id===e.id);return s>=0?r[s]=n:r.unshift(n),r.length>mo&&(r.length=mo),o[t]=r,localStorage.setItem(Pt,JSON.stringify(o)),d("storage",`Message saved from ${e.sender}`,{messageId:e.id,channel:t}),!0}catch(t){return console.error("[CRM Extension] Error saving message:",t),d("storage","Error saving message",{error:t.message}),!1}}function Dt(){try{let e=localStorage.getItem(Pt);return e?JSON.parse(e):{}}catch(e){return console.error("[CRM Extension] Error getting messages map:",e),d("storage","Error getting messages map",{error:e.message}),{}}}function tt(e="general",t=50){try{return(Dt()[e]||[]).slice(0,t)}catch(n){return console.error("[CRM Extension] Error getting channel messages:",n),d("storage","Error getting channel messages",{error:n.message}),[]}}function Bt(){try{let e=Dt(),t=Date.now(),n=0;return Object.keys(e).forEach(o=>{let s=e[o].filter(i=>{let a=i.stored||t,l=t-a>=Pr;return l&&n++,!l});e[o]=s}),localStorage.setItem(Pt,JSON.stringify(e)),n>0&&(d("storage",`Removed ${n} expired messages`),console.log(`[CRM Extension] Removed ${n} expired messages`)),n}catch(e){return console.error("[CRM Extension] Error cleaning up messages:",e),d("storage","Error cleaning up expired messages",{error:e.message}),0}}function nt(e){try{if(!e||!e.id)return!1;let t=ot(),n=t.findIndex(o=>o.id===e.id);return n>=0?t[n]=e:t.push(e),localStorage.setItem(ho,JSON.stringify(t)),d("storage",`Channel saved: ${e.name}`,{channelId:e.id}),!0}catch(t){return console.error("[CRM Extension] Error saving channel:",t),d("storage","Error saving channel",{error:t.message}),!1}}function ot(){try{let e=localStorage.getItem(ho);return e?JSON.parse(e):[]}catch(e){return console.error("[CRM Extension] Error getting channels:",e),d("storage","Error getting channels",{error:e.message}),[]}}function zt(e){try{if(!e||!e.id)return!1;let t=Le(),n=t.findIndex(o=>o.id===e.id);return n>=0?t[n]=e:t.push(e),localStorage.setItem(go,JSON.stringify(t)),d("storage",`User saved: ${e.username}`,{userId:e.id}),!0}catch(t){return console.error("[CRM Extension] Error saving user:",t),d("storage","Error saving user",{error:t.message}),!1}}function Le(){try{let e=localStorage.getItem(go);return e?JSON.parse(e):[]}catch(e){return console.error("[CRM Extension] Error getting users:",e),d("storage","Error getting users",{error:e.message}),[]}}function W(e,t){try{if(!e)return!1;let n=yo();return n[e]=t,localStorage.setItem(fo,JSON.stringify(n)),d("storage",`Setting saved: ${e}`),!0}catch(n){return console.error("[CRM Extension] Error saving setting:",n),d("storage","Error saving setting",{error:n.message}),!1}}function v(e,t=null){try{let n=yo();return e in n?n[e]:t}catch(n){return console.error("[CRM Extension] Error getting setting:",n),d("storage","Error getting setting",{error:n.message}),t}}function yo(){try{let e=localStorage.getItem(fo);return e?JSON.parse(e):{}}catch(e){return console.error("[CRM Extension] Error getting settings:",e),d("storage","Error getting settings",{error:e.message}),{}}}var pe=null,Ce=null,Ot=typeof window<"u"&&window.crypto&&window.crypto.subtle;async function rt(){try{return Ot?(pe=await window.crypto.subtle.generateKey({name:"AES-GCM",length:256},!0,["encrypt","decrypt"]),Ce=window.crypto.getRandomValues(new Uint8Array(12)),console.log("[CRM Extension] Generated secure encryption keys using Web Crypto API")):(pe=Co(32),Ce=Co(16),console.warn("[CRM Extension] Using fallback encryption methods - less secure"),d("security","Using fallback encryption (not recommended for PHI)")),d("security","Generated new encryption keys"),!0}catch(e){return console.error("[CRM Extension] Error generating encryption keys:",e),d("security","Failed to generate encryption keys",{error:e.message}),!1}}function Co(e){let t="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",n="";if(window.crypto&&window.crypto.getRandomValues){let o=new Uint32Array(e);window.crypto.getRandomValues(o);for(let r=0;r<e;r++)n+=t.charAt(o[r]%t.length)}else for(let o=0;o<e;o++)n+=t.charAt(Math.floor(Math.random()*t.length));return n}function _t(e){let t=new ArrayBuffer(e.length),n=new Uint8Array(t);for(let o=0;o<e.length;o++)n[o]=e.charCodeAt(o);return t}function Ft(e){return String.fromCharCode.apply(null,new Uint8Array(e))}async function Vr(e){try{let t=JSON.stringify(e),n=_t(t),o=await window.crypto.subtle.encrypt({name:"AES-GCM",iv:Ce,tagLength:128},pe,n),r=btoa(Ft(o)),s=btoa(Ft(Ce.buffer));return{id:e.id,sender:e.sender,recipient:e.recipient,channel:e.channel,encrypted:!0,encryptionMethod:"AES-GCM",encryptedData:r,iv:s,timestamp:e.timestamp,type:e.type}}catch(t){return console.error("[CRM Extension] Error encrypting with Web Crypto API:",t),bo(e)}}async function Dr(e){try{let t=_t(atob(e.encryptedData)),n=_t(atob(e.iv)),o=new Uint8Array(n),r=await window.crypto.subtle.decrypt({name:"AES-GCM",iv:o,tagLength:128},pe,t),s=Ft(r);return JSON.parse(s)}catch(t){throw console.error("[CRM Extension] Error decrypting with Web Crypto API:",t),t}}function bo(e){try{let t=JSON.stringify(e),n=Eo(t,pe);return{id:e.id,sender:e.sender,recipient:e.recipient,channel:e.channel,encrypted:!0,encryptionMethod:"XOR",encryptedData:n,timestamp:e.timestamp,type:e.type}}catch(t){return console.error("[CRM Extension] Error in legacy encryption:",t),{...e,encrypted:!1}}}function zr(e){try{let t=Eo(e.encryptedData,pe);return JSON.parse(t)}catch(t){throw console.error("[CRM Extension] Error in legacy decryption:",t),t}}function Eo(e,t){let n="";for(let o=0;o<e.length;o++){let r=e.charCodeAt(o)^t.charCodeAt(o%t.length);n+=String.fromCharCode(r)}return btoa(n)}async function $t(e){try{return e?((!pe||!Ce)&&await rt(),Ot?await Vr(e):bo(e)):null}catch(t){return console.error("[CRM Extension] Error encrypting message:",t),d("security","Encryption error",{error:t.message}),{...e,encrypted:!1}}}async function jt(e){try{if(!e||!e.encrypted)return e;if(!pe||!Ce)throw new Error("Encryption keys not available");return e.encryptionMethod==="AES-GCM"&&Ot?await Dr(e):zr(e)}catch(t){return console.error("[CRM Extension] Error decrypting message:",t),d("security","Decryption error",{error:t.message}),{id:e.id||_r(),sender:e.sender||"Unknown",text:"[Encrypted message - unable to decrypt]",timestamp:e.timestamp||new Date().toISOString(),type:e.type||"chat",channel:e.channel||"general"}}}function _r(){return Date.now().toString(36)+Math.random().toString(36).substr(2,5)}var g={};ye(g,{PermissionCatalog:()=>ko,addAuthListener:()=>Re,createRole:()=>ns,createUser:()=>Mo,default:()=>ts,deleteRole:()=>rs,deleteUser:()=>Yt,forceLogoutUser:()=>Ao,generateUserImportTemplate:()=>as,getAllPermissions:()=>So,getAllRoles:()=>ss,getAllUsers:()=>Kt,getAuthToken:()=>be,getAvailablePermissions:()=>is,getCurrentUser:()=>C,getPermissionsForRole:()=>vo,getSessionStatus:()=>re,hasPermission:()=>V,importUsers:()=>Zt,initAuth:()=>dt,isAuthenticated:()=>S,login:()=>ge,logout:()=>te,removeAuthListener:()=>qt,resetUserPassword:()=>Qt,updateLastActivity:()=>pt,updateRole:()=>os,updateUser:()=>Lo,validatePermissions:()=>wo});var Gt={};ye(Gt,{addAuthListener:()=>Re,getAuthToken:()=>be,getCurrentUser:()=>C,getSessionStatus:()=>re,hasPermission:()=>V,initAuth:()=>dt,isAuthenticated:()=>S,login:()=>ge,logout:()=>te,removeAuthListener:()=>qt,updateLastActivity:()=>pt});var st={};ye(st,{PermissionCatalog:()=>ko,getAllPermissions:()=>So,getPermissionsForRole:()=>vo,hasPermission:()=>V,validatePermissions:()=>wo});var O={USER:{VIEW:"user.view",CREATE:"user.create",UPDATE:"user.update",DELETE:"user.delete",MANAGE_ROLES:"user.manage_roles"},CHANNEL:{VIEW:"channel.view",CREATE:"channel.create",UPDATE:"channel.update",DELETE:"channel.delete",INVITE:"channel.invite"},MESSAGE:{VIEW:"message.view",CREATE:"message.create",UPDATE:"message.update",DELETE:"message.delete",UPDATE_OWN:"message.update.own",DELETE_OWN:"message.delete.own"},ADMIN:{SYSTEM_SETTINGS:"admin.system_settings",AUDIT_LOG:"admin.audit_log",MANAGE_ROLES:"admin.manage_roles"}},Ht={admin:Object.values(O).flatMap(Object.values),moderator:[O.USER.VIEW,O.CHANNEL.VIEW,O.CHANNEL.CREATE,O.MESSAGE.VIEW,O.MESSAGE.CREATE,O.MESSAGE.DELETE],user:[O.MESSAGE.CREATE,O.MESSAGE.VIEW,O.MESSAGE.UPDATE_OWN,O.MESSAGE.DELETE_OWN,O.CHANNEL.VIEW]};function V(e){if(!S())return!1;let t=C();return t.role==="admin"?!0:(Ht[t.role]||[]).includes(e)}function So(){let e=C();return!e||e.role!=="admin"?(d("permissions","Unauthorized permissions access attempt",{requestingUser:e?.username||"unauthenticated"}),null):{catalog:O,roleSets:Ht}}function wo(e){let t=Object.values(O).flatMap(Object.values),n=e.filter(o=>!t.includes(o));return{valid:n.length===0,invalidPermissions:n}}function vo(e){let t=C();return!t||t.role!=="admin"?(d("permissions","Unauthorized role permissions access",{requestedRole:e,requestingUser:t?.username||"unauthenticated"}),[]):Ht[e]||[]}var ko=O;var at="crmplus_chat_auth_token",lt="crmplus_chat_user_info",it=15*60*1e3,j=null,he=null,ct=Date.now(),oe=null,Ie=[],Ae={username:"CBarnett",password:"Admin123",role:"admin",displayName:"Admin"};function Wt(e=null){let t={authenticated:S(),user:C()};Ie.forEach(n=>{try{n(t,e)}catch(o){console.error("[CRM Extension] Error in auth listener:",o)}})}function Re(e){typeof e=="function"&&!Ie.includes(e)&&Ie.push(e)}function qt(e){let t=Ie.indexOf(e);t!==-1&&Ie.splice(t,1)}function dt(){try{return Fr(),ut(),$r(),Or(),d("auth","Authentication service initialized"),!0}catch(e){return console.error("[CRM Extension] Error initializing auth service:",e),!1}}function re(){return{authenticated:S(),user:C(),lastActivity:ct,sessionTimeout:it}}function Fr(){try{let e=localStorage.getItem(at);e&&(he=e);let t=localStorage.getItem(lt);t&&(j=JSON.parse(t)),he&&j&&(ct=Date.now(),Wt(),console.log("[CRM Extension] Loaded saved authentication data"),d("auth","Restored authentication session",{username:j.username}))}catch(e){console.error("[CRM Extension] Error loading saved auth data:",e),localStorage.removeItem(at),localStorage.removeItem(lt)}}function Or(){v("admin_account_created",!1)||(console.log("[CRM Extension] Setting up initial admin account"),W("admin_account_created",!0),d("auth","Initial admin account setup completed"))}function $r(){["mousedown","keydown","touchstart","click"].forEach(t=>{document.addEventListener(t,()=>{pt()})})}function pt(){ct=Date.now(),oe&&clearTimeout(oe),S()&&ut()}function ut(){oe&&clearTimeout(oe),S()&&(oe=setTimeout(()=>{let e=Date.now()-ct;if(e>=it)d("auth","Session timed out due to inactivity",{username:j?.username,inactiveTime:Math.round(e/1e3)+" seconds"}),te("Session timed out due to inactivity");else{let t=it-e;oe=setTimeout(ut,t)}},it))}async function ge(e,t){try{if(!e||!t)throw new Error("Username and password are required");d("auth","Login attempt",{username:e});let o=(localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000").replace("ws://","http://").replace("wss://","https://"),r=null;if(e===Ae.username&&t===Ae.password)r={success:!0,token:"admin_"+Date.now().toString(36)+Math.random().toString(36).substr(2),user:{id:"admin_"+Math.random().toString(36).substr(2),username:Ae.username,role:Ae.role,displayName:Ae.displayName,isAdmin:!0}};else try{let s=await fetch(`${o}/auth/login`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username:e,password:t})});if(!s.ok){let i=await s.json();throw new Error(i.message||"Login failed")}r=await s.json()}catch(s){if(console.error("[CRM Extension] Server auth error:",s),v("allow_local_auth",!1)){let a=v("local_users",[]).find(l=>l.username===e);if(a&&a.password===t)r={success:!0,token:"local_"+Date.now().toString(36)+Math.random().toString(36).substr(2),user:{id:a.id||"user_"+Math.random().toString(36).substr(2),username:a.username,role:a.role||"user",displayName:a.displayName||a.username,isLocal:!0}};else throw new Error("Invalid username or password")}else throw new Error("Server authentication failed")}if(!r||!r.success)throw new Error("Authentication failed");return he=r.token,j=r.user,localStorage.setItem(at,he),localStorage.setItem(lt,JSON.stringify(j)),pt(),ut(),d("auth","Login successful",{username:j.username,role:j.role}),Wt(),{success:!0,user:j}}catch(n){return d("auth","Login failed",{username:e,error:n.message}),console.error("[CRM Extension] Login error:",n),{success:!1,error:n.message}}}function te(e="User logout"){try{if(!S())return!1;d("auth","Logout",{username:j?.username,reason:e}),he=null;let t=j;return j=null,localStorage.removeItem(at),localStorage.removeItem(lt),oe&&(clearTimeout(oe),oe=null),Wt(t),!0}catch(t){return console.error("[CRM Extension] Logout error:",t),!1}}function S(){return!!he&&!!j}function C(){return j}function be(){return he}var mt={};ye(mt,{createRole:()=>Hr,deleteRole:()=>qr,getAllRoles:()=>jr,updateRole:()=>Wr});async function jr(){try{if(!S())return{success:!1,error:"Authentication required"};if(!V("roles.view"))return{success:!1,error:"Permission denied"};let t=(localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000").replace("ws://","http://").replace("wss://","https://");try{let n=await fetch(`${t}/admin/roles`,{method:"GET",headers:{Authorization:`Bearer ${localStorage.getItem("crmplus_chat_auth_token")}`}});if(!n.ok){let r=await n.json();throw new Error(r.message||"Failed to retrieve roles")}return{success:!0,roles:await n.json()}}catch(n){if(console.error("[CRM Extension] Server roles retrieval error:",n),v("allow_local_auth",!1))return{success:!0,roles:[{id:"user",name:"User",description:"Standard user with basic permissions",permissions:["message.create","channel.view"]},{id:"moderator",name:"Moderator",description:"User with additional moderation powers",permissions:["message.create","message.delete","channel.create","user.view"]},{id:"admin",name:"Administrator",description:"Full system access",permissions:["*"]}]};throw new Error("Server request failed: "+n.message)}}catch(e){return console.error("[CRM Extension] Roles retrieval error:",e),{success:!1,error:e.message}}}async function Hr(e){try{let t=C();if(!S())return{success:!1,error:"Authentication required"};if(!V("roles.create"))return{success:!1,error:"Permission denied"};if(!e.name)return{success:!1,error:"Role name is required"};let o=(localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000").replace("ws://","http://").replace("wss://","https://");try{let r=await fetch(`${o}/admin/roles`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${localStorage.getItem("crmplus_chat_auth_token")}`},body:JSON.stringify(e)});if(!r.ok){let i=await r.json();throw new Error(i.message||"Failed to create role")}let s=await r.json();return d("auth","Role created",{roleName:s.name,createdBy:t.username}),{success:!0,role:s}}catch(r){if(console.error("[CRM Extension] Server role creation error:",r),v("allow_local_auth",!1)){let s=v("local_roles",[]),i={id:`role_${Date.now().toString(36)}`,...e,createdAt:new Date().toISOString(),createdBy:t.id};return s.push(i),W("local_roles",s),d("auth","Local role created",{roleName:i.name,createdBy:t.username,isLocal:!0}),{success:!0,role:i}}throw new Error("Server request failed: "+r.message)}}catch(t){return console.error("[CRM Extension] Role creation error:",t),{success:!1,error:t.message}}}async function Wr(e,t){try{let n=C();if(!S())return{success:!1,error:"Authentication required"};if(!V("roles.update"))return{success:!1,error:"Permission denied"};if(!e)return{success:!1,error:"Role ID is required"};let r=(localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000").replace("ws://","http://").replace("wss://","https://");try{let s=await fetch(`${r}/admin/roles/${e}`,{method:"PUT",headers:{"Content-Type":"application/json",Authorization:`Bearer ${localStorage.getItem("crmplus_chat_auth_token")}`},body:JSON.stringify(t)});if(!s.ok){let a=await s.json();throw new Error(a.message||"Failed to update role")}let i=await s.json();return d("auth","Role updated",{roleId:e,roleName:i.name,updatedBy:n.username}),{success:!0,role:i}}catch(s){if(console.error("[CRM Extension] Server role update error:",s),v("allow_local_auth",!1)){let i=v("local_roles",[]),a=i.findIndex(c=>c.id===e);if(a===-1)return{success:!1,error:"Role not found"};let l={...i[a],...t,updatedAt:new Date().toISOString(),updatedBy:n.id};return i[a]=l,W("local_roles",i),d("auth","Local role updated",{roleId:e,roleName:l.name,updatedBy:n.username,isLocal:!0}),{success:!0,role:l}}throw new Error("Server request failed: "+s.message)}}catch(n){return console.error("[CRM Extension] Role update error:",n),{success:!1,error:n.message}}}async function qr(e){try{let t=C();if(!S())return{success:!1,error:"Authentication required"};if(!V("roles.delete"))return{success:!1,error:"Permission denied"};if(!e)return{success:!1,error:"Role ID is required"};if(["admin","moderator","user"].includes(e))return{success:!1,error:"Cannot delete default roles"};let r=(localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000").replace("ws://","http://").replace("wss://","https://");try{let s=await fetch(`${r}/admin/roles/${e}`,{method:"DELETE",headers:{Authorization:`Bearer ${localStorage.getItem("crmplus_chat_auth_token")}`}});if(!s.ok){let i=await s.json();throw new Error(i.message||"Failed to delete role")}return d("auth","Role deleted",{roleId:e,deletedBy:t.username}),{success:!0}}catch(s){if(console.error("[CRM Extension] Server role deletion error:",s),v("allow_local_auth",!1)){let i=v("local_roles",[]),a=i.findIndex(l=>l.id===e);return a===-1?{success:!1,error:"Role not found"}:(i.splice(a,1),W("local_roles",i),d("auth","Local role deleted",{roleId:e,deletedBy:t.username,isLocal:!0}),{success:!0})}throw new Error("Server request failed: "+s.message)}}catch(t){return console.error("[CRM Extension] Role deletion error:",t),{success:!1,error:t.message}}}var ht={};ye(ht,{createUser:()=>Gr,deleteUser:()=>Yr,getAllUsers:()=>Kr,updateUser:()=>Jr});async function Gr(e){try{let t=C();if(!S()||t.role!=="admin")return{success:!1,error:"Administrator privileges required to create users"};if(!e.username||!e.password)return{success:!1,error:"Username and password are required"};let o=(localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000").replace("ws://","http://").replace("wss://","https://");try{let r=await fetch(`${o}/admin/users`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${localStorage.getItem("crmplus_chat_auth_token")}`},body:JSON.stringify(e)});if(!r.ok){let i=await r.json();throw new Error(i.message||"Failed to create user")}let s=await r.json();return d("auth","Admin created user",{username:s.username,role:s.role||"user"}),{success:!0,user:s}}catch(r){if(console.error("[CRM Extension] Server create user error:",r),v("allow_local_auth",!1)){let s=v("local_users",[]);if(s.some(a=>a.username===e.username))return{success:!1,error:"Username already exists"};let i={id:`user_${Date.now().toString(36)}`,...e,role:e.role||"user",displayName:e.displayName||e.username,createdAt:new Date().toISOString(),createdBy:t.id};return s.push(i),W("local_users",s),d("auth","Local user created",{username:i.username,role:i.role,isLocal:!0}),{success:!0,user:{id:i.id,username:i.username,displayName:i.displayName,role:i.role,isLocal:!0}}}throw new Error("Server request failed: "+r.message)}}catch(t){return console.error("[CRM Extension] Create user error:",t),{success:!1,error:t.message}}}async function Jr(e,t){try{let n=C();if(!S())return{success:!1,error:"Authentication required"};if(e!==n.id&&n.role!=="admin")return{success:!1,error:"Permission denied"};if(!e)return{success:!1,error:"User ID is required"};let r=(localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000").replace("ws://","http://").replace("wss://","https://");try{let s=await fetch(`${r}/admin/users/${e}`,{method:"PUT",headers:{"Content-Type":"application/json",Authorization:`Bearer ${localStorage.getItem("crmplus_chat_auth_token")}`},body:JSON.stringify(t)});if(!s.ok){let a=await s.json();throw new Error(a.message||"Failed to update user")}let i=await s.json();return d("auth","User updated",{userId:e,updatedFields:Object.keys(t).join(", ")}),{success:!0,user:i}}catch(s){if(console.error("[CRM Extension] Server update user error:",s),v("allow_local_auth",!1)){let i=v("local_users",[]),a=i.findIndex(c=>c.id===e);if(a===-1)return{success:!1,error:"User not found"};let l={...i[a],displayName:t.displayName||i[a].displayName,email:t.email||i[a].email};return n.role==="admin"&&t.role&&(l.role=t.role),i[a]=l,W("local_users",i),d("auth","Updated local user",{userId:e,updatedFields:Object.keys(t).join(", "),isLocal:!0}),{success:!0,user:{id:l.id,username:l.username,displayName:l.displayName,role:l.role,email:l.email,isLocal:!0}}}throw new Error("Server request failed: "+s.message)}}catch(n){return console.error("[CRM Extension] Update user error:",n),{success:!1,error:n.message}}}async function Yr(e){try{let t=C();if(!S())return{success:!1,error:"Authentication required"};if(t.role!=="admin")return{success:!1,error:"Administrator privileges required to delete users"};if(!e)throw new Error("User ID is required");if(e===t.id)return{success:!1,error:"Cannot delete your own account"};let o=(localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000").replace("ws://","http://").replace("wss://","https://");try{let r=await fetch(`${o}/admin/users/${e}`,{method:"DELETE",headers:{Authorization:`Bearer ${localStorage.getItem("crmplus_chat_auth_token")}`}});if(!r.ok){let s=await r.json();throw new Error(s.message||"Failed to delete user")}return d("auth","Admin deleted user",{adminUsername:t.username,targetUserId:e}),{success:!0}}catch(r){if(console.error("[CRM Extension] Server delete user error:",r),v("allow_local_auth",!1)){let s=v("local_users",[]),i=s.findIndex(a=>a.id===e);if(i>=0){let a=s[i].username;return s.splice(i,1),W("local_users",s),d("auth","Admin deleted local user",{adminUsername:t.username,targetUserId:e,targetUsername:a,isLocal:!0}),{success:!0}}else throw new Error("User not found")}throw new Error("Server request failed: "+r.message)}}catch(t){return console.error("[CRM Extension] Delete user error:",t),d("auth","Admin user deletion failed",{error:t.message}),{success:!1,error:t.message}}}async function Kr(){try{let e=C();if(!S())return{success:!1,error:"Authentication required"};if(!V("user.view"))return{success:!1,error:"Permission denied"};let n=(localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000").replace("ws://","http://").replace("wss://","https://");try{let o=await fetch(`${n}/admin/users`,{method:"GET",headers:{Authorization:`Bearer ${localStorage.getItem("crmplus_chat_auth_token")}`}});if(!o.ok){let s=await o.json();throw new Error(s.message||"Failed to get users")}return{success:!0,users:await o.json()}}catch(o){if(console.error("[CRM Extension] Server get users error:",o),v("allow_local_auth",!1))return{success:!0,users:v("local_users",[]).map(s=>({id:s.id,username:s.username,displayName:s.displayName,role:s.role,createdAt:s.createdAt,isLocal:!0}))};throw new Error("Server request failed: "+o.message)}}catch(e){return console.error("[CRM Extension] Get users error:",e),{success:!1,error:e.message}}}var gt={};ye(gt,{generateUserImportTemplate:()=>Xr,importUsers:()=>Qr});function Zr(e){let t={validUsers:[],invalidUsers:[]};return e.forEach(n=>{let o=[];n.username||o.push("Username is required"),n.password||o.push("Password is required"),n.email||o.push("Email is recommended");let r=["user","moderator","admin"];n.role&&!r.includes(n.role)&&o.push(`Invalid role. Must be one of: ${r.join(", ")}`),o.length>0?t.invalidUsers.push({user:n,errors:o}):t.validUsers.push(n)}),t}async function Qr(e){try{let t=C();if(!S())return{success:!1,error:"Authentication required"};if(t.role!=="admin")return{success:!1,error:"Administrator privileges required to import users"};if(!Array.isArray(e)||e.length===0)return{success:!1,error:"Valid user array is required"};let{validUsers:n,invalidUsers:o}=Zr(e),s=(localStorage.getItem("crmplus_chat_server_url")||"ws://localhost:3000").replace("ws://","http://").replace("wss://","https://"),i={success:!0,totalUsers:e.length,successCount:0,failedCount:0,validationErrors:o,importedUsers:[],serverErrors:[]};try{let a=await fetch(`${s}/admin/users/import`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${localStorage.getItem("crmplus_chat_auth_token")}`},body:JSON.stringify({users:n})});if(!a.ok){let c=await a.json();throw new Error(c.message||"Failed to import users")}let l=await a.json();return i.successCount=l.successCount||0,i.failedCount=l.failedCount||0,i.importedUsers=l.importedUsers||[],d("auth","Admin bulk user import",{adminUsername:t.username,totalUsers:e.length,successCount:i.successCount,failedCount:i.failedCount}),i}catch(a){if(console.error("[CRM Extension] Server user import error:",a),v("allow_local_auth",!1)){let l=v("local_users",[]),c=new Set(l.map(p=>p.username));return n.forEach(p=>{try{if(c.has(p.username)){i.failedCount++,i.serverErrors.push({username:p.username,error:"Username already exists"});return}let u={id:`user_${Date.now().toString(36)}`,...p,role:p.role||"user",displayName:p.displayName||p.username,createdAt:new Date().toISOString(),createdBy:t.id};l.push(u),c.add(p.username),i.successCount++,i.importedUsers.push(u)}catch(u){i.failedCount++,i.serverErrors.push({username:p.username||"Unknown",error:u.message})}}),W("local_users",l),d("auth","Local bulk user import",{adminUsername:t.username,totalUsers:e.length,successCount:i.successCount,failedCount:i.failedCount,isLocal:!0}),i}throw new Error("Server request failed: "+a.message)}}catch(t){return console.error("[CRM Extension] Bulk user import error:",t),{success:!1,error:t.message,totalUsers:e.length,successCount:0,failedCount:e.length}}}function Xr(){return[{username:"john.doe",password:"SecurePassword123!",email:"john.doe@example.com",displayName:"John Doe",role:"user"},{username:"jane.smith",password:"AnotherSecurePass456!",email:"jane.smith@example.com",displayName:"Jane Smith",role:"moderator"}]}var es=Vn(Jt());F(g,Vn(Jt()));var ts={...Gt,...mt,...st,...ht,...gt,...es},{createUser:Mo,updateUser:Lo,deleteUser:Yt,getAllUsers:Kt,importUsers:Zt,createRole:ns,updateRole:os,deleteRole:rs,getAllRoles:ss,getAvailablePermissions:is,resetUserPassword:Qt,forceLogoutUser:Ao,generateUserImportTemplate:as}={...ht,...mt,...st,...gt};var Io="ws://localhost:3000",ls=5e3,cs=5,ds=3e4,D=null,Ct="disconnected",Ne=0,ft=null,en=localStorage.getItem("crmplus_chat_active_channel")||"general",xt=[],yt=[],ps=[],us=[];function Ro(){return en=localStorage.getItem("crmplus_chat_active_channel")||"general",d("system","Message service initialized"),!0}function se(){return D&&(D.readyState===WebSocket.OPEN||D.readyState===WebSocket.CONNECTING)?(console.log("[MessageService] WebSocket already connected or connecting"),Promise.resolve(!0)):new Promise(e=>{try{console.log(`[MessageService] Attempting to connect to ${Io}`),Ee("connecting"),D=new WebSocket(Io),D.onopen=()=>{console.log("[MessageService] WebSocket connection established"),Ne=0,Ee("connected"),hs(),ms(),e(!0)},D.onmessage=t=>{try{let n=JSON.parse(t.data);gs(n)}catch(n){console.error("[MessageService] Error parsing message:",n)}},D.onclose=t=>{console.warn("[MessageService] WebSocket connection closed",t),No(),Ee("disconnected"),t.code!==1e3&&Xt(),e(!1)},D.onerror=t=>{console.error("[MessageService] WebSocket error:",t),Ee("error"),Xt(),e(!1)}}catch(t){console.error("[MessageService] Connection error:",t),Ee("error"),Xt(),e(!1)}})}function ms(){if(!D||D.readyState!==WebSocket.OPEN)return;let e=C(),t=be();if(!e||!t){console.warn("[MessageService] Cannot authenticate: No user or token");return}let n={type:"authenticate",payload:{userId:e.id,username:e.username,token:t}};tn(n)}function tn(e){if(!D||D.readyState!==WebSocket.OPEN)return console.warn("[MessageService] WebSocket not connected"),!1;try{return D.send(JSON.stringify(e)),!0}catch(t){return console.error("[MessageService] Error sending message:",t),!1}}function bt(e,t=null,n=null){if(!e||!e.trim()||!S())return!1;let o=C();if(!o)return!1;t=t||en;let r=Date.now().toString(36)+Math.random().toString(36).substr(2,5),s=new Date().toISOString(),i={id:r,text:e.trim(),sender:o.username,senderDisplayName:o.displayName||o.username,timestamp:s,channel:t,recipient:n},a={type:"chat_message",payload:{id:r,text:e.trim(),sender:o.id,senderUsername:o.username,timestamp:s,channelId:t,recipientId:n}},l=!1;if(D&&D.readyState===WebSocket.OPEN)try{let c=$t(a);l=tn(c)}catch(c){console.warn("[MessageService] Error sending message via WebSocket:",c)}return l||(console.log("[MessageService] Using local message handling"),Vt(i),setTimeout(()=>{To([i])},100)),d("message","Message sent",{messageId:r,channelId:t,recipientId:n,localOnly:!l}),!0}function nn(){return Ct}function hs(){No(),ft=setInterval(()=>{if(D&&D.readyState===WebSocket.OPEN){let e={type:"heartbeat",timestamp:new Date().toISOString()};tn(e)}},ds)}function No(){ft&&(clearInterval(ft),ft=null)}function Xt(){if(Ne>=cs){console.error("[MessageService] Max reconnection attempts reached"),Ee("error");return}Ne++;let e=ls*Math.pow(2,Ne);console.log(`[MessageService] Attempting reconnection in ${e}ms (Attempt ${Ne})`),setTimeout(()=>{se()},e)}function gs(e){try{switch(e.type){case"chat_message":let t=jt(e);Vt(t),To([t]);break;case"authentication_response":fs(e);break;case"user_list":ys(e.users);break;case"channel_list":Cs(e.channels);break;case"error":console.error("[MessageService] Server error:",e.payload);break;default:console.warn("[MessageService] Unknown message type:",e.type)}}catch(t){console.error("[MessageService] Error handling message:",t)}}function fs(e){e.success?(console.log("[MessageService] Authentication successful"),d("auth","WebSocket authentication successful")):(console.error("[MessageService] Authentication failed:",e.reason),d("auth","WebSocket authentication failed",{reason:e.reason}))}function Ee(e){Ct!==e&&(Ct=e,xs(e))}function Et(e){return typeof e!="function"?()=>{}:(xt.push(e),()=>{xt=xt.filter(t=>t!==e)})}function To(e){xt.forEach(t=>{try{t(e)}catch(n){console.error("[MessageService] Error in message listener:",n)}})}function on(e){return typeof e!="function"?()=>{}:(yt.push(e),e(Ct),()=>{yt=yt.filter(t=>t!==e)})}function xs(e){yt.forEach(t=>{try{t(e)}catch(n){console.error("[MessageService] Error in connection status listener:",n)}})}function ys(e){ps.forEach(t=>{try{t(e)}catch(n){console.error("[MessageService] Error in user list listener:",n)}})}function Cs(e){us.forEach(t=>{try{t(e)}catch(n){console.error("[MessageService] Error in channel list listener:",n)}})}function rn(){return en}var bs=[];function Uo(){try{return Es(),d("system","User service initialized"),console.log("[CRM Extension] User service initialized"),!0}catch(e){return console.error("[CRM Extension] Error initializing user service:",e),!1}}function Es(){let e=Le();e.length>0&&e.forEach(t=>{t.online=!1,t.lastSeen=t.lastSeen||new Date().toISOString()})}function Bo(e){try{if(!e)return null;let t=bs.find(o=>o.id===e);return t||Le().find(o=>o.id===e)||null}catch(t){return console.error("[CRM Extension] Error getting user by ID:",t),null}}async function sn(e){try{if(!S())return!1;let t=C(),n={type:"status_update",userId:t.id,status:e,timestamp:new Date().toISOString()};typeof window.sendToServer=="function"&&window.sendToServer(n);let o=Bo(t.id);return o&&(o.status=e,zt(o)),d("user","Status updated",{status:e}),!0}catch(t){return console.error("[CRM Extension] Error setting user status:",t),!1}}var Po=[];var Ba=localStorage.getItem("crmplus_chat_active_channel")||"general";function Vo(){try{return ws(),d("system","Channel service initialized"),console.log("[CRM Extension] Channel service initialized"),!0}catch(e){return console.error("[CRM Extension] Error initializing channel service:",e),!1}}function ws(){let e=ot();if(e.length===0){let t={id:"general",name:"General",description:"General discussion channel",type:"public",createdAt:new Date().toISOString(),createdBy:"system"},n={id:"announcements",name:"Announcements",description:"Important announcements",type:"public",createdAt:new Date().toISOString(),createdBy:"system",readonly:!0};nt(t),nt(n),Po=[t,n]}else Po=e}var an=class{constructor(){this.listeners=[],this.authState={authenticated:S(),user:C(),sessionStatus:re()},this.setupAuthListener(),this.setupSessionRefresh()}notifyListeners(){let t=this.getAuthState();this.listeners.forEach(n=>{try{n(t)}catch(o){console.error("[CRM Extension] Error in auth context listener:",o)}})}setupAuthListener(){Re(t=>{this.authState={...this.authState,authenticated:t.authenticated,user:t.user},this.notifyListeners()})}setupSessionRefresh(){setInterval(()=>{this.authState.sessionStatus=re(),this.authState.authenticated&&this.notifyListeners()},6e4)}async login(t,n){let o=await ge(t,n);return o.success&&(this.authState={authenticated:!0,user:o.user,sessionStatus:re()},this.notifyListeners()),o}logout(t){let n=te(t);return n&&(this.authState={authenticated:!1,user:null,sessionStatus:re()},this.notifyListeners()),n}async register(t){return await(0,g.registerUser)(t)}async updateProfile(t){let n=await(0,g.updateUserProfile)(t);return n.success&&(this.authState={...this.authState,user:n.user},this.notifyListeners()),n}hasPermission(t){return V(t)}getAuthState(){return this.authState.sessionStatus=re(),{...this.authState}}subscribe(t){return typeof t!="function"?(console.error("[CRM Extension] Auth context listener must be a function"),()=>{}):(this.listeners.push(t),t(this.getAuthState()),()=>{this.listeners=this.listeners.filter(n=>n!==t)})}},vs=new an,ln=vs;var ks={server:{url:v("server_url","ws://localhost:3000"),connectionTimeout:1e4,reconnect:{maxAttempts:5,delay:5e3,useExponentialBackoff:!0},heartbeatInterval:3e4},security:{sessionTimeout:15*60*1e3,hasCryptoAPI:typeof window<"u"&&window.crypto&&window.crypto.subtle,minPasswordLength:8,enableTwoFactorAuth:!1},storage:{maxMessagesPerChannel:100,messageExpiration:24*60*60*1e3,keyPrefix:"crmplus_chat_"},ui:{theme:v("theme","light"),notifications:{enabled:v("notifications_enabled",!0),sound:v("notification_sound",!0),soundUrl:v("notification_sound_url",null)},messages:{maxLength:2e3,allowEditing:!0,editWindow:5*60*1e3,allowDeletion:!0},channels:{defaultChannel:"general"}},features:{directMessaging:!0,fileSharing:!1,messageThreading:!1,messageReactions:!0,userChannelCreation:v("user_channel_creation",!1),userStatus:!0},hipaa:{enableSessionTimeout:!0,enableAuditLogging:!0,enableMessageExpiration:!0,showPhiIndicators:!0,enableEncryption:!0},roles:{admin:{name:"Administrator",permissions:["user.create","user.read","user.update","user.delete","channel.create","channel.read","channel.update","channel.delete","channel.invite","message.delete","audit.read"]},moderator:{name:"Moderator",permissions:["user.read","channel.create","channel.read","channel.update","channel.invite","message.delete"]},user:{name:"User",permissions:["user.read","channel.read","message.create","message.read","message.update.own","message.delete.own"]}},version:{number:"1.0.0",buildDate:new Date("2025-03-18").toISOString()}};function Te(e,t=null){try{let n=e.split("."),o=ks;for(let r of n)if(o&&typeof o=="object"&&r in o)o=o[r];else return t;return o}catch(n){return console.error("[CRM Extension] Error getting config value:",n),t}}var cn=class{constructor(t={}){this.options={sound:Te("ui.notifications.sound",!0),soundUrl:Te("ui.notifications.soundUrl",null),desktop:Te("ui.notifications.enabled",!0),onNotificationClick:null,...t},this.notificationCount=0,this.notificationQueue=[],this.processingQueue=!1,this.enabled=!0,this.focused=document.hasFocus(),this.unsubscribeMessageListener=null,this.notificationPermission="default",this.audio=null,this.initialize=this.initialize.bind(this),this.handleMessage=this.handleMessage.bind(this),this.showNotification=this.showNotification.bind(this),this.playNotificationSound=this.playNotificationSound.bind(this),this.handleVisibilityChange=this.handleVisibilityChange.bind(this),this.processBatchedNotifications=this.processBatchedNotifications.bind(this),this.requestNotificationPermission=this.requestNotificationPermission.bind(this),this.initialize()}initialize(){try{"Notification"in window&&(this.notificationPermission=Notification.permission,this.notificationPermission!=="granted"&&this.options.desktop&&document.addEventListener("click",this.requestNotificationPermission,{once:!0})),this.options.sound&&(this.audio=new Audio(this.options.soundUrl||this.getDefaultSoundUrl()),this.audio.load()),document.addEventListener("visibilitychange",this.handleVisibilityChange),window.addEventListener("focus",()=>{this.focused=!0,this.resetNotificationCount()}),window.addEventListener("blur",()=>{this.focused=!1}),this.unsubscribeMessageListener=Et(this.handleMessage),d("ui","Notification system initialized"),console.log("[CRM Extension] Notification system initialized")}catch(t){console.error("[CRM Extension] Error initializing notification system:",t)}}getDefaultSoundUrl(){return"data:audio/mp3;base64,SUQzBAAAAAABEVRYWFgAAAAtAAADY29tbWVudABCaWdTb3VuZEJhbmsuY29tIC8gTGFTb25vdGhlcXVlLm9yZwBURU5DAAAAHQAAA1N3aXRjaCBQbHVzIMKpIE5DSCBTb2Z0d2FyZQBUSVQyAAAABgAAAzIyMzUAVFNTRQAAAA8AAANMYXZmNTguMTYuMTAwAAAAAAAAAAAAAAD/80DEAAAAA0gAAAAATEFNRTMuMTAwVVVVVVVVVVVVVUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/zQsRbAAADSAAAAABVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/zQMSkAAADSAAAAABVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV"}requestNotificationPermission(){"Notification"in window&&this.notificationPermission!=="granted"&&Notification.requestPermission().then(t=>{this.notificationPermission=t,d("ui",`Notification permission ${t}`)})}handleVisibilityChange(){document.visibilityState==="visible"?(this.focused=!0,this.resetNotificationCount()):this.focused=!1}handleMessage(t){if(!this.enabled||!t||t.length===0)return;let n=C();if(!n)return;let o=t.filter(r=>r.sender!==n.username&&r.sender!==n.id);o.length!==0&&(this.notificationQueue.push(...o),this.notificationCount+=o.length,this.dispatchNotificationCountEvent(),this.processingQueue||this.processBatchedNotifications())}processBatchedNotifications(){if(this.notificationQueue.length===0){this.processingQueue=!1;return}this.processingQueue=!0;let t=this.notificationQueue.shift();this.focused||this.showNotification(t),this.options.sound&&this.notificationQueue.length===0&&this.playNotificationSound(),setTimeout(this.processBatchedNotifications,300)}showNotification(t){try{if(!this.options.desktop||!("Notification"in window)||this.notificationPermission!=="granted")return;let n=`New message from ${t.senderDisplayName||t.sender}`,o={body:"You have received a new message",icon:this.getIconUrl(t.sender),tag:`chat-msg-${t.id}`,requireInteraction:!1,silent:!0},r=new Notification(n,o);r.onclick=()=>{window.focus(),this.options.onNotificationClick&&typeof this.options.onNotificationClick=="function"&&this.options.onNotificationClick(t),r.close()},d("ui","Showed desktop notification",{sender:t.sender})}catch(n){console.error("[CRM Extension] Error showing notification:",n)}}playNotificationSound(){try{if(!this.options.sound||!this.audio)return;this.audio.currentTime=0,this.audio.play().catch(t=>{console.warn("[CRM Extension] Could not play notification sound:",t)})}catch(t){console.error("[CRM Extension] Error playing notification sound:",t)}}getIconUrl(t){return"data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA0OCA0OCIgd2lkdGg9IjQ4IiBoZWlnaHQ9IjQ4Ij48Y2lyY2xlIGN4PSIyNCIgY3k9IjI0IiByPSIyNCIgZmlsbD0iIzQyOTVmMyIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0yNCAyMGMzLjMgMCA2LTIuNyA2LTZzLTIuNy02LTYtNi02IDIuNy02IDYgMi43IDYgNiA2em0wIDRjLTQgMC0xMiAyLTEyIDZWMzRoMjR2LTRjMC00LTgtNi0xMi02eiIvPjwvc3ZnPg=="}getNotificationCount(){return this.notificationCount}resetNotificationCount(){this.notificationCount!==0&&(this.notificationCount=0,this.dispatchNotificationCountEvent(),d("ui","Reset notification count"))}dispatchNotificationCountEvent(){let t=new CustomEvent("chat_notification_count",{detail:{count:this.notificationCount}});window.dispatchEvent(t)}setEnabled(t){this.enabled=!!t,d("ui",`Notifications ${t?"enabled":"disabled"}`)}setSound(t,n=null){this.options.sound=!!t,t&&n&&(this.options.soundUrl=n,this.audio?(this.audio.src=n,this.audio.load()):(this.audio=new Audio(n),this.audio.load())),d("ui",`Notification sound ${t?"enabled":"disabled"}`)}showSystemNotification(t,n){try{if(!this.options.desktop||!("Notification"in window)||this.notificationPermission!=="granted")return;let o={body:n,icon:"data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA0OCA0OCIgd2lkdGg9IjQ4IiBoZWlnaHQ9IjQ4Ij48Y2lyY2xlIGN4PSIyNCIgY3k9IjI0IiByPSIyNCIgZmlsbD0iIzI4YTc0NSIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0yMCAzNGwtOS05IDMtMyA2IDYgMTQtMTQgMyAzeiIvPjwvc3ZnPg==",tag:`chat-system-${Date.now()}`,requireInteraction:!1,silent:!0},r=new Notification(t,o);r.onclick=()=>{window.focus(),r.close()},this.options.sound&&this.playNotificationSound(),d("ui","Showed system notification",{title:t})}catch(o){console.error("[CRM Extension] Error showing system notification:",o)}}destroy(){document.removeEventListener("visibilitychange",this.handleVisibilityChange),window.removeEventListener("focus",()=>{this.focused=!0}),window.removeEventListener("blur",()=>{this.focused=!1}),this.unsubscribeMessageListener&&this.unsubscribeMessageListener(),this.audio&&(this.audio.pause(),this.audio=null),d("ui","Notification system destroyed")}},dn=cn;function pn(e,t={}){let{currentUser:n,connectionStatus:o="connected",activeView:r="chat",onViewSwitch:s=()=>{},onToggleUserList:i=()=>{},onLogout:a=()=>{}}=t,l={primary:"#2196F3",primaryDark:"#1976D2",text:"#ffffff",textSecondary:"rgba(255, 255, 255, 0.7)",accent:"#4CAF50",warning:"#FFC107",error:"#F44336"},c=document.createElement("div");c.className="hipaa-chat-header",T(c,{backgroundColor:l.primary,color:l.text,padding:"0 20px",height:"60px",display:"flex",alignItems:"center",justifyContent:"space-between",borderTopLeftRadius:"8px",borderTopRightRadius:"8px",boxShadow:"0 2px 4px rgba(0,0,0,0.1)"});let p=document.createElement("div");T(p,{display:"flex",alignItems:"center",height:"100%"});let u=document.createElement("div");T(u,{display:"flex",alignItems:"center",marginRight:"24px"});let m=document.createElement("span");m.textContent="\u{1F4AC}",T(m,{fontSize:"24px",marginRight:"10px"});let x=document.createElement("h1");x.textContent="MCP Chat",T(x,{margin:"0",fontSize:"20px",fontWeight:"bold",letterSpacing:"0.5px"}),u.appendChild(m),u.appendChild(x),p.appendChild(u);let N=document.createElement("nav");T(N,{display:"flex",height:"100%"}),[{id:"chat",label:"Chat"},{id:"admin",label:"Admin",adminOnly:!0},{id:"settings",label:"Settings"}].forEach(w=>{if(w.adminOnly&&n?.role!=="admin")return;let k=r===w.id,L=document.createElement("div");if(L.className=`nav-item ${k?"active":""}`,T(L,{height:"100%",display:"flex",alignItems:"center",padding:"0 16px",cursor:"pointer",position:"relative",color:k?l.text:l.textSecondary,fontWeight:k?"bold":"normal"}),k){let Z=document.createElement("div");T(Z,{position:"absolute",bottom:"0",left:"0",width:"100%",height:"3px",backgroundColor:l.text}),L.appendChild(Z)}L.textContent=w.label,L.addEventListener("mouseover",()=>{k||(L.style.backgroundColor="rgba(255, 255, 255, 0.1)",L.style.color=l.text)}),L.addEventListener("mouseout",()=>{k||(L.style.backgroundColor="transparent",L.style.color=l.textSecondary)}),L.addEventListener("click",()=>{s&&s(w.id)}),N.appendChild(L)}),p.appendChild(N);let _=document.createElement("div");T(_,{display:"flex",justifyContent:"center",flex:"1"});let H=Ms(o);_.appendChild(H);let E=document.createElement("div");T(E,{display:"flex",alignItems:"center",gap:"16px"});let M=document.createElement("button");M.title="Toggle Team Members",M.innerHTML="\u{1F465}",T(M,{backgroundColor:"rgba(255, 255, 255, 0.2)",border:"none",color:l.text,fontSize:"18px",cursor:"pointer",width:"36px",height:"36px",borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center"}),M.addEventListener("mouseover",()=>{M.style.backgroundColor="rgba(255, 255, 255, 0.3)"}),M.addEventListener("mouseout",()=>{M.style.backgroundColor="rgba(255, 255, 255, 0.2)"}),M.addEventListener("click",()=>{i&&i()});let I=document.createElement("div");T(I,{display:"flex",alignItems:"center",gap:"8px",cursor:"pointer",padding:"6px",borderRadius:"4px",position:"relative"}),I.addEventListener("mouseover",()=>{I.style.backgroundColor="rgba(255, 255, 255, 0.1)"}),I.addEventListener("mouseout",()=>{I.style.backgroundColor="transparent"});let U=document.createElement("div");T(U,{width:"36px",height:"36px",borderRadius:"50%",backgroundColor:"rgba(255, 255, 255, 0.3)",display:"flex",alignItems:"center",justifyContent:"center",fontWeight:"bold",fontSize:"16px"});let Y=n?.displayName?.charAt(0)||n?.username?.charAt(0)||"?";U.textContent=Y.toUpperCase();let K=document.createElement("div");K.textContent=n?.displayName||n?.username||"Guest",T(K,{fontSize:"14px",fontWeight:"medium"});let G=document.createElement("span");G.innerHTML="&#9662;",T(G,{fontSize:"12px",marginLeft:"4px"}),I.appendChild(U),I.appendChild(K),I.appendChild(G);let z=document.createElement("div");return z.className="user-dropdown",T(z,{position:"absolute",top:"50px",right:"0",backgroundColor:"white",boxShadow:"0 2px 10px rgba(0,0,0,0.2)",borderRadius:"4px",zIndex:"100",minWidth:"180px",display:"none"}),[{label:"Profile",icon:"\u{1F464}",onClick:()=>console.log("Profile clicked")},{label:"Preferences",icon:"\u2699\uFE0F",onClick:()=>console.log("Preferences clicked")},{type:"divider"},{label:"Logout",icon:"\u{1F6AA}",onClick:a}].forEach(w=>{if(w.type==="divider"){let ne=document.createElement("div");T(ne,{height:"1px",backgroundColor:"#e0e0e0",margin:"8px 0"}),z.appendChild(ne);return}let k=document.createElement("div");T(k,{display:"flex",alignItems:"center",padding:"10px 16px",cursor:"pointer",color:"#333",fontSize:"14px"}),k.addEventListener("mouseover",()=>{k.style.backgroundColor="#f5f5f5"}),k.addEventListener("mouseout",()=>{k.style.backgroundColor="transparent"});let L=document.createElement("span");L.textContent=w.icon,T(L,{marginRight:"12px",fontSize:"16px"});let Z=document.createElement("span");Z.textContent=w.label,k.appendChild(L),k.appendChild(Z),w.onClick&&k.addEventListener("click",ne=>{ne.stopPropagation(),z.style.display="none",w.onClick()}),z.appendChild(k)}),I.addEventListener("click",w=>{w.stopPropagation(),z.style.display=z.style.display==="block"?"none":"block"}),document.addEventListener("click",()=>{z.style.display="none"}),E.appendChild(M),E.appendChild(I),E.appendChild(z),c.appendChild(p),c.appendChild(_),c.appendChild(E),e&&e.appendChild(c),c}function Ms(e){let t={connected:"#4CAF50",connecting:"#FFC107",disconnected:"#F44336",error:"#F44336"},n={connected:"Connected",connecting:"Connecting...",disconnected:"Disconnected",error:"Connection Error"},o=document.createElement("div");T(o,{display:"flex",alignItems:"center",gap:"8px",backgroundColor:"rgba(255, 255, 255, 0.1)",borderRadius:"16px",padding:"6px 12px"});let r=document.createElement("div");T(r,{width:"8px",height:"8px",borderRadius:"50%",backgroundColor:t[e]||t.error});let s=document.createElement("span");return s.textContent=n[e]||"Unknown",T(s,{fontSize:"12px",fontWeight:"medium"}),o.appendChild(r),o.appendChild(s),o}function T(e,t){Object.assign(e.style,t)}function Ue(e){if(!e||e.trim()==="")return!1;let t=[/\b\d{3}[-.\s]?\d{2}[-.\s]?\d{4}\b/,/\b\d{1,2}[-/]\d{1,2}[-/]\d{2,4}\b/,/\bMR[#\s]?\d{5,10}\b/i,/\bmedical[\s-]record[\s-]number\b/i,/\b\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b/,/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/,/\b\d+\s+[A-Za-z\s]+\b(?:street|st|avenue|ave|road|rd|boulevard|blvd|drive|dr|court|ct|lane|ln|way)\b/i,/\b(?:patient|chart)[\s-](?:id|number|#)[\s:]*(?:\d{3,10}|[A-Z]{1,3}\d{3,7})\b/i,/\b(?:insurance|policy)[\s-](?:id|number|#)[\s:]*(?:\d{3,12}|[A-Z]{1,3}\d{3,10})\b/i,/\bdiagnosis\b|\bdiagnosed\b|\bsymptoms\b|\bprescription\b|\bmedication\b|\bdosage\b/i,/\bpatient information\b|\bhealth information\b|\bmedical history\b|\btest results\b/i,/\ballergies\b|\bvital signs\b|\blab results\b|\bmedical conditions\b|\bimmunizations\b/i];for(let r of t)if(r.test(e))return!0;let n=["confidential","private","sensitive","hipaa","phi","pii","personal information","health record","chart","physician","doctor","patient","treatment","dob","birth date","date of birth","age","ssn","social security","medicare","medicaid","insurance","claim","authorization","consent"],o=e.toLowerCase();for(let r of n)if(o.includes(r))return!0;return!1}function un(e){if(!e||typeof e!="string")return{success:!1,error:"Message text is required"};let t=e.trim();if(t.length===0)return{success:!1,error:"Message cannot be empty"};if(t.length>2e3)return{success:!1,error:"Message cannot exceed 2000 characters"};let n=Ue(t);return{success:!0,message:t,containsPHI:n}}var mn=class{constructor(t,n={}){this.container=t,this.options={channelId:null,userId:null,placeholder:"Type a message...",maxLength:2e3,showCharacterCount:!0,showPHIWarning:!0,autoFocus:!0,...n},this.inputContainerElement=null,this.textareaElement=null,this.sendButtonElement=null,this.characterCountElement=null,this.phiWarningElement=null,this.render=this.render.bind(this),this.handleInput=this.handleInput.bind(this),this.handleKeyDown=this.handleKeyDown.bind(this),this.handleSendClick=this.handleSendClick.bind(this),this.sendMessage=this.sendMessage.bind(this),this.checkPHI=this.checkPHI.bind(this),this.initialize()}initialize(){this.inputContainerElement=document.createElement("div"),this.inputContainerElement.className="message-input-container",this.applyStyles(this.inputContainerElement,{display:"flex",flexDirection:"column",width:"100%",backgroundColor:"#f9f9f9",borderTop:"1px solid #e0e0e0",padding:"10px",boxSizing:"border-box"}),this.container&&this.container.appendChild(this.inputContainerElement),this.render(),d("ui","Message input component initialized",{channelId:this.options.channelId,userId:this.options.userId})}render(){if(!this.inputContainerElement)return;if(this.inputContainerElement.innerHTML="",S()&&V("message.create")){let o=document.createElement("div");o.className="input-row",this.applyStyles(o,{display:"flex",alignItems:"flex-end"}),this.textareaElement=document.createElement("textarea"),this.textareaElement.className="message-textarea",this.textareaElement.placeholder=this.options.placeholder,this.textareaElement.maxLength=this.options.maxLength,this.applyStyles(this.textareaElement,{flex:"1",minHeight:"40px",maxHeight:"120px",padding:"10px",border:"1px solid #ddd",borderRadius:"4px",resize:"none",fontSize:"14px",fontFamily:"inherit",outline:"none"}),this.textareaElement.addEventListener("input",this.handleInput),this.textareaElement.addEventListener("keydown",this.handleKeyDown),this.sendButtonElement=document.createElement("button"),this.sendButtonElement.className="send-button",this.sendButtonElement.innerHTML="\u27A4",this.sendButtonElement.title="Send Message",this.sendButtonElement.disabled=!0,this.applyStyles(this.sendButtonElement,{marginLeft:"8px",width:"40px",height:"40px",backgroundColor:"#2196F3",color:"white",border:"none",borderRadius:"4px",cursor:"pointer",fontSize:"16px",display:"flex",alignItems:"center",justifyContent:"center",opacity:"0.7"}),this.sendButtonElement.addEventListener("click",this.handleSendClick),o.appendChild(this.textareaElement),o.appendChild(this.sendButtonElement),this.inputContainerElement.appendChild(o);let r=document.createElement("div");r.className="info-row",this.applyStyles(r,{display:"flex",justifyContent:"space-between",marginTop:"4px",fontSize:"12px",color:"#666"}),this.options.showCharacterCount&&(this.characterCountElement=document.createElement("div"),this.characterCountElement.className="character-count",this.characterCountElement.textContent=`0/${this.options.maxLength}`,r.appendChild(this.characterCountElement)),this.options.showPHIWarning&&(this.phiWarningElement=document.createElement("div"),this.phiWarningElement.className="phi-warning",this.phiWarningElement.innerHTML="\u{1F512} This message may contain PHI (Protected Health Information)",this.applyStyles(this.phiWarningElement,{color:"#bf360c",fontWeight:"bold",display:"none"}),r.appendChild(this.phiWarningElement)),this.inputContainerElement.appendChild(r),this.options.autoFocus&&this.textareaElement.focus()}else{let o=document.createElement("div");o.className="readonly-notice",this.applyStyles(o,{padding:"10px",backgroundColor:"#f0f0f0",color:"#666",borderRadius:"4px",textAlign:"center"}),S()?o.textContent="You do not have permission to send messages":o.textContent="You must be logged in to send messages",this.inputContainerElement.appendChild(o)}let n=document.createElement("div");n.className="hipaa-notice",n.innerHTML="\u{1F512} HIPAA Compliant Chat - Messages are encrypted and expire after 24 hours",this.applyStyles(n,{fontSize:"10px",color:"#666",textAlign:"center",padding:"4px",backgroundColor:"#f0f0f0",marginTop:"8px",borderRadius:"2px"}),this.inputContainerElement.appendChild(n)}handleInput(t){if(!this.textareaElement)return;let n=this.textareaElement.value.trim();this.characterCountElement&&(this.characterCountElement.textContent=`${n.length}/${this.options.maxLength}`,n.length>this.options.maxLength*.9?this.characterCountElement.style.color="#f44336":this.characterCountElement.style.color="#666"),this.sendButtonElement&&(n.length>0?(this.sendButtonElement.disabled=!1,this.sendButtonElement.style.opacity="1"):(this.sendButtonElement.disabled=!0,this.sendButtonElement.style.opacity="0.7")),this.checkPHI(n),this.autoResizeTextarea()}checkPHI(t){!this.phiWarningElement||!this.options.showPHIWarning||(Ue(t)?this.phiWarningElement.style.display="block":this.phiWarningElement.style.display="none")}autoResizeTextarea(){if(!this.textareaElement)return;this.textareaElement.style.height="auto";let t=Math.min(Math.max(this.textareaElement.scrollHeight,40),120);this.textareaElement.style.height=`${t}px`}handleKeyDown(t){t.key==="Enter"&&!t.shiftKey&&(t.preventDefault(),this.sendMessage())}handleSendClick(){this.sendMessage()}sendMessage(){if(!this.textareaElement)return;let t=this.textareaElement.value.trim();if(!t)return;let n=un(t);if(!n.success){alert(n.error);return}if(this.options.channelId)bt(t,this.options.channelId);else if(this.options.userId)bt(t,null,this.options.userId);else{console.error("[CRM Extension] Cannot send message: no channel ID or user ID specified");return}this.textareaElement.value="",this.characterCountElement&&(this.characterCountElement.textContent=`0/${this.options.maxLength}`,this.characterCountElement.style.color="#666"),this.phiWarningElement&&(this.phiWarningElement.style.display="none"),this.sendButtonElement&&(this.sendButtonElement.disabled=!0,this.sendButtonElement.style.opacity="0.7"),this.autoResizeTextarea(),this.textareaElement.focus(),d("ui","Message sent",{channelId:this.options.channelId,userId:this.options.userId,containsPHI:n.containsPHI})}updateChannel(t){this.options.channelId=t,this.options.userId=null,d("ui","Message input switched to channel",{channelId:t})}updateDirectMessage(t){this.options.userId=t,this.options.channelId=null,d("ui","Message input switched to direct messages",{userId:t})}applyStyles(t,n){Object.assign(t.style,n)}destroy(){this.textareaElement&&(this.textareaElement.removeEventListener("input",this.handleInput),this.textareaElement.removeEventListener("keydown",this.handleKeyDown)),this.sendButtonElement&&this.sendButtonElement.removeEventListener("click",this.handleSendClick),this.inputContainerElement&&this.inputContainerElement.parentNode&&this.inputContainerElement.parentNode.removeChild(this.inputContainerElement),d("ui","Message input component destroyed")}},hn=mn;function gn(e,t={}){let{showUserList:n=!0,selectedChannel:o="general",mockChannels:r=[],mockUsers:s=[],onChannelSelect:i=()=>{},onUserSelect:a=()=>{},toggleUserList:l=()=>{}}=t,c=document.createElement("div");f(c,{display:"flex",width:"100%",height:"100%",backgroundColor:"#ffffff"});let p=Ls(r,o,i),u=Is(o,r,l,s),m=Ts(s,a);return f(p,{flex:"0 0 180px",minWidth:"160px",maxWidth:"180px"}),f(u,{flex:"1 1 auto",minWidth:"250px"}),n&&f(m,{flex:"0 0 200px",minWidth:"180px",maxWidth:"200px"}),c.appendChild(p),c.appendChild(u),n&&c.appendChild(m),e.appendChild(c),c}function Ls(e,t,n){let o=document.createElement("div");f(o,{height:"100%",borderRight:"1px solid #e0e0e0",display:"flex",flexDirection:"column",backgroundColor:"#f8f9fa",overflow:"hidden"});let r=document.createElement("div");f(r,{padding:"10px 12px",borderBottom:"1px solid #e0e0e0",display:"flex",justifyContent:"space-between",alignItems:"center"});let s=document.createElement("h2");s.textContent="Channels",f(s,{margin:"0",fontSize:"16px",fontWeight:"bold"});let i=document.createElement("span");i.textContent=e.length.toString(),f(i,{backgroundColor:"#e0e0e0",color:"#333",borderRadius:"12px",padding:"1px 6px",fontSize:"11px",fontWeight:"bold"}),r.appendChild(s),r.appendChild(i);let a=document.createElement("div");f(a,{flex:"1",overflowY:"auto",padding:"4px 0"});let l=e.filter(x=>x.type==="public"),c=e.filter(x=>x.type==="private");l.length>0&&Do(a,"PUBLIC CHANNELS",l,t,n),c.length>0&&Do(a,"PRIVATE CHANNELS",c,t,n);let p=document.createElement("button");f(p,{margin:"8px",padding:"6px 0",backgroundColor:"#2196F3",color:"white",border:"none",borderRadius:"4px",fontSize:"13px",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:"6px",fontWeight:"bold"});let u=document.createElement("span");u.textContent="+",f(u,{fontSize:"16px"});let m=document.createElement("span");return m.textContent="New Channel",p.appendChild(u),p.appendChild(m),p.addEventListener("mouseover",()=>{p.style.backgroundColor="#1976D2"}),p.addEventListener("mouseout",()=>{p.style.backgroundColor="#2196F3"}),o.appendChild(r),o.appendChild(a),o.appendChild(p),o}function Do(e,t,n,o,r){let s=document.createElement("div");f(s,{padding:"8px 12px 4px",fontSize:"10px",color:"#666",fontWeight:"bold",textTransform:"uppercase",letterSpacing:"0.5px"}),s.textContent=t;let i=document.createElement("div");f(i,{marginBottom:"10px"}),n.forEach(a=>{let l=As(a,a.id===o,r);i.appendChild(l)}),e.appendChild(s),e.appendChild(i)}function As(e,t,n){let o=document.createElement("div");f(o,{padding:"6px 12px 6px 10px",display:"flex",alignItems:"center",cursor:"pointer",fontSize:"13px",color:t?"#2196F3":"#333",backgroundColor:t?"rgba(33, 150, 243, 0.08)":"transparent",borderLeft:t?"3px solid #2196F3":"3px solid transparent"});let r=document.createElement("span");r.textContent=e.type==="public"?"\u{1F310}":"\u{1F512}",f(r,{marginRight:"8px",fontSize:"14px",opacity:"0.7"});let s=document.createElement("span");if(s.textContent=e.name,f(s,{flex:"1",fontWeight:t?"bold":"normal",whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}),e.unread&&e.unread>0){let i=document.createElement("span");i.textContent=e.unread>99?"99+":e.unread,f(i,{minWidth:"18px",height:"18px",backgroundColor:t?"#2196F3":"#f44336",color:"white",borderRadius:"9px",fontSize:"11px",fontWeight:"bold",display:"flex",alignItems:"center",justifyContent:"center",padding:"0 4px"}),o.appendChild(i)}return o.appendChild(r),o.appendChild(s),o.addEventListener("click",()=>{n(e)}),o.addEventListener("mouseover",()=>{t||(o.style.backgroundColor="rgba(0, 0, 0, 0.05)")}),o.addEventListener("mouseout",()=>{t||(o.style.backgroundColor="transparent")}),o}function Is(e,t,n,o){let r=document.createElement("div");f(r,{flex:"1",display:"flex",flexDirection:"column",backgroundColor:"#fff",width:"100%"});let s=t.find(p=>p.id===e)||{id:"general",name:"General",type:"public"},i=Rs(s,n),a=Ns(s),l=document.createElement("div");f(l,{width:"100%"});let c=new hn(l,{channelId:s.id,placeholder:`Message #${s.name}`,maxLength:2e3});return r.appendChild(i),r.appendChild(a),r.appendChild(l),r}function Rs(e,t){let n=document.createElement("div");f(n,{padding:"10px 12px",borderBottom:"1px solid #e0e0e0",display:"flex",justifyContent:"space-between",alignItems:"center",backgroundColor:"#fff",width:"100%"});let o=document.createElement("div");f(o,{display:"flex",alignItems:"center",gap:"8px"});let r=document.createElement("span");r.textContent=e.type==="public"?"\u{1F310}":"\u{1F512}",f(r,{fontSize:"16px"});let s=document.createElement("div");s.textContent=e.name,f(s,{fontSize:"16px",fontWeight:"bold"});let i=document.createElement("span");i.textContent=e.type==="public"?"Public":"Private",f(i,{fontSize:"10px",padding:"2px 8px",borderRadius:"10px",backgroundColor:e.type==="public"?"#e3f2fd":"#fff3e0",color:e.type==="public"?"#1565c0":"#e65100"}),o.appendChild(r),o.appendChild(s),o.appendChild(i);let a=document.createElement("div");f(a,{display:"flex",gap:"8px"});let l=zo("\u{1F50D}","Search in channel"),c=zo("\u{1F465}","Toggle team members");return c.addEventListener("click",t),a.appendChild(l),a.appendChild(c),n.appendChild(o),n.appendChild(a),n}function zo(e,t){let n=document.createElement("button");return n.textContent=e,n.title=t,f(n,{width:"28px",height:"28px",borderRadius:"4px",backgroundColor:"transparent",border:"none",cursor:"pointer",fontSize:"14px",display:"flex",alignItems:"center",justifyContent:"center"}),n.addEventListener("mouseover",()=>{n.style.backgroundColor="#f5f5f5"}),n.addEventListener("mouseout",()=>{n.style.backgroundColor="transparent"}),n}function Ns(e){let t=document.createElement("div");f(t,{flex:"1",overflowY:"auto",padding:"20px",display:"flex",flexDirection:"column",gap:"12px",width:"100%",minHeight:"200px"});let n=document.createElement("div");f(n,{margin:"auto",textAlign:"center",color:"#666",padding:"20px",backgroundColor:"#f8f9fa",borderRadius:"8px",maxWidth:"80%"});let o=document.createElement("div");o.textContent="\u{1F4AC}",f(o,{fontSize:"48px",marginBottom:"12px"});let r=document.createElement("div");r.textContent=`Welcome to #${e.name}`,f(r,{fontSize:"18px",fontWeight:"bold",marginBottom:"8px"});let s=document.createElement("div");return s.textContent="This is the start of your conversation. Messages are encrypted and will expire after 24 hours.",f(s,{fontSize:"14px"}),n.appendChild(o),n.appendChild(r),n.appendChild(s),t.appendChild(n),t}function Ts(e,t){let n=document.createElement("div");f(n,{height:"100%",borderLeft:"1px solid #e0e0e0",display:"flex",flexDirection:"column",backgroundColor:"#f8f9fa"});let o=document.createElement("div");f(o,{padding:"10px 12px",borderBottom:"1px solid #e0e0e0",display:"flex",justifyContent:"space-between",alignItems:"center"});let r=document.createElement("h2");r.textContent="Team Members",f(r,{margin:"0",fontSize:"16px",fontWeight:"bold"});let s=document.createElement("span");s.textContent=e.length.toString(),f(s,{backgroundColor:"#e0e0e0",color:"#333",borderRadius:"12px",padding:"1px 6px",fontSize:"11px",fontWeight:"bold"}),o.appendChild(r),o.appendChild(s);let i=document.createElement("div");f(i,{padding:"8px 12px",borderBottom:"1px solid #e0e0e0"});let a=document.createElement("div");f(a,{display:"flex",alignItems:"center",backgroundColor:"white",borderRadius:"16px",border:"1px solid #ddd",padding:"0 10px"});let l=document.createElement("span");l.textContent="\u{1F50D}",f(l,{fontSize:"12px",color:"#666",marginRight:"6px"});let c=document.createElement("input");c.type="text",c.placeholder="Search users...",f(c,{width:"100%",padding:"6px 0",border:"none",borderRadius:"16px",fontSize:"13px",outline:"none"}),a.appendChild(l),a.appendChild(c),i.appendChild(a);let p=document.createElement("div");f(p,{flex:"1",overflowY:"auto",padding:"4px 0"});let u=e.filter(A=>A.status==="online"),m=e.filter(A=>A.status==="away"),x=e.filter(A=>A.status==="dnd"),N=e.filter(A=>A.status==="offline"||!A.status);return u.length>0&&St(p,"Online",u,t),m.length>0&&St(p,"Away",m,t),x.length>0&&St(p,"Do Not Disturb",x,t),N.length>0&&St(p,"Offline",N,t),n.appendChild(o),n.appendChild(i),n.appendChild(p),n}function St(e,t,n,o){let r=document.createElement("div");f(r,{padding:"8px 12px 4px",fontSize:"10px",color:"#666",fontWeight:"bold",textTransform:"uppercase",letterSpacing:"0.5px"}),r.textContent=`${t} \u2014 ${n.length}`;let s=document.createElement("div");f(s,{marginBottom:"10px"}),n.forEach(i=>{let a=Us(i,i.status==="online",o);s.appendChild(a)}),e.appendChild(r),e.appendChild(s)}function Us(e,t,n){let o=document.createElement("div");f(o,{display:"flex",alignItems:"center",padding:"6px 12px",cursor:"pointer",opacity:t?"1":"0.7"});let r=document.createElement("div");f(r,{width:"6px",height:"6px",borderRadius:"50%",marginRight:"8px"}),e.status==="online"?r.style.backgroundColor="#4CAF50":e.status==="away"?r.style.backgroundColor="#FFC107":e.status==="dnd"?r.style.backgroundColor="#F44336":r.style.backgroundColor="#9E9E9E";let s=document.createElement("div"),i=(e.displayName||e.username).charAt(0).toUpperCase();s.textContent=i;let a=Bs(e.username),l=`hsl(${a}, 70%, 80%)`,c=`hsl(${a}, 70%, 30%)`;f(s,{width:"28px",height:"28px",borderRadius:"50%",backgroundColor:l,color:c,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:"bold",fontSize:"14px",marginRight:"8px"});let p=document.createElement("div");f(p,{flex:"1"});let u=document.createElement("div");if(u.textContent=e.displayName||e.username,f(u,{fontWeight:"medium",fontSize:"13px"}),e.role==="admin"||e.role==="moderator"){let x=document.createElement("span");x.textContent=e.role,f(x,{fontSize:"9px",backgroundColor:e.role==="admin"?"#f44336":"#2196F3",color:"white",padding:"1px 4px",borderRadius:"8px",marginLeft:"4px",textTransform:"uppercase",fontWeight:"bold"}),u.appendChild(x)}if(e.statusMessage){let x=document.createElement("div");x.textContent=e.statusMessage,f(x,{fontSize:"11px",color:"#666",marginTop:"1px"}),p.appendChild(x)}p.appendChild(u);let m=document.createElement("button");return m.innerHTML="\u{1F4AC}",m.title="Message",f(m,{backgroundColor:"transparent",border:"none",cursor:"pointer",fontSize:"14px",padding:"2px",borderRadius:"4px"}),m.addEventListener("mouseover",()=>{m.style.backgroundColor="rgba(0, 0, 0, 0.05)"}),m.addEventListener("mouseout",()=>{m.style.backgroundColor="transparent"}),m.addEventListener("click",x=>{x.stopPropagation(),n(e)}),o.addEventListener("click",()=>{n(e)}),o.addEventListener("mouseover",()=>{o.style.backgroundColor="rgba(0, 0, 0, 0.05)"}),o.addEventListener("mouseout",()=>{o.style.backgroundColor="transparent"}),o.appendChild(r),o.appendChild(s),o.appendChild(p),o.appendChild(m),o}function Bs(e){let t=0;for(let n=0;n<e.length;n++)t=e.charCodeAt(n)+((t<<5)-t);return t%360}function f(e,t){Object.assign(e.style,t)}function xn(e,t={}){let{currentUser:n=null}=t;if(!(n&&n.role==="admin"))return Ps(e);let r=document.createElement("div");b(r,{display:"flex",flexDirection:"column",width:"100%",height:"100%",backgroundColor:"#f5f7f9",padding:"20px"});let s=Vs();r.appendChild(s);let i=document.createElement("div");b(i,{display:"flex",borderBottom:"1px solid #dee2e6",marginBottom:"20px"});let a=[{id:"users",label:"Users",icon:"\u{1F465}"},{id:"channels",label:"Channels",icon:"\u{1F310}"},{id:"roles",label:"Roles & Permissions",icon:"\u{1F512}"},{id:"audit",label:"Audit Log",icon:"\u{1F4CB}"}],l="users";a.forEach(p=>{let u=Ds(p,p.id===l);i.appendChild(u)}),r.appendChild(i);let c=document.createElement("div");switch(b(c,{flex:"1",backgroundColor:"#ffffff",borderRadius:"4px",padding:"20px",boxShadow:"0 1px 3px rgba(0,0,0,0.1)",overflow:"auto"}),l){case"users":_o(c);break;case"channels":$s(c);break;case"roles":js(c);break;case"audit":Hs(c);break;default:_o(c)}return r.appendChild(c),e.appendChild(r),r}function Ps(e){let t=document.createElement("div");b(t,{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",width:"100%",padding:"20px",textAlign:"center",color:"#721c24",backgroundColor:"#f8d7da"});let n=document.createElement("div");n.innerHTML="\u26D4",b(n,{fontSize:"48px",marginBottom:"16px"});let o=document.createElement("h3");o.textContent="Access Denied",b(o,{margin:"0 0 10px 0",fontSize:"24px"});let r=document.createElement("p");return r.textContent="Administrator privileges are required to access this area.",t.appendChild(n),t.appendChild(o),t.appendChild(r),e.appendChild(t),t}function Vs(){let e=document.createElement("div");b(e,{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"20px"});let t=document.createElement("h2");t.textContent="Admin Panel",b(t,{margin:"0",fontSize:"24px",fontWeight:"bold",color:"#333"});let n=document.createElement("p");n.textContent="Manage users, channels, and permissions",b(n,{margin:"0",color:"#666",fontSize:"14px"});let o=document.createElement("div");return o.appendChild(t),o.appendChild(n),e.appendChild(o),e}function Ds(e,t){let n=document.createElement("div");b(n,{padding:"12px 16px",cursor:"pointer",borderBottom:t?"2px solid #2196F3":"2px solid transparent",color:t?"#2196F3":"#666",fontWeight:t?"bold":"normal",display:"flex",alignItems:"center",gap:"8px"});let o=document.createElement("span");o.textContent=e.icon;let r=document.createElement("span");return r.textContent=e.label,n.appendChild(o),n.appendChild(r),n.addEventListener("mouseover",()=>{t||(n.style.color="#333",n.style.borderBottom="2px solid #ddd")}),n.addEventListener("mouseout",()=>{t||(n.style.color="#666",n.style.borderBottom="2px solid transparent")}),n}function _o(e){let t=zs();e.appendChild(t);let n=_s();e.appendChild(n)}function zs(){let e=document.createElement("div");b(e,{display:"flex",justifyContent:"space-between",marginBottom:"15px",padding:"15px",backgroundColor:"#f8f9fa",borderRadius:"4px",border:"1px solid #dee2e6"});let t=document.createElement("div");b(t,{display:"flex",alignItems:"center",flex:"1",marginRight:"15px"});let n=document.createElement("span");n.textContent="\u{1F50D}",b(n,{marginRight:"8px"});let o=document.createElement("input");o.type="text",o.placeholder="Search users...",b(o,{flex:"1",padding:"8px 12px",border:"1px solid #ced4da",borderRadius:"4px",fontSize:"14px"}),t.appendChild(n),t.appendChild(o);let r=document.createElement("div");b(r,{display:"flex",gap:"10px"});let s=document.createElement("button");b(s,{backgroundColor:"#28a745",color:"white",border:"none",borderRadius:"4px",padding:"8px 12px",fontSize:"14px",cursor:"pointer",display:"flex",alignItems:"center",gap:"6px"});let i=document.createElement("span");i.textContent="+",s.appendChild(i);let a=document.createElement("span");a.textContent="Create User",s.appendChild(a);let l=document.createElement("button");b(l,{backgroundColor:"#6c757d",color:"white",border:"none",borderRadius:"4px",padding:"8px 12px",fontSize:"14px",cursor:"pointer",display:"flex",alignItems:"center",gap:"6px"});let c=document.createElement("span");c.textContent="\u2191",l.appendChild(c);let p=document.createElement("span");return p.textContent="Import",l.appendChild(p),r.appendChild(s),r.appendChild(l),e.appendChild(t),e.appendChild(r),e}function _s(){let e=document.createElement("div");b(e,{backgroundColor:"#ffffff",border:"1px solid #dee2e6",borderRadius:"4px",overflow:"hidden"});let t=document.createElement("table");b(t,{width:"100%",borderCollapse:"collapse",fontSize:"14px"});let n=document.createElement("thead");b(n,{backgroundColor:"#f8f9fa",fontWeight:"bold"});let o=document.createElement("tr");["Username","Display Name","Role","Status","Last Login","Actions"].forEach(l=>{let c=document.createElement("th");c.textContent=l,b(c,{padding:"12px 15px",textAlign:"left",borderBottom:"2px solid #dee2e6"}),o.appendChild(c)}),n.appendChild(o),t.appendChild(n);let s=document.createElement("tbody");[{username:"admin",displayName:"Administrator",role:"admin",status:"online",lastLogin:"2023-04-15T08:30:00Z"},{username:"john.doe",displayName:"John Doe",role:"user",status:"online",lastLogin:"2023-04-15T09:15:00Z"},{username:"jane.smith",displayName:"Jane Smith",role:"moderator",status:"away",lastLogin:"2023-04-14T17:45:00Z"},{username:"support",displayName:"Support Team",role:"moderator",status:"dnd",lastLogin:"2023-04-15T10:00:00Z"}].forEach(l=>{let c=Fs(l);s.appendChild(c)}),t.appendChild(s),e.appendChild(t);let a=Os(1,1,4);return e.appendChild(a),e}function Fs(e){let t=document.createElement("tr");t.addEventListener("mouseover",()=>{t.style.backgroundColor="#f8f9fa"}),t.addEventListener("mouseout",()=>{t.style.backgroundColor=""});let n=document.createElement("td");n.textContent=e.username,b(n,{padding:"12px 15px",borderBottom:"1px solid #dee2e6"});let o=document.createElement("td");o.textContent=e.displayName,b(o,{padding:"12px 15px",borderBottom:"1px solid #dee2e6"});let r=document.createElement("td"),s=document.createElement("span");s.textContent=e.role||"user";let i="#6c757d";e.role==="admin"?i="#dc3545":e.role==="moderator"&&(i="#ffc107"),b(s,{backgroundColor:i,color:"white",padding:"3px 8px",borderRadius:"12px",fontSize:"12px",fontWeight:"bold",textTransform:"uppercase"}),r.appendChild(s),b(r,{padding:"12px 15px",borderBottom:"1px solid #dee2e6"});let a=document.createElement("td"),l=document.createElement("span");l.textContent=e.status||"offline";let c="#6c757d";e.status==="online"?c="#28a745":e.status==="away"?c="#ffc107":e.status==="dnd"&&(c="#dc3545"),b(l,{backgroundColor:c,color:"white",padding:"3px 8px",borderRadius:"12px",fontSize:"12px"}),a.appendChild(l),b(a,{padding:"12px 15px",borderBottom:"1px solid #dee2e6"});let p=document.createElement("td");p.textContent=Ws(e.lastLogin),b(p,{padding:"12px 15px",borderBottom:"1px solid #dee2e6"});let u=document.createElement("td");b(u,{padding:"12px 15px",borderBottom:"1px solid #dee2e6"});let m=document.createElement("div");b(m,{display:"flex",gap:"5px"});let x=fn("\u270F\uFE0F","Edit user"),N=fn("\u{1F511}","Reset password"),A=fn("\u{1F5D1}\uFE0F","Delete user");return m.appendChild(x),m.appendChild(N),m.appendChild(A),u.appendChild(m),t.appendChild(n),t.appendChild(o),t.appendChild(r),t.appendChild(a),t.appendChild(p),t.appendChild(u),t}function fn(e,t){let n=document.createElement("button");return n.textContent=e,n.title=t,b(n,{width:"28px",height:"28px",borderRadius:"4px",border:"1px solid #dee2e6",backgroundColor:"white",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"14px"}),n.addEventListener("mouseover",()=>{n.style.backgroundColor="#f8f9fa"}),n.addEventListener("mouseout",()=>{n.style.backgroundColor="white"}),n}function Os(e,t,n){let o=document.createElement("div");b(o,{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"10px 15px",backgroundColor:"#f8f9fa",borderTop:"1px solid #dee2e6"});let r=document.createElement("div");r.textContent=`Showing ${n} of ${n} users`,b(r,{fontSize:"14px",color:"#6c757d"});let s=document.createElement("div");b(s,{display:"flex",gap:"5px",alignItems:"center"});let i=document.createElement("button");i.textContent="\u27E8\u27E8",i.title="First Page",b(i,{padding:"5px 10px",border:"1px solid #dee2e6",borderRadius:"4px",backgroundColor:"white",cursor:"pointer",opacity:"0.5"}),i.disabled=!0;let a=document.createElement("button");a.textContent="\u27E8",a.title="Previous Page",b(a,{padding:"5px 10px",border:"1px solid #dee2e6",borderRadius:"4px",backgroundColor:"white",cursor:"pointer",opacity:"0.5"}),a.disabled=!0;let l=document.createElement("span");l.textContent=`Page ${e} of ${t}`,b(l,{padding:"0 10px",fontSize:"14px"});let c=document.createElement("button");c.textContent="\u27E9",c.title="Next Page",b(c,{padding:"5px 10px",border:"1px solid #dee2e6",borderRadius:"4px",backgroundColor:"white",cursor:"pointer",opacity:"0.5"}),c.disabled=!0;let p=document.createElement("button");return p.textContent="\u27E9\u27E9",p.title="Last Page",b(p,{padding:"5px 10px",border:"1px solid #dee2e6",borderRadius:"4px",backgroundColor:"white",cursor:"pointer",opacity:"0.5"}),p.disabled=!0,s.appendChild(i),s.appendChild(a),s.appendChild(l),s.appendChild(c),s.appendChild(p),o.appendChild(r),o.appendChild(s),o}function $s(e){let t=document.createElement("div");b(t,{textAlign:"center",padding:"20px",color:"#666"}),t.textContent="Channel management interface would go here",e.appendChild(t)}function js(e){let t=document.createElement("div");b(t,{textAlign:"center",padding:"20px",color:"#666"}),t.textContent="Roles and permissions management interface would go here",e.appendChild(t)}function Hs(e){let t=document.createElement("div");b(t,{textAlign:"center",padding:"20px",color:"#666"}),t.textContent="Audit log interface would go here",e.appendChild(t)}function Ws(e){if(!e)return"Never";try{return new Date(e).toLocaleString()}catch{return e}}function b(e,t){Object.assign(e.style,t)}function yn(e,t={}){let{onLogout:n=()=>console.log("Logout not implemented")}=t,o=document.createElement("div");$(o,{display:"flex",flexDirection:"column",width:"100%",height:"100%",padding:"20px",backgroundColor:"#ffffff",overflowY:"auto"});let r=document.createElement("div");$(r,{marginBottom:"24px",borderBottom:"1px solid #e0e0e0",paddingBottom:"16px"});let s=document.createElement("h2");return s.textContent="Settings",$(s,{margin:"0",fontSize:"20px",color:"#333"}),r.appendChild(s),o.appendChild(r),[{title:"Appearance",icon:"\u{1F3A8}",description:"Customize the look and feel of the chat.",settings:[{name:"Theme",type:"select",options:["Light","Dark","System"],defaultValue:"Light"},{name:"Font Size",type:"select",options:["Small","Medium","Large"],defaultValue:"Small"}]},{title:"Privacy & Security",icon:"\u{1F512}",description:"Manage security and privacy settings.",settings:[{name:"Change Password",type:"button",label:"Change Password"},{name:"Two-Factor Authentication",type:"checkbox"}]},{title:"Account",icon:"\u{1F464}",description:"Manage your account settings.",settings:[{name:"Logout",type:"logout",label:"Sign Out",description:"Log out of your account"}]}].forEach(a=>{let l=qs(a,n);o.appendChild(l)}),e.appendChild(o),o}function qs(e,t){let n=document.createElement("div");$(n,{marginBottom:"24px",padding:"16px",backgroundColor:"#f8f9fa",borderRadius:"8px"});let o=document.createElement("div");$(o,{display:"flex",alignItems:"center",marginBottom:"12px"});let r=document.createElement("span");r.textContent=e.icon,$(r,{fontSize:"20px",marginRight:"8px"});let s=document.createElement("h3");if(s.textContent=e.title,$(s,{margin:"0",fontSize:"16px",color:"#333"}),o.appendChild(r),o.appendChild(s),e.description){let i=document.createElement("p");i.textContent=e.description,$(i,{margin:"0 0 16px 0",fontSize:"14px",color:"#666"}),n.appendChild(o),n.appendChild(i)}if(e.settings&&e.settings.length){let i=document.createElement("div");$(i,{display:"flex",flexDirection:"column",gap:"12px"}),e.settings.forEach(a=>{let l=Gs(a,t);i.appendChild(l)}),n.appendChild(i)}return n}function Gs(e,t){let n=document.createElement("div");$(n,{display:"flex",alignItems:"center",justifyContent:"space-between"});let o=document.createElement("div");$(o,{display:"flex",flexDirection:"column"});let r=document.createElement("label");r.textContent=e.name,$(r,{fontSize:"14px",color:"#333"}),o.appendChild(r);let s;switch(e.type){case"select":s=document.createElement("select"),$(s,{padding:"8px",border:"1px solid #ddd",borderRadius:"4px",width:"120px"}),e.options&&e.options.length&&e.options.forEach(i=>{let a=document.createElement("option");a.value=i,a.textContent=i,i===e.defaultValue&&(a.selected=!0),s.appendChild(a)});break;case"checkbox":s=document.createElement("input"),s.type="checkbox";break;case"button":s=document.createElement("button"),s.textContent=e.label,$(s,{padding:"8px 12px",backgroundColor:"#fff",color:"#333",border:"1px solid #ddd",borderRadius:"4px",cursor:"pointer"});break;case"logout":s=document.createElement("button"),s.textContent=e.label,$(s,{padding:"8px 12px",backgroundColor:"#dc3545",color:"white",border:"none",borderRadius:"4px",cursor:"pointer"}),s.addEventListener("mouseover",()=>{s.style.backgroundColor="#c82333"}),s.addEventListener("mouseout",()=>{s.style.backgroundColor="#dc3545"}),s.addEventListener("click",t);break;default:s=document.createElement("span"),s.textContent="Unsupported setting type"}return n.appendChild(o),n.appendChild(s),n}function $(e,t){Object.assign(e.style,t)}function ie(e,t){Object.assign(e.style,t)}function Cn(){return{channels:[{id:"general",name:"General",description:"General chat for team discussions",type:"public",unread:0},{id:"announcements",name:"Announcements",description:"Important team announcements",type:"public",unread:2},{id:"hipaa-compliance",name:"HIPAA Compliance",description:"Discussions about HIPAA compliance",type:"public",unread:0},{id:"pharmacy-staff",name:"Pharmacy Staff",description:"Private channel for pharmacy staff",type:"private",unread:5}],users:[{id:"user1",username:"john.smith",displayName:"John Smith",role:"admin",status:"online"},{id:"user2",username:"sarah.johnson",displayName:"Sarah Johnson",role:"user",status:"online"},{id:"user3",username:"michael.brown",displayName:"Michael Brown",role:"moderator",status:"away"},{id:"user4",username:"lisa.davis",displayName:"Lisa Davis",role:"user",status:"dnd"},{id:"user5",username:"robert.wilson",displayName:"Robert Wilson",role:"user",status:"offline"}]}}var Js={primary:"#2196F3",primaryDark:"#1976D2",secondary:"#343a40",accent:"#4CAF50",error:"#F44336",warning:"#FFC107",text:"#333333",textSecondary:"#666666",border:"#e0e0e0",background:"#f5f7f9",white:"#ffffff"};function Fo(e,t){Object.assign(e.style,t)}function Ys(e){if(!e)return"Never";try{let t=new Date(e);return t.toLocaleDateString()+" "+t.toLocaleTimeString()}catch{return e}}function Ks(e,t="#2196F3"){let n=document.createElement("button");return n.textContent=e,Fo(n,{backgroundColor:t,color:"#fff",border:"none",borderRadius:"4px",padding:"6px 12px",fontSize:"13px",cursor:"pointer",fontWeight:"bold",minWidth:"70px"}),n.addEventListener("mouseover",()=>{let o=t.replace(/^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i,(r,s,i,a)=>"#"+Math.max(0,parseInt(s,16)-20).toString(16).padStart(2,"0")+Math.max(0,parseInt(i,16)-20).toString(16).padStart(2,"0")+Math.max(0,parseInt(a,16)-20).toString(16).padStart(2,"0"));n.style.backgroundColor=o}),n.addEventListener("mouseout",()=>{n.style.backgroundColor=t}),n}var il={createCustomHeader,renderChatView,renderAdminView,renderSettingsView,setupMockData:Cn,COLORS:Js,applyStyles:Fo,formatDateTime:Ys,createActionButton:Ks};async function Oo(e){let t=document.createElement("div");t.className="hipaa-chat-wrapper",t.id="hipaa-chat-container",ie(t,{position:"fixed",bottom:"20px",right:"20px",zIndex:"9999",width:"700px",height:"500px",boxSizing:"border-box",display:"none"}),e.container&&e.container.parentNode?e.container.parentNode.replaceChild(t,e.container):document.body.appendChild(t);let n=document.createElement("div");n.className="hipaa-chat-app",ie(n,{display:"flex",flexDirection:"column",width:"100%",height:"100%",overflow:"hidden",fontFamily:'-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, "Open Sans", "Helvetica Neue", sans-serif',borderRadius:"8px",boxShadow:"0 4px 12px rgba(0, 0, 0, 0.3)",color:"#333",backgroundColor:"#fff"}),t.appendChild(n);let o=Cn();return $o()||await Q(),{container:t,appElement:n,mockData:o}}var Be={primary:"#343a40",secondary:"#3a444f",text:"#ffffff",accent:"#2196F3"},bn=class{constructor(t,n){this.container=t,this.onLoginSuccess=typeof n=="function"?n:()=>{console.warn("[LoginForm] No login success callback provided")},this.formElement=null,this.usernameInput=null,this.passwordInput=null,this.submitButton=null,this.render=this.render.bind(this),this.handleSubmit=this.handleSubmit.bind(this),this.render()}render(){let t=document.createElement("div");t.className="login-container",this.applyStyles(t,{maxWidth:"380px",width:"100%",margin:"40px auto 0",padding:"20px",backgroundColor:"white",borderRadius:"8px",boxShadow:"0 2px 10px rgba(0,0,0,0.1)",textAlign:"center"});let n=document.createElement("h2");n.textContent="Mountain Care Pharmacy",this.applyStyles(n,{color:Be.primary,fontSize:"24px",margin:"0 0 8px",fontWeight:"bold"});let o=document.createElement("p");o.textContent="Please log in to continue",this.applyStyles(o,{color:"#666",margin:"0 0 20px",fontSize:"14px"}),this.formElement=document.createElement("form"),this.formElement.className="login-form",this.applyStyles(this.formElement,{display:"flex",flexDirection:"column",gap:"16px"}),this.formElement.addEventListener("submit",this.handleSubmit);let r=this.createFormGroup("Username","username","text");this.usernameInput=r.querySelector("input");let s=this.createFormGroup("Password","password","password");this.passwordInput=s.querySelector("input");let i=document.createElement("div");this.applyStyles(i,{display:"flex",alignItems:"center",marginTop:"-8px"});let a=document.createElement("input");a.type="checkbox",a.id="remember-me",a.name="remember";let l=document.createElement("label");l.htmlFor="remember-me",l.textContent="Remember me",this.applyStyles(l,{fontSize:"14px",color:"#666",marginLeft:"8px",cursor:"pointer"}),i.appendChild(a),i.appendChild(l),this.submitButton=document.createElement("button"),this.submitButton.type="submit",this.submitButton.textContent="Login",this.applyStyles(this.submitButton,{backgroundColor:Be.primary,color:Be.text,border:"none",padding:"10px",borderRadius:"4px",fontSize:"16px",cursor:"pointer",fontWeight:"bold",width:"100%"}),this.submitButton.addEventListener("mouseover",()=>{this.submitButton.style.backgroundColor=Be.secondary}),this.submitButton.addEventListener("mouseout",()=>{this.submitButton.style.backgroundColor=Be.primary});let c=document.createElement("p");c.textContent="This system complies with HIPAA security requirements",this.applyStyles(c,{fontSize:"12px",color:"#666",margin:"16px 0 0"});let p=document.createElement("p");p.textContent="All communication is encrypted",this.applyStyles(p,{fontSize:"12px",color:"#666",margin:"8px 0 0"}),this.formElement.appendChild(r),this.formElement.appendChild(s),this.formElement.appendChild(i),this.formElement.appendChild(this.submitButton),t.appendChild(n),t.appendChild(o),t.appendChild(this.formElement),t.appendChild(c),t.appendChild(p),this.container.innerHTML="",this.container.appendChild(t)}createFormGroup(t,n,o){let r=document.createElement("div");this.applyStyles(r,{display:"flex",flexDirection:"column",textAlign:"left"});let s=document.createElement("label");s.htmlFor=n,s.textContent=t,this.applyStyles(s,{fontSize:"14px",color:"#666",marginBottom:"4px"});let i=document.createElement("div");this.applyStyles(i,{position:"relative"});let a=document.createElement("input");if(a.type=o,a.id=n,a.name=n,a.required=!0,this.applyStyles(a,{padding:"10px",border:"1px solid #ddd",borderRadius:"4px",width:"100%",boxSizing:"border-box",fontSize:"14px"}),o==="password"){let l=document.createElement("button");l.type="button",l.textContent="\u{1F441}\uFE0F",this.applyStyles(l,{position:"absolute",right:"8px",top:"50%",transform:"translateY(-50%)",backgroundColor:"transparent",border:"none",cursor:"pointer",fontSize:"16px",color:"#f44336"}),l.addEventListener("click",()=>{a.type=a.type==="password"?"text":"password"}),i.appendChild(l)}return i.appendChild(a),r.appendChild(s),r.appendChild(i),r}async handleSubmit(t){t.preventDefault();try{let n=this.usernameInput.value,o=this.passwordInput.value,r=t.target.remember?.checked||!1;this.submitButton.disabled=!0,this.submitButton.textContent="Logging in...",this.usernameInput.disabled=!0,this.passwordInput.disabled=!0;let s=await ge(n,o);s.success?(d("auth","Login successful",{username:n}),this.onLoginSuccess(s.user)):(alert(s.error||"Login failed. Please try again."),this.submitButton.disabled=!1,this.submitButton.textContent="Login",this.usernameInput.disabled=!1,this.passwordInput.disabled=!1)}catch(n){console.error("[CRM Extension] Login error:",n),alert("An unexpected error occurred. Please try again."),this.submitButton.disabled=!1,this.submitButton.textContent="Login",this.usernameInput.disabled=!1,this.passwordInput.disabled=!1}}applyStyles(t,n){Object.assign(t.style,n)}destroy(){this.formElement&&this.formElement.removeEventListener("submit",this.handleSubmit),this.container&&(this.container.innerHTML="")}},Pe=bn;function jo(e){try{this.connectionStatus=e,this.render(),d("system",`Connection status changed: ${e}`)}catch(t){console.error("[AppContainer] Connection status change error:",t)}}function Ho(e){try{if(console.log("[AppContainer] Login success handler called",e),!e||!e.username){console.error("[AppContainer] Invalid user object received");return}se(),this.render(),d("auth","User logged in successfully",{username:e.username,userId:e.id,role:e.role})}catch(t){console.error("[AppContainer] Login success handler error:",t),alert("An error occurred during login. Please try again.")}}function Wo(e){try{console.log(`[AppContainer] Channel selected: ${e.id}`),this.selectedChannel=e.id,this.render()}catch(t){console.error("[AppContainer] Channel selection error:",t)}}function qo(e){try{console.log(`[AppContainer] Selected user for direct message: ${e.username}`),d("ui","Selected user for direct message",{targetUser:e.username})}catch(t){console.error("[AppContainer] User selection error:",t)}}function Go(e){try{this.currentView!==e&&(this.currentView=e,this.render(),d("ui",`Switched to ${e} view`))}catch(t){console.error("[AppContainer] View switch error:",t)}}function Jo(){try{this.showUserList=!this.showUserList,this.render(),d("ui",`${this.showUserList?"Showed":"Hid"} user list`)}catch(e){console.error("[AppContainer] Toggle user list error:",e)}}function Yo(){try{te(),this.currentView="chat",this.showUserList=!0,this.selectedChannel="general",d("auth","User logged out"),this.appElement&&(this.appElement.innerHTML=""),this.loginFormComponent=new Pe(this.appElement,this.handleLoginSuccess)}catch(e){console.error("[AppContainer] Logout error:",e)}}var En=class{constructor(t,n={}){this.container=t,this.options={showStatusText:!0,...n},this.statusElement=null,this.statusMenuOpen=!1,this.statusOptions=[{value:"online",label:"Online",icon:"\u{1F7E2}"},{value:"away",label:"Away",icon:"\u{1F7E1}"},{value:"busy",label:"Busy",icon:"\u{1F534}"},{value:"offline",label:"Appear Offline",icon:"\u26AB"}],this.currentStatus="online",this.render=this.render.bind(this),this.toggleStatusMenu=this.toggleStatusMenu.bind(this),this.handleStatusSelect=this.handleStatusSelect.bind(this),this.handleClickOutside=this.handleClickOutside.bind(this),this.initialize()}initialize(){this.statusElement=document.createElement("div"),this.statusElement.className="user-status-container",this.applyStyles(this.statusElement,{position:"relative",display:"inline-block"}),this.container&&this.container.appendChild(this.statusElement);let t=C();t&&t.status&&(this.currentStatus=t.status),this.render(),document.addEventListener("click",this.handleClickOutside),d("ui","User status component initialized")}render(){if(!this.statusElement)return;this.statusElement.innerHTML="";let t=C();if(!S()||!t){this.statusElement.style.display="none";return}else this.statusElement.style.display="inline-block";let n=document.createElement("button");n.className="status-button",this.applyStyles(n,{display:"flex",alignItems:"center",backgroundColor:"transparent",border:"none",padding:"4px 8px",cursor:"pointer",borderRadius:"4px"});let o=this.statusOptions.find(s=>s.value===this.currentStatus)||this.statusOptions[0],r=document.createElement("span");if(r.className="status-icon",r.textContent=o.icon,this.applyStyles(r,{marginRight:this.options.showStatusText?"8px":"0"}),n.appendChild(r),this.options.showStatusText){let s=document.createElement("span");s.className="status-text",s.textContent=o.label,this.applyStyles(s,{fontSize:"14px"});let i=document.createElement("span");i.className="caret-icon",i.innerHTML="&#9662;",this.applyStyles(i,{marginLeft:"4px",fontSize:"10px"}),n.appendChild(s),n.appendChild(i)}if(n.addEventListener("click",this.toggleStatusMenu),this.statusElement.appendChild(n),this.statusMenuOpen){let s=document.createElement("div");s.className="status-menu",this.applyStyles(s,{position:"absolute",top:"100%",right:"0",backgroundColor:"white",border:"1px solid #ddd",borderRadius:"4px",boxShadow:"0 2px 8px rgba(0,0,0,0.15)",zIndex:"1000",marginTop:"4px",minWidth:"150px"}),this.statusOptions.forEach(i=>{let a=document.createElement("div");a.className=`status-menu-item ${i.value===this.currentStatus?"active":""}`,this.applyStyles(a,{display:"flex",alignItems:"center",padding:"8px 12px",cursor:"pointer",backgroundColor:i.value===this.currentStatus?"#f0f0f0":"transparent",borderLeft:i.value===this.currentStatus?"3px solid #2196F3":"3px solid transparent"}),a.addEventListener("mouseover",()=>{i.value!==this.currentStatus&&(a.style.backgroundColor="#f5f5f5")}),a.addEventListener("mouseout",()=>{i.value!==this.currentStatus&&(a.style.backgroundColor="transparent")});let l=document.createElement("span");l.className="status-icon",l.textContent=i.icon,this.applyStyles(l,{marginRight:"8px"});let c=document.createElement("span");c.className="status-label",c.textContent=i.label,a.appendChild(l),a.appendChild(c),a.addEventListener("click",()=>this.handleStatusSelect(i.value)),s.appendChild(a)}),this.statusElement.appendChild(s)}}toggleStatusMenu(t){t.stopPropagation(),this.statusMenuOpen=!this.statusMenuOpen,this.render()}handleStatusSelect(t){this.currentStatus=t,this.statusMenuOpen=!1,this.render(),sn(t),d("ui","User status changed",{status:t})}handleClickOutside(t){this.statusElement&&!this.statusElement.contains(t.target)&&this.statusMenuOpen&&(this.statusMenuOpen=!1,this.render())}updateStatus(t){this.statusOptions.some(n=>n.value===t)&&(this.currentStatus=t,this.render())}applyStyles(t,n){Object.assign(t.style,n)}destroy(){document.removeEventListener("click",this.handleClickOutside),this.statusElement&&this.statusElement.parentNode&&this.statusElement.parentNode.removeChild(this.statusElement),d("ui","User status component destroyed")}},Sn=En;var wn=class{constructor(t={}){this.options={user:null,connectionStatus:"disconnected",activeView:"chat",onViewSwitch:()=>{},onToggleUserList:()=>{},onToggleAdminPanel:()=>{},...t},this.headerElement=null,this.connectionIndicator=null,this.userStatusComponent=null,this.render=this.render.bind(this),this.updateConnectionStatus=this.updateConnectionStatus.bind(this),this.updateActiveView=this.updateActiveView.bind(this),this.handleLogout=this.handleLogout.bind(this)}render(){this.headerElement=document.createElement("div"),this.headerElement.className="hipaa-chat-header",this.applyStyles(this.headerElement,{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"0 16px",height:"60px",backgroundColor:"#2196F3",color:"white",boxShadow:"0 2px 4px rgba(0,0,0,0.1)"});let t=document.createElement("div");this.applyStyles(t,{display:"flex",alignItems:"center"});let n=document.createElement("h1");n.textContent="MCP Chat",this.applyStyles(n,{margin:"0 20px 0 0",fontSize:"18px",fontWeight:"bold"});let o=document.createElement("nav");this.applyStyles(o,{display:"flex",gap:"15px"});let r=this.createNavLink("Chat",this.options.activeView==="chat",()=>{this.options.onViewSwitch("chat")}),s=null;this.options.user&&this.options.user.role==="admin"&&(s=this.createNavLink("Admin",this.options.activeView==="admin",()=>{this.options.onViewSwitch("admin")}),o.appendChild(s));let i=this.createNavLink("Settings",this.options.activeView==="settings",()=>{this.options.onViewSwitch("settings")});o.appendChild(r),s&&o.appendChild(s),o.appendChild(i),t.appendChild(n),t.appendChild(o);let a=document.createElement("div");this.connectionIndicator=this.createConnectionIndicator(this.options.connectionStatus),a.appendChild(this.connectionIndicator);let l=document.createElement("div");this.applyStyles(l,{display:"flex",alignItems:"center",gap:"15px"}),this.options.user&&(this.userStatusComponent=new Sn(l));let c=document.createElement("button");c.title="Toggle User List",c.innerHTML="\u{1F465}",this.applyStyles(c,{backgroundColor:"transparent",border:"none",color:"white",fontSize:"20px",cursor:"pointer",padding:"5px"}),c.addEventListener("click",()=>{this.options.onToggleUserList()});let p=this.createUserMenu(this.options.user);return l.appendChild(c),l.appendChild(p),this.headerElement.appendChild(t),this.headerElement.appendChild(a),this.headerElement.appendChild(l),this.headerElement}createNavLink(t,n,o){let r=document.createElement("button");return r.textContent=t,this.applyStyles(r,{backgroundColor:"transparent",border:"none",color:"white",padding:"5px",cursor:"pointer",fontSize:"14px",fontWeight:n?"bold":"normal",borderBottom:n?"2px solid white":"none"}),r.addEventListener("click",o),r}createConnectionIndicator(t){let n={connected:"#4CAF50",connecting:"#FFC107",disconnected:"#F44336",error:"#F44336"},o={connected:"Connected",connecting:"Connecting...",disconnected:"Disconnected",error:"Connection Error"},r=document.createElement("div");r.className="connection-indicator",this.applyStyles(r,{display:"flex",alignItems:"center",gap:"5px",fontSize:"12px"});let s=document.createElement("span");this.applyStyles(s,{display:"inline-block",width:"8px",height:"8px",borderRadius:"50%",backgroundColor:n[t]||"#F44336"});let i=document.createElement("span");return i.textContent=o[t]||"Unknown",r.appendChild(s),r.appendChild(i),r}createUserMenu(t){let n=document.createElement("div");this.applyStyles(n,{position:"relative",display:"flex",alignItems:"center",cursor:"pointer"});let o=document.createElement("div"),r=t?.username?.charAt(0)?.toUpperCase()||"?";o.textContent=r,this.applyStyles(o,{width:"32px",height:"32px",borderRadius:"50%",backgroundColor:"#ffffff33",display:"flex",alignItems:"center",justifyContent:"center",fontWeight:"bold",marginRight:"8px"});let s=document.createElement("div"),i=document.createElement("div");i.textContent=t?.displayName||t?.username||"Unknown User",this.applyStyles(i,{fontWeight:"bold",fontSize:"14px"});let a=document.createElement("div");a.textContent=t?.role||"user",this.applyStyles(a,{fontSize:"12px",opacity:"0.8"}),s.appendChild(i),s.appendChild(a);let l=document.createElement("div");l.className="user-dropdown-menu",this.applyStyles(l,{position:"absolute",top:"100%",right:"0",backgroundColor:"white",boxShadow:"0 2px 10px rgba(0,0,0,0.1)",borderRadius:"4px",width:"150px",display:"none",zIndex:"1000"});let c=this.createMenuItem("Profile",()=>{console.log("[CRM Extension] Profile menu clicked")}),p=this.createMenuItem("Logout",this.handleLogout);l.appendChild(c),l.appendChild(p);let u=()=>{let m=l.style.display==="block";l.style.display=m?"none":"block"};return n.addEventListener("click",u),document.addEventListener("click",m=>{n.contains(m.target)||(l.style.display="none")}),n.appendChild(o),n.appendChild(s),n.appendChild(l),n}createMenuItem(t,n){let o=document.createElement("div");return o.textContent=t,this.applyStyles(o,{padding:"8px 16px",color:"#333",cursor:"pointer",fontSize:"14px"}),o.addEventListener("mouseover",()=>{o.style.backgroundColor="#f5f5f5"}),o.addEventListener("mouseout",()=>{o.style.backgroundColor=""}),o.addEventListener("click",n),o}handleLogout(){d("auth","User initiated logout"),te("User initiated logout"),window.location.reload()}updateConnectionStatus(t){if(!this.connectionIndicator)return;let n=this.createConnectionIndicator(t);this.connectionIndicator.parentNode.replaceChild(n,this.connectionIndicator),this.connectionIndicator=n}updateActiveView(t){if(this.headerElement){let n=this.headerElement.parentNode;if(n){this.options.activeView=t;let o=this.render();n.replaceChild(o,this.headerElement)}}}applyStyles(t,n){Object.assign(t.style,n)}destroy(){this.userStatusComponent&&this.userStatusComponent.destroy(),this.headerElement&&this.headerElement.parentNode&&this.headerElement.parentNode.removeChild(this.headerElement)}},vn=wn;function Ko(e){try{if(console.log("Rendering application, authenticated:",S()),!e.appElement)return;if(e.appElement.innerHTML="",!S()){e.loginFormComponent=new Pe(e.appElement,e.handleLoginSuccess);return}let n=C();if(console.log("Current user:",n),!n){console.error("[AppContainer] No current user found"),e.handleLogout();return}let o;try{o=pn(null,{currentUser:n,connectionStatus:e.connectionStatus,activeView:e.currentView,onViewSwitch:e.switchView,onToggleUserList:e.toggleUserList,onLogout:e.handleLogout})}catch(s){console.warn("[AppContainer] Error using createCustomHeader, falling back to Header component:",s),e.headerComponent=new vn({user:n,connectionStatus:e.connectionStatus,activeView:e.currentView,onViewSwitch:e.switchView,onToggleUserList:e.toggleUserList}),o=e.headerComponent.render()}e.appElement.appendChild(o);let r=document.createElement("div");r.className="app-content",ie(r,{display:"flex",flex:"1",overflow:"hidden",backgroundColor:"#f5f7f9",width:"100%"});try{e.currentView==="chat"?gn(r,{showUserList:e.showUserList,selectedChannel:e.selectedChannel,mockChannels:e.mockData.channels,mockUsers:e.mockData.users,onChannelSelect:e.handleChannelSelect,onUserSelect:e.handleUserSelect,toggleUserList:e.toggleUserList}):e.currentView==="admin"?xn(r,{currentUser:n}):e.currentView==="settings"&&yn(r,{onLogout:e.handleLogout})}catch(s){console.error("[AppContainer] Error rendering view:",s),r.innerHTML='<div style="padding: 20px; text-align: center;">Error loading view. Please try again.</div>'}e.appElement.appendChild(r)}catch(t){console.error("[AppContainer] Render error:",t),e.renderErrorState(t)}}var kn=class{constructor(t){this.container=t,this.appElement=null,this.headerComponent=null,this.loginFormComponent=null,this.notificationSystem=null,this.connectionStatus="connected",this.currentView="chat",this.showUserList=!0,this.selectedChannel="general",this.mockData={},this.unsubscribeConnectionStatus=null,this.handleConnectionStatusChange=jo.bind(this),this.handleLoginSuccess=Ho.bind(this),this.handleChannelSelect=Wo.bind(this),this.handleUserSelect=qo.bind(this),this.switchView=Go.bind(this),this.toggleUserList=Jo.bind(this),this.toggleChatVisibility=this.toggleChatVisibility.bind(this),this.handleLogout=Yo.bind(this),this.render=this.render.bind(this),this.renderErrorState=this.renderErrorState.bind(this),this.initialize()}async initialize(){try{let t=await Oo(this);this.container=t.container,this.appElement=t.appElement,this.mockData=t.mockData,window.toggleChatUI=()=>{this.toggleChatVisibility()},console.log("[CRM Extension] toggleChatUI registered globally",typeof window.toggleChatUI),this.unsubscribeConnectionStatus=on(this.handleConnectionStatusChange),this.connectionStatus=nn(),this.notificationSystem=new dn,S()&&se(),this.render(),d("system","Application initialized")}catch(t){console.error("[AppContainer] Initialization error:",t),this.renderErrorState(t)}}toggleChatVisibility(){if(!this.container){console.error("[CRM Extension] Cannot toggle chat: container is null");return}console.log("[CRM Extension] toggleChatVisibility called");let t=this.container.style.display,n=t==="none"||t===""?"flex":"none";this.container.style.display=n,n==="flex"&&this.render(),console.log(`[CRM Extension] Chat container toggled to: ${this.container.style.display}`)}render(){Ko(this)}renderErrorState(t){if(!this.appElement)return;this.appElement.innerHTML="";let n=document.createElement("div");ie(n,{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",padding:"20px",textAlign:"center",backgroundColor:"#f8d7da",color:"#721c24"});let o=document.createElement("div");o.textContent="\u26A0\uFE0F",ie(o,{fontSize:"48px",marginBottom:"16px"});let r=document.createElement("h2");r.textContent="Application Initialization Failed";let s=document.createElement("p");s.textContent=t.message||"An unexpected error occurred.";let i=document.createElement("button");i.textContent="Retry",ie(i,{backgroundColor:"#007bff",color:"white",border:"none",padding:"10px 20px",borderRadius:"4px",marginTop:"16px",cursor:"pointer"}),i.addEventListener("click",()=>this.initialize()),n.appendChild(o),n.appendChild(r),n.appendChild(s),n.appendChild(i),this.appElement.appendChild(n)}destroy(){try{this.unsubscribeConnectionStatus&&this.unsubscribeConnectionStatus(),this.notificationSystem&&this.notificationSystem.destroy(),this.appElement&&this.appElement.parentNode&&this.appElement.parentNode.removeChild(this.appElement),typeof window.toggleChatUI=="function"&&delete window.toggleChatUI,d("system","Application destroyed")}catch(t){console.error("[AppContainer] Destruction error:",t)}}},Mn=kn;var Ln=null;function q(){try{if(document.getElementById("hipaa-chat-container"))return console.log("[CRM Extension] Chat UI already initialized"),!0;console.log("[CRM Extension] Initializing Chat UI");let e=document.createElement("div");return e.id="hipaa-chat-container",Object.assign(e.style,{position:"fixed",bottom:"20px",right:"20px",width:"400px",height:"500px",backgroundColor:"#f0f8ff",borderRadius:"8px",boxShadow:"0 4px 12px rgba(0, 0, 0, 0.3)",zIndex:"10000",overflow:"hidden",border:"2px solid #2196F3",display:"none"}),document.body.appendChild(e),Ln=new Mn(e),window.toggleChatUI=function(){console.log("[CRM Extension] toggleChatUI called");let t=document.getElementById("hipaa-chat-container");if(!t){console.error("[CRM Extension] Chat container not found");return}let n=t.style.display!=="none";if(t.style.display=n?"none":"flex",console.log(`[CRM Extension] Chat container toggled to: ${t.style.display}`),!n&&Ln)try{Ln.render()}catch(o){console.error("[CRM Extension] Error rendering chat app:",o)}},d("system","Chat UI initialized"),!0}catch(e){return console.error("[CRM Extension] Error initializing Chat UI:",e),!1}}var An=!1,er=[];async function Q(){if(An)return console.log("[CRM Extension] Chat system already initialized"),!0;try{if(console.log("[CRM Extension] Initializing HIPAA-compliant chat system"),!xo())throw new Error("Failed to initialize storage");if(await rt(),!dt())throw new Error("Failed to initialize auth service");if(!Uo())throw new Error("Failed to initialize user service");if(!Vo())throw new Error("Failed to initialize channel service");if(!Ro())throw new Error("Failed to initialize message service");return q(),d("system","HIPAA-compliant chat system initialized"),An=!0,console.log("[CRM Extension] HIPAA-compliant chat system initialized successfully"),ln.getAuthState().authenticated&&se(),!0}catch(e){return console.error("[CRM Extension] Failed to initialize chat system:",e),d("error","Failed to initialize chat system",{error:e.message}),!1}}function tr(){let e=tt(rn());setInterval(()=>{getConnectionStatus()==="disconnected"&&(console.log("[CRM Extension] Attempting to reconnect chat"),se())},3e4),d("system","Chat monitoring initialized")}function $o(){return An}function nr(e){typeof e=="function"&&!er.includes(e)&&er.push(e)}function Ve(e,t,n={}){let o=document.createElement("div");o.className="group";let r=document.createElement("span");r.className="label",r.textContent=`${t}:`,o.appendChild(r);let s=document.createElement("span");if(s.id=`${e}-display`,s.className="clickable-value",n.initialValue&&s.setAttribute("data-value",n.initialValue),n.icon){let l=document.createElement("span");l.className="btn-icon",l.innerHTML=n.icon,s.appendChild(l)}let i=document.createElement("span");i.textContent=n.initialValue||"",i.id=`${e}-text`,s.appendChild(i);let a=async()=>{let l=s.getAttribute("data-value")||i.textContent.trim();l&&l!==""?await we(l)?y(`Copied ${t}: ${l}`):y(`Failed to copy ${t.toLowerCase()}`):y(`No ${t.toLowerCase()} available to copy`)};return s.addEventListener("click",()=>{n.onClick?n.onClick(s):a()}),s.title=`Click to copy ${t.toLowerCase()} to clipboard`,o.appendChild(s),o}function or(){let e=document.createElement("div");return e.className="group",e.id="crm-actions-group",e}function rr(){let e=document.createElement("div");e.className="dropdown",e.id="crm-tags-dropdown";let t=document.createElement("button");t.className="dropdown-btn",t.textContent="Tags",t.addEventListener("click",h=>{h.stopPropagation(),document.querySelectorAll(".dropdown.show").forEach(Pn=>{Pn!==e&&Pn.classList.remove("show")}),e.classList.toggle("show")});let n=document.createElement("div");if(n.className="dropdown-content",n.style.padding="10px",!document.getElementById("tags-dropdown-styles")){let h=document.createElement("style");h.id="tags-dropdown-styles",h.textContent=`
      .nested-dropdown {
        margin-bottom: 8px;
        width: 100%;
        position: relative;
      }
      .nested-dropdown-btn {
        width: 100%;
        text-align: left;
        padding: 8px 12px;
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 3px;
        cursor: pointer;
        font-weight: bold;
        font-size: 13px;
        color: #e6e6e6;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .nested-dropdown-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      .nested-dropdown-btn:after {
        content: "\u25BC";
        font-size: 8px;
        color: #e6e6e6;
      }
      .nested-dropdown-content {
        display: none;
        padding: 5px 0 5px 10px;
        margin-top: 3px !important;
      }
      .nested-dropdown.open .nested-dropdown-content {
        display: block;
      }
      
      /* Button-style tag options */
      .tag-btn {
        display: block;
        width: 100%;
        padding: 8px 12px;
        margin-bottom: 8px;
        background-color: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 4px;
        text-align: left;
        font-size: 13px;
        color: #e6e6e6;
        cursor: pointer;
        transition: all 0.2s ease;
        font-weight: normal;
      }
      .tag-btn:hover {
        background-color: rgba(255, 255, 255, 0.15);
        border-color: rgba(255, 255, 255, 0.2);
      }
      .tag-btn:active {
        background-color: rgba(255, 255, 255, 0.2);
      }
    `,document.head.appendChild(h)}let o=document.createElement("button");o.className="tag-btn",o.textContent="Opt-in",o.addEventListener("click",()=>{sr("opt-in"),e.classList.remove("show")}),n.appendChild(o);let r=document.createElement("button");r.className="tag-btn",r.textContent="Refill-Sema-Inj",r.addEventListener("click",()=>{R("refill-sema-inj"),e.classList.remove("show")}),n.appendChild(r);let s=document.createElement("button");s.className="tag-btn",s.textContent="Refill-Tirz-Inj",s.addEventListener("click",()=>{R("refill-tirz-inj"),e.classList.remove("show")}),n.appendChild(s);let i=document.createElement("div");i.className="nested-dropdown";let a=document.createElement("button");a.className="nested-dropdown-btn",a.textContent="Vial-Semaglutide";let l=document.createElement("div");l.className="nested-dropdown-content",a.addEventListener("click",h=>{h.stopPropagation(),i.classList.toggle("open")});let c=document.createElement("button");c.className="tag-btn",c.textContent="Vial-Sema-B12",c.addEventListener("click",h=>{h.stopPropagation(),B(),R("vial-sema-b12")}),l.appendChild(c);let p=document.createElement("button");p.className="tag-btn",p.textContent="Vial-Sema-B6",p.addEventListener("click",h=>{h.stopPropagation(),B(),R("vial-sema-b6")}),l.appendChild(p);let u=document.createElement("button");u.className="tag-btn",u.textContent="Vial-Sema-Lipo",u.addEventListener("click",h=>{h.stopPropagation(),B(),R("vial-sema-lipo")}),l.appendChild(u);let m=document.createElement("button");m.className="tag-btn",m.textContent="Vial-Sema-NAD+",m.addEventListener("click",h=>{h.stopPropagation(),B(),R("vial-sema-nad+")}),l.appendChild(m),i.appendChild(a),i.appendChild(l),n.appendChild(i);let x=document.createElement("div");x.className="nested-dropdown";let N=document.createElement("button");N.className="nested-dropdown-btn",N.textContent="Vial-Tirzepatide";let A=document.createElement("div");A.className="nested-dropdown-content",N.addEventListener("click",h=>{h.stopPropagation(),x.classList.toggle("open")});let _=document.createElement("button");_.className="tag-btn",_.textContent="Vial-Tirz-Cyano",_.addEventListener("click",h=>{h.stopPropagation(),B(),R("vial-tirz-cyano")}),A.appendChild(_);let H=document.createElement("button");H.className="tag-btn",H.textContent="Vial-Tirz-NAD+",H.addEventListener("click",h=>{h.stopPropagation(),B(),R("vial-tirz-nad+")}),A.appendChild(H);let E=document.createElement("button");E.className="tag-btn",E.textContent="Vial-Tirz-Pyr",E.addEventListener("click",h=>{h.stopPropagation(),B(),R("vial-tirz-pyridoxine")}),A.appendChild(E),x.appendChild(N),x.appendChild(A),n.appendChild(x);let M=document.createElement("div");M.className="nested-dropdown";let I=document.createElement("button");I.className="nested-dropdown-btn",I.textContent="NP-Semaglutide";let U=document.createElement("div");U.className="nested-dropdown-content",I.addEventListener("click",h=>{h.stopPropagation(),M.classList.toggle("open")});let Y=document.createElement("button");Y.className="tag-btn",Y.textContent="NP-Sema 0.125",Y.addEventListener("click",h=>{h.stopPropagation(),B(),R("np-sema-0.125ml-inj")}),U.appendChild(Y);let K=document.createElement("button");K.className="tag-btn",K.textContent="NP-Sema 0.25",K.addEventListener("click",h=>{h.stopPropagation(),B(),R("np-sema-0.25ml-inj")}),U.appendChild(K);let G=document.createElement("button");G.className="tag-btn",G.textContent="NP-Sema 0.5",G.addEventListener("click",h=>{h.stopPropagation(),B(),R("np-sema-0.5ml-inj")}),U.appendChild(G);let z=document.createElement("button");z.className="tag-btn",z.textContent="NP-Sema 0.75",z.addEventListener("click",h=>{h.stopPropagation(),B(),R("np-sema-0.75ml-inj")}),U.appendChild(z);let me=document.createElement("button");me.className="tag-btn",me.textContent="NP-Sema 1.0",me.addEventListener("click",h=>{h.stopPropagation(),B(),R("np-sema-1.0ml-inj")}),U.appendChild(me);let w=document.createElement("button");w.className="tag-btn",w.textContent="NP-Sema 1.25",w.addEventListener("click",h=>{h.stopPropagation(),B(),R("np-sema-1.25ml-inj")}),U.appendChild(w);let k=document.createElement("button");k.className="tag-btn",k.textContent="NP-Sema 1.5",k.addEventListener("click",h=>{h.stopPropagation(),B(),R("np-sema-1.5ml-inj")}),U.appendChild(k);let L=document.createElement("button");L.className="tag-btn",L.textContent="NP-Sema 2.0",L.addEventListener("click",h=>{h.stopPropagation(),B(),R("np-sema-2.0ml-inj")}),U.appendChild(L),M.appendChild(I),M.appendChild(U),n.appendChild(M);let Z=document.createElement("div");Z.className="nested-dropdown";let ne=document.createElement("button");ne.className="nested-dropdown-btn",ne.textContent="NP-Tirzepatide";let de=document.createElement("div");de.className="nested-dropdown-content",ne.addEventListener("click",h=>{h.stopPropagation(),Z.classList.toggle("open")});let _e=document.createElement("button");_e.className="tag-btn",_e.textContent="NP-Tirz 0.25",_e.addEventListener("click",h=>{h.stopPropagation(),B(),R("np-tirz-0.25ml-inj")}),de.appendChild(_e);let Fe=document.createElement("button");Fe.className="tag-btn",Fe.textContent="NP-Tirz 0.5",Fe.addEventListener("click",h=>{h.stopPropagation(),B(),R("np-tirz-0.5ml-inj")}),de.appendChild(Fe);let Oe=document.createElement("button");Oe.className="tag-btn",Oe.textContent="NP-Tirz 0.75",Oe.addEventListener("click",h=>{h.stopPropagation(),B(),R("np-tirz-0.75ml-inj")}),de.appendChild(Oe);let $e=document.createElement("button");$e.className="tag-btn",$e.textContent="NP-Tirz 1.0",$e.addEventListener("click",h=>{h.stopPropagation(),B(),R("np-tirz-1.0ml-inj")}),de.appendChild($e);let je=document.createElement("button");je.className="tag-btn",je.textContent="NP-Tirz 1.25",je.addEventListener("click",h=>{h.stopPropagation(),B(),R("np-tirz-1.25ml-inj")}),de.appendChild(je);let He=document.createElement("button");return He.className="tag-btn",He.textContent="NP-Tirz 1.5",He.addEventListener("click",h=>{h.stopPropagation(),B(),R("np-tirz-1.5ml-inj")}),de.appendChild(He),Z.appendChild(ne),Z.appendChild(de),n.appendChild(Z),e.appendChild(t),e.appendChild(n),e}function B(){document.querySelectorAll(".dropdown.show").forEach(e=>e.classList.remove("show")),document.querySelectorAll(".nested-dropdown.open").forEach(e=>e.classList.remove("open"))}async function R(e){try{let[t,n]=await Promise.all([Nt(),Tt()]);console.log("[CRM Extension] Cleanup completed:"),console.log(`- Tags: ${t.removed}/${t.total} removed`),console.log(`- Automations: ${n.removed}/${n.total} removed`),sr(e)}catch(t){console.error("[CRM Extension] Error during cleanup:",t),y("Error during cleanup. Please try again.")}}function sr(e){let t=Li();t?(t.focus(),setTimeout(()=>{t.value=e,t.dispatchEvent(new Event("input",{bubbles:!0})),setTimeout(()=>{let n=document.querySelectorAll(".v-list-item, .dropdown-item, .select-option, li"),o=!1;for(let r of n)if(r.textContent.toLowerCase().includes(e)){r.click(),o=!0,y(`Selected tag: ${e}`);break}if(!o){let r=document.querySelectorAll("*");for(let s of r)if(s.textContent.trim().toLowerCase()===e){s.click(),o=!0,y(`Selected tag: ${e}`);break}o||t.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",code:"Enter",keyCode:13,which:13,bubbles:!0}))}},300)},300)):y("Tags field not found")}function Li(){let e=document.querySelector('input[placeholder="Add Tags"]');if(e)return e;let t=Array.from(document.querySelectorAll("input[placeholder]")).filter(s=>s.placeholder.toLowerCase().includes("tag"));if(t.length>0)return t[0];let n=document.querySelectorAll(".tag-input, .tags-input, .tag-container");for(let s of n){let i=s.querySelector("input");if(i)return i}if(e=document.querySelector('input[placeholder="smartList.bulkTags.addTags"]'),e)return e;let o=document.querySelectorAll(".hl-text-input");if(o.length>0)return o[0];console.error("[CRM Extension] Could not find tag input field with any strategy");let r=document.querySelectorAll("input");return console.log("[CRM Extension] All inputs on page:",r),null}var ae={"Sema/B12 Refill - Step 2":"Refill - Semaglutide/B12 Injection Refill Order - (Step 2)","Sema/B12 Vial - Step 2":"Semaglutide/B12 Vial Order - (Step 2)","Sema/B6 Vial - Step 2":"Semaglutide/B6 Vial Order - (Step 2)","Sema/Lipo Vial - Step 2":"Semaglutide/Lipo Vial Order - (Step 2)","Sema/NAD+ Vial - Step 2":"Semaglutide/NAD+ Vial Order - (Step 2)","Tirz/B6 Refill - Step 2":"Syringe - Tirzepatide/Pyridoxine Injection Order - (Step 2)","Tirz/B12 Vial - Step 2":"Tirzepatide/Cyano Vial Order - (Step 2)","Tirz/NAD+ Vial - Step 2":"Tirzepatide/NAD+ Vial Order - (Step 2)","Tirz/B6 Vial - Step 2":"Tirzepatide/Pyridoxine Vial Order - (Step 2)"};function ir(){let e=document.createElement("div");e.className="dropdown",e.id="crm-automation-dropdown";let t=document.createElement("button");t.className="dropdown-btn",t.textContent="Automation",t.addEventListener("click",E=>{E.stopPropagation(),document.querySelectorAll(".dropdown.show").forEach(M=>{M!==e&&M.classList.remove("show")}),e.classList.toggle("show")});let n=document.createElement("div");if(n.className="dropdown-content",n.style.padding="10px",!document.getElementById("automation-dropdown-styles")){let E=document.createElement("style");E.id="automation-dropdown-styles",E.textContent=`
      .nested-dropdown {
        margin-bottom: 8px;
        width: 100%;
        position: relative;
      }
      .nested-dropdown-btn {
        width: 100%;
        text-align: left;
        padding: 8px 12px;
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 3px;
        cursor: pointer;
        font-weight: bold;
        font-size: 13px;
        color: #e6e6e6;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .nested-dropdown-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      .nested-dropdown-btn:after {
        content: "\u25BC";
        font-size: 8px;
        color: #e6e6e6;
      }
      .nested-dropdown-content {
        display: none;
        padding: 5px 0 5px 10px;
        margin-top: 3px !important;
      }
      .nested-dropdown.open .nested-dropdown-content {
        display: block;
      }
      
      /* Button-style options */
      .automation-btn {
        display: block;
        width: 100%;
        padding: 8px 12px;
        margin-bottom: 8px;
        background-color: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 4px;
        text-align: left;
        font-size: 13px;
        color: #e6e6e6;
        cursor: pointer;
        transition: all 0.2s ease;
        font-weight: normal;
      }
      .automation-btn:hover {
        background-color: rgba(255, 255, 255, 0.15);
        border-color: rgba(255, 255, 255, 0.2);
      }
      .automation-btn:active {
        background-color: rgba(255, 255, 255, 0.2);
      }
    `,document.head.appendChild(E)}let o=document.createElement("div");o.className="nested-dropdown";let r=document.createElement("button");r.className="nested-dropdown-btn",r.textContent="Semaglutide (Step 2)";let s=document.createElement("div");s.className="nested-dropdown-content",r.addEventListener("click",E=>{E.stopPropagation(),o.classList.toggle("open")});let i=document.createElement("button");i.className="automation-btn",i.textContent="Sema/B12 Refill - Step 2",i.addEventListener("click",E=>{E.stopPropagation(),le(),setTimeout(()=>{ce(ae["Sema/B12 Refill - Step 2"])},300)}),s.appendChild(i);let a=document.createElement("button");a.className="automation-btn",a.textContent="Sema/B12 Vial - Step 2",a.addEventListener("click",E=>{E.stopPropagation(),le(),setTimeout(()=>{ce(ae["Sema/B12 Vial - Step 2"])},300)}),s.appendChild(a);let l=document.createElement("button");l.className="automation-btn",l.textContent="Sema/B6 Vial - Step 2",l.addEventListener("click",E=>{E.stopPropagation(),le(),setTimeout(()=>{ce(ae["Sema/B6 Vial - Step 2"])},300)}),s.appendChild(l);let c=document.createElement("button");c.className="automation-btn",c.textContent="Sema/Lipo Vial - Step 2",c.addEventListener("click",E=>{E.stopPropagation(),le(),setTimeout(()=>{ce(ae["Sema/Lipo Vial - Step 2"])},300)}),s.appendChild(c);let p=document.createElement("button");p.className="automation-btn",p.textContent="Sema/NAD+ Vial - Step 2",p.addEventListener("click",E=>{E.stopPropagation(),le(),setTimeout(()=>{ce(ae["Sema/NAD+ Vial - Step 2"])},300)}),s.appendChild(p),o.appendChild(r),o.appendChild(s),n.appendChild(o);let u=document.createElement("div");u.className="nested-dropdown";let m=document.createElement("button");m.className="nested-dropdown-btn",m.textContent="Tirzepatide (Step 2)";let x=document.createElement("div");x.className="nested-dropdown-content",m.addEventListener("click",E=>{E.stopPropagation(),u.classList.toggle("open")});let N=document.createElement("button");N.className="automation-btn",N.textContent="Tirz/B6 Refill - Step 2",N.addEventListener("click",E=>{E.stopPropagation(),le(),setTimeout(()=>{ce(ae["Tirz/B6 Refill - Step 2"])},300)}),x.appendChild(N);let A=document.createElement("button");A.className="automation-btn",A.textContent="Tirz/B12 Vial - Step 2",A.addEventListener("click",E=>{E.stopPropagation(),le(),setTimeout(()=>{ce(ae["Tirz/B12 Vial - Step 2"])},300)}),x.appendChild(A);let _=document.createElement("button");_.className="automation-btn",_.textContent="Tirz/NAD+ Vial - Step 2",_.addEventListener("click",E=>{E.stopPropagation(),le(),setTimeout(()=>{ce(ae["Tirz/NAD+ Vial - Step 2"])},300)}),x.appendChild(_);let H=document.createElement("button");return H.className="automation-btn",H.textContent="Tirz/B6 Vial - Step 2",H.addEventListener("click",E=>{E.stopPropagation(),le(),setTimeout(()=>{ce(ae["Tirz/B6 Vial - Step 2"])},300)}),x.appendChild(H),u.appendChild(m),u.appendChild(x),n.appendChild(u),e.appendChild(t),e.appendChild(n),e}function le(){document.querySelectorAll(".dropdown.show").forEach(e=>e.classList.remove("show")),document.querySelectorAll(".nested-dropdown.open").forEach(e=>e.classList.remove("open"))}function ce(e){try{console.log(`[CRM Extension] Starting workflow for "${e}"`),y(`Starting workflow for "${e}"`);let t=Array.from(document.querySelectorAll("button.btn.btn-light2.btn-xs")).find(n=>n.textContent.trim().includes("Add"));if(!t){console.error("[CRM Extension] Add Automation button not found"),y("Add Automation button not found");return}console.log("[CRM Extension] Found Add button, clicking it"),t.click(),setTimeout(()=>{let n=document.querySelector('input[placeholder="Type to search"]');if(!n){console.error("[CRM Extension] Search input not found"),y("Search input not found");return}console.log("[CRM Extension] Found search input, entering 'step 2'"),n.focus(),n.value="step 2",n.dispatchEvent(new Event("input",{bubbles:!0})),setTimeout(()=>{let o=[".v-list",".dropdown-menu",".v-select-list",".vs__dropdown-menu",'[role="listbox"]',"ul",".v-menu__content"],r=null;for(let c of o){let p=document.querySelector(c);if(p&&p.querySelector("li, .v-list-item, .dropdown-item")&&p.scrollHeight>p.clientHeight){r=p,console.log(`[CRM Extension] Found scrollable dropdown container: ${c}`);break}}if(!r){let c=document.querySelector('.modal, dialog, [role="dialog"]');if(c){let p=Array.from(c.querySelectorAll("*")).filter(u=>u.scrollHeight>u.clientHeight&&u.clientHeight>50);p.length>0&&(r=p[0],console.log("[CRM Extension] Found scrollable element via fallback method"))}}if(!r){console.error("[CRM Extension] Could not find scrollable container"),y("Could not find dropdown container");return}console.log("[CRM Extension] Starting scroll wheel simulation"),console.log(`[CRM Extension] Container dimensions: ${r.scrollHeight}x${r.clientHeight}`);let s=0,i=20,a=!1;function l(){if(a||s>=i){a||(console.error("[CRM Extension] Max scroll attempts reached without finding match"),y("Option not found after scrolling"));return}s++,console.log(`[CRM Extension] Scroll attempt ${s}/${i}`);let c=new WheelEvent("wheel",{deltaY:100,bubbles:!0});r.dispatchEvent(c),r.scrollTop+=100,console.log(`[CRM Extension] Scrolled to position: ${r.scrollTop}/${r.scrollHeight}`),setTimeout(()=>{let p=r.querySelectorAll('li, .v-list-item, .dropdown-item, [role="option"]');console.log(`[CRM Extension] Found ${p.length} options after scrolling`);for(let u of p){if(!u.textContent)continue;let m=u.textContent.trim();if(m===e&&!m.includes("Provider Paid")&&!m.includes("New Patient")){console.log(`[CRM Extension] Found exact matching option: "${m}"`);try{u.scrollIntoView({block:"center"}),setTimeout(()=>{u.click(),a=!0,setTimeout(()=>{let x=Array.from(document.querySelectorAll("button")).find(N=>N.textContent.trim()==="Add");x?(console.log("[CRM Extension] Clicking Add button in dialog"),x.click(),y(`Added "${e}" workflow`)):(console.error("[CRM Extension] Add button in dialog not found"),y("Add button in dialog not found"))},1e3)},300)}catch(x){console.error("[CRM Extension] Error clicking option:",x)}break}}if(!a){if(r.scrollHeight-r.scrollTop<=r.clientHeight+20){console.log("[CRM Extension] Reached bottom of dropdown without finding match"),y(`Reached end without finding "${e}"`);return}setTimeout(l,500)}},500)}l()},1500)},1e3)}catch(t){console.error("[CRM Extension] Error in workflow:",t),y(`Error in workflow: ${t.message}`)}}function ar(){let e=document.createElement("div");return e.className="group",e.id="crm-dropdowns-group",e.appendChild(ir()),e.appendChild(rr()),document.addEventListener("click",t=>{document.querySelectorAll(".dropdown").forEach(o=>{o.contains(t.target)||(o.classList.remove("show"),o.querySelectorAll(".nested-dropdown").forEach(s=>{s.classList.remove("open")}))})}),Ai(),e}function Ai(){if(document.getElementById("custom-dropdown-styles"))return;let e=document.createElement("style");e.id="custom-dropdown-styles",e.textContent=`
    /* Improved dropdown positioning */
    .dropdown {
      position: relative !important;
      margin-right: 8px !important; /* Ensure space between dropdowns, reduced for tighter layout */
    }
    
    .dropdown:last-child {
      margin-right: 0 !important; /* Remove margin from the last dropdown */
    }
    
    .dropdown-content {
      position: absolute !important;
      background-color: #2F3A4B; /* Match toolbar background color */
      min-width: 220px !important; /* Increased width */
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.3);
      z-index: 999;
      border-radius: 4px;
      margin-top: 5px !important; /* Add space between button and dropdown */
      left: 0;
      top: 100% !important; /* Position below the button */
      display: none;
      border: 1px solid rgba(255, 255, 255, 0.1); /* Subtle border */
    }
    
    /* Ensure right-aligned dropdowns don't overflow */
    #crm-tags-dropdown .dropdown-content {
      right: 0;
      left: auto; /* Override left positioning for Tags dropdown */
    }
    
    .dropdown.show .dropdown-content {
      display: block;
    }
    
    /* Improved nested dropdown positioning */
    .nested-dropdown-content {
      margin-top: 3px !important;
      background-color: #2F3A4B; /* Match toolbar background color */
      border-radius: 4px;
      padding: 5px !important;
    }
    
    /* Style dropdown items */
    .dropdown-item {
      color: #e6e6e6; /* White text for visibility */
      padding: 10px 14px !important; /* Increased padding */
      text-decoration: none;
      display: block;
      font-size: 14px;
      cursor: pointer;
      border-radius: 3px;
      font-weight: normal;
    }
    
    .dropdown-item:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
    
    /* Fix for Vial-Sema and Vial-Tirz nested dropdowns */
    .nested-dropdown-btn {
      text-align: left !important;
      padding: 8px 12px !important;
      background-color: rgba(255, 255, 255, 0.1) !important;
      border: 1px solid rgba(255, 255, 255, 0.15) !important;
      color: #e6e6e6 !important;
      font-weight: bold !important;
    }
    
    .nested-dropdown-btn:hover {
      background-color: rgba(255, 255, 255, 0.2) !important;
    }
    
    /* Force visibility for Tags dropdown */
    #crm-tags-dropdown {
      display: flex !important;
    }
    
    #crm-tags-dropdown .dropdown-content {
      min-width: 220px !important;
    }
  `,document.head.appendChild(e)}function lr(){let e=document.createElement("div");e.className="group",e.id="crm-settings-group",e.style.position="relative";let t=document.createElement("button");t.className="btn",t.id="crm-settings-btn";let n=document.createElement("span");n.className="btn-icon",n.innerHTML="\u2699\uFE0F",t.appendChild(n);let o=document.createElement("span");o.textContent="Settings",t.appendChild(o);let r=Ri();if(t.addEventListener("click",s=>{s.stopPropagation(),r.classList.toggle("show")}),document.addEventListener("click",s=>{s.target!==t&&!t.contains(s.target)&&s.target!==r&&!r.contains(s.target)&&r.classList.remove("show")}),!document.getElementById("settings-dropdown-styles")){let s=document.createElement("style");s.id="settings-dropdown-styles",s.textContent=`
      #mcp-crm-settings-dropdown {
        display: none;
        position: absolute;
        top: calc(100% + 5px); /* Position below the button with 5px gap */
        right: 0;
        z-index: 1000;
        min-width: 230px;
        background-color: #2F3A4B;
        border-radius: 4px;
        border: 1px solid rgba(255, 255, 255, 0.1);
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
        overflow: hidden;
      }
      
      #mcp-crm-settings-dropdown.show {
        display: block;
      }
      
      .settings-header {
        padding: 10px;
        background-color: rgba(255, 255, 255, 0.1);
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        font-weight: bold;
        color: #e6e6e6;
      }
      
      .settings-body {
        padding: 10px;
        color: #e6e6e6;
      }
      
      .setting-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
        font-size: 13px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        padding-bottom: 10px;
      }
      
      .setting-item:last-child {
        margin-bottom: 0;
        border-bottom: none;
        padding-bottom: 0;
      }
      
      .setting-label {
        color: #e6e6e6;
        font-weight: normal;
      }
      
      /* Toggle switch styles */
      .switch {
        position: relative;
        display: inline-block;
        width: 40px;
        height: 20px;
      }
      
      .switch input {
        opacity: 0;
        width: 0;
        height: 0;
      }
      
      .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #555;
        transition: .4s;
        border-radius: 34px;
      }
      
      .slider:before {
        position: absolute;
        content: "";
        height: 16px;
        width: 16px;
        left: 2px;
        bottom: 2px;
        background-color: white;
        transition: .4s;
        border-radius: 50%;
      }
      
      input:checked + .slider {
        background-color: #2196F3;
      }
      
      input:focus + .slider {
        box-shadow: 0 0 1px #2196F3;
      }
      
      input:checked + .slider:before {
        transform: translateX(20px);
      }
      
      /* Version info styles */
      .version-info {
        border-top: 1px solid rgba(255, 255, 255, 0.1);
        margin-top: 10px;
        padding-top: 10px;
        font-size: 12px;
        color: #e6e6e6;
      }
      
      .version-info p {
        margin: 5px 0;
        color: #e6e6e6;
      }
      
      .version-number {
        font-weight: 600;
        color: #e6e6e6;
      }
      
      .check-updates-btn {
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 3px;
        padding: 4px 8px;
        margin-top: 5px;
        font-size: 11px;
        cursor: pointer;
        transition: background-color 0.2s;
        width: 100%;
        text-align: center;
        color: #e6e6e6;
      }
      
      .check-updates-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      
      .check-updates-btn:disabled {
        opacity: 0.6;
        cursor: not-allowed;
      }
      
      #crm-update-status {
        margin: 5px 0 0 0;
        padding: 3px 6px;
        font-size: 11px;
        border-radius: 3px;
        background-color: rgba(255, 255, 255, 0.05);
        text-align: center;
        transition: all 0.3s ease;
        color: #e6e6e6;
      }
      
      #last-update-check {
        font-size: 11px;
        margin: 5px 0;
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        color: #e6e6e6;
      }
      
      .check-status {
        font-size: 10px;
        margin-left: 5px;
        padding: 1px 4px;
        border-radius: 3px;
        font-weight: normal;
      }
      
      .loading-text {
        font-style: italic;
        color: #aaa;
      }
      
      /* Section styles */
      .setting-section {
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      }
      
      .setting-section-title {
        font-size: 12px;
        font-weight: bold;
        color: #e6e6e6;
        margin-bottom: 10px;
      }
    `,document.head.appendChild(s)}return e.appendChild(t),e.appendChild(r),e}function Ii(e){try{(typeof browser<"u"?browser:chrome).runtime.sendMessage({action:"getLastUpdateCheck"}).then(n=>{if(n&&n.success&&n.lastUpdateCheck){let o=n.lastUpdateCheck,r="",s="";o.success?o.status==="update_available"?(r="Update available",s="#4CAF50"):o.status==="no_update"?(r="No updates needed",s="#2196F3"):o.status==="throttled"?(r="Check throttled",s="#FF9800"):(r="Completed",s="#2196F3"):(r="Failed",s="#F44336"),e.innerHTML=`Last Check: <span class="version-number">${o.formattedTime}</span> <span class="check-status" style="color:${s};font-size:10px;margin-left:5px;">${r}</span>`}else e.innerHTML='Last Check: <span class="version-number">No checks recorded</span>'}).catch(n=>{console.error("[CRM Extension] Error fetching last update check:",n),e.innerHTML='Last Check: <span class="version-number">Unknown</span>'})}catch(t){console.error("[CRM Extension] Error in fetchLastUpdateCheckInfo:",t),e.innerHTML='Last Check: <span class="version-number">Error</span>'}}function Ri(){let e=document.createElement("div");e.id="mcp-crm-settings-dropdown";let t=document.createElement("div");t.className="settings-header",t.textContent="CRM+ Settings",e.appendChild(t);let n=document.createElement("div");if(n.className="settings-body",e.appendChild(n),!document.getElementById("collapsible-settings-styles")){let a=document.createElement("style");a.id="collapsible-settings-styles",a.textContent=`
      .setting-section {
        margin-bottom: 8px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        padding-bottom: 0; /* No bottom padding when collapsed */
      }
      
      .setting-section-title {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 13px;
        font-weight: bold;
        color: #e6e6e6;
        padding: 8px 0;
        cursor: pointer;
        user-select: none;
      }
      
      .setting-section-title:after {
        content: "\u25BC";
        font-size: 8px;
        color: #e6e6e6;
        transition: transform 0.2s ease;
      }
      
      .setting-section.collapsed .setting-section-title:after {
        transform: rotate(-90deg);
      }
      
      .setting-section-content {
        max-height: 500px;
        overflow: hidden;
        transition: max-height 0.3s ease, opacity 0.2s ease, margin-bottom 0.3s ease;
        opacity: 1;
        margin-bottom: 10px;
      }
      
      .setting-section.collapsed .setting-section-content {
        max-height: 0;
        opacity: 0;
        margin-bottom: 0;
      }
    `,document.head.appendChild(a)}let o=In("General Settings");o.content.appendChild(fe("Show Header Bar","crmplus_headerBarVisible",a=>{let l=document.getElementById("mcp-crm-header");l&&(l.style.display=a?"flex":"none",document.body.style.paddingTop=a?"32px":"0"),y(`Header bar: ${a?"Visible":"Hidden"}`)},!0)),o.content.appendChild(fe("Show Provider-Paid Alerts","crmplus_showProviderPaidAlerts",a=>{y(`Provider-Paid alerts: ${a?"Enabled":"Disabled"}`)},!0)),n.appendChild(o.section);let r=In("External Links");r.content.appendChild(fe("Show ShipStation Link","crmplus_showShipStation",a=>{let l=document.querySelector(".shipstation-link");l&&(l.style.display=a?"flex":"none"),y(`ShipStation link: ${a?"Visible":"Hidden"}`)},!0)),r.content.appendChild(fe("Show Stripe Link","crmplus_showStripe",a=>{let l=document.querySelector(".stripe-link");l&&(l.style.display=a?"flex":"none"),y(`Stripe link: ${a?"Visible":"Hidden"}`)},!0)),r.content.appendChild(fe("Show Webmail Link","crmplus_showWebmail",a=>{let l=document.querySelector(".webmail-link");l&&(l.style.display=a?"flex":"none"),y(`Webmail link: ${a?"Visible":"Hidden"}`)},!0)),n.appendChild(r.section);let s=In("Features");s.content.appendChild(fe("Auto-copy phone number on page load","crmplus_autoCopyPhone",a=>{y(`Auto-copy phone: ${a?"Enabled":"Disabled"}`)},!1)),s.content.appendChild(fe("CRM Automation","crmplus_automationEnabled",a=>{[document.getElementById("crm-automation-dropdown"),document.getElementById("crm-tags-dropdown")].forEach(c=>{c?(c.style.display=a?"flex":"none",console.log(`[CRM Extension] Changed visibility for ${c.id}: ${a?"visible":"hidden"}`)):console.error("[CRM Extension] Could not find automation element to toggle")}),y(`CRM Automation: ${a?"Enabled":"Disabled"}`)},!0)),n.appendChild(s.section);let i=Ni();return n.appendChild(i),e}function In(e,t=!1){let n=document.createElement("div");n.className="setting-section"+(t?" collapsed":"");let o=document.createElement("div");o.className="setting-section-title",o.textContent=e,o.addEventListener("click",()=>{n.classList.toggle("collapsed")}),n.appendChild(o);let r=document.createElement("div");return r.className="setting-section-content",n.appendChild(r),{section:n,content:r}}function Ni(){let e=document.createElement("div");e.className="version-info";let t="Loading...",n="Loading...";try{let l=(typeof browser<"u"?browser:chrome).runtime.getManifest();if(l&&l.version&&(t=l.version,t.includes("."))){let c=t.split(".");if(c.length===3&&c[0].length===4){let p=c[0],u=c[1],m=c[2];n=`${u}/${m}/${p}`}}}catch(a){console.error("[CRM Extension] Error fetching version:",a),t="Unknown",n="Unknown"}let o=document.createElement("p");o.innerHTML=`Version: <span class="version-number">${t}</span>`,e.appendChild(o);let r=document.createElement("p");r.innerHTML=`Last Updated: <span class="version-number">${n}</span>`,e.appendChild(r);let s=document.createElement("p");s.id="last-update-check",s.innerHTML='Last Check: <span class="loading-text">Loading...</span>',e.appendChild(s),Ii(s);let i=document.createElement("button");return i.className="check-updates-btn",i.textContent="Check for Updates",i.addEventListener("click",()=>{let a=typeof browser<"u"?browser:chrome;i.disabled=!0,i.textContent="Checking...",y("Checking for updates...");let l=document.getElementById("crm-update-status");l||(l=document.createElement("p"),l.id="crm-update-status",l.style.fontSize="11px",l.style.marginTop="5px",l.style.color="#e6e6e6",l.textContent="",e.appendChild(l)),a.runtime.sendMessage({action:"checkForUpdates"}).then(c=>{if(c&&c.success){y("Update check completed"),c.updateStatus==="update_available"?(l.textContent=`Update available (${c.updateVersion})`,l.style.color="#4CAF50"):c.updateStatus==="no_update"?(l.textContent="You have the latest version",l.style.color="#2196F3"):c.updateStatus==="throttled"?(l.textContent="Update check throttled, try again later",l.style.color="#FF9800"):c.updateStatus==="error"?(l.textContent="Error checking for updates",l.style.color="#F44336"):(l.textContent="Update check initiated",l.style.color="#e6e6e6");let p=document.getElementById("last-update-check");if(p&&c.lastCheck){let u=c.lastCheck,m="",x="";u.success?u.status==="update_available"?(m="Update available",x="#4CAF50"):u.status==="no_update"?(m="No updates needed",x="#2196F3"):u.status==="throttled"?(m="Check throttled",x="#FF9800"):(m="Completed",x="#2196F3"):(m="Failed",x="#F44336"),p.innerHTML=`Last Check: <span class="version-number">${u.formattedTime}</span> <span class="check-status" style="color:${x};font-size:10px;margin-left:5px;">${m}</span>`}}else y("Error checking for updates"),l.textContent="Update check failed",l.style.color="#F44336";i.disabled=!1,i.textContent="Check for Updates"}).catch(c=>{console.error("[CRM Extension] Error sending update check message:",c),y("Error checking for updates"),l.textContent="Connection failed",l.style.color="#F44336",i.disabled=!1,i.textContent="Check for Updates"})}),e.appendChild(i),e}function fe(e,t,n,o=!1){let r=document.createElement("div");r.className="setting-item";let s=document.createElement("div");s.className="setting-label",s.textContent=e,r.appendChild(s);let i=document.createElement("label");i.className="switch";let a=document.createElement("input");a.type="checkbox";let l=localStorage.getItem(t),c=l!==null?l==="true":o;l===null&&localStorage.setItem(t,o.toString()),a.checked=c,a.addEventListener("change",()=>{let u=a.checked;localStorage.setItem(t,u.toString()),n&&typeof n=="function"&&n(u)});let p=document.createElement("span");return p.className="slider",i.appendChild(a),i.appendChild(p),r.appendChild(i),r}function cr(){if(document.getElementById("mcp-crm-header-styles"))return;let e=document.createElement("style");e.id="mcp-crm-header-styles",e.textContent=`
    #mcp-crm-header {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 32px;
      background-color: #2F3A4B;
      display: flex;
      align-items: center;
      padding: 0 15px;
      font-family: 'Segoe UI', 'Roboto', sans-serif;
      font-size: 12px;
      z-index: 999999;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    }
    
    #mcp-crm-header .group {
      display: flex;
      align-items: center;
      margin-right: 15px;
      border-right: 1px solid rgba(255, 255, 255, 0.1);
      padding-right: 15px;
    }
    
    #mcp-crm-header .group:last-child {
      border-right: none;
      margin-right: 0; /* Remove margin from the last group (Settings) */
    }
    
    /* Special styling for dropdowns group to match other elements' spacing */
    #crm-dropdowns-group {
      margin-right: 15px; /* Same spacing as other elements */
      padding-right: 15px; /* Same padding as other elements */
    }
    
    /* Ensure settings is positioned at the far right */
    #crm-settings-btn {
      margin-right: 0;
    }
    
    #mcp-crm-header .spacer {
      flex-grow: 1;
    }
    
    #mcp-crm-header .label {
      color: #8a9cad;
      margin-right: 6px;
      font-weight: 500;
    }
    
    #mcp-crm-header .value {
      color: #e6e6e6;
      font-weight: 600;
    }
    
    #mcp-crm-header .clickable-value {
      color: #e6e6e6;
      font-weight: 600;
      cursor: pointer;
      background-color: rgba(255, 255, 255, 0.05);
      padding: 2px 8px;
      border-radius: 3px;
      transition: background-color 0.2s;
      display: inline-flex;
      align-items: center;
    }
    
    #mcp-crm-header .clickable-value:hover {
      background-color: rgba(255, 255, 255, 0.15);
    }
    
    #mcp-crm-header .btn-icon {
      margin-right: 4px;
      font-size: 10px;
    }
    
    /* Logo link styling */
    #mcp-crm-header .logo-link {
      display: flex;
      align-items: center;
      text-decoration: none;
      transition: all 0.2s ease;
    }
    
    #mcp-crm-header .logo-link:hover {
      opacity: 0.85;
    }
    
    #mcp-crm-header .logo-icon {
      width: 16px;
      height: 16px;
      margin-right: 6px;
    }
    
    #mcp-crm-header .logo {
      font-weight: bold;
      color: white;
      font-size: 14px;
    }
    
    #mcp-crm-header .external-link {
      text-decoration: none;
      color: #e6e6e6;
      display: flex;
      align-items: center;
      transition: all 0.2s ease;
      margin-right: 10px;
    }
    
    #mcp-crm-header .external-link:hover {
      background: rgba(255, 255, 255, 0.2);
      transform: translateY(-1px);
    }
    
    #mcp-crm-header .ext-link-icon {
      font-size: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    /* Styling for text links with icons */
    #mcp-crm-header .text-link {
      text-decoration: none;
      margin-right: 4px; /* Reduced margin between buttons */
      font-size: 12px;
      padding: 3px 6px; /* Reduced horizontal padding to make buttons skinnier */
      border-radius: 3px;
      color: #e6e6e6;
      display: flex;
      align-items: center;
      justify-content: center; /* Center content horizontally */
      white-space: nowrap; /* Prevent text wrapping */
      min-width: 68px; /* Set minimum width to keep consistency */
    }
    
    #mcp-crm-header .text-link:hover {
      background-color: rgba(255, 255, 255, 0.15);
    }
    
    #mcp-crm-header .text-link .link-icon {
      margin-right: 4px; /* Slightly reduced margin for tighter look */
      width: 16px;
      height: 16px;
      vertical-align: middle;
      flex-shrink: 0; /* Prevent icon from shrinking */
    }
    
    /* Add a specific class for each button to fine-tune widths if needed */
    #mcp-crm-header .shipstation-link {
      min-width: 92px;
    }
    
    #mcp-crm-header .stripe-link {
      min-width: 65px;
    }
    
    #mcp-crm-header .webmail-link {
      min-width: 78px;
    }
    
    #mcp-crm-header .btn {
      color: #e6e6e6;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 3px;
      padding: 4px 8px;
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      margin-right: 8px;
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
    }
    
    #mcp-crm-header .btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    #mcp-crm-header .btn:active {
      background-color: rgba(255, 255, 255, 0.3);
    }
    
    #mcp-crm-header .btn:last-child {
      margin-right: 0;
    }
    
    /* Dropdown styling */
    .dropdown {
      position: relative;
      display: inline-block;
      margin-right: 8px;
    }
    
    .dropdown-btn {
      color: #e6e6e6;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 3px;
      padding: 4px 8px;
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
      justify-content: space-between;
      min-width: 100px;
    }
    
    .dropdown-btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .dropdown-btn:after {
      content: "\u25BC";
      font-size: 8px;
      margin-left: 5px;
    }
    
    .dropdown-content {
      display: none;
      position: absolute;
      background-color: #2F3A4B;
      min-width: 180px;
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.3);
      z-index: 1000000;
      border-radius: 4px;
      border: 1px solid rgba(255, 255, 255, 0.1);
      margin-top: 2px;
      left: 0;
    }
    
    .dropdown.show .dropdown-content {
      display: block;
    }
    
    .dropdown-item {
      color: #e6e6e6;
      padding: 8px 12px;
      text-decoration: none;
      display: block;
      font-size: 12px;
      cursor: pointer;
      font-weight: normal;
    }
    
    .dropdown-item:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
    
    /* Nested Dropdown styling */
    .nested-dropdown {
      margin-bottom: 5px;
      width: 100%;
    }
    
    .nested-dropdown-btn {
      width: 100%;
      text-align: left;
      padding: 6px 10px;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 3px;
      cursor: pointer;
      font-weight: bold;
      font-size: 12px;
      color: #e6e6e6;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .nested-dropdown-btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .nested-dropdown-btn:after {
      content: "\u25BC";
      font-size: 8px;
      color: #e6e6e6;
    }
    
    .nested-dropdown-content {
      display: none;
      padding: 5px 0 5px 10px;
      background-color: #2F3A4B;
    }
    
    .nested-dropdown.open .nested-dropdown-content {
      display: block;
    }
    
    .nested-dropdown-item {
      display: block;
      padding: 5px 10px;
      color: #e6e6e6;
      text-decoration: none;
      font-size: 12px;
      cursor: pointer;
      border-radius: 3px;
      font-weight: normal;
    }
    
    .nested-dropdown-item:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
    
    /* Settings dropdown styling */
    #mcp-crm-settings-dropdown {
      position: absolute;
      top: 32px;
      right: 15px;
      background-color: #2F3A4B;
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 4px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.3);
      min-width: 200px;
      z-index: 1000000;
      display: none;
      color: #e6e6e6;
    }
    
    #mcp-crm-settings-dropdown.show {
      display: block;
    }
    
    #mcp-crm-settings-dropdown .settings-header {
      background-color: rgba(255, 255, 255, 0.1);
      color: #e6e6e6;
      padding: 8px 12px;
      font-weight: bold;
      border-top-left-radius: 3px;
      border-top-right-radius: 3px;
    }
    
    #mcp-crm-settings-dropdown .settings-body {
      padding: 10px;
    }
    
    #mcp-crm-settings-dropdown .setting-item {
      display: flex;
      align-items: center;
      margin-bottom: 8px;
      padding-bottom: 8px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    #mcp-crm-settings-dropdown .setting-item:last-child {
      margin-bottom: 0;
      padding-bottom: 0;
      border-bottom: none;
    }
    
    #mcp-crm-settings-dropdown .setting-label {
      flex-grow: 1;
      font-size: 13px;
      color: #e6e6e6;
    }
    
    /* Toggle switch styling */
    .switch {
      position: relative;
      display: inline-block;
      width: 40px;
      height: 20px;
    }
    
    .switch input { 
      opacity: 0;
      width: 0;
      height: 0;
    }
    
    .slider {
      position: absolute;
      cursor: pointer;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: #555;
      transition: .4s;
      border-radius: 34px;
    }
    
    .slider:before {
      position: absolute;
      content: "";
      height: 16px;
      width: 16px;
      left: 2px;
      bottom: 2px;
      background-color: white;
      transition: .4s;
      border-radius: 50%;
    }
    
    input:checked + .slider {
      background-color: #2196F3;
    }
    
    input:checked + .slider:before {
      transform: translateX(20px);
    }
    
    /* Version info section in settings */
    .version-info {
      border-top: 1px solid rgba(255, 255, 255, 0.1);
      margin-top: 10px;
      padding-top: 10px;
      font-size: 12px;
      color: #e6e6e6;
    }
    
    .version-info p {
      margin: 5px 0;
    }
    
    .version-number {
      font-weight: 600;
      color: #e6e6e6;
    }
    
    .check-updates-btn {
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 3px;
      padding: 4px 8px;
      margin-top: 5px;
      font-size: 11px;
      cursor: pointer;
      transition: background-color 0.2s;
      width: 100%;
      text-align: center;
      color: #e6e6e6;
    }
    
    .check-updates-btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .check-updates-btn:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
  `,document.head.appendChild(e)}function pr(){let e=document.createElement("div");e.className="dropdown",e.id="crm-history-dropdown";let t=document.createElement("button");t.className="dropdown-btn",t.textContent="History",t.addEventListener("click",a=>{a.stopPropagation(),document.querySelectorAll(".dropdown.show").forEach(l=>{l!==e&&l.classList.remove("show")}),e.classList.toggle("show"),e.classList.contains("show")&&dr(e)});let n=document.createElement("div");if(n.className="dropdown-content",n.id="crm-history-content",n.style.width="300px",n.style.maxHeight="400px",n.style.overflowY="auto",n.style.right="0",n.style.left="auto",!document.getElementById("history-dropdown-styles")){let a=document.createElement("style");a.id="history-dropdown-styles",a.textContent=`
      #crm-history-dropdown .dropdown-content {
        padding: 0;
        right: 0;
        left: auto;
      }
      
      /* For small screens, make sure the dropdown doesn't extend beyond viewport */
      @media screen and (max-width: 768px) {
        #crm-history-dropdown .dropdown-content {
          right: 0;
          left: auto;
          max-width: 100vw;
          width: 280px; /* Slightly smaller on small screens */
        }
      }
      
      .history-header {
        padding: 10px;
        background-color: rgba(255, 255, 255, 0.1);
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      
      .history-title {
        font-weight: bold;
        color: #e6e6e6;
        font-size: 14px;
      }
      
      .history-clear-btn {
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 3px;
        padding: 2px 6px;
        font-size: 11px;
        cursor: pointer;
        color: #e6e6e6;
        transition: background-color 0.2s;
      }
      
      .history-clear-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      
      .history-empty {
        padding: 20px;
        text-align: center;
        color: #aaa;
        font-style: italic;
        font-size: 13px;
      }
      
      .history-item {
        padding: 10px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        cursor: pointer;
        transition: background-color 0.2s;
      }
      
      .history-item:hover {
        background-color: rgba(255, 255, 255, 0.1);
      }
      
      .history-item:last-child {
        border-bottom: none;
      }
      
      .history-item-row {
        display: flex;
        margin-bottom: 3px;
        width: 100%;
      }
      
      .history-item-time {
        color: #aaa;
        font-size: 11px;
        width: 60px;
        flex-shrink: 0;
        margin-right: 5px;
      }
      
      .history-item-name {
        font-weight: bold;
        color: #e6e6e6;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        flex-grow: 1;
      }
      
      .history-item-phone {
        color: #ccc;
        font-size: 12px;
        margin-left: 65px; /* Align with name (time width + margin) */
      }
    `,document.head.appendChild(a)}let o=document.createElement("div");o.className="history-header";let r=document.createElement("div");r.className="history-title",r.textContent="Recent Patients",o.appendChild(r);let s=document.createElement("button");s.className="history-clear-btn",s.textContent="Clear All",s.addEventListener("click",a=>{a.stopPropagation(),lo(),dr(e),y("History cleared")}),o.appendChild(s),n.appendChild(o);let i=document.createElement("div");return i.className="history-empty",i.textContent="No patient history yet",n.appendChild(i),e.appendChild(t),e.appendChild(n),e}function dr(e){let t=e.querySelector("#crm-history-content");if(!t)return;let n=ao(),o=t.querySelector(".history-header");if(t.innerHTML="",o&&t.appendChild(o),n.length===0){let r=document.createElement("div");r.className="history-empty",r.textContent="No patient history yet",t.appendChild(r);return}n.forEach(r=>{let s=document.createElement("div");s.className="history-item",s.addEventListener("click",()=>{window.location.href=r.url,e.classList.remove("show")});let i=document.createElement("div");i.className="history-item-row";let a=document.createElement("div");a.className="history-item-time",a.textContent=co(r.timestamp);let l=document.createElement("div");if(l.className="history-item-name",l.textContent=r.patientName||"Unknown Patient",i.appendChild(a),i.appendChild(l),s.appendChild(i),r.phoneNumber){let c=document.createElement("div");c.className="history-item-phone",c.textContent=r.phoneNumber,s.appendChild(c)}t.appendChild(s)})}var Ti=!1;function Nn(){try{if(document.getElementById("mcp-crm-header")){console.log("[uiHeaderBar] Toolbar already exists.");return}cr();let e=document.createElement("div");e.id="mcp-crm-header";let t=localStorage.getItem("crmplus_headerBarVisible")!=="false";console.log("[CRM Extension] Header visibility setting:",t),e.style.display=t?"flex":"none";let n=typeof browser<"u"?browser:chrome,o=w=>n.runtime.getURL(w),r=document.createElement("div");r.className="group";let s=document.createElement("a");s.href="https://app.mtncarerx.com/",s.className="logo-link";let i=document.createElement("img");i.src=o("assets/mcp-favicon.ico"),i.alt="",i.className="logo-icon",s.appendChild(i);let a=document.createElement("span");a.className="logo",a.textContent="CRM+",s.appendChild(a),r.appendChild(s);let l=document.createElement("div");l.className="group external-links";let c=Rn("ShipStation","https://ship15.shipstation.com/onboard","shipstation-link",o("assets/shipstation-favicon.ico"));l.appendChild(c);let p=Rn("Stripe","https://dashboard.stripe.com/login","stripe-link",o("assets/stripe-favicon.ico"));l.appendChild(p);let u=Rn("Webmail","https://p3plzcpnl506102.prod.phx3.secureserver.net:2096/cpsess5640910985/webmail/jupiter/index.html?login=1&post_login=89371011642013","webmail-link",o("assets/webmail-favicon.ico"));l.appendChild(u);let m=Ve("name","Name"),x=Ve("phone","Phone",{icon:"\u{1F4DE}",initialValue:"",onClick:async w=>{$n(w)}}),N=Ve("dob","DOB"),A=Ve("srxid","SRx ID"),_=or(),H=ar(),E=document.createElement("div");E.className="spacer";let M=document.createElement("div");M.className="group right-buttons",M.style.borderRight="none",M.style.display="flex",M.style.marginRight="0";let I=document.createElement("button");I.className="chat-button btn",I.title="Mountain Care Chat",I.style.marginRight="8px";let U=document.createElement("div");U.style.display="flex",U.style.alignItems="center",U.style.justifyContent="center";let Y=document.createElement("span");Y.className="icon",Y.innerHTML="\u{1F4AC}",Y.style.marginRight="4px";let K=document.createElement("span");K.textContent="Chat";let G=document.createElement("span");G.className="badge",Object.assign(G.style,{position:"absolute",top:"0",right:"0",backgroundColor:"#f44336",color:"white",fontSize:"12px",fontWeight:"bold",padding:"2px 6px",borderRadius:"50%",display:"none"}),U.appendChild(Y),U.appendChild(K),I.appendChild(U),I.appendChild(G),I.addEventListener("click",function(){if(console.log("[CRM Extension] Chat button clicked"),typeof window.toggleChatUI=="function")window.toggleChatUI();else{console.error("[CRM Extension] toggleChatUI function not available");let w=document.getElementById("hipaa-chat-container");if(w)w.style.display=w.style.display==="none"?"flex":"none",console.log("[CRM Extension] Toggled chat container visibility as fallback");else{console.error("[CRM Extension] Chat container not found");try{typeof Q=="function"&&Q().then(()=>{typeof window.toggleChatUI=="function"&&window.toggleChatUI()})}catch(k){console.error("[CRM Extension] Failed to initialize chat:",k)}}}});let z=pr();M.appendChild(I),M.appendChild(z);let me=lr();e.appendChild(r),e.appendChild(l),e.appendChild(m),e.appendChild(x),e.appendChild(N),e.appendChild(A),e.appendChild(H),e.appendChild(_),e.appendChild(E),e.appendChild(M),e.appendChild(me),document.body.appendChild(e),document.body.style.paddingTop=t?"32px":"0",setTimeout(()=>{try{let w=localStorage.getItem("crmplus_automationEnabled")==="true";[document.getElementById("crm-automation-dropdown"),document.getElementById("crm-tags-dropdown")].forEach(L=>{L&&(L.style.display=w?"flex":"none",console.log(`[CRM Extension] Initial visibility for ${L.id}: ${w?"visible":"hidden"}`))})}catch(w){console.error("[CRM Extension] Error setting initial automation visibility:",w)}},100),X(),Hn(),Gn(),On(),Kn(),so(),Q(),tr(),nr(w=>{if(w.length>0){let k=w[0];y(`New message from ${k.sender}: ${k.text.substring(0,30)}${k.text.length>30?"...":""}`,3e3)}}),window.addEventListener("popstate",function(){console.log("[CRM Extension] Navigation detected, clearing phone display"),X()}),Ui()||X(),Ti=!0,console.log("[CRM Extension] Header successfully initialized")}catch(e){console.error("[CRM Extension] Critical error creating toolbar:",e);try{let t=document.getElementById("mcp-crm-header");t&&(t.style.display="flex")}catch(t){console.error("[CRM Extension] Failed to recover toolbar:",t)}}}function Rn(e,t,n="",o=""){let r=document.createElement("a");r.href=t,r.target="_blank",r.className=`text-link btn ${n}`,r.rel="noopener noreferrer";let s=document.createElement("div");if(s.style.display="flex",s.style.alignItems="center",s.style.justifyContent="center",s.style.width="100%",o){let a=document.createElement("img");a.src=o,a.alt="",a.className="link-icon",a.style.width="16px",a.style.height="16px",a.style.marginRight="4px",s.appendChild(a)}let i=document.createElement("span");return i.textContent=e,s.appendChild(i),r.appendChild(s),r}function Ui(){let e=window.location.href;return[/\/patient\/\d+/i,/\/contact\/\d+/i,/\/profile\/\d+/i,/[?&]patient_id=\d+/i,/[?&]contact_id=\d+/i].some(o=>o.test(e))?!0:['input[name="contact.phone"]','input[name="contact.first_name"]','input[name="contact.last_name"]','input[name="contact.date_of_birth"]',".patient-info",".contact-details",".patient-header",".patient-profile"].some(o=>document.querySelector(o)!==null)}function Tn(e){try{let t=document.getElementById("mcp-crm-header");if(t){console.log(`[CRM Extension] Setting header visibility to: ${e}`),t.style.display=e?"flex":"none";let n=document.body.classList.contains("has-alert");return e?(document.body.style.paddingTop=n?"72px":"32px",document.body.classList.remove("no-header")):(document.body.style.paddingTop=n?"40px":"0",document.body.classList.add("no-header")),localStorage.setItem("crmplus_headerBarVisible",e.toString()),!0}else if(e)return console.log("[CRM Extension] Header not found but should be visible, creating it"),Nn(),!0;return!1}catch(t){return console.error("[CRM Extension] Error toggling header visibility:",t),!1}}function ur(){if(!(localStorage.getItem("crmplus_autoCopyPhone")==="true")){console.log("[CRM Extension] Auto-copy phone is disabled");return}let t=()=>{let o=qe();if(o){let r=Rt(o);r&&we(r).then(s=>{if(s)return y("Phone number auto-copied: "+r),!0})}return!1};if(t())return;let n=new MutationObserver((o,r)=>{t()&&r.disconnect()});n.observe(document.body,{childList:!0,subtree:!0,attributes:!0,characterData:!0}),setTimeout(()=>{n.disconnect(),t()},5e3)}var mr=!1,De=new Set,wt="",Bn=!1,vt=null,Un=null;function gr(){mr||(Bi(),Pi(),mr=!0,console.log("[CRM Extension] Alert system initialized"))}function Bi(){if(document.getElementById("crm-alert-styles"))return;let e=document.createElement("style");e.id="crm-alert-styles",e.textContent=`
    .crm-alert-banner {
      position: fixed;
      top: 32px; /* Positioned right below the header bar */
      left: 0;
      right: 0;
      width: 100%;
      padding: 4px 15px; /* Reduced vertical padding for smaller height */
      font-size: 13px;
      font-weight: 500;
      z-index: 999990;
      display: flex;
      align-items: center;
      justify-content: center; /* Center contents horizontally */
      transition: all 0.3s ease;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
      transform: translateY(-100%);
      opacity: 0;
      height: 25px; /* Fixed height at 3/4 of original (approx) */
    }
    
    .crm-alert-banner.show {
      transform: translateY(0);
      opacity: 1;
    }
    
    .crm-alert-banner .alert-icon {
      margin-right: 8px;
      font-size: 16px;
    }
    
    .crm-alert-banner .alert-message {
      text-align: center; /* Center the text */
      margin: 0 auto; /* Center with auto margins */
      flex-grow: 0; /* Don't grow to fill space */
    }
    
    /* Provider Paid specific alert styling */
    .crm-alert-banner.provider-paid {
      background-color: #FFAB40; /* Orange */
      color: #5F4200;
      border-bottom: 1px solid #FF9100;
    }
    
    /* Adjust body padding to accommodate the alert banner */
    body.has-alert {
      padding-top: 72px !important; /* 32px (header) + approx alert height */
    }
    
    /* When header is hidden but alert is visible */
    body.no-header.has-alert {
      padding-top: 25px !important; /* Just the alert height */
    }
    
    /* Multiple alerts stacking */
    .crm-alert-banner.second-alert {
      top: 57px;
    }
    
    .crm-alert-banner.third-alert {
      top: 82px;
    }
    
    /* Countdown timer styling */
    .countdown-timer {
      margin-left: 5px;
      font-size: 11px;
      opacity: 0.75;
      background-color: rgba(0, 0, 0, 0.1);
      padding: 1px 4px;
      border-radius: 3px;
      min-width: 30px;
      text-align: center;
    }
  `,document.head.appendChild(e)}function hr(){let e=window.location.href,t=[/\/patient\/(\d+)/i,/\/contact\/(\d+)/i,/\/profile\/(\d+)/i,/[?&]patient_id=(\d+)/i,/[?&]contact_id=(\d+)/i];for(let n of t){let o=e.match(n);if(o&&o[1])return o[1]}return""}function Pi(){wt=hr(),kt(),vt&&vt.disconnect(),vt=new MutationObserver(e=>{for(let t of e)t.type==="childList"&&kt(),t.type==="attributes"&&(t.target.classList.contains("tag")||t.target.classList.contains("tag-label")||t.target.classList.contains("provider-paid"))&&kt()}),vt.observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["class","data-tag"]}),Un&&clearInterval(Un),Un=setInterval(()=>{let e=hr();e!==wt&&(console.log("[CRM Extension] Navigation detected, patient changed from",wt,"to",e),wt=e,Bn=!1,Mt("provider-paid"),setTimeout(kt,1e3))},1e3)}function kt(){if(!(localStorage.getItem("crmplus_showProviderPaidAlerts")!=="false")){Mt("provider-paid");return}Vi()?Bn||Di():Mt("provider-paid")}function Vi(){let e=document.querySelectorAll(".tag, .tag-label, .pill, .badge");for(let r of e)if(r.textContent.toLowerCase().includes("provider-paid"))return r;let t=document.querySelectorAll(".provider-paid");if(t.length>0)return t[0];let n=document.querySelectorAll('[data-tag="provider-paid"], [data-tag-name="provider-paid"]');if(n.length>0)return n[0];let o=document.querySelectorAll(".tags-container, .tag-list, .tags");for(let r of o)if(r.textContent.toLowerCase().includes("provider-paid"))return r;return null}function Di(){if(De.has("provider-paid"))return;Bn=!0;let e=document.createElement("div");e.className="crm-alert-banner provider-paid",e.id="provider-paid-alert",e.setAttribute("data-alert-type","provider-paid");let t=document.createElement("span");t.className="alert-icon",t.innerHTML="\u26A0\uFE0F",e.appendChild(t);let n=document.createElement("span");n.className="alert-message",n.textContent="This patient has Provider Paid status. Special billing rules apply.";let o=document.createElement("span");o.className="countdown-timer",o.textContent="30",n.appendChild(o),e.appendChild(n),document.body.appendChild(e),zi(e),setTimeout(()=>{e.classList.add("show"),document.body.classList.add("has-alert")},10),De.add("provider-paid");let r=document.getElementById("mcp-crm-header");r&&r.style.display==="none"?document.body.classList.add("no-header"):document.body.classList.remove("no-header"),console.log("[CRM Extension] Provider Paid alert shown");let s=15,i=setInterval(()=>{s--,o&&(o.textContent=s),s<=0&&(clearInterval(i),Mt("provider-paid"))},1e3)}function zi(e){let t=De.size;t===1?e.classList.add("second-alert"):t===2&&e.classList.add("third-alert")}function Mt(e){let t=document.querySelector(`.crm-alert-banner[data-alert-type="${e}"]`);t&&(t.classList.remove("show"),De.delete(e),setTimeout(()=>{t.parentNode&&t.parentNode.removeChild(t),De.size===0&&document.body.classList.remove("has-alert"),_i()},300))}function _i(){document.querySelectorAll(".crm-alert-banner").forEach((t,n)=>{t.classList.remove("second-alert","third-alert"),n===1?t.classList.add("second-alert"):n===2&&t.classList.add("third-alert")})}console.log("[CRM Extension] Content script injected.");var ze=typeof browser<"u"?browser:chrome;ze.runtime.sendMessage({action:"loadSettings"}).then(e=>{e&&e.success&&(console.log("[CRM Extension] Settings loaded from browser storage on startup:",e.settings),document.getElementById("mcp-crm-header")||xe())}).catch(e=>{console.error("[CRM Extension] Error requesting settings on startup:",e)});localStorage.getItem("crmplus_headerBarVisible")===null?(console.log("[CRM Extension] No local toolbar visibility setting, requesting from browser storage"),ze.runtime.sendMessage({action:"loadSettings"}).then(e=>{e&&e.success?(console.log("[CRM Extension] Settings loaded from browser storage:",e.settings),xe()):(console.error("[CRM Extension] Failed to load settings, using defaults"),localStorage.setItem("crmplus_headerBarVisible","true"),xe())}).catch(e=>{console.error("[CRM Extension] Error requesting settings:",e),localStorage.setItem("crmplus_headerBarVisible","true"),xe()})):(console.log("[CRM Extension] Using existing localStorage settings"),xe());function xe(){let e=localStorage.getItem("crmplus_headerBarVisible")!=="false";console.log("[CRM Extension] Header visibility setting on init:",e);try{console.log("[CRM Extension] Creating fixed header..."),Nn(),Tn(e)}catch(t){console.error("[CRM Extension] Error creating fixed header:",t)}try{Dn(t=>{console.log(`[CRM Extension] Intercepted console message: ${t}`)})}catch(t){console.error("[CRM Extension] Error initializing console monitor:",t)}try{ur()}catch(t){console.error("[CRM Extension] Error initializing auto phone copy:",t)}try{gr()}catch(t){console.error("[CRM Extension] Error initializing alert system:",t)}try{Zn()}catch(t){console.error("[CRM Extension] Error initializing tag removal system:",t)}try{eo()}catch(t){console.error("[CRM Extension] Error initializing automation removal system:",t)}X();try{Q().then(()=>{console.log("[CRM Extension] Chat system initialized successfully"),setTimeout(()=>{typeof q=="function"?(q(),console.log("[CRM Extension] Explicitly initialized Chat UI")):console.error("[CRM Extension] initChatUI function not found")},500)})}catch(t){console.error("[CRM Extension] Error initializing chat system:",t)}}document.addEventListener("click",function(e){if(e.target.closest(".chat-button")&&(console.log("[CRM Extension] Chat button clicked (global event listener)"),console.log("window.toggleChatUI exists:",typeof window.toggleChatUI=="function"),console.log("Chat container exists:",!!document.getElementById("hipaa-chat-container")),!document.getElementById("hipaa-chat-container"))){console.log("[CRM Extension] Chat container not found, initializing chat UI...");try{typeof q=="function"&&(q(),setTimeout(()=>{if(typeof window.toggleChatUI=="function")window.toggleChatUI();else{let n=document.getElementById("hipaa-chat-container");n&&(n.style.display=n.style.display==="none"?"flex":"none")}},100))}catch(n){console.error("[CRM Extension] Error initializing chat UI:",n)}}});ze.runtime.onMessage.addListener((e,t,n)=>{if(console.log("[CRM Extension] Received message:",e),e.action==="toggleHeaderVisibility"){console.log("[CRM Extension] Toggling header visibility to:",e.isVisible);try{let o=Tn(e.isVisible);localStorage.setItem("crmplus_headerBarVisible",e.isVisible.toString()),ze.runtime.sendMessage({action:"syncSettings"}).catch(r=>console.error("[CRM Extension] Error syncing settings:",r)),n({success:o})}catch(o){console.error("[CRM Extension] Error toggling header visibility:",o),n({success:!1,error:o.message})}return!0}if(e.action==="initializeChat"){try{Q().then(()=>{typeof q=="function"?(q(),n({success:!0})):n({success:!1,error:"initChatUI function not found"})})}catch(o){console.error("[CRM Extension] Error initializing chat:",o),n({success:!1,error:o.message})}return!0}return!1});document.addEventListener("DOMContentLoaded",()=>{if(console.log("[CRM Extension] DOM fully loaded, checking visibility setting"),document.getElementById("mcp-crm-header")||ze.runtime.sendMessage({action:"loadSettings"}).then(e=>{e&&e.success&&xe()}).catch(()=>{localStorage.setItem("crmplus_headerBarVisible","true"),xe()}),!document.getElementById("hipaa-chat-container"))try{Q().then(()=>{typeof q=="function"&&q()})}catch(e){console.error("[CRM Extension] Error initializing chat on DOMContentLoaded:",e)}});try{window.addEventListener("load",()=>{console.log("[CRM Extension] Window loaded, initializing chat..."),Q().then(()=>{typeof q=="function"&&q()})})}catch(e){console.error("[CRM Extension] Critical error initializing chat on window.load:",e)}})();
