// modules/ui/components/dropdowns/tagsDropdown.js

import { createDropdown } from '../dropdownsGroup.js';
import { showToast } from '../../../phoneUtils.js';

/**
 * Creates the Tags dropdown with both direct tag options and nested Vial dropdowns
 * 
 * @returns {HTMLElement} The Tags dropdown element
 */
export function createTagsDropdown() {
  // Create the main dropdown container
  const dropdown = document.createElement("div");
  dropdown.className = "dropdown";
  dropdown.id = "crm-tags-dropdown"; // Add ID for future reference
  
  // Create the main dropdown button
  const dropdownBtn = document.createElement("button");
  dropdownBtn.className = "dropdown-btn";
  dropdownBtn.textContent = "Tags";
  
  // Toggle dropdown menu when button is clicked
  dropdownBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    // Close any other open dropdowns
    document.querySelectorAll('.dropdown.show').forEach(d => {
      if (d !== dropdown) {
        d.classList.remove('show');
      }
    });
    dropdown.classList.toggle("show");
  });
  
  // Create the dropdown content container
  const dropdownContent = document.createElement("div");
  dropdownContent.className = "dropdown-content";
  dropdownContent.style.padding = "5px";
  
  // Add Custom styling for nested dropdowns if it doesn't exist already
  if (!document.getElementById('nested-dropdown-styles')) {
    const style = document.createElement('style');
    style.id = 'nested-dropdown-styles';
    style.textContent = `
      .nested-dropdown {
        margin-bottom: 5px;
        width: 100%;
        position: relative;
      }
      .nested-dropdown-btn {
        width: 100%;
        text-align: left;
        padding: 8px 12px;
        background-color: #f1f1f1;
        border: 1px solid #ddd;
        border-radius: 3px;
        cursor: pointer;
        font-weight: bold;
        font-size: 13px;
        color: #333;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .nested-dropdown-btn:hover {
        background-color: #e1e1e1;
      }
      .nested-dropdown-btn:after {
        content: "▼";
        font-size: 8px;
      }
      .nested-dropdown-content {
        display: none;
        padding: 5px 0 5px 10px;
        margin-top: 3px !important;
      }
      .nested-dropdown.open .nested-dropdown-content {
        display: block;
      }
      .nested-dropdown-item {
        display: block;
        padding: 8px 12px;
        color: #333;
        text-decoration: none;
        font-size: 13px;
        cursor: pointer;
        border-radius: 3px;
        margin-bottom: 2px;
      }
      .nested-dropdown-item:hover {
        background-color: #e8e8e8;
      }
    `;
    document.head.appendChild(style);
  }
  
  // Add direct tag options to the main dropdown
  // Create Refill-Sema-Inj option
  const semaRefillTag = document.createElement("a");
  semaRefillTag.className = "dropdown-item";
  semaRefillTag.textContent = "Refill-Sema-Inj";
  semaRefillTag.addEventListener("click", () => {
    selectTagOption("refill-sema-inj");
    dropdown.classList.remove("show"); // Close dropdown after selection
  });
  dropdownContent.appendChild(semaRefillTag);
  
  // Create Refill-Tirz-Inj option
  const tirzRefillTag = document.createElement("a");
  tirzRefillTag.className = "dropdown-item";
  tirzRefillTag.textContent = "Refill-Tirz-Inj";
  tirzRefillTag.addEventListener("click", () => {
    selectTagOption("refill-tirz-inj");
    dropdown.classList.remove("show"); // Close dropdown after selection
  });
  dropdownContent.appendChild(tirzRefillTag);
  
  // Add a separator
  const separator = document.createElement("div");
  separator.style.borderTop = "1px solid #eee";
  separator.style.margin = "5px 0";
  dropdownContent.appendChild(separator);
  
  // ============ VIAL-SEMA DROPDOWN ITEMS ============
  // Create Vial-Sema nested dropdown
  const vialSemaNestedDropdown = document.createElement("div");
  vialSemaNestedDropdown.className = "nested-dropdown";

  const vialSemaNestedBtn = document.createElement("button");
  vialSemaNestedBtn.className = "nested-dropdown-btn";
  vialSemaNestedBtn.textContent = "Vial-Sema";

  const vialSemaNestedContent = document.createElement("div");
  vialSemaNestedContent.className = "nested-dropdown-content";

  // Toggle nested dropdown when button is clicked
  vialSemaNestedBtn.addEventListener("click", (e) => {
    e.stopPropagation(); // Prevent event from bubbling up
    vialSemaNestedDropdown.classList.toggle("open");
  });

  // Vial-Sema Option 1: Vial-Sema-B12
  const vialSemaB12Item = document.createElement("a");
  vialSemaB12Item.className = "nested-dropdown-item";
  vialSemaB12Item.textContent = "Vial-Sema-B12";
  vialSemaB12Item.addEventListener("click", (e) => {
    e.stopPropagation(); // Prevent event from bubbling up
    closeAllDropdowns();
    setTimeout(() => {
      selectTagOption("vial-sema-b12");
    }, 300);
  });
  vialSemaNestedContent.appendChild(vialSemaB12Item);

  // Vial-Sema Option 2: Vial-Sema-B6
  const vialSemaB6Item = document.createElement("a");
  vialSemaB6Item.className = "nested-dropdown-item";
  vialSemaB6Item.textContent = "Vial-Sema-B6";
  vialSemaB6Item.addEventListener("click", (e) => {
    e.stopPropagation();
    closeAllDropdowns();
    setTimeout(() => {
      selectTagOption("vial-sema-b6");
    }, 300);
  });
  vialSemaNestedContent.appendChild(vialSemaB6Item);

  // Vial-Sema Option 3: Vial-Sema-Lipo
  const vialSemaLipoItem = document.createElement("a");
  vialSemaLipoItem.className = "nested-dropdown-item";
  vialSemaLipoItem.textContent = "Vial-Sema-Lipo";
  vialSemaLipoItem.addEventListener("click", (e) => {
    e.stopPropagation();
    closeAllDropdowns();
    setTimeout(() => {
      selectTagOption("vial-sema-lipo");
    }, 300);
  });
  vialSemaNestedContent.appendChild(vialSemaLipoItem);

  // Vial-Sema Option 4: Vial-Sema-NAD+
  const vialSemaNADItem = document.createElement("a");
  vialSemaNADItem.className = "nested-dropdown-item";
  vialSemaNADItem.textContent = "Vial-Sema-NAD+";
  vialSemaNADItem.addEventListener("click", (e) => {
    e.stopPropagation();
    closeAllDropdowns();
    setTimeout(() => {
      selectTagOption("vial-sema-nad+");
    }, 300);
  });
  vialSemaNestedContent.appendChild(vialSemaNADItem);

  // Assemble Vial-Sema nested dropdown
  vialSemaNestedDropdown.appendChild(vialSemaNestedBtn);
  vialSemaNestedDropdown.appendChild(vialSemaNestedContent);

  // Add to main dropdown
  dropdownContent.appendChild(vialSemaNestedDropdown);

  // ============ VIAL-TIRZ DROPDOWN ITEMS ============
  // Create Vial-Tirz nested dropdown
  const vialTirzNestedDropdown = document.createElement("div");
  vialTirzNestedDropdown.className = "nested-dropdown";

  const vialTirzNestedBtn = document.createElement("button");
  vialTirzNestedBtn.className = "nested-dropdown-btn";
  vialTirzNestedBtn.textContent = "Vial-Tirz";

  const vialTirzNestedContent = document.createElement("div");
  vialTirzNestedContent.className = "nested-dropdown-content";

  // Toggle nested dropdown when button is clicked
  vialTirzNestedBtn.addEventListener("click", (e) => {
    e.stopPropagation(); // Prevent event from bubbling up
    vialTirzNestedDropdown.classList.toggle("open");
  });

  // Vial-Tirz Option 1: Vial-Tirz-Cyano
  const vialTirzCyanoItem = document.createElement("a");
  vialTirzCyanoItem.className = "nested-dropdown-item";
  vialTirzCyanoItem.textContent = "Vial-Tirz-Cyano";
  vialTirzCyanoItem.addEventListener("click", (e) => {
    e.stopPropagation();
    closeAllDropdowns();
    setTimeout(() => {
      selectTagOption("vial-tirz-cyano");
    }, 300);
  });
  vialTirzNestedContent.appendChild(vialTirzCyanoItem);

  // Vial-Tirz Option 2: Vial-Tirz-NAD+
  const vialTirzNADItem = document.createElement("a");
  vialTirzNADItem.className = "nested-dropdown-item";
  vialTirzNADItem.textContent = "Vial-Tirz-NAD+";
  vialTirzNADItem.addEventListener("click", (e) => {
    e.stopPropagation();
    closeAllDropdowns();
    setTimeout(() => {
      selectTagOption("vial-tirz-nad+");
    }, 300);
  });
  vialTirzNestedContent.appendChild(vialTirzNADItem);

  // Vial-Tirz Option 3: Vial-Tirz-Pyr
  const vialTirzPyrItem = document.createElement("a");
  vialTirzPyrItem.className = "nested-dropdown-item";
  vialTirzPyrItem.textContent = "Vial-Tirz-Pyr";
  vialTirzPyrItem.addEventListener("click", (e) => {
    e.stopPropagation();
    closeAllDropdowns();
    setTimeout(() => {
      selectTagOption("vial-tirz-pyridoxine");
    }, 300);
  });
  vialTirzNestedContent.appendChild(vialTirzPyrItem);

  // Assemble Vial-Tirz nested dropdown
  vialTirzNestedDropdown.appendChild(vialTirzNestedBtn);
  vialTirzNestedDropdown.appendChild(vialTirzNestedContent);

  // Add to main dropdown
  dropdownContent.appendChild(vialTirzNestedDropdown);
  
  // Add separator
  const separator2 = document.createElement("div");
  separator2.style.borderTop = "1px solid #eee";
  separator2.style.margin = "5px 0";
  dropdownContent.appendChild(separator2);
  
  // Add "Add Custom Tag" option
  const customTagItem = document.createElement("a");
  customTagItem.className = "dropdown-item";
  customTagItem.style.paddingTop = "5px";
  customTagItem.innerHTML = '<span style="margin-right: 5px;">➕</span> Add Custom Tag...';
  customTagItem.addEventListener("click", () => {
    dropdown.classList.remove("show"); // Close dropdown
    
    setTimeout(() => {
      const customTag = prompt("Enter custom tag name:");
      if (customTag && customTag.trim() !== "") {
        selectTagOption(customTag.trim());
      }
    }, 300);
  });
  dropdownContent.appendChild(customTagItem);
  
  // Assemble the main dropdown
  dropdown.appendChild(dropdownBtn);
  dropdown.appendChild(dropdownContent);
  
  return dropdown;
}

/**
 * Helper to close all open dropdowns and nested dropdowns
 */
function closeAllDropdowns() {
  document.querySelectorAll('.dropdown.show').forEach(d => d.classList.remove('show'));
  document.querySelectorAll('.nested-dropdown.open').forEach(d => d.classList.remove('open'));
}

/**
 * Selects a tag option from the dropdown
 * 
 * @param {string} tagText - The text of the tag to select
 */
function selectTagOption(tagText) {
  // UPDATED: Find the Tags input field with expanded selectors
  let tagInput = findTagInput();
  
  if (tagInput) {
    // Focus on the input field to open the dropdown
    tagInput.focus();
    
    // Try to find the tag in the list of options
    // Wait a moment for the dropdown to appear
    setTimeout(() => {
      // Type the text to filter the dropdown
      tagInput.value = tagText;
      tagInput.dispatchEvent(new Event('input', { bubbles: true }));
      
      // Wait for the filtered dropdown to update
      setTimeout(() => {
        // Look for the option in the dropdown that contains our text
        const options = document.querySelectorAll('.v-list-item, .dropdown-item, .select-option, li');
        let found = false;
        
        for (const option of options) {
          if (option.textContent.toLowerCase().includes(tagText)) {
            // Click the option to select it
            option.click();
            found = true;
            showToast(`Selected tag: ${tagText}`);
            break;
          }
        }
        
        // If we can't find the exact option, try alternative approaches
        if (!found) {
          // Try looking for a more generic class that might contain dropdown options
          const allElements = document.querySelectorAll('*');
          for (const elem of allElements) {
            if (elem.textContent.trim().toLowerCase() === tagText) {
              // If we find text content that matches exactly, try clicking it
              elem.click();
              found = true;
              showToast(`Selected tag: ${tagText}`);
              break;
            }
          }
          
          // If still not found, try keyboard navigation - press Enter key
          if (!found) {
            // Press Enter key to attempt to select the filtered option
            tagInput.dispatchEvent(new KeyboardEvent('keydown', { 
              key: 'Enter', 
              code: 'Enter',
              keyCode: 13,
              which: 13,
              bubbles: true 
            }));
            
            // If the option doesn't exist yet, maybe we need to add it
            // Wait a moment and press Enter again to try to create it
            setTimeout(() => {
              tagInput.dispatchEvent(new KeyboardEvent('keydown', { 
                key: 'Enter', 
                code: 'Enter',
                keyCode: 13,
                which: 13,
                bubbles: true 
              }));
              showToast(`Attempted to add tag: ${tagText}`);
            }, 300);
          }
        }
      }, 300); // Wait for dropdown to filter
    }, 300); // Wait for dropdown to appear
  } else {
    showToast("Tags field not found");
  }
}

/**
 * ADDED: Enhanced function to find the tag input field with multiple strategies
 * @returns {HTMLElement|null} The found tag input element or null
 */
function findTagInput() {
  // Try several strategies to find the tag input field
  
  // Strategy 1: Original selector - looking for "Add Tags" placeholder
  let tagInput = document.querySelector('input[placeholder="Add Tags"]');
  if (tagInput) return tagInput;
  
  // Strategy 2: Broader placeholder pattern - any input with "tag" in placeholder
  const tagInputs = Array.from(document.querySelectorAll('input[placeholder]')).filter(input => {
    return input.placeholder.toLowerCase().includes('tag');
  });
  if (tagInputs.length > 0) return tagInputs[0];
  
  // Strategy 3: Input within element with tag-related class
  const tagContainers = document.querySelectorAll('.tag-input, .tags-input, .tag-container');
  for (const container of tagContainers) {
    const input = container.querySelector('input');
    if (input) return input;
  }
  
  // Strategy 4: Looking for smartList.bulkTags placeholder (from your example)
  tagInput = document.querySelector('input[placeholder="smartList.bulkTags.addTags"]');
  if (tagInput) return tagInput;
  
  // Strategy 5: Generic attribute search - looking for any input that might be for tags
  const possibleTagInputs = document.querySelectorAll('.hl-text-input');
  if (possibleTagInputs.length > 0) {
    return possibleTagInputs[0]; // Return the first one as best guess
  }
  
  // If no tag input found with any strategy
  console.error('[CRM Extension] Could not find tag input field with any strategy');
  
  // One last attempt - log all inputs to help diagnose
  const allInputs = document.querySelectorAll('input');
  console.log('[CRM Extension] All inputs on page:', allInputs);
  
  return null;
}