(()=>{function Le(e){if(window.__crmConsoleMonitor)return;window.__crmConsoleMonitor=!0;let t=console.log,o=console.error,n=console.warn;console.log=function(...r){t.apply(console,r),!(typeof r[0]=="string"&&r[0].includes("[CRM Extension]"))&&ye(r,"log",e)},console.error=function(...r){o.apply(console,r),!(typeof r[0]=="string"&&r[0].includes("[CRM Extension]"))&&ye(r,"error",e)},console.warn=function(...r){n.apply(console,r),!(typeof r[0]=="string"&&r[0].includes("[CRM Extension]"))&&ye(r,"warn",e)}}function ye(e,t,o){let n=e.join(" ");["error","failed","unauthorized","critical"].some(i=>n.toLowerCase().includes(i))&&o(n)}var Te=window.location.href,j="";function se(){if(!Pe())return"";let e=document.querySelector('input[name="contact.phone"]');if(e&&e.value.trim()!=="")return e.value.trim();let t=document.querySelector(".phone-number .number");if(t&&t.textContent.trim()!=="")return t.textContent.trim();let o=['input[placeholder="Phone"]','input[placeholder="Phone Number"]',".patient-info .phone",".contact-info .phone","span.phone",'label[for*="phone"]',".phone-display",'div[data-field="phone"]','span[data-field="phone_number"]'];for(let n of o){let r=document.querySelector(n);if(r)if(r.tagName==="INPUT"){let i=r.value.trim();if(i)return i}else if(r.tagName==="LABEL"){let i=r.getAttribute("for");if(i){let s=document.getElementById(i);if(s&&s.value.trim())return s.value.trim()}let a=r.parentElement?.querySelector("input");if(a&&a.value.trim())return a.value.trim()}else{let i=r.textContent.trim();if(i)return i}}return""}function Pe(){let e=window.location.href;return[/\/patient\/\d+/i,/\/contact\/\d+/i,/\/profile\/\d+/i,/[?&]patient_id=\d+/i,/[?&]contact_id=\d+/i].some(n=>n.test(e))?!0:['input[name="contact.phone"]','input[name="contact.first_name"]','input[name="contact.last_name"]','input[name="contact.date_of_birth"]',".patient-info",".contact-details",".patient-header",".patient-profile"].some(n=>document.querySelector(n)!==null)}function ze(e){try{let t=e?bt(e):"";if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("phone",t);else{let o=document.getElementById("phone-text");if(o){o.textContent=t;let n=document.getElementById("phone-display");n&&(e?n.setAttribute("data-value",e):n.removeAttribute("data-value"))}}}catch(t){console.error("[CRM Extension] Error updating phone display:",t)}}function A(){j="",ze("");try{let e=document.getElementById("phone-display");e&&e.removeAttribute("data-value")}catch(e){console.error("[CRM Extension] Error clearing phone display:",e)}}function bt(e){if(!e)return"";let t=e.replace(/\D/g,"");if(t.length===0)return"";if(t.length===10)return`(${t.substring(0,3)}) ${t.substring(3,6)}-${t.substring(6)}`;if(t.length===11&&t.startsWith("1"))return`(${t.substring(1,4)}) ${t.substring(4,7)}-${t.substring(7)}`;if(t.length>4){let o="";for(let n=0;n<t.length;n+=3)if(n+4>=t.length&&t.length%3!==0){o+=" "+t.substring(n);break}else o+=" "+t.substring(n,n+3);return o.trim()}return t.replace(/(\d{3})/g,"$1 ").trim()}function ae(){try{if(!Pe())return j&&A(),!1;let e=se();return e?(e!==j&&(j=e,ze(e)),!0):(j&&A(),!1)}catch(e){return console.error("[CRM Extension] Error detecting phone number:",e),!1}}function Be(){A(),ae();let e=setInterval(()=>{let t=window.location.href;t!==Te&&(console.log("[CRM Extension] URL changed, resetting phone detection"),Te=t,A()),ae()},200);try{let t=new MutationObserver(n=>{ae()}),o=document.body;t.observe(o,{childList:!0,subtree:!0,characterData:!0,attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] Phone number mutation observer active")}catch(t){console.error("[CRM Extension] Error setting up phone mutation observer:",t)}}function De(e){let t=se();if(!t){p("No phone number found");return}let o=we(t);if(!o){p("Invalid phone number format");return}e.setAttribute("data-value",t),W(o).then(n=>{p(n?"Copied: "+o:"Failed to copy phone number")})}function we(e){if(!e)return"";let t=e.replace(/\D/g,"");return t.length<7?"":"+1"+t}async function W(e){if(navigator.clipboard&&navigator.clipboard.writeText)try{return await navigator.clipboard.writeText(e),!0}catch(t){console.warn("Clipboard API failed, trying fallback method:",t)}try{let t=document.createElement("textarea");t.value=e,t.style.position="fixed",t.style.top="0",t.style.left="0",t.style.opacity="0",t.style.pointerEvents="none",document.body.appendChild(t),t.focus(),t.select();let o=document.execCommand("copy");return document.body.removeChild(t),o}catch(t){return console.error("All clipboard methods failed:",t),!1}}function p(e,t=2e3){let o=document.getElementById("crm-plus-toast-container");o||(o=document.createElement("div"),o.id="crm-plus-toast-container",o.style.position="fixed",o.style.bottom="20px",o.style.right="20px",o.style.zIndex="100000",document.body.appendChild(o));let n=document.createElement("div");n.textContent=e,n.style.background="#333",n.style.color="#fff",n.style.padding="10px",n.style.borderRadius="5px",n.style.marginTop="10px",n.style.boxShadow="0 2px 5px rgba(0,0,0,0.2)",n.style.transition="opacity 0.5s, transform 0.5s",n.style.opacity="0",n.style.transform="translateY(20px)",o.appendChild(n),n.offsetWidth,n.style.opacity="1",n.style.transform="translateY(0)",setTimeout(()=>{n.style.opacity="0",n.style.transform="translateY(20px)",setTimeout(()=>{n.parentNode&&n.parentNode.removeChild(n),o.childNodes.length===0&&document.body.removeChild(o)},500)},t)}var $e=window.location.href;function G(e){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("name",e);else{let t=document.getElementById("name-text");if(t){t.textContent=e;let o=document.getElementById("name-display");o&&o.setAttribute("data-value",e)}}}catch(t){console.error("[CRM Extension] Error updating name display:",t)}}function le(){try{let e=document.querySelector('input[name="contact.first_name"]'),t=document.querySelector('input[name="contact.last_name"]');if(e&&e.value&&t&&t.value){let r=`${e.value} ${t.value}`;return G(r),!0}let o=document.querySelectorAll(".patient-name, .contact-name, h1.name, .customer-name");for(let r of o)if(r&&r.textContent&&r.textContent.trim()!==""){let i=r.textContent.trim();return G(i),!0}let n=["span.name",".profile-name","h2.name",".contact-header .name",'div[data-field="name"]',".patient-info .name"];for(let r of n){let i=document.querySelector(r);if(i&&i.textContent&&i.textContent.trim()!==""){let a=i.textContent.trim();return G(a),!0}}return!1}catch(e){return console.error("[CRM Extension] Error detecting name:",e),!1}}function qe(){le();let e=setInterval(()=>{let t=window.location.href;t!==$e&&(console.log("[CRM Extension] URL changed, resetting name detection"),$e=t,G(""),le());let o=document.getElementById("name-text");o&&(o.textContent==="Loading..."||!o.textContent)&&le()},1e3);try{let t=new MutationObserver(n=>{n.some(i=>i.addedNodes.length>5||i.removedNodes.length>5)&&(console.log("[CRM Extension] Significant DOM changes detected, rechecking name"),G(""),le())}),o=document.querySelector("main")||document.body;t.observe(o,{childList:!0,subtree:!0})}catch(t){console.error("[CRM Extension] Error setting up navigation observer for name:",t)}}var Ve=window.location.href;function de(e){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("dob",e);else{let t=document.getElementById("dob-text");if(t){t.textContent=e;let o=document.getElementById("dob-display");o&&o.setAttribute("data-value",e)}}}catch(t){console.error("[CRM Extension] Error updating DOB display:",t)}}function Oe(e){if(!e)return"";if(e.match(/^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2}(st|nd|rd|th)?\s+\d{4}$/))try{let t=e.match(/(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+(\d{1,2})(st|nd|rd|th)?\s+(\d{4})/);if(t){let o=t[1],n=t[2],r=t[4];return`${(["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"].indexOf(o)+1).toString().padStart(2,"0")}/${n.toString().padStart(2,"0")}/${r}`}}catch(t){console.error("[CRM Extension] Error parsing date:",t)}try{let t=new Date(e);if(!isNaN(t.getTime()))return`${(t.getMonth()+1).toString().padStart(2,"0")}/${t.getDate().toString().padStart(2,"0")}/${t.getFullYear()}`}catch(t){console.error("[CRM Extension] Error parsing date as Date object:",t)}return e}function ce(){try{let e=document.querySelector('input[name="contact.date_of_birth"]');if(e&&e.value){let o=Oe(e.value);return de(o),!0}let t=[".dob",".patient-dob",".contact-dob",'span[data-field="date_of_birth"]','div[data-field="dob"]',".patient-info .dob",".contact-info .dob"];for(let o of t){let n=document.querySelector(o);if(n&&n.textContent&&n.textContent.trim()!==""){let r=Oe(n.textContent.trim());return de(r),!0}}return!1}catch(e){return console.error("[CRM Extension] Error detecting DOB:",e),!1}}function _e(){ce();let e=setInterval(()=>{let t=window.location.href;t!==Ve&&(console.log("[CRM Extension] URL changed, resetting DOB detection"),Ve=t,de(""),ce());let o=document.getElementById("dob-text");o&&(o.textContent==="Loading..."||!o.textContent)&&ce()},1e3);try{let t=new MutationObserver(n=>{n.some(i=>i.addedNodes.length>5||i.removedNodes.length>5)&&(console.log("[CRM Extension] Significant DOM changes detected, rechecking DOB"),de(""),ce())}),o=document.querySelector("main")||document.body;t.observe(o,{childList:!0,subtree:!0})}catch(t){console.error("[CRM Extension] Error setting up navigation observer for DOB:",t)}}var Fe=window.location.href,pe="";function Ue(e){try{if(typeof updateClickableDisplayValue=="function")updateClickableDisplayValue("srxid",e);else{let t=document.getElementById("srxid-text");if(t){t.textContent=e;let o=document.getElementById("srxid-display");o&&o.setAttribute("data-value",e)}}}catch(t){console.error("[CRM Extension] Error updating SRx ID display:",t)}}function Y(){try{let e=document.querySelector('input[name="contact.srx_id"]');if(e&&e.value){let t="^"+e.value.trim();if(t&&/^\d+$/.test(t))return t!==pe&&(console.log("[CRM Extension] Found SRx ID from contact.srx_id input:",t),pe=t,Ue(t)),!0}return!!pe}catch(e){return console.error("[CRM Extension] Error detecting SRx ID:",e),!1}}function He(){Y();let e=setInterval(()=>{let t=window.location.href;t!==Fe&&(console.log("[CRM Extension] URL changed, resetting SRx ID detection"),Fe=t,pe="",Ue(""),Y()),Y()},500);try{new MutationObserver(o=>{let n=!1;for(let r of o){if(r.target.tagName==="INPUT"&&r.target.name==="contact.srx_id"||r.target.querySelector&&r.target.querySelector('input[name="contact.srx_id"]')){n=!0;break}if(r.addedNodes.length>0){for(let i of r.addedNodes)if(i.nodeType===1&&i.querySelector&&(i.tagName==="INPUT"&&i.name==="contact.srx_id"||i.querySelector('input[name="contact.srx_id"]'))){n=!0;break}}}n&&Y()}).observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] SRx ID mutation observer active")}catch(t){console.error("[CRM Extension] Error setting up observer for SRx ID:",t)}setTimeout(()=>{try{let t=document.querySelector('input[name="contact.srx_id"]');t&&(new MutationObserver(n=>{Y()}).observe(t,{attributes:!0,attributeFilter:["value"]}),console.log("[CRM Extension] Direct input observer attached to contact.srx_id"))}catch(t){console.error("[CRM Extension] Error setting up direct input observer:",t)}},1e3)}var me=["np-tirz-1.5ml-inj","refill-sema-inj","refill-tirz-inj","vial-sema-b12","vial-sema-b6","vial-sema-lipo","vial-sema-nad+","vial-tirz-cyano","vial-tirz-nad+","vial-tirz-pyridoxine","np-sema-0.125ml-inj","np-sema-0.25ml-inj","np-sema-0.5ml-inj","np-sema-0.75ml-inj","np-sema-1.0ml-inj","np-sema-1.25ml-inj","np-sema-1.5ml-inj","np-sema-2.0ml-inj","np-tirz-0.25ml-inj","np-tirz-0.5ml-inj","np-tirz-0.75ml-inj","np-tirz-1.0ml-inj","np-tirz-1.25ml-inj"],N=[];function je(){console.log("[CRM Extension] Tag removal system initialized")}function xt(){N=[];try{let e=document.querySelectorAll(".tag, .tag-label, .pill, .badge");for(let r of e){let i=r.textContent.trim().toLowerCase();me.some(a=>i.includes(a))&&N.push({element:r,text:i})}let t=document.querySelectorAll("[data-tag]");for(let r of t){let i=r.getAttribute("data-tag").toLowerCase();me.some(a=>i.includes(a))&&N.push({element:r,text:i})}let o=document.querySelectorAll(".tags-container, .tag-list, .tags");for(let r of o){let i=r.querySelectorAll("*");for(let a of i)if(a.nodeType===1){let s=a.textContent.trim().toLowerCase();me.some(l=>s.includes(l))&&(N.some(l=>l.element===a)||N.push({element:a,text:s}))}}let n=document.querySelectorAll("*[class]");for(let r of n){let i=r.className.toLowerCase();i&&typeof i=="string"&&me.some(a=>i.includes(a))&&(N.some(a=>a.element===r)||N.push({element:r,text:r.textContent.trim().toLowerCase()}))}return console.log(`[CRM Extension] Found ${N.length} removable tags`),N}catch(e){return console.error("[CRM Extension] Error detecting tags:",e),[]}}function yt(e){try{let t=e.querySelector('.close, .remove, .delete, .tag-remove, [aria-label="Remove"], .x-button');if(t)return console.log("[CRM Extension] Found close button in tag, clicking it"),t.click(),!0;let o=e.parentElement;if(o){let i=o.querySelector('.close, .remove, .delete, .tag-remove, [aria-label="Remove"], .x-button');if(i)return console.log("[CRM Extension] Found close button as sibling, clicking it"),i.click(),!0}let n=[...Array.from(e.querySelectorAll("*")),...Array.from(o?o.children:[])];for(let i of n){let a=i.textContent.trim();if(a==="\xD7"||a==="x"||a==="\u2715"||a==="\u2716"||a==="X")return console.log("[CRM Extension] Found X button by text content, clicking it"),i.click(),!0;if(i.className&&(i.className.includes("close")||i.className.includes("delete")||i.className.includes("remove")||i.className.includes("x-button")))return console.log("[CRM Extension] Found X button by class name, clicking it"),i.click(),!0;if(i.classList&&(i.classList.contains("fa-times")||i.classList.contains("fa-close")||i.classList.contains("icon-close")||i.classList.contains("icon-remove")))return console.log("[CRM Extension] Found X button by icon class, clicking it"),i.click(),!0}if(e.tagName==="BUTTON"||e.tagName==="A"||e.getAttribute("role")==="button"||window.getComputedStyle(e).cursor==="pointer")return console.log("[CRM Extension] Tag appears to be clickable, clicking it"),e.click(),!0;let r=o;for(let i=0;i<3&&r;i++){let a=r.querySelectorAll("button, span, i, div");for(let s of a){let l=s.textContent.trim();if(l==="\xD7"||l==="x"||l==="\u2715"||l==="\u2716"||l==="X"||s.classList.contains("fa-times")||s.classList.contains("fa-close")||s.classList.contains("close")||s.classList.contains("remove"))return console.log("[CRM Extension] Found X button in parent container, clicking it"),s.click(),!0}r=r.parentElement}return console.log("[CRM Extension] No method found to remove tag:",e),!1}catch(t){return console.error("[CRM Extension] Error removing tag:",t),!1}}function Ce(){return new Promise((e,t)=>{try{let r=function(i){if(i>=N.length){console.log(`[CRM Extension] Removed ${o}/${n} tags`),e({success:!0,message:`Removed ${o} of ${n} tags`,removed:o,total:n});return}let a=N[i];console.log(`[CRM Extension] Removing tag: ${a.text}`),yt(a.element)&&o++,setTimeout(()=>{r(i+1)},300)};xt();let o=0,n=N.length;if(n===0){console.log("[CRM Extension] No removable tags found"),e({success:!0,message:"No tags to remove",removed:0,total:0});return}console.log(`[CRM Extension] Attempting to remove ${n} tags`),r(0)}catch(o){console.error("[CRM Extension] Error in removeAllTags:",o),t(o)}})}var wt=["Workflow - New Patient - Semaglutide 0.125ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 0.25ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 0.5ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 0.75ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 1.0ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 1.25ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 1.5ml Onboarding (Step 1)","Workflow - New Patient - Semaglutide 2.0ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 0.25ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 0.5ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 0.75ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 1.0ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 1.25ml Onboarding - (Step 1)","Workflow - New Patient - Tirzepatide 1.5ml Onboarding - (Step 1)","Workflow - Refill - Semaglutide/B12 Injection Refill Order - (Step 1)","Workflow - Semaglutide/B12 Vial Order - (Step 1)","Workflow - Semaglutide/B6 Vial Order - (Step 1)","Workflow - Semaglutide/Lipo Vial Order - (Step 1)","Workflow - Semaglutide/NAD+ Vial Order - (Step 1)","Workflow - Syringe - Tirzepatide/Pyridoxine Injection Order - (Step 1)","Workflow - Tirzepatide/Cyano Vial Order - (Step 1)","Workflow - Tirzepatide/NAD+ Vial Order - (Step 1)","Workflow - Tirzepatide/Pyridoxine Vial Order - (Step 1)"],ue=[];function L(e){try{if(e&&typeof e.getBoundingClientRect=="function")return e.getBoundingClientRect()}catch{}return{top:0,bottom:0,left:0,right:0,width:0,height:0}}function Ye(){console.log("[CRM Extension] Automation removal system initialized")}function Ct(){ue=[];try{let e=Je("Active");return e?(ue=(e.workflows.length?e.workflows:Et(e.label)).filter(o=>{if(!o)return!1;let n=(o.textContent||"").trim();return n.includes("Workflow")&&wt.some(r=>n.includes(r))}),console.log(`[CRM Extension] Found ${ue.length} automation(s) in Active section.`),ue):(console.log("[CRM Extension] Active section not found."),[])}catch(e){return console.error("[CRM Extension] Error detecting automations:",e),[]}}function Et(e){let t=L(e).bottom,o=null,n=Je("Past");return n&&n.label&&(o=L(n.label).top),Array.from(document.querySelectorAll('div[id^="workflow_"], div[data-workflow-id]')).filter(i=>{let a=L(i);return!(a.top<t||o&&a.top>=o)})}function Je(e){try{let o=Array.from(document.querySelectorAll("div.py-2")).find(i=>(i.textContent||"").trim()===e);if(o)return{label:o,workflows:e==="Active"?vt(o):kt(o)};let n=e==="Active"?'[data-automation="Active"], #automation-active':'[data-automation="Past"], #automation-past',r=document.querySelector(n);return r?{label:r,workflows:[]}:null}catch(t){return console.error(`[CRM Extension] Error finding section for "${e}":`,t),null}}function vt(e){let t=L(e).bottom,n=Array.from(document.querySelectorAll("div.py-2")).find(a=>(a.textContent||"").trim()==="Past"),r=n?L(n).top:null;return Array.from(document.querySelectorAll('div[id^="workflow_"], div[data-workflow-id]')).filter(a=>{let s=L(a);return s.top>t&&(!r||s.top<r)})}function kt(e){let t=L(e).bottom;return Array.from(document.querySelectorAll('div[id^="workflow_"], div[data-workflow-id]')).filter(n=>L(n).top>t)}function St(e){if(!e)return console.error("[CRM Extension] removeAutomation called with undefined element."),!1;try{let t=L(e),o=t.width>0&&t.height>0,n=t.top>=0&&t.left>=0&&t.bottom<=(window.innerHeight||document.documentElement.clientHeight);return!o||!n?(e.scrollIntoView({behavior:"smooth",block:"center"}),new Promise(r=>{setTimeout(()=>r(We(e)),500)})):We(e)}catch(t){return console.error("[CRM Extension] Error removing automation:",t),!1}}function We(e){if(!e)return!1;try{let t=e.querySelectorAll("i.icon-close, i.icon.icon-close");if(t.length)return t[0].click(),!0}catch(t){console.error("[CRM Extension] Error in Strategy 1:",t)}try{let t=e.querySelectorAll("a");for(let o of t){let n=(o.textContent||"").trim();if(n==="\xD7"||n.toLowerCase()==="x")return o.click(),!0}}catch(t){console.error("[CRM Extension] Error in Strategy 2:",t)}try{let t=e.querySelectorAll('button, .btn, [role="button"]');for(let o of t)if((o.textContent||"").toLowerCase().includes("manage"))return o.click(),setTimeout(()=>{document.querySelectorAll(".dropdown-menu .dropdown-item, .menu-item").forEach(i=>{let a=(i.textContent||"").toLowerCase();(a.includes("remove")||a.includes("delete"))&&i.click()})},300),!0}catch(t){console.error("[CRM Extension] Error in Strategy 3:",t)}if(e.id&&e.id.startsWith("workflow_")){let t=e.id;try{let o=`#${t} i.icon-close, #${t} i.icon.icon-close`,n=document.querySelector(o);if(n)return n.click(),!0;o=`#${t} .remove, #${t} .close`;let r=document.querySelector(o);if(r)return r.click(),!0}catch(o){console.error("[CRM Extension] Error in Strategy 4:",o)}}try{let t=e.querySelectorAll("span");for(let o of t){let n=(o.textContent||"").trim();if(n==="\xD7"||n.toLowerCase()==="x")return o.click(),!0}}catch(t){console.error("[CRM Extension] Error in Strategy 5:",t)}try{let t=e.nextElementSibling,o=0;for(;t&&o<3;){if(t.classList&&(t.classList.contains("close")||t.classList.contains("remove"))||t.textContent&&(t.textContent.trim()==="\xD7"||t.textContent.trim().toLowerCase()==="x"))return t.click(),!0;let n=t.querySelector("i.icon-close, i.icon.icon-close");if(n)return n.click(),!0;t=t.nextElementSibling,o++}}catch(t){console.error("[CRM Extension] Error in Strategy 6:",t)}try{let t=L(e),o=t.right-10,n=t.top+t.height/2,r=document.elementsFromPoint(o,n);for(let a of r)if(a!==e)return a.click(),!0;let i=new MouseEvent("click",{view:window,bubbles:!0,cancelable:!0,clientX:o,clientY:n});return(r[0]||document.elementFromPoint(o,n))?.dispatchEvent(i),!0}catch(t){console.error("[CRM Extension] Error in Strategy 7:",t)}return console.error("[CRM Extension] No method found to remove automation:",e),!1}function Ge(){return new Promise(e=>{setTimeout(()=>{if(document.querySelectorAll('.modal, [role="dialog"], .dialog').length){let o=document.querySelectorAll('.modal .btn-primary, .modal .btn-danger, .modal .confirm-btn, [role="dialog"] .btn-primary, .modal button, [role="dialog"] button');for(let r of o){let i=(r.textContent||"").trim().toLowerCase();if(["delete","remove","yes","confirm","ok","continue"].includes(i)){r.click(),e(!0);return}}let n=document.querySelectorAll('.modal button, [role="dialog"] button, .dialog button');if(n.length){n[n.length-1].click(),e(!0);return}}e(!1)},500)})}function Ee(){return new Promise((e,t)=>{try{let i=function(a){if(a>=r){e({success:!0,message:`Removed ${n} of ${r} automations`,removed:n,total:r});return}let s=o[a],l=St(s.element);l instanceof Promise?l.then(d=>{d&&n++,Ge().then(()=>setTimeout(()=>i(a+1),1e3))}):(l&&n++,Ge().then(()=>setTimeout(()=>i(a+1),1e3)))},o=Ct();if(!o.length){console.log("[CRM Extension] No automations to remove."),e({success:!0,message:"No automations to remove",removed:0,total:0});return}let n=0,r=o.length;i(0)}catch(o){console.error("[CRM Extension] Error in removeAllAutomations:",o),t(o)}})}var w=[];var ge="crmplus_history";function Qe(){et(),Rt(),Mt(),window.addEventListener("storage",Nt),console.log("[CRM Extension] History tracking initialized")}function et(){try{let e=localStorage.getItem(ge);if(e){w=JSON.parse(e);let t=Date.now();w=w.filter(o=>t-o.timestamp<144e5),ve()}}catch(e){console.error("[CRM Extension] Error loading history:",e),w=[]}}function ve(){try{localStorage.setItem(ge,JSON.stringify(w))}catch(e){console.error("[CRM Extension] Error saving history:",e)}}function Nt(e){if(e.key===ge)try{e.newValue?(w=JSON.parse(e.newValue),console.log("[CRM Extension] History updated from another tab")):(w=[],console.log("[CRM Extension] History cleared from another tab"))}catch(t){console.error("[CRM Extension] Error processing cross-tab history update:",t)}}function Rt(){let e=window.location.href;setInterval(()=>{let n=window.location.href;n!==e&&(e=n,J(n))},500),J(window.location.href);let t=history.pushState;history.pushState=function(){t.apply(this,arguments),J(window.location.href)};let o=history.replaceState;history.replaceState=function(){o.apply(this,arguments),J(window.location.href)},window.addEventListener("popstate",()=>{J(window.location.href)})}function J(e){if(!e)return;let t=e.match(/\/detail\/([^/]+)/);if(t&&t[1]){let o=t[1];setTimeout(()=>{let n=Xe(),r=Ke();n&&n!=="Unknown Patient"?Ze(o,n,r,e):(console.log("[CRM Extension] Patient name not found yet, retrying in 3 seconds..."),setTimeout(()=>{let i=Xe(),a=Ke();i&&i!=="Unknown Patient"?Ze(o,i,a,e):console.log("[CRM Extension] Could not retrieve patient info after retry, not adding to history")},3e3))},5e3)}}function Xe(){let e=document.getElementById("name-text");if(e&&e.textContent&&e.textContent.trim()!=="")return e.textContent.trim();let t=document.querySelector('input[name="contact.first_name"]'),o=document.querySelector('input[name="contact.last_name"]');if(t&&t.value&&o&&o.value)return`${t.value} ${o.value}`.trim();let n=[".patient-name",".contact-name","h1.name",".customer-name","span.name",".profile-name","h2.name",".contact-header .name",'div[data-field="name"]',".patient-info .name"];for(let r of n){let i=document.querySelector(r);if(i&&i.textContent&&i.textContent.trim()!=="")return i.textContent.trim()}return"Unknown Patient"}function Ke(){let e=document.getElementById("phone-text");if(e&&e.textContent&&e.textContent.trim()!=="")return e.textContent.trim();let t=document.querySelector('input[name="contact.phone"]');if(t&&t.value.trim()!=="")return t.value.trim();let o=[".phone-number .number",'input[placeholder="Phone"]','input[placeholder="Phone Number"]',".patient-info .phone",".contact-info .phone","span.phone",'div[data-field="phone"]','span[data-field="phone_number"]'];for(let n of o){let r=document.querySelector(n);if(r)if(r.tagName==="INPUT"){let i=r.value.trim();if(i)return i}else{let i=r.textContent.trim();if(i)return i}}return""}function Ze(e,t,o,n){let i=Date.now(),a=w.findIndex(s=>s.patientId===e);if(a!==-1){let s=w[a];s.timestamp=i,s.patientName=t,s.phoneNumber=o,w.splice(a,1),w.unshift(s)}else w.unshift({patientId:e,patientName:t,phoneNumber:o,url:n,timestamp:i}),w.length>20&&w.pop();ve()}function Mt(){setInterval(()=>{let e=Date.now(),t=0;w=w.filter(o=>{let n=e-o.timestamp<144e5;return n||t++,n}),t>0&&(console.log(`[CRM Extension] Removed ${t} expired history entries`),ve())},5*60*1e3)}function tt(){et();let e=Date.now();return w=w.filter(t=>e-t.timestamp<144e5),[...w]}function ot(){w=[],localStorage.removeItem(ge),console.log("[CRM Extension] History cleared")}function nt(e){return new Date(e).toLocaleString("en-US",{hour:"numeric",minute:"2-digit",hour12:!0})}function X(e,t,o={}){let n=document.createElement("div");n.className="group";let r=document.createElement("span");r.className="label",r.textContent=`${t}:`,n.appendChild(r);let i=document.createElement("span");if(i.id=`${e}-display`,i.className="clickable-value",o.initialValue&&i.setAttribute("data-value",o.initialValue),o.icon){let l=document.createElement("span");l.className="btn-icon",l.innerHTML=o.icon,i.appendChild(l)}let a=document.createElement("span");a.textContent=o.initialValue||"",a.id=`${e}-text`,i.appendChild(a);let s=async()=>{let l=i.getAttribute("data-value")||a.textContent.trim();l&&l!==""?await W(l)?p(`Copied ${t}: ${l}`):p(`Failed to copy ${t.toLowerCase()}`):p(`No ${t.toLowerCase()} available to copy`)};return i.addEventListener("click",()=>{o.onClick?o.onClick(i):s()}),i.title=`Click to copy ${t.toLowerCase()} to clipboard`,n.appendChild(i),n}function rt(){let e=document.createElement("div");return e.className="group",e.id="crm-actions-group",e}function it(){let e=document.createElement("div");e.className="dropdown",e.id="crm-tags-dropdown";let t=document.createElement("button");t.className="dropdown-btn",t.textContent="Tags",t.addEventListener("click",c=>{c.stopPropagation(),document.querySelectorAll(".dropdown.show").forEach(Ae=>{Ae!==e&&Ae.classList.remove("show")}),e.classList.toggle("show")});let o=document.createElement("div");if(o.className="dropdown-content",o.style.padding="10px",!document.getElementById("tags-dropdown-styles")){let c=document.createElement("style");c.id="tags-dropdown-styles",c.textContent=`
      .nested-dropdown {
        margin-bottom: 8px;
        width: 100%;
        position: relative;
      }
      .nested-dropdown-btn {
        width: 100%;
        text-align: left;
        padding: 8px 12px;
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 3px;
        cursor: pointer;
        font-weight: bold;
        font-size: 13px;
        color: #e6e6e6;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .nested-dropdown-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      .nested-dropdown-btn:after {
        content: "\u25BC";
        font-size: 8px;
        color: #e6e6e6;
      }
      .nested-dropdown-content {
        display: none;
        padding: 5px 0 5px 10px;
        margin-top: 3px !important;
      }
      .nested-dropdown.open .nested-dropdown-content {
        display: block;
      }
      
      /* Button-style tag options */
      .tag-btn {
        display: block;
        width: 100%;
        padding: 8px 12px;
        margin-bottom: 8px;
        background-color: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 4px;
        text-align: left;
        font-size: 13px;
        color: #e6e6e6;
        cursor: pointer;
        transition: all 0.2s ease;
        font-weight: normal;
      }
      .tag-btn:hover {
        background-color: rgba(255, 255, 255, 0.15);
        border-color: rgba(255, 255, 255, 0.2);
      }
      .tag-btn:active {
        background-color: rgba(255, 255, 255, 0.2);
      }
    `,document.head.appendChild(c)}let n=document.createElement("button");n.className="tag-btn",n.textContent="Opt-in",n.addEventListener("click",()=>{at("opt-in"),e.classList.remove("show")}),o.appendChild(n);let r=document.createElement("button");r.className="tag-btn",r.textContent="Refill-Sema-Inj",r.addEventListener("click",()=>{b("refill-sema-inj"),e.classList.remove("show")}),o.appendChild(r);let i=document.createElement("button");i.className="tag-btn",i.textContent="Refill-Tirz-Inj",i.addEventListener("click",()=>{b("refill-tirz-inj"),e.classList.remove("show")}),o.appendChild(i);let a=document.createElement("div");a.className="nested-dropdown";let s=document.createElement("button");s.className="nested-dropdown-btn",s.textContent="Vial-Semaglutide";let l=document.createElement("div");l.className="nested-dropdown-content",s.addEventListener("click",c=>{c.stopPropagation(),a.classList.toggle("open")});let d=document.createElement("button");d.className="tag-btn",d.textContent="Vial-Sema-B12",d.addEventListener("click",c=>{c.stopPropagation(),x(),b("vial-sema-b12")}),l.appendChild(d);let g=document.createElement("button");g.className="tag-btn",g.textContent="Vial-Sema-B6",g.addEventListener("click",c=>{c.stopPropagation(),x(),b("vial-sema-b6")}),l.appendChild(g);let m=document.createElement("button");m.className="tag-btn",m.textContent="Vial-Sema-Lipo",m.addEventListener("click",c=>{c.stopPropagation(),x(),b("vial-sema-lipo")}),l.appendChild(m);let h=document.createElement("button");h.className="tag-btn",h.textContent="Vial-Sema-NAD+",h.addEventListener("click",c=>{c.stopPropagation(),x(),b("vial-sema-nad+")}),l.appendChild(h),a.appendChild(s),a.appendChild(l),o.appendChild(a);let f=document.createElement("div");f.className="nested-dropdown";let v=document.createElement("button");v.className="nested-dropdown-btn",v.textContent="Vial-Tirzepatide";let k=document.createElement("div");k.className="nested-dropdown-content",v.addEventListener("click",c=>{c.stopPropagation(),f.classList.toggle("open")});let R=document.createElement("button");R.className="tag-btn",R.textContent="Vial-Tirz-Cyano",R.addEventListener("click",c=>{c.stopPropagation(),x(),b("vial-tirz-cyano")}),k.appendChild(R);let M=document.createElement("button");M.className="tag-btn",M.textContent="Vial-Tirz-NAD+",M.addEventListener("click",c=>{c.stopPropagation(),x(),b("vial-tirz-nad+")}),k.appendChild(M);let u=document.createElement("button");u.className="tag-btn",u.textContent="Vial-Tirz-Pyr",u.addEventListener("click",c=>{c.stopPropagation(),x(),b("vial-tirz-pyridoxine")}),k.appendChild(u),f.appendChild(v),f.appendChild(k),o.appendChild(f);let E=document.createElement("div");E.className="nested-dropdown";let S=document.createElement("button");S.className="nested-dropdown-btn",S.textContent="NP-Semaglutide";let C=document.createElement("div");C.className="nested-dropdown-content",S.addEventListener("click",c=>{c.stopPropagation(),E.classList.toggle("open")});let T=document.createElement("button");T.className="tag-btn",T.textContent="NP-Sema 0.125",T.addEventListener("click",c=>{c.stopPropagation(),x(),b("np-sema-0.125ml-inj")}),C.appendChild(T);let V=document.createElement("button");V.className="tag-btn",V.textContent="NP-Sema 0.25",V.addEventListener("click",c=>{c.stopPropagation(),x(),b("np-sema-0.25ml-inj")}),C.appendChild(V);let D=document.createElement("button");D.className="tag-btn",D.textContent="NP-Sema 0.5",D.addEventListener("click",c=>{c.stopPropagation(),x(),b("np-sema-0.5ml-inj")}),C.appendChild(D);let F=document.createElement("button");F.className="tag-btn",F.textContent="NP-Sema 0.75",F.addEventListener("click",c=>{c.stopPropagation(),x(),b("np-sema-0.75ml-inj")}),C.appendChild(F);let U=document.createElement("button");U.className="tag-btn",U.textContent="NP-Sema 1.0",U.addEventListener("click",c=>{c.stopPropagation(),x(),b("np-sema-1.0ml-inj")}),C.appendChild(U);let y=document.createElement("button");y.className="tag-btn",y.textContent="NP-Sema 1.25",y.addEventListener("click",c=>{c.stopPropagation(),x(),b("np-sema-1.25ml-inj")}),C.appendChild(y);let I=document.createElement("button");I.className="tag-btn",I.textContent="NP-Sema 1.5",I.addEventListener("click",c=>{c.stopPropagation(),x(),b("np-sema-1.5ml-inj")}),C.appendChild(I);let $=document.createElement("button");$.className="tag-btn",$.textContent="NP-Sema 2.0",$.addEventListener("click",c=>{c.stopPropagation(),x(),b("np-sema-2.0ml-inj")}),C.appendChild($),E.appendChild(S),E.appendChild(C),o.appendChild(E);let H=document.createElement("div");H.className="nested-dropdown";let Q=document.createElement("button");Q.className="nested-dropdown-btn",Q.textContent="NP-Tirzepatide";let q=document.createElement("div");q.className="nested-dropdown-content",Q.addEventListener("click",c=>{c.stopPropagation(),H.classList.toggle("open")});let ee=document.createElement("button");ee.className="tag-btn",ee.textContent="NP-Tirz 0.25",ee.addEventListener("click",c=>{c.stopPropagation(),x(),b("np-tirz-0.25ml-inj")}),q.appendChild(ee);let te=document.createElement("button");te.className="tag-btn",te.textContent="NP-Tirz 0.5",te.addEventListener("click",c=>{c.stopPropagation(),x(),b("np-tirz-0.5ml-inj")}),q.appendChild(te);let oe=document.createElement("button");oe.className="tag-btn",oe.textContent="NP-Tirz 0.75",oe.addEventListener("click",c=>{c.stopPropagation(),x(),b("np-tirz-0.75ml-inj")}),q.appendChild(oe);let ne=document.createElement("button");ne.className="tag-btn",ne.textContent="NP-Tirz 1.0",ne.addEventListener("click",c=>{c.stopPropagation(),x(),b("np-tirz-1.0ml-inj")}),q.appendChild(ne);let re=document.createElement("button");re.className="tag-btn",re.textContent="NP-Tirz 1.25",re.addEventListener("click",c=>{c.stopPropagation(),x(),b("np-tirz-1.25ml-inj")}),q.appendChild(re);let ie=document.createElement("button");return ie.className="tag-btn",ie.textContent="NP-Tirz 1.5",ie.addEventListener("click",c=>{c.stopPropagation(),x(),b("np-tirz-1.5ml-inj")}),q.appendChild(ie),H.appendChild(Q),H.appendChild(q),o.appendChild(H),e.appendChild(t),e.appendChild(o),e}function x(){document.querySelectorAll(".dropdown.show").forEach(e=>e.classList.remove("show")),document.querySelectorAll(".nested-dropdown.open").forEach(e=>e.classList.remove("open"))}async function b(e){try{let[t,o]=await Promise.all([Ce(),Ee()]);console.log("[CRM Extension] Cleanup completed:"),console.log(`- Tags: ${t.removed}/${t.total} removed`),console.log(`- Automations: ${o.removed}/${o.total} removed`),at(e)}catch(t){console.error("[CRM Extension] Error during cleanup:",t),p("Error during cleanup. Please try again.")}}function at(e){let t=It();t?(t.focus(),setTimeout(()=>{t.value=e,t.dispatchEvent(new Event("input",{bubbles:!0})),setTimeout(()=>{let o=document.querySelectorAll(".v-list-item, .dropdown-item, .select-option, li"),n=!1;for(let r of o)if(r.textContent.toLowerCase().includes(e)){r.click(),n=!0,p(`Selected tag: ${e}`);break}if(!n){let r=document.querySelectorAll("*");for(let i of r)if(i.textContent.trim().toLowerCase()===e){i.click(),n=!0,p(`Selected tag: ${e}`);break}n||t.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",code:"Enter",keyCode:13,which:13,bubbles:!0}))}},300)},300)):p("Tags field not found")}function It(){let e=document.querySelector('input[placeholder="Add Tags"]');if(e)return e;let t=Array.from(document.querySelectorAll("input[placeholder]")).filter(i=>i.placeholder.toLowerCase().includes("tag"));if(t.length>0)return t[0];let o=document.querySelectorAll(".tag-input, .tags-input, .tag-container");for(let i of o){let a=i.querySelector("input");if(a)return a}if(e=document.querySelector('input[placeholder="smartList.bulkTags.addTags"]'),e)return e;let n=document.querySelectorAll(".hl-text-input");if(n.length>0)return n[0];console.error("[CRM Extension] Could not find tag input field with any strategy");let r=document.querySelectorAll("input");return console.log("[CRM Extension] All inputs on page:",r),null}var P={"Sema/B12 Refill - Step 2":"Refill - Semaglutide/B12 Injection Refill Order - (Step 2)","Sema/B12 Vial - Step 2":"Semaglutide/B12 Vial Order - (Step 2)","Sema/B6 Vial - Step 2":"Semaglutide/B6 Vial Order - (Step 2)","Sema/Lipo Vial - Step 2":"Semaglutide/Lipo Vial Order - (Step 2)","Sema/NAD+ Vial - Step 2":"Semaglutide/NAD+ Vial Order - (Step 2)","Tirz/B6 Refill - Step 2":"Syringe - Tirzepatide/Pyridoxine Injection Order - (Step 2)","Tirz/B12 Vial - Step 2":"Tirzepatide/Cyano Vial Order - (Step 2)","Tirz/NAD+ Vial - Step 2":"Tirzepatide/NAD+ Vial Order - (Step 2)","Tirz/B6 Vial - Step 2":"Tirzepatide/Pyridoxine Vial Order - (Step 2)"};function st(){let e=document.createElement("div");e.className="dropdown",e.id="crm-automation-dropdown";let t=document.createElement("button");t.className="dropdown-btn",t.textContent="Automation",t.addEventListener("click",u=>{u.stopPropagation(),document.querySelectorAll(".dropdown.show").forEach(E=>{E!==e&&E.classList.remove("show")}),e.classList.toggle("show")});let o=document.createElement("div");if(o.className="dropdown-content",o.style.padding="10px",!document.getElementById("automation-dropdown-styles")){let u=document.createElement("style");u.id="automation-dropdown-styles",u.textContent=`
      .nested-dropdown {
        margin-bottom: 8px;
        width: 100%;
        position: relative;
      }
      .nested-dropdown-btn {
        width: 100%;
        text-align: left;
        padding: 8px 12px;
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 3px;
        cursor: pointer;
        font-weight: bold;
        font-size: 13px;
        color: #e6e6e6;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .nested-dropdown-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      .nested-dropdown-btn:after {
        content: "\u25BC";
        font-size: 8px;
        color: #e6e6e6;
      }
      .nested-dropdown-content {
        display: none;
        padding: 5px 0 5px 10px;
        margin-top: 3px !important;
      }
      .nested-dropdown.open .nested-dropdown-content {
        display: block;
      }

      /* Button-style options */
      .automation-btn {
        display: block;
        width: 100%;
        padding: 8px 12px;
        margin-bottom: 8px;
        background-color: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 4px;
        text-align: left;
        font-size: 13px;
        color: #e6e6e6;
        cursor: pointer;
        transition: all 0.2s ease;
        font-weight: normal;
      }
      .automation-btn:hover {
        background-color: rgba(255, 255, 255, 0.15);
        border-color: rgba(255, 255, 255, 0.2);
      }
      .automation-btn:active {
        background-color: rgba(255, 255, 255, 0.2);
      }
    `,document.head.appendChild(u)}let n=document.createElement("div");n.className="nested-dropdown";let r=document.createElement("button");r.className="nested-dropdown-btn",r.textContent="Semaglutide (Step 2)";let i=document.createElement("div");i.className="nested-dropdown-content",r.addEventListener("click",u=>{u.stopPropagation(),n.classList.toggle("open")});let a=document.createElement("button");a.className="automation-btn",a.textContent="Sema/B12 Refill - Step 2",a.addEventListener("click",u=>{u.stopPropagation(),z(),setTimeout(()=>{B(P["Sema/B12 Refill - Step 2"])},300)}),i.appendChild(a);let s=document.createElement("button");s.className="automation-btn",s.textContent="Sema/B12 Vial - Step 2",s.addEventListener("click",u=>{u.stopPropagation(),z(),setTimeout(()=>{B(P["Sema/B12 Vial - Step 2"])},300)}),i.appendChild(s);let l=document.createElement("button");l.className="automation-btn",l.textContent="Sema/B6 Vial - Step 2",l.addEventListener("click",u=>{u.stopPropagation(),z(),setTimeout(()=>{B(P["Sema/B6 Vial - Step 2"])},300)}),i.appendChild(l);let d=document.createElement("button");d.className="automation-btn",d.textContent="Sema/Lipo Vial - Step 2",d.addEventListener("click",u=>{u.stopPropagation(),z(),setTimeout(()=>{B(P["Sema/Lipo Vial - Step 2"])},300)}),i.appendChild(d);let g=document.createElement("button");g.className="automation-btn",g.textContent="Sema/NAD+ Vial - Step 2",g.addEventListener("click",u=>{u.stopPropagation(),z(),setTimeout(()=>{B(P["Sema/NAD+ Vial - Step 2"])},300)}),i.appendChild(g),n.appendChild(r),n.appendChild(i),o.appendChild(n);let m=document.createElement("div");m.className="nested-dropdown";let h=document.createElement("button");h.className="nested-dropdown-btn",h.textContent="Tirzepatide (Step 2)";let f=document.createElement("div");f.className="nested-dropdown-content",h.addEventListener("click",u=>{u.stopPropagation(),m.classList.toggle("open")});let v=document.createElement("button");v.className="automation-btn",v.textContent="Tirz/B6 Refill - Step 2",v.addEventListener("click",u=>{u.stopPropagation(),z(),setTimeout(()=>{B(P["Tirz/B6 Refill - Step 2"])},300)}),f.appendChild(v);let k=document.createElement("button");k.className="automation-btn",k.textContent="Tirz/B12 Vial - Step 2",k.addEventListener("click",u=>{u.stopPropagation(),z(),setTimeout(()=>{B(P["Tirz/B12 Vial - Step 2"])},300)}),f.appendChild(k);let R=document.createElement("button");R.className="automation-btn",R.textContent="Tirz/NAD+ Vial - Step 2",R.addEventListener("click",u=>{u.stopPropagation(),z(),setTimeout(()=>{B(P["Tirz/NAD+ Vial - Step 2"])},300)}),f.appendChild(R);let M=document.createElement("button");return M.className="automation-btn",M.textContent="Tirz/B6 Vial - Step 2",M.addEventListener("click",u=>{u.stopPropagation(),z(),setTimeout(()=>{B(P["Tirz/B6 Vial - Step 2"])},300)}),f.appendChild(M),m.appendChild(h),m.appendChild(f),o.appendChild(m),e.appendChild(t),e.appendChild(o),e}function z(){document.querySelectorAll(".dropdown.show").forEach(e=>e.classList.remove("show")),document.querySelectorAll(".nested-dropdown.open").forEach(e=>e.classList.remove("open"))}function B(e){try{console.log(`[CRM Extension] Starting workflow for "${e}"`),p(`Starting workflow for "${e}"`);let t=Array.from(document.querySelectorAll("button.btn.btn-light2.btn-xs")).find(o=>o.textContent.trim().includes("Add"));if(!t){console.error("[CRM Extension] Add Automation button not found"),p("Add Automation button not found");return}console.log("[CRM Extension] Found Add button, clicking it"),t.click(),setTimeout(()=>{let o=document.querySelector('input[placeholder="Type to search"]');if(!o){console.error("[CRM Extension] Search input not found"),p("Search input not found");return}console.log("[CRM Extension] Found search input, entering 'step 2'"),o.focus(),o.value="step 2",o.dispatchEvent(new Event("input",{bubbles:!0})),setTimeout(()=>{let n=[".v-list",".dropdown-menu",".v-select-list",".vs__dropdown-menu",'[role="listbox"]',"ul",".v-menu__content"],r=null;for(let d of n){let g=document.querySelector(d);for(let m=0;m<=10;m++){if(g&&g.querySelector("li, .v-list-item, .dropdown-item")&&g.scrollHeight>g.clientHeight){r=g,console.log(`[CRM Extension] Found scrollable dropdown container: ${d}`);break}wait(500)}}if(!r){let d=document.querySelector('.modal, dialog, [role="dialog"]');if(d){let g=Array.from(d.querySelectorAll("*")).filter(m=>m.scrollHeight>m.clientHeight&&m.clientHeight>50);g.length>0&&(r=g[0],console.log("[CRM Extension] Found scrollable element via fallback method"))}}if(!r){console.error("[CRM Extension] Could not find scrollable container"),p("Could not find dropdown container");return}console.log("[CRM Extension] Starting scroll wheel simulation"),console.log(`[CRM Extension] Container dimensions: ${r.scrollHeight}x${r.clientHeight}`);let i=0,a=20,s=!1;function l(){if(s||i>=a){s||(console.error("[CRM Extension] Max scroll attempts reached without finding match"),p("Option not found after scrolling"));return}i++,console.log(`[CRM Extension] Scroll attempt ${i}/${a}`);let d=new WheelEvent("wheel",{deltaY:100,bubbles:!0});r.dispatchEvent(d),r.scrollTop+=100,console.log(`[CRM Extension] Scrolled to position: ${r.scrollTop}/${r.scrollHeight}`),setTimeout(()=>{let g=r.querySelectorAll('li, .v-list-item, .dropdown-item, [role="option"]');console.log(`[CRM Extension] Found ${g.length} options after scrolling`);for(let m of g){if(!m.textContent)continue;let h=m.textContent.trim();if(h===e&&!h.includes("Provider Paid")&&!h.includes("New Patient")){console.log(`[CRM Extension] Found exact matching option: "${h}"`);try{m.scrollIntoView({block:"center"}),setTimeout(()=>{m.click(),s=!0,setTimeout(()=>{let f=Array.from(document.querySelectorAll("button")).find(v=>v.textContent.trim()==="Add");f?(console.log("[CRM Extension] Clicking Add button in dialog"),f.click(),p(`Added "${e}" workflow`)):(console.error("[CRM Extension] Add button in dialog not found"),p("Add button in dialog not found"))},1e3)},300)}catch(f){console.error("[CRM Extension] Error clicking option:",f)}break}}if(!s){if(r.scrollHeight-r.scrollTop<=r.clientHeight+20){console.log("[CRM Extension] Reached bottom of dropdown without finding match"),p(`Reached end without finding "${e}"`);return}setTimeout(l,500)}},500)}l()},1500)},1e3)}catch(t){console.error("[CRM Extension] Error in workflow:",t),p(`Error in workflow: ${t.message}`)}}function lt(){let e=document.createElement("div");return e.className="group",e.id="crm-dropdowns-group",e.appendChild(st()),e.appendChild(it()),document.addEventListener("click",t=>{document.querySelectorAll(".dropdown").forEach(n=>{n.contains(t.target)||(n.classList.remove("show"),n.querySelectorAll(".nested-dropdown").forEach(i=>{i.classList.remove("open")}))})}),At(),e}function At(){if(document.getElementById("custom-dropdown-styles"))return;let e=document.createElement("style");e.id="custom-dropdown-styles",e.textContent=`
    /* Improved dropdown positioning */
    .dropdown {
      position: relative !important;
      margin-right: 8px !important; /* Ensure space between dropdowns, reduced for tighter layout */
    }
    
    .dropdown:last-child {
      margin-right: 0 !important; /* Remove margin from the last dropdown */
    }
    
    .dropdown-content {
      position: absolute !important;
      background-color: #2F3A4B; /* Match toolbar background color */
      min-width: 220px !important; /* Increased width */
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.3);
      z-index: 999;
      border-radius: 4px;
      margin-top: 5px !important; /* Add space between button and dropdown */
      left: 0;
      top: 100% !important; /* Position below the button */
      display: none;
      border: 1px solid rgba(255, 255, 255, 0.1); /* Subtle border */
    }
    
    /* Ensure right-aligned dropdowns don't overflow */
    #crm-tags-dropdown .dropdown-content {
      right: 0;
      left: auto; /* Override left positioning for Tags dropdown */
    }
    
    .dropdown.show .dropdown-content {
      display: block;
    }
    
    /* Improved nested dropdown positioning */
    .nested-dropdown-content {
      margin-top: 3px !important;
      background-color: #2F3A4B; /* Match toolbar background color */
      border-radius: 4px;
      padding: 5px !important;
    }
    
    /* Style dropdown items */
    .dropdown-item {
      color: #e6e6e6; /* White text for visibility */
      padding: 10px 14px !important; /* Increased padding */
      text-decoration: none;
      display: block;
      font-size: 14px;
      cursor: pointer;
      border-radius: 3px;
      font-weight: normal;
    }
    
    .dropdown-item:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
    
    /* Fix for Vial-Sema and Vial-Tirz nested dropdowns */
    .nested-dropdown-btn {
      text-align: left !important;
      padding: 8px 12px !important;
      background-color: rgba(255, 255, 255, 0.1) !important;
      border: 1px solid rgba(255, 255, 255, 0.15) !important;
      color: #e6e6e6 !important;
      font-weight: bold !important;
    }
    
    .nested-dropdown-btn:hover {
      background-color: rgba(255, 255, 255, 0.2) !important;
    }
    
    /* Force visibility for Tags dropdown */
    #crm-tags-dropdown {
      display: flex !important;
    }
    
    #crm-tags-dropdown .dropdown-content {
      min-width: 220px !important;
    }
  `,document.head.appendChild(e)}function ct(){let e=document.createElement("div");e.className="group",e.id="crm-settings-group",e.style.position="relative";let t=document.createElement("button");t.className="btn",t.id="crm-settings-btn";let o=document.createElement("span");o.className="btn-icon",o.innerHTML="\u2699\uFE0F",t.appendChild(o);let n=document.createElement("span");n.textContent="Settings",t.appendChild(n);let r=Tt();if(t.addEventListener("click",i=>{i.stopPropagation(),r.classList.toggle("show")}),document.addEventListener("click",i=>{i.target!==t&&!t.contains(i.target)&&i.target!==r&&!r.contains(i.target)&&r.classList.remove("show")}),!document.getElementById("settings-dropdown-styles")){let i=document.createElement("style");i.id="settings-dropdown-styles",i.textContent=`
      #mcp-crm-settings-dropdown {
        display: none;
        position: absolute;
        top: calc(100% + 5px); /* Position below the button with 5px gap */
        right: 0;
        z-index: 1000;
        min-width: 230px;
        background-color: #2F3A4B;
        border-radius: 4px;
        border: 1px solid rgba(255, 255, 255, 0.1);
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
        overflow: hidden;
      }
      
      #mcp-crm-settings-dropdown.show {
        display: block;
      }
      
      .settings-header {
        padding: 10px;
        background-color: rgba(255, 255, 255, 0.1);
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        font-weight: bold;
        color: #e6e6e6;
      }
      
      .settings-body {
        padding: 10px;
        color: #e6e6e6;
      }
      
      .setting-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
        font-size: 13px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        padding-bottom: 10px;
      }
      
      .setting-item:last-child {
        margin-bottom: 0;
        border-bottom: none;
        padding-bottom: 0;
      }
      
      .setting-label {
        color: #e6e6e6;
        font-weight: normal;
      }
      
      /* Toggle switch styles */
      .switch {
        position: relative;
        display: inline-block;
        width: 40px;
        height: 20px;
      }
      
      .switch input {
        opacity: 0;
        width: 0;
        height: 0;
      }
      
      .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #555;
        transition: .4s;
        border-radius: 34px;
      }
      
      .slider:before {
        position: absolute;
        content: "";
        height: 16px;
        width: 16px;
        left: 2px;
        bottom: 2px;
        background-color: white;
        transition: .4s;
        border-radius: 50%;
      }
      
      input:checked + .slider {
        background-color: #2196F3;
      }
      
      input:focus + .slider {
        box-shadow: 0 0 1px #2196F3;
      }
      
      input:checked + .slider:before {
        transform: translateX(20px);
      }
      
      /* Version info styles */
      .version-info {
        border-top: 1px solid rgba(255, 255, 255, 0.1);
        margin-top: 10px;
        padding-top: 10px;
        font-size: 12px;
        color: #e6e6e6;
      }
      
      .version-info p {
        margin: 5px 0;
        color: #e6e6e6;
      }
      
      .version-number {
        font-weight: 600;
        color: #e6e6e6;
      }
      
      .check-updates-btn {
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 3px;
        padding: 4px 8px;
        margin-top: 5px;
        font-size: 11px;
        cursor: pointer;
        transition: background-color 0.2s;
        width: 100%;
        text-align: center;
        color: #e6e6e6;
      }
      
      .check-updates-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      
      .check-updates-btn:disabled {
        opacity: 0.6;
        cursor: not-allowed;
      }
      
      #crm-update-status {
        margin: 5px 0 0 0;
        padding: 3px 6px;
        font-size: 11px;
        border-radius: 3px;
        background-color: rgba(255, 255, 255, 0.05);
        text-align: center;
        transition: all 0.3s ease;
        color: #e6e6e6;
      }
      
      #last-update-check {
        font-size: 11px;
        margin: 5px 0;
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        color: #e6e6e6;
      }
      
      .check-status {
        font-size: 10px;
        margin-left: 5px;
        padding: 1px 4px;
        border-radius: 3px;
        font-weight: normal;
      }
      
      .loading-text {
        font-style: italic;
        color: #aaa;
      }
      
      /* Section styles */
      .setting-section {
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      }
      
      .setting-section-title {
        font-size: 12px;
        font-weight: bold;
        color: #e6e6e6;
        margin-bottom: 10px;
      }
    `,document.head.appendChild(i)}return e.appendChild(t),e.appendChild(r),e}function Lt(e){try{(typeof browser<"u"?browser:chrome).runtime.sendMessage({action:"getLastUpdateCheck"}).then(o=>{if(o&&o.success&&o.lastUpdateCheck){let n=o.lastUpdateCheck,r="",i="";n.success?n.status==="update_available"?(r="Update available",i="#4CAF50"):n.status==="no_update"?(r="No updates needed",i="#2196F3"):n.status==="throttled"?(r="Check throttled",i="#FF9800"):(r="Completed",i="#2196F3"):(r="Failed",i="#F44336"),e.innerHTML=`Last Check: <span class="version-number">${n.formattedTime}</span> <span class="check-status" style="color:${i};font-size:10px;margin-left:5px;">${r}</span>`}else e.innerHTML='Last Check: <span class="version-number">No checks recorded</span>'}).catch(o=>{console.error("[CRM Extension] Error fetching last update check:",o),e.innerHTML='Last Check: <span class="version-number">Unknown</span>'})}catch(t){console.error("[CRM Extension] Error in fetchLastUpdateCheckInfo:",t),e.innerHTML='Last Check: <span class="version-number">Error</span>'}}function Tt(){let e=document.createElement("div");e.id="mcp-crm-settings-dropdown";let t=document.createElement("div");t.className="settings-header",t.textContent="CRM+ Settings",e.appendChild(t);let o=document.createElement("div");if(o.className="settings-body",e.appendChild(o),!document.getElementById("collapsible-settings-styles")){let s=document.createElement("style");s.id="collapsible-settings-styles",s.textContent=`
      .setting-section {
        margin-bottom: 8px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        padding-bottom: 0; /* No bottom padding when collapsed */
      }
      
      .setting-section-title {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 13px;
        font-weight: bold;
        color: #e6e6e6;
        padding: 8px 0;
        cursor: pointer;
        user-select: none;
      }
      
      .setting-section-title:after {
        content: "\u25BC";
        font-size: 8px;
        color: #e6e6e6;
        transition: transform 0.2s ease;
      }
      
      .setting-section.collapsed .setting-section-title:after {
        transform: rotate(-90deg);
      }
      
      .setting-section-content {
        max-height: 500px;
        overflow: hidden;
        transition: max-height 0.3s ease, opacity 0.2s ease, margin-bottom 0.3s ease;
        opacity: 1;
        margin-bottom: 10px;
      }
      
      .setting-section.collapsed .setting-section-content {
        max-height: 0;
        opacity: 0;
        margin-bottom: 0;
      }
    `,document.head.appendChild(s)}let n=ke("General Settings");n.content.appendChild(O("Show Header Bar","crmplus_headerBarVisible",s=>{let l=document.getElementById("mcp-crm-header");l&&(l.style.display=s?"flex":"none",document.body.style.paddingTop=s?"32px":"0"),p(`Header bar: ${s?"Visible":"Hidden"}`)},!0)),n.content.appendChild(O("Show Provider-Paid Alerts","crmplus_showProviderPaidAlerts",s=>{p(`Provider-Paid alerts: ${s?"Enabled":"Disabled"}`)},!0)),o.appendChild(n.section);let r=ke("External Links");r.content.appendChild(O("Show ShipStation Link","crmplus_showShipStation",s=>{let l=document.querySelector(".shipstation-link");l&&(l.style.display=s?"flex":"none"),p(`ShipStation link: ${s?"Visible":"Hidden"}`)},!0)),r.content.appendChild(O("Show Stripe Link","crmplus_showStripe",s=>{let l=document.querySelector(".stripe-link");l&&(l.style.display=s?"flex":"none"),p(`Stripe link: ${s?"Visible":"Hidden"}`)},!0)),r.content.appendChild(O("Show Webmail Link","crmplus_showWebmail",s=>{let l=document.querySelector(".webmail-link");l&&(l.style.display=s?"flex":"none"),p(`Webmail link: ${s?"Visible":"Hidden"}`)},!0)),o.appendChild(r.section);let i=ke("Features");i.content.appendChild(O("Auto-copy phone number on page load","crmplus_autoCopyPhone",s=>{p(`Auto-copy phone: ${s?"Enabled":"Disabled"}`)},!1)),i.content.appendChild(O("CRM Automation","crmplus_automationEnabled",s=>{[document.getElementById("crm-automation-dropdown"),document.getElementById("crm-tags-dropdown")].forEach(d=>{d?(d.style.display=s?"flex":"none",console.log(`[CRM Extension] Changed visibility for ${d.id}: ${s?"visible":"hidden"}`)):console.error("[CRM Extension] Could not find automation element to toggle")}),p(`CRM Automation: ${s?"Enabled":"Disabled"}`)},!0)),o.appendChild(i.section);let a=Pt();return o.appendChild(a),e}function ke(e,t=!1){let o=document.createElement("div");o.className="setting-section"+(t?" collapsed":"");let n=document.createElement("div");n.className="setting-section-title",n.textContent=e,n.addEventListener("click",()=>{o.classList.toggle("collapsed")}),o.appendChild(n);let r=document.createElement("div");return r.className="setting-section-content",o.appendChild(r),{section:o,content:r}}function Pt(){let e=document.createElement("div");e.className="version-info";let t="Loading...",o="Loading...";try{let l=(typeof browser<"u"?browser:chrome).runtime.getManifest();if(l&&l.version&&(t=l.version,t.includes("."))){let d=t.split(".");if(d.length===3&&d[0].length===4){let g=d[0],m=d[1],h=d[2];o=`${m}/${h}/${g}`}}}catch(s){console.error("[CRM Extension] Error fetching version:",s),t="Unknown",o="Unknown"}let n=document.createElement("p");n.innerHTML=`Version: <span class="version-number">${t}</span>`,e.appendChild(n);let r=document.createElement("p");r.innerHTML=`Last Updated: <span class="version-number">${o}</span>`,e.appendChild(r);let i=document.createElement("p");i.id="last-update-check",i.innerHTML='Last Check: <span class="loading-text">Loading...</span>',e.appendChild(i),Lt(i);let a=document.createElement("button");return a.className="check-updates-btn",a.textContent="Check for Updates",a.addEventListener("click",()=>{let s=typeof browser<"u"?browser:chrome;a.disabled=!0,a.textContent="Checking...",p("Checking for updates...");let l=document.getElementById("crm-update-status");l||(l=document.createElement("p"),l.id="crm-update-status",l.style.fontSize="11px",l.style.marginTop="5px",l.style.color="#e6e6e6",l.textContent="",e.appendChild(l)),s.runtime.sendMessage({action:"checkForUpdates"}).then(d=>{if(d&&d.success){p("Update check completed"),d.updateStatus==="update_available"?(l.textContent=`Update available (${d.updateVersion})`,l.style.color="#4CAF50"):d.updateStatus==="no_update"?(l.textContent="You have the latest version",l.style.color="#2196F3"):d.updateStatus==="throttled"?(l.textContent="Update check throttled, try again later",l.style.color="#FF9800"):d.updateStatus==="error"?(l.textContent="Error checking for updates",l.style.color="#F44336"):(l.textContent="Update check initiated",l.style.color="#e6e6e6");let g=document.getElementById("last-update-check");if(g&&d.lastCheck){let m=d.lastCheck,h="",f="";m.success?m.status==="update_available"?(h="Update available",f="#4CAF50"):m.status==="no_update"?(h="No updates needed",f="#2196F3"):m.status==="throttled"?(h="Check throttled",f="#FF9800"):(h="Completed",f="#2196F3"):(h="Failed",f="#F44336"),g.innerHTML=`Last Check: <span class="version-number">${m.formattedTime}</span> <span class="check-status" style="color:${f};font-size:10px;margin-left:5px;">${h}</span>`}}else p("Error checking for updates"),l.textContent="Update check failed",l.style.color="#F44336";a.disabled=!1,a.textContent="Check for Updates"}).catch(d=>{console.error("[CRM Extension] Error sending update check message:",d),p("Error checking for updates"),l.textContent="Connection failed",l.style.color="#F44336",a.disabled=!1,a.textContent="Check for Updates"})}),e.appendChild(a),e}function O(e,t,o,n=!1){let r=document.createElement("div");r.className="setting-item";let i=document.createElement("div");i.className="setting-label",i.textContent=e,r.appendChild(i);let a=document.createElement("label");a.className="switch";let s=document.createElement("input");s.type="checkbox";let l=localStorage.getItem(t),d=l!==null?l==="true":n;l===null&&localStorage.setItem(t,n.toString()),s.checked=d,s.addEventListener("change",()=>{let m=s.checked;localStorage.setItem(t,m.toString()),o&&typeof o=="function"&&o(m)});let g=document.createElement("span");return g.className="slider",a.appendChild(s),a.appendChild(g),r.appendChild(a),r}function dt(){if(document.getElementById("mcp-crm-header-styles"))return;let e=document.createElement("style");e.id="mcp-crm-header-styles",e.textContent=`
    #mcp-crm-header {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 32px;
      background-color: #2F3A4B;
      display: flex;
      align-items: center;
      padding: 0 15px;
      font-family: 'Segoe UI', 'Roboto', sans-serif;
      font-size: 12px;
      z-index: 999999;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    }
    
    #mcp-crm-header .group {
      display: flex;
      align-items: center;
      margin-right: 15px;
      border-right: 1px solid rgba(255, 255, 255, 0.1);
      padding-right: 15px;
    }
    
    #mcp-crm-header .group:last-child {
      border-right: none;
      margin-right: 0; /* Remove margin from the last group (Settings) */
    }
    
    /* Special styling for dropdowns group to match other elements' spacing */
    #crm-dropdowns-group {
      margin-right: 15px; /* Same spacing as other elements */
      padding-right: 15px; /* Same padding as other elements */
    }
    
    /* Ensure settings is positioned at the far right */
    #crm-settings-btn {
      margin-right: 0;
    }
    
    #mcp-crm-header .spacer {
      flex-grow: 1;
    }
    
    #mcp-crm-header .label {
      color: #8a9cad;
      margin-right: 6px;
      font-weight: 500;
    }
    
    #mcp-crm-header .value {
      color: #e6e6e6;
      font-weight: 600;
    }
    
    #mcp-crm-header .clickable-value {
      color: #e6e6e6;
      font-weight: 600;
      cursor: pointer;
      background-color: rgba(255, 255, 255, 0.05);
      padding: 2px 8px;
      border-radius: 3px;
      transition: background-color 0.2s;
      display: inline-flex;
      align-items: center;
    }
    
    #mcp-crm-header .clickable-value:hover {
      background-color: rgba(255, 255, 255, 0.15);
    }
    
    #mcp-crm-header .btn-icon {
      margin-right: 4px;
      font-size: 10px;
    }
    
    /* Logo link styling */
    #mcp-crm-header .logo-link {
      display: flex;
      align-items: center;
      text-decoration: none;
      transition: all 0.2s ease;
    }
    
    #mcp-crm-header .logo-link:hover {
      opacity: 0.85;
    }
    
    #mcp-crm-header .logo-icon {
      width: 16px;
      height: 16px;
      margin-right: 6px;
    }
    
    #mcp-crm-header .logo {
      font-weight: bold;
      color: white;
      font-size: 14px;
    }
    
    #mcp-crm-header .external-link {
      text-decoration: none;
      color: #e6e6e6;
      display: flex;
      align-items: center;
      transition: all 0.2s ease;
      margin-right: 10px;
    }
    
    #mcp-crm-header .external-link:hover {
      background: rgba(255, 255, 255, 0.2);
      transform: translateY(-1px);
    }
    
    #mcp-crm-header .ext-link-icon {
      font-size: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    /* Styling for text links with icons */
    #mcp-crm-header .text-link {
      text-decoration: none;
      margin-right: 4px; /* Reduced margin between buttons */
      font-size: 12px;
      padding: 3px 6px; /* Reduced horizontal padding to make buttons skinnier */
      border-radius: 3px;
      color: #e6e6e6;
      display: flex;
      align-items: center;
      justify-content: center; /* Center content horizontally */
      white-space: nowrap; /* Prevent text wrapping */
      min-width: 68px; /* Set minimum width to keep consistency */
    }
    
    #mcp-crm-header .text-link:hover {
      background-color: rgba(255, 255, 255, 0.15);
    }
    
    #mcp-crm-header .text-link .link-icon {
      margin-right: 4px; /* Slightly reduced margin for tighter look */
      width: 16px;
      height: 16px;
      vertical-align: middle;
      flex-shrink: 0; /* Prevent icon from shrinking */
    }
    
    /* Add a specific class for each button to fine-tune widths if needed */
    #mcp-crm-header .shipstation-link {
      min-width: 92px;
    }
    
    #mcp-crm-header .stripe-link {
      min-width: 65px;
    }
    
    #mcp-crm-header .webmail-link {
      min-width: 78px;
    }
    
    #mcp-crm-header .btn {
      color: #e6e6e6;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 3px;
      padding: 4px 8px;
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      margin-right: 8px;
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
    }
    
    #mcp-crm-header .btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    #mcp-crm-header .btn:active {
      background-color: rgba(255, 255, 255, 0.3);
    }
    
    #mcp-crm-header .btn:last-child {
      margin-right: 0;
    }
    
    /* Dropdown styling */
    .dropdown {
      position: relative;
      display: inline-block;
      margin-right: 8px;
    }
    
    .dropdown-btn {
      color: #e6e6e6;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 3px;
      padding: 4px 8px;
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
      justify-content: space-between;
      min-width: 100px;
    }
    
    .dropdown-btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .dropdown-btn:after {
      content: "\u25BC";
      font-size: 8px;
      margin-left: 5px;
    }
    
    .dropdown-content {
      display: none;
      position: absolute;
      background-color: #2F3A4B;
      min-width: 180px;
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.3);
      z-index: 1000000;
      border-radius: 4px;
      border: 1px solid rgba(255, 255, 255, 0.1);
      margin-top: 2px;
      left: 0;
    }
    
    .dropdown.show .dropdown-content {
      display: block;
    }
    
    .dropdown-item {
      color: #e6e6e6;
      padding: 8px 12px;
      text-decoration: none;
      display: block;
      font-size: 12px;
      cursor: pointer;
      font-weight: normal;
    }
    
    .dropdown-item:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
    
    /* Nested Dropdown styling */
    .nested-dropdown {
      margin-bottom: 5px;
      width: 100%;
    }
    
    .nested-dropdown-btn {
      width: 100%;
      text-align: left;
      padding: 6px 10px;
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 3px;
      cursor: pointer;
      font-weight: bold;
      font-size: 12px;
      color: #e6e6e6;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .nested-dropdown-btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .nested-dropdown-btn:after {
      content: "\u25BC";
      font-size: 8px;
      color: #e6e6e6;
    }
    
    .nested-dropdown-content {
      display: none;
      padding: 5px 0 5px 10px;
      background-color: #2F3A4B;
    }
    
    .nested-dropdown.open .nested-dropdown-content {
      display: block;
    }
    
    .nested-dropdown-item {
      display: block;
      padding: 5px 10px;
      color: #e6e6e6;
      text-decoration: none;
      font-size: 12px;
      cursor: pointer;
      border-radius: 3px;
      font-weight: normal;
    }
    
    .nested-dropdown-item:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
    
    /* Settings dropdown styling */
    #mcp-crm-settings-dropdown {
      position: absolute;
      top: 32px;
      right: 15px;
      background-color: #2F3A4B;
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 4px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.3);
      min-width: 200px;
      z-index: 1000000;
      display: none;
      color: #e6e6e6;
    }
    
    #mcp-crm-settings-dropdown.show {
      display: block;
    }
    
    #mcp-crm-settings-dropdown .settings-header {
      background-color: rgba(255, 255, 255, 0.1);
      color: #e6e6e6;
      padding: 8px 12px;
      font-weight: bold;
      border-top-left-radius: 3px;
      border-top-right-radius: 3px;
    }
    
    #mcp-crm-settings-dropdown .settings-body {
      padding: 10px;
    }
    
    #mcp-crm-settings-dropdown .setting-item {
      display: flex;
      align-items: center;
      margin-bottom: 8px;
      padding-bottom: 8px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    #mcp-crm-settings-dropdown .setting-item:last-child {
      margin-bottom: 0;
      padding-bottom: 0;
      border-bottom: none;
    }
    
    #mcp-crm-settings-dropdown .setting-label {
      flex-grow: 1;
      font-size: 13px;
      color: #e6e6e6;
    }
    
    /* Toggle switch styling */
    .switch {
      position: relative;
      display: inline-block;
      width: 40px;
      height: 20px;
    }
    
    .switch input { 
      opacity: 0;
      width: 0;
      height: 0;
    }
    
    .slider {
      position: absolute;
      cursor: pointer;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: #555;
      transition: .4s;
      border-radius: 34px;
    }
    
    .slider:before {
      position: absolute;
      content: "";
      height: 16px;
      width: 16px;
      left: 2px;
      bottom: 2px;
      background-color: white;
      transition: .4s;
      border-radius: 50%;
    }
    
    input:checked + .slider {
      background-color: #2196F3;
    }
    
    input:checked + .slider:before {
      transform: translateX(20px);
    }
    
    /* Version info section in settings */
    .version-info {
      border-top: 1px solid rgba(255, 255, 255, 0.1);
      margin-top: 10px;
      padding-top: 10px;
      font-size: 12px;
      color: #e6e6e6;
    }
    
    .version-info p {
      margin: 5px 0;
    }
    
    .version-number {
      font-weight: 600;
      color: #e6e6e6;
    }
    
    .check-updates-btn {
      background-color: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 3px;
      padding: 4px 8px;
      margin-top: 5px;
      font-size: 11px;
      cursor: pointer;
      transition: background-color 0.2s;
      width: 100%;
      text-align: center;
      color: #e6e6e6;
    }
    
    .check-updates-btn:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    
    .check-updates-btn:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
  `,document.head.appendChild(e)}function mt(){let e=document.createElement("div");e.className="dropdown",e.id="crm-history-dropdown";let t=document.createElement("button");t.className="dropdown-btn",t.textContent="History",t.addEventListener("click",s=>{s.stopPropagation(),document.querySelectorAll(".dropdown.show").forEach(l=>{l!==e&&l.classList.remove("show")}),e.classList.toggle("show"),e.classList.contains("show")&&pt(e)});let o=document.createElement("div");if(o.className="dropdown-content",o.id="crm-history-content",o.style.width="300px",o.style.maxHeight="400px",o.style.overflowY="auto",o.style.right="0",o.style.left="auto",!document.getElementById("history-dropdown-styles")){let s=document.createElement("style");s.id="history-dropdown-styles",s.textContent=`
      #crm-history-dropdown .dropdown-content {
        padding: 0;
        right: 0;
        left: auto;
      }
      
      /* For small screens, make sure the dropdown doesn't extend beyond viewport */
      @media screen and (max-width: 768px) {
        #crm-history-dropdown .dropdown-content {
          right: 0;
          left: auto;
          max-width: 100vw;
          width: 280px; /* Slightly smaller on small screens */
        }
      }
      
      .history-header {
        padding: 10px;
        background-color: rgba(255, 255, 255, 0.1);
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      
      .history-title {
        font-weight: bold;
        color: #e6e6e6;
        font-size: 14px;
      }
      
      .history-clear-btn {
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 3px;
        padding: 2px 6px;
        font-size: 11px;
        cursor: pointer;
        color: #e6e6e6;
        transition: background-color 0.2s;
      }
      
      .history-clear-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
      }
      
      .history-empty {
        padding: 20px;
        text-align: center;
        color: #aaa;
        font-style: italic;
        font-size: 13px;
      }
      
      .history-item {
        padding: 10px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        cursor: pointer;
        transition: background-color 0.2s;
      }
      
      .history-item:hover {
        background-color: rgba(255, 255, 255, 0.1);
      }
      
      .history-item:last-child {
        border-bottom: none;
      }
      
      .history-item-row {
        display: flex;
        margin-bottom: 3px;
        width: 100%;
      }
      
      .history-item-time {
        color: #aaa;
        font-size: 11px;
        width: 60px;
        flex-shrink: 0;
        margin-right: 5px;
      }
      
      .history-item-name {
        font-weight: bold;
        color: #e6e6e6;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        flex-grow: 1;
      }
      
      .history-item-phone {
        color: #ccc;
        font-size: 12px;
        margin-left: 65px; /* Align with name (time width + margin) */
      }
    `,document.head.appendChild(s)}let n=document.createElement("div");n.className="history-header";let r=document.createElement("div");r.className="history-title",r.textContent="Recent Patients",n.appendChild(r);let i=document.createElement("button");i.className="history-clear-btn",i.textContent="Clear All",i.addEventListener("click",s=>{s.stopPropagation(),ot(),pt(e),p("History cleared")}),n.appendChild(i),o.appendChild(n);let a=document.createElement("div");return a.className="history-empty",a.textContent="No patient history yet",o.appendChild(a),e.appendChild(t),e.appendChild(o),e}function pt(e){let t=e.querySelector("#crm-history-content");if(!t)return;let o=tt(),n=t.querySelector(".history-header");if(t.innerHTML="",n&&t.appendChild(n),o.length===0){let r=document.createElement("div");r.className="history-empty",r.textContent="No patient history yet",t.appendChild(r);return}o.forEach(r=>{let i=document.createElement("div");i.className="history-item",i.addEventListener("click",()=>{window.location.href=r.url,e.classList.remove("show")});let a=document.createElement("div");a.className="history-item-row";let s=document.createElement("div");s.className="history-item-time",s.textContent=nt(r.timestamp);let l=document.createElement("div");if(l.className="history-item-name",l.textContent=r.patientName||"Unknown Patient",a.appendChild(s),a.appendChild(l),i.appendChild(a),r.phoneNumber){let d=document.createElement("div");d.className="history-item-phone",d.textContent=r.phoneNumber,i.appendChild(d)}t.appendChild(i)})}var zt=!1;function Ne(){try{if(document.getElementById("mcp-crm-header")){console.log("[uiHeaderBar] Toolbar already exists.");return}dt();let e=document.createElement("div");e.id="mcp-crm-header";let t=localStorage.getItem("crmplus_headerBarVisible")!=="false";console.log("[CRM Extension] Header visibility setting:",t),e.style.display=t?"flex":"none";let o=typeof browser<"u"?browser:chrome,n=y=>o.runtime.getURL(y),r=document.createElement("div");r.className="group";let i=document.createElement("a");i.href="https://app.mtncarerx.com/",i.className="logo-link";let a=document.createElement("img");a.src=n("assets/mcp-favicon.ico"),a.alt="",a.className="logo-icon",i.appendChild(a);let s=document.createElement("span");s.className="logo",s.textContent="CRM+",i.appendChild(s),r.appendChild(i);let l=document.createElement("div");l.className="group external-links";let d=Se("ShipStation","https://ship15.shipstation.com/onboard","shipstation-link",n("assets/shipstation-favicon.ico"));l.appendChild(d);let g=Se("Stripe","https://dashboard.stripe.com/login","stripe-link",n("assets/stripe-favicon.ico"));l.appendChild(g);let m=Se("Webmail","https://p3plzcpnl506102.prod.phx3.secureserver.net:2096/cpsess5640910985/webmail/jupiter/index.html?login=1&post_login=89371011642013","webmail-link",n("assets/webmail-favicon.ico"));l.appendChild(m);let h=X("name","Name"),f=X("phone","Phone",{icon:"\u{1F4DE}",initialValue:"",onClick:async y=>{De(y)}}),v=X("dob","DOB"),k=X("srxid","SRx ID"),R=rt(),M=lt(),u=document.createElement("div");u.className="spacer";let E=document.createElement("div");E.className="group right-buttons",E.style.borderRight="none",E.style.display="flex",E.style.marginRight="0";let S=document.createElement("button");S.className="chat-button btn",S.title="Mountain Care Chat",S.style.marginRight="8px";let C=document.createElement("div");C.style.display="flex",C.style.alignItems="center",C.style.justifyContent="center";let T=document.createElement("span");T.className="icon",T.innerHTML="\u{1F4AC}",T.style.marginRight="4px";let V=document.createElement("span");V.textContent="Chat";let D=document.createElement("span");D.className="badge",Object.assign(D.style,{position:"absolute",top:"0",right:"0",backgroundColor:"#f44336",color:"white",fontSize:"12px",fontWeight:"bold",padding:"2px 6px",borderRadius:"50%",display:"none"}),C.appendChild(T),C.appendChild(V),S.appendChild(C),S.appendChild(D),S.addEventListener("click",function(){if(console.log("[CRM Extension] Chat button clicked"),typeof window.toggleChatUI=="function")window.toggleChatUI();else{console.error("[CRM Extension] toggleChatUI function not available");let y=document.getElementById("hipaa-chat-container");if(y)y.style.display=y.style.display==="none"?"flex":"none",console.log("[CRM Extension] Toggled chat container visibility as fallback");else{console.error("[CRM Extension] Chat container not found");try{typeof initChat=="function"&&initChat().then(()=>{typeof window.toggleChatUI=="function"&&window.toggleChatUI()})}catch(I){console.error("[CRM Extension] Failed to initialize chat:",I)}}}});let F=mt();E.appendChild(S),E.appendChild(F);let U=ct();e.appendChild(r),e.appendChild(l),e.appendChild(h),e.appendChild(f),e.appendChild(v),e.appendChild(k),e.appendChild(M),e.appendChild(R),e.appendChild(u),e.appendChild(E),e.appendChild(U),document.body.appendChild(e),document.body.style.paddingTop=t?"32px":"0",setTimeout(()=>{try{let y=localStorage.getItem("crmplus_automationEnabled")==="true";[document.getElementById("crm-automation-dropdown"),document.getElementById("crm-tags-dropdown")].forEach($=>{$&&($.style.display=y?"flex":"none",console.log(`[CRM Extension] Initial visibility for ${$.id}: ${y?"visible":"hidden"}`))})}catch(y){console.error("[CRM Extension] Error setting initial automation visibility:",y)}},100),A(),qe(),_e(),Be(),He(),Qe(),initChat(),initChatMonitoring(),onNewMessages(y=>{if(y.length>0){let I=y[0];p(`New message from ${I.sender}: ${I.text.substring(0,30)}${I.text.length>30?"...":""}`,3e3)}}),window.addEventListener("popstate",function(){console.log("[CRM Extension] Navigation detected, clearing phone display"),A()}),Bt()||A(),zt=!0,console.log("[CRM Extension] Header successfully initialized")}catch(e){console.error("[CRM Extension] Critical error creating toolbar:",e);try{let t=document.getElementById("mcp-crm-header");t&&(t.style.display="flex")}catch(t){console.error("[CRM Extension] Failed to recover toolbar:",t)}}}function Se(e,t,o="",n=""){let r=document.createElement("a");r.href=t,r.target="_blank",r.className=`text-link btn ${o}`,r.rel="noopener noreferrer";let i=document.createElement("div");if(i.style.display="flex",i.style.alignItems="center",i.style.justifyContent="center",i.style.width="100%",n){let s=document.createElement("img");s.src=n,s.alt="",s.className="link-icon",s.style.width="16px",s.style.height="16px",s.style.marginRight="4px",i.appendChild(s)}let a=document.createElement("span");return a.textContent=e,i.appendChild(a),r.appendChild(i),r}function Bt(){let e=window.location.href;return[/\/patient\/\d+/i,/\/contact\/\d+/i,/\/profile\/\d+/i,/[?&]patient_id=\d+/i,/[?&]contact_id=\d+/i].some(n=>n.test(e))?!0:['input[name="contact.phone"]','input[name="contact.first_name"]','input[name="contact.last_name"]','input[name="contact.date_of_birth"]',".patient-info",".contact-details",".patient-header",".patient-profile"].some(n=>document.querySelector(n)!==null)}function Re(e){try{let t=document.getElementById("mcp-crm-header");if(t){console.log(`[CRM Extension] Setting header visibility to: ${e}`),t.style.display=e?"flex":"none";let o=document.body.classList.contains("has-alert");return e?(document.body.style.paddingTop=o?"72px":"32px",document.body.classList.remove("no-header")):(document.body.style.paddingTop=o?"40px":"0",document.body.classList.add("no-header")),localStorage.setItem("crmplus_headerBarVisible",e.toString()),!0}else if(e)return console.log("[CRM Extension] Header not found but should be visible, creating it"),Ne(),!0;return!1}catch(t){return console.error("[CRM Extension] Error toggling header visibility:",t),!1}}function ut(){if(!(localStorage.getItem("crmplus_autoCopyPhone")==="true")){console.log("[CRM Extension] Auto-copy phone is disabled");return}let t=()=>{let n=se();if(n){let r=we(n);r&&W(r).then(i=>{if(i)return p("Phone number auto-copied: "+r),!0})}return!1};if(t())return;let o=new MutationObserver((n,r)=>{t()&&r.disconnect()});o.observe(document.body,{childList:!0,subtree:!0,attributes:!0,characterData:!0}),setTimeout(()=>{o.disconnect(),t()},5e3)}var gt=!1,K=new Set,fe="",Ie=!1,he=null,Me=null;function ht(){gt||(Dt(),$t(),gt=!0,console.log("[CRM Extension] Alert system initialized"))}function Dt(){if(document.getElementById("crm-alert-styles"))return;let e=document.createElement("style");e.id="crm-alert-styles",e.textContent=`
    .crm-alert-banner {
      position: fixed;
      top: 32px; /* Positioned right below the header bar */
      left: 0;
      right: 0;
      width: 100%;
      padding: 4px 15px; /* Reduced vertical padding for smaller height */
      font-size: 13px;
      font-weight: 500;
      z-index: 999990;
      display: flex;
      align-items: center;
      justify-content: center; /* Center contents horizontally */
      transition: all 0.3s ease;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
      transform: translateY(-100%);
      opacity: 0;
      height: 25px; /* Fixed height at 3/4 of original (approx) */
    }
    
    .crm-alert-banner.show {
      transform: translateY(0);
      opacity: 1;
    }
    
    .crm-alert-banner .alert-icon {
      margin-right: 8px;
      font-size: 16px;
    }
    
    .crm-alert-banner .alert-message {
      text-align: center; /* Center the text */
      margin: 0 auto; /* Center with auto margins */
      flex-grow: 0; /* Don't grow to fill space */
    }
    
    /* Provider Paid specific alert styling */
    .crm-alert-banner.provider-paid {
      background-color: #FFAB40; /* Orange */
      color: #5F4200;
      border-bottom: 1px solid #FF9100;
    }
    
    /* Adjust body padding to accommodate the alert banner */
    body.has-alert {
      padding-top: 72px !important; /* 32px (header) + approx alert height */
    }
    
    /* When header is hidden but alert is visible */
    body.no-header.has-alert {
      padding-top: 25px !important; /* Just the alert height */
    }
    
    /* Multiple alerts stacking */
    .crm-alert-banner.second-alert {
      top: 57px;
    }
    
    .crm-alert-banner.third-alert {
      top: 82px;
    }
    
    /* Countdown timer styling */
    .countdown-timer {
      margin-left: 5px;
      font-size: 11px;
      opacity: 0.75;
      background-color: rgba(0, 0, 0, 0.1);
      padding: 1px 4px;
      border-radius: 3px;
      min-width: 30px;
      text-align: center;
    }
  `,document.head.appendChild(e)}function ft(){let e=window.location.href,t=[/\/patient\/(\d+)/i,/\/contact\/(\d+)/i,/\/profile\/(\d+)/i,/[?&]patient_id=(\d+)/i,/[?&]contact_id=(\d+)/i];for(let o of t){let n=e.match(o);if(n&&n[1])return n[1]}return""}function $t(){fe=ft(),be(),he&&he.disconnect(),he=new MutationObserver(e=>{for(let t of e)t.type==="childList"&&be(),t.type==="attributes"&&(t.target.classList.contains("tag")||t.target.classList.contains("tag-label")||t.target.classList.contains("provider-paid"))&&be()}),he.observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["class","data-tag"]}),Me&&clearInterval(Me),Me=setInterval(()=>{let e=ft();e!==fe&&(console.log("[CRM Extension] Navigation detected, patient changed from",fe,"to",e),fe=e,Ie=!1,xe("provider-paid"),setTimeout(be,1e3))},1e3)}function be(){if(!(localStorage.getItem("crmplus_showProviderPaidAlerts")!=="false")){xe("provider-paid");return}qt()?Ie||Vt():xe("provider-paid")}function qt(){let e=document.querySelectorAll(".tag, .tag-label, .pill, .badge");for(let r of e)if(r.textContent.toLowerCase().includes("provider-paid"))return r;let t=document.querySelectorAll(".provider-paid");if(t.length>0)return t[0];let o=document.querySelectorAll('[data-tag="provider-paid"], [data-tag-name="provider-paid"]');if(o.length>0)return o[0];let n=document.querySelectorAll(".tags-container, .tag-list, .tags");for(let r of n)if(r.textContent.toLowerCase().includes("provider-paid"))return r;return null}function Vt(){if(K.has("provider-paid"))return;Ie=!0;let e=document.createElement("div");e.className="crm-alert-banner provider-paid",e.id="provider-paid-alert",e.setAttribute("data-alert-type","provider-paid");let t=document.createElement("span");t.className="alert-icon",t.innerHTML="\u26A0\uFE0F",e.appendChild(t);let o=document.createElement("span");o.className="alert-message",o.textContent="This patient has Provider Paid status. Special billing rules apply.";let n=document.createElement("span");n.className="countdown-timer",n.textContent="30",o.appendChild(n),e.appendChild(o),document.body.appendChild(e),Ot(e),setTimeout(()=>{e.classList.add("show"),document.body.classList.add("has-alert")},10),K.add("provider-paid");let r=document.getElementById("mcp-crm-header");r&&r.style.display==="none"?document.body.classList.add("no-header"):document.body.classList.remove("no-header"),console.log("[CRM Extension] Provider Paid alert shown");let i=15,a=setInterval(()=>{i--,n&&(n.textContent=i),i<=0&&(clearInterval(a),xe("provider-paid"))},1e3)}function Ot(e){let t=K.size;t===1?e.classList.add("second-alert"):t===2&&e.classList.add("third-alert")}function xe(e){let t=document.querySelector(`.crm-alert-banner[data-alert-type="${e}"]`);t&&(t.classList.remove("show"),K.delete(e),setTimeout(()=>{t.parentNode&&t.parentNode.removeChild(t),K.size===0&&document.body.classList.remove("has-alert"),_t()},300))}function _t(){document.querySelectorAll(".crm-alert-banner").forEach((t,o)=>{t.classList.remove("second-alert","third-alert"),o===1?t.classList.add("second-alert"):o===2&&t.classList.add("third-alert")})}console.log("[CRM Extension] Content script injected.");var Z=typeof browser<"u"?browser:chrome;Z.runtime.sendMessage({action:"loadSettings"}).then(e=>{e&&e.success&&(console.log("[CRM Extension] Settings loaded from browser storage on startup:",e.settings),document.getElementById("mcp-crm-header")||_())}).catch(e=>{console.error("[CRM Extension] Error requesting settings on startup:",e)});localStorage.getItem("crmplus_headerBarVisible")===null?(console.log("[CRM Extension] No local toolbar visibility setting, requesting from browser storage"),Z.runtime.sendMessage({action:"loadSettings"}).then(e=>{e&&e.success?(console.log("[CRM Extension] Settings loaded from browser storage:",e.settings),_()):(console.error("[CRM Extension] Failed to load settings, using defaults"),localStorage.setItem("crmplus_headerBarVisible","true"),_())}).catch(e=>{console.error("[CRM Extension] Error requesting settings:",e),localStorage.setItem("crmplus_headerBarVisible","true"),_()})):(console.log("[CRM Extension] Using existing localStorage settings"),_());function _(){let e=localStorage.getItem("crmplus_headerBarVisible")!=="false";console.log("[CRM Extension] Header visibility setting on init:",e);try{console.log("[CRM Extension] Creating fixed header..."),Ne(),Re(e)}catch(t){console.error("[CRM Extension] Error creating fixed header:",t)}try{Le(t=>{console.log(`[CRM Extension] Intercepted console message: ${t}`)})}catch(t){console.error("[CRM Extension] Error initializing console monitor:",t)}try{ut()}catch(t){console.error("[CRM Extension] Error initializing auto phone copy:",t)}try{ht()}catch(t){console.error("[CRM Extension] Error initializing alert system:",t)}try{je()}catch(t){console.error("[CRM Extension] Error initializing tag removal system:",t)}try{Ye()}catch(t){console.error("[CRM Extension] Error initializing automation removal system:",t)}A();try{initChat().then(()=>{console.log("[CRM Extension] Chat system initialized successfully"),setTimeout(()=>{typeof initChatUI=="function"?(initChatUI(),console.log("[CRM Extension] Explicitly initialized Chat UI")):console.error("[CRM Extension] initChatUI function not found")},500)})}catch(t){console.error("[CRM Extension] Error initializing chat system:",t)}}document.addEventListener("click",function(e){if(e.target.closest(".chat-button")&&(console.log("[CRM Extension] Chat button clicked (global event listener)"),console.log("window.toggleChatUI exists:",typeof window.toggleChatUI=="function"),console.log("Chat container exists:",!!document.getElementById("hipaa-chat-container")),!document.getElementById("hipaa-chat-container"))){console.log("[CRM Extension] Chat container not found, initializing chat UI...");try{typeof initChatUI=="function"&&(initChatUI(),setTimeout(()=>{if(typeof window.toggleChatUI=="function")window.toggleChatUI();else{let o=document.getElementById("hipaa-chat-container");o&&(o.style.display=o.style.display==="none"?"flex":"none")}},100))}catch(o){console.error("[CRM Extension] Error initializing chat UI:",o)}}});Z.runtime.onMessage.addListener((e,t,o)=>{if(console.log("[CRM Extension] Received message:",e),e.action==="toggleHeaderVisibility"){console.log("[CRM Extension] Toggling header visibility to:",e.isVisible);try{let n=Re(e.isVisible);localStorage.setItem("crmplus_headerBarVisible",e.isVisible.toString()),Z.runtime.sendMessage({action:"syncSettings"}).catch(r=>console.error("[CRM Extension] Error syncing settings:",r)),o({success:n})}catch(n){console.error("[CRM Extension] Error toggling header visibility:",n),o({success:!1,error:n.message})}return!0}if(e.action==="initializeChat"){try{initChat().then(()=>{typeof initChatUI=="function"?(initChatUI(),o({success:!0})):o({success:!1,error:"initChatUI function not found"})})}catch(n){console.error("[CRM Extension] Error initializing chat:",n),o({success:!1,error:n.message})}return!0}return!1});document.addEventListener("DOMContentLoaded",()=>{if(console.log("[CRM Extension] DOM fully loaded, checking visibility setting"),document.getElementById("mcp-crm-header")||Z.runtime.sendMessage({action:"loadSettings"}).then(e=>{e&&e.success&&_()}).catch(()=>{localStorage.setItem("crmplus_headerBarVisible","true"),_()}),!document.getElementById("hipaa-chat-container"))try{initChat().then(()=>{typeof initChatUI=="function"&&initChatUI()})}catch(e){console.error("[CRM Extension] Error initializing chat on DOMContentLoaded:",e)}});try{window.addEventListener("load",()=>{console.log("[CRM Extension] Window loaded, initializing chat..."),initChat().then(()=>{typeof initChatUI=="function"&&initChatUI()})})}catch(e){console.error("[CRM Extension] Critical error initializing chat on window.load:",e)}})();
